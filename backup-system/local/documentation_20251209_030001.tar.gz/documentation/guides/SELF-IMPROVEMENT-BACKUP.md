# 🧠💾 Modules Self-Improvement & Backup

> **Date** : 6 décembre 2025
> **Statut** : ✅ Opérationnels

---

## 🧠 Self-Improvement Analyzer

### Description
Module d'auto-amélioration qui analyse les métriques système et génère des recommandations via LLM local.

### Emplacement
```
/home/lalpha/projets/ai-tools/self-improvement/
├── analyzer.py      # Script principal
├── setup.sh         # Installation
├── README.md        # Documentation
└── reports/         # Rapports JSON
```

### Utilisation
```bash
# Analyse complète
python3 analyzer.py

# Analyse rapide (sans Loki)
python3 analyzer.py --quick
```

### Automatisation
- **Cron** : Tous les jours à 6h00
- **Logs** : `cron.log`

### Métriques collectées
- CPU, RAM, Disque (système + Ollama)
- GPU (utilisation + mémoire)
- Conteneurs Docker
- Logs d'erreurs (Loki)

### Sortie
- Score de santé (0-100)
- Status (healthy/warning/critical)
- Liste des problèmes avec recommandations
- Optimisations suggérées

---

## 💾 Backup System v2.0 (Cloudflare R2)

### Description
Système de sauvegarde automatique vers Cloudflare R2 (S3-compatible).

### Emplacement
```
/home/lalpha/projets/ai-tools/backup-system/
├── backup.py        # Script principal v2.0
├── .env             # Credentials R2 (chmod 600)
├── README.md        # Documentation
└── local/           # Backups locaux temporaires
```

### Configuration
Le fichier `.env` contient les credentials Cloudflare R2 :
```
S3_ENDPOINT=https://xxx.r2.cloudflarestorage.com
S3_ACCESS_KEY=xxx
S3_SECRET_KEY=xxx
S3_BUCKET=ai4lb-backups
```

### Éléments sauvegardés
| Élément | Type | Contenu |
|---------|------|---------|
| docker-compose | Directory | Stack Docker principale |
| ai-orchestrator | Directory | Agent IA v2.0 |
| mcp-servers | Directory | 33 outils MCP |
| documentation | Directory | Documentation |
| scripts | Directory | Scripts système |
| postgres | Database | PostgreSQL dump |
| self-improvement-reports | Directory | Rapports IA |

### Utilisation
```bash
# Backup complet avec upload R2 + nettoyage local
python3 backup.py --cleanup

# Backup local seulement (sans upload)
python3 backup.py --no-upload

# Lister les backups sur R2
python3 backup.py --list
```

### Automatisation
- **Cron** : Tous les jours à 3h00
- **Logs** : `cron.log`
- **Upload** : Automatique vers Cloudflare R2
- **Nettoyage** : Backups locaux >7 jours supprimés

### Organisation sur R2
```
ai4lb-backups/
├── 2025/
│   ├── 12/
│   │   ├── docker-compose_20251206_152918.tar.gz
│   │   ├── ai-orchestrator_20251206_152918.tar.gz
│   │   ├── mcp-servers_20251206_152918.tar.gz
│   │   └── ...
│   └── ...
└── ...
```

### Cloudflare R2 Dashboard
- **Bucket** : ai4lb-backups
- **Région** : Eastern North America (ENAM)
- **URL** : https://dash.cloudflare.com → R2 Object Storage

---

## ⏰ Crons Actifs

| Heure | Module | Description |
|-------|--------|-------------|
| 3h00 | Backup v2.0 | Sauvegarde → R2 + nettoyage local |
| 6h00 | Self-Improvement | Analyse système + recommandations |

---

## 📊 Workflow Quotidien

```
03:00  💾 Backup System v2.0
        → Sauvegarde configs, code, DB
        → Upload vers Cloudflare R2
        → Nettoyage backups locaux >7 jours

06:00  🧠 Self-Improvement
        → Collecte métriques Prometheus
        → Analyse conteneurs Docker
        → Génération recommandations LLM
        → Rapport JSON
```

---

## 🔐 Sécurité

- Credentials R2 dans `.env` avec permissions 600
- API Token R2 limité au bucket `ai4lb-backups`
- Backups chiffrés en transit (HTTPS)
- Pas d'accès public au bucket

---

## 💰 Coûts R2 (estimés)

| Ressource | Usage mensuel | Coût |
|-----------|---------------|------|
| Stockage | ~70 MB/mois | **Gratuit** (< 10 GB) |
| Requêtes PUT | ~210/mois | **Gratuit** (< 1M) |
| Egress | N/A | **Toujours gratuit** |

---

*Documentation mise à jour le 6 décembre 2025*
