# 🏗️ Architecture Infrastructure IA - lalpha-server-1

> **Dernière mise à jour** : 7 décembre 2025
> **Serveur** : Ubuntu 25.10 (Oracular)
> **Domaine** : 4lb.ca

---

## 📊 Vue d'ensemble

```
                              Internet
                                  │
                                  ▼
                    ┌─────────────────────────┐
                    │   Cloudflare CDN/WAF    │
                    └─────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Traefik (Reverse Proxy)                       │
│                    Ports: 80, 443, 8080                          │
│                    SSL: Let's Encrypt                            │
│                    Réseau: unified-net                           │
└──────────────────────────────────────────────────────────────────┘
          │              │              │              │
          ▼              ▼              ▼              ▼
    ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
    │   AI     │  │  Open    │  │ Grafana  │  │   JSR    │
    │Orchestr. │  │  WebUI   │  │Prometheus│  │  Sites   │
    │ai.4lb.ca │  │llm.4lb.ca│  │ .4lb.ca  │  │jsr.4lb.ca│
    └──────────┘  └──────────┘  └──────────┘  └──────────┘
          │
          ▼
    ┌──────────────────────────────────────┐
    │           Ollama (LLM)               │
    │         Port: 11434 (host)           │
    │      GPU: RTX 5070 Ti (16GB)         │
    └──────────────────────────────────────┘
```

---

## 🎯 UNIFIED STACK - Architecture Simplifiée

### Principe Fondamental
**UN docker-compose.yml → UN réseau → TOUS les services**

```
📁 /home/lalpha/projets/infrastructure/unified-stack/
├── docker-compose.yml    # Source unique de vérité
├── .env                  # Variables d'environnement
├── stack.sh              # Script de gestion
└── configs/
    ├── prometheus/
    │   └── prometheus.yml
    └── traefik/
        └── dynamic/
```

### Commandes de Gestion

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

./stack.sh up              # Démarrer tous les services
./stack.sh down            # Arrêter tout
./stack.sh status          # État des conteneurs
./stack.sh restart <svc>   # Redémarrer un service
./stack.sh update <svc>    # Mettre à jour (pull + rebuild)
./stack.sh logs <svc>      # Voir les logs
./stack.sh test            # Tester tous les endpoints
```

---

## 🖥️ Spécifications Serveur

| Composant | Spécification |
|-----------|---------------|
| **CPU** | AMD Ryzen 9 7900X (12 cores, 24 threads) @ 5.74 GHz |
| **GPU** | NVIDIA GeForce RTX 5070 Ti - 16 GB VRAM |
| **RAM** | 64 GB DDR5 |
| **Stockage Système** | NVMe Kingston 1.8 TB (nvme1n1) |
| **Stockage Ollama** | NVMe ORICO 953.9 GB (nvme0n1) avec dissipateur |
| **OS** | Ubuntu 25.10 (Oracular) |
| **Kernel** | 6.17.0+ |
| **IP Locale** | 10.10.10.46 (VLAN 2 - Home) |

---

## 🐳 Services Docker (Unified Stack)

### Conteneurs Actifs (14 services)

| Conteneur | Image | Rôle | URL |
|-----------|-------|------|-----|
| **traefik** | traefik:v3.0 | Reverse proxy, SSL | traefik.4lb.ca |
| **postgres** | postgres:16-alpine | Base données | localhost:5432 |
| **redis** | redis:7-alpine | Cache | localhost:6379 |
| **open-webui** | ghcr.io/open-webui/open-webui:main | Chat LLM | llm.4lb.ca |
| **ai-orchestrator-backend** | custom build | API Agent IA | ai.4lb.ca/api |
| **ai-orchestrator-frontend** | nginx:alpine | Interface Agent | ai.4lb.ca |
| **chromadb** | chromadb/chroma:latest | Base vectorielle | localhost:8000 |
| **jsr-dev** | custom build | Site JSR dev | jsr.4lb.ca |
| **jsr-solutions** | custom build | Site JSR prod | jsr-solutions.ca |
| **prometheus** | prom/prometheus:latest | Métriques | prometheus.4lb.ca |
| **grafana** | grafana/grafana:latest | Dashboards | grafana.4lb.ca |
| **node-exporter** | prom/node-exporter:latest | Métriques système | - |
| **cadvisor** | gcr.io/cadvisor/cadvisor:latest | Métriques Docker | - |
| **code-server** | lscr.io/linuxserver/code-server:latest | IDE Web | code.4lb.ca |

### Réseau Docker

```
unified-net (bridge) - 192.168.200.0/24
└── Tous les 14 conteneurs sur le même réseau
```

---

## 🌐 URLs et Accès

### URLs Publiques (HTTPS)

| Service | URL | Description |
|---------|-----|-------------|
| AI Orchestrator | https://ai.4lb.ca | Agent IA autonome v2.1 |
| Open WebUI | https://llm.4lb.ca | Chat LLM rapide |
| Grafana | https://grafana.4lb.ca | Dashboards monitoring |
| Prometheus | https://prometheus.4lb.ca | Métriques |
| Code Server | https://code.4lb.ca | IDE VS Code web |
| JSR Dev | https://jsr.4lb.ca | Site client dev |
| JSR Prod | https://jsr-solutions.ca | Site client production |
| Traefik | https://traefik.4lb.ca | Dashboard reverse proxy |

### Services Locaux (Host)

| Service | URL | Port |
|---------|-----|------|
| Ollama | http://localhost:11434 | 11434 |
| ChromaDB | http://localhost:8000 | 8000 |
| PostgreSQL | localhost | 5432 |
| Redis | localhost | 6379 |

---

## 🤖 Stack LLM

### Ollama (Service Système)

**Port** : 11434
**GPU** : RTX 5070 Ti (16 GB VRAM)
**Stockage** : `/mnt/ollama-models` (disque ORICO avec dissipateur)

#### Modèles Installés

| Modèle | Taille | Usage |
|--------|--------|-------|
| qwen2.5-coder:32b | 19 GB | Code (principal) |
| deepseek-coder:33b | 18 GB | Code (alternatif) |
| qwen3-vl:32b | 20 GB | Vision multimodale |
| llama3.2-vision:11b | 12 GB | Vision + texte |
| nomic-embed-text | 274 MB | Embeddings RAG |

**Total** : ~70 GB / 938 GB disponibles

#### Commandes Utiles

```bash
# Lister les modèles
ollama list

# Tester un modèle
ollama run qwen2.5-coder:32b

# API
curl http://localhost:11434/api/tags

# Vérifier l'espace disque Ollama
df -h /mnt/ollama-models
```

---

## 🤖 AI Orchestrator v2.1

**URL** : https://ai.4lb.ca
**Version** : 2.1.0
**Lignes de code** : 626

### Fonctionnalités

- 🤖 **Sélection AUTO** des modèles LLM
- 📎 **Upload fichiers** (images, code, logs)
- 👁️ **Analyse d'images** via vision models
- 🔄 **Boucle ReAct** autonome
- 📊 **Activity Log** temps réel
- 💬 **Historique** des conversations

### Outils Disponibles (31 outils)

| Catégorie | Outils |
|-----------|--------|
| **Files** | read_file, write_file, list_directory, search_files |
| **Docker** | docker_status, docker_logs, docker_restart |
| **System** | execute_command, system_info, disk_usage |
| **Logs** | analyze_logs, get_service_logs |
| **Network** | udm_status, udm_network_info, network_scan |
| **Security** | check_permissions, audit_system |
| **Services** | service_status, service_control |

---

## 🔌 Serveurs MCP (Model Context Protocol)

### Architecture MCP

```
┌─────────────────────────────────────────────────────────────┐
│              Claude Desktop + Continue.dev                   │
│   Claude: ~/.config/Claude/claude_desktop_config.json       │
│   Continue: ~/.continue/mcp.json                            │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────┬───────┴───────┬─────────────┐
        ▼             ▼               ▼             ▼
┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ ubuntu-mcp  │ │ udm-pro-mcp │ │ filesystem  │ │  chromadb   │
│   v2.0.0    │ │   v2.0.0    │ │   v2.0.0    │ │   v2.0.0    │
│ (12 outils) │ │ (8 outils)  │ │ (4 outils)  │ │ (9 outils)  │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
```

**Total : 33 outils MCP disponibles**

---

## 📊 Monitoring

### Prometheus Targets

| Target | Status | Description |
|--------|--------|-------------|
| prometheus | ✅ UP | Auto-monitoring |
| node-exporter | ✅ UP | Métriques système |
| cadvisor | ✅ UP | Métriques Docker |
| traefik | ✅ UP | Métriques HTTP |
| ollama | ⚠️ Config | LLM metrics |
| nvidia-gpu | ⚠️ À ajouter | GPU metrics |

### Grafana Dashboards

- System Overview (CPU, RAM, Disque)
- Docker Containers
- Self-Improvement (à importer)

---

## 📁 Structure des Dossiers

```
/home/lalpha/
├── projets/
│   ├── ai-tools/
│   │   ├── ai-orchestrator/      # Agent IA v2.1
│   │   ├── self-improvement/     # Module auto-amélioration
│   │   └── mcp-servers/          # 4 serveurs MCP
│   │       ├── ubuntu-mcp/
│   │       ├── udm-pro-mcp/
│   │       ├── filesystem-mcp/
│   │       └── chromadb-mcp/
│   │
│   ├── clients/
│   │   └── jsr/
│   │       ├── JSR/              # Site dev
│   │       └── JSR-solutions/    # Site prod
│   │
│   └── infrastructure/
│       ├── unified-stack/        # ⭐ STACK PRINCIPALE
│       │   ├── docker-compose.yml
│       │   ├── .env
│       │   ├── stack.sh
│       │   └── configs/
│       │
│       └── 4lb-docker-stack/     # 📦 Archive (ancienne stack)
│
├── scripts/
│   ├── docker/
│   └── backup/
│
└── documentation/
    ├── ARCHITECTURE.md           # Ce fichier
    ├── INDEX.md
    └── guides/
```

---

## 🔐 Sécurité

### Firewall (UFW)

```bash
# Vérifier statut
sudo ufw status verbose

# Règles principales
80/tcp    ALLOW    # HTTP
443/tcp   ALLOW    # HTTPS
22/tcp    ALLOW    10.10.10.0/25  # SSH local uniquement
```

### Docker

- Réseau isolé (unified-net)
- Pas de ports exposés inutilement
- Healthchecks sur services critiques

---

## 🚀 Commandes Utiles

### Unified Stack

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

./stack.sh up              # Démarrer
./stack.sh status          # État
./stack.sh logs traefik    # Logs
./stack.sh restart grafana # Redémarrer
./stack.sh test            # Tester URLs
```

### Ollama

```bash
ollama list                     # Modèles installés
ollama run qwen2.5-coder:32b    # Lancer modèle
systemctl status ollama         # Status service
```

### Monitoring

```bash
htop                            # Ressources CPU/RAM
nvidia-smi                      # GPU
docker stats                    # Conteneurs
```

---

## 🔗 Références

- [Guide AI Orchestrator](guides/AI-ORCHESTRATOR.md)
- [Guide MCP Server UDM-Pro](guides/MCP-SERVER-UDM-PRO.md)
- [Procédures IA Sécurisées](PROCEDURES-IA-SECURISEES.md)

---

*Documentation mise à jour le 7 décembre 2025*
