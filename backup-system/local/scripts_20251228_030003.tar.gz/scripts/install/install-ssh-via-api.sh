#!/bin/bash

echo "🔐 Tentative d'ajout de clé SSH via l'API UniFi"
echo "================================================"
echo ""

# Lire la clé publique
SSH_KEY=$(cat ~/.ssh/id_rsa_udm.pub)

echo "📋 Clé SSH à ajouter :"
echo "$SSH_KEY"
echo ""

# Demander la clé API
echo "🔑 Entrez votre clé API UniFi (celle que vous avez créée: Udm-pro)"
read -r API_KEY

if [ -z "$API_KEY" ]; then
    echo "❌ Clé API vide"
    exit 1
fi

echo ""
echo "📤 Tentative d'ajout via l'API..."

# Essayer différentes méthodes API
# Méthode 1: Via l'API system
curl -k -s -X POST \
    "https://10.10.10.1/proxy/network/api/s/default/cmd/system" \
    -H "X-API-KEY: ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{\"cmd\":\"set-locate\",\"mac\":\"root\"}" 2>&1

# Méthode 2: Via SSH config endpoint  
RESPONSE=$(curl -k -s -X PUT \
    "https://10.10.10.1/api/system/ssh" \
    -H "X-API-KEY: ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{\"authorized_keys\":[\"${SSH_KEY}\"]}" 2>&1)

echo "Réponse: $RESPONSE"

echo ""
echo "⚠️  L'API peut ne pas supporter cette fonctionnalité."
echo "   Il est recommandé d'utiliser l'accès console physique."
