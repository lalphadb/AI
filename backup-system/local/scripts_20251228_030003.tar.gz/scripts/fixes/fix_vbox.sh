#!/bin/bash

echo "=== Fixing VirtualBox kernel modules ==="

# Load the VirtualBox kernel modules
echo "Loading VirtualBox modules..."
modprobe vboxdrv
modprobe vboxnetflt
modprobe vboxnetadp
modprobe vboxpci

# Check if modules are loaded
echo ""
echo "Checking loaded modules:"
lsmod | grep vbox

# Verify VirtualBox status
echo ""
echo "VirtualBox version:"
vboxmanage --version

# Check /dev/vboxdrv
echo ""
echo "Checking /dev/vboxdrv:"
ls -la /dev/vboxdrv

echo ""
echo "=== Fix complete! ==="
