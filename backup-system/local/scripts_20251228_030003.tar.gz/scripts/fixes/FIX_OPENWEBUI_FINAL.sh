#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║     CONFIGURATION FINALE OPEN WEBUI                          ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

docker stop open-webui
docker rm open-webui

# Essayer avec l'IP de la gateway du réseau traefik-net
GATEWAY=$(docker network inspect traefik-net | grep Gateway | awk '{print $2}' | tr -d '",')
echo "Gateway trouvée: $GATEWAY"

docker run -d \
  --name open-webui \
  --network traefik-net \
  --add-host=host.docker.internal:host-gateway \
  -e ENABLE_OLLAMA_API=true \
  -e OLLAMA_BASE_URL=http://host.docker.internal:11434 \
  -v traefik-config_open-webui:/app/backend/data \
  --label "traefik.enable=true" \
  --label "traefik.http.routers.open-webui.rule=Host(\`llama.lalpha.ca\`)" \
  --label "traefik.http.routers.open-webui.entrypoints=websecure" \
  --label "traefik.http.routers.open-webui.tls.certresolver=myresolver" \
  --label "traefik.http.services.open-webui.loadbalancer.server.port=8080" \
  --restart unless-stopped \
  ghcr.io/open-webui/open-webui:main

echo ""
echo "✅ Open WebUI démarré avec host.docker.internal"
echo "   Ollama URL: http://host.docker.internal:11434"
echo ""
echo "Attente de 20 secondes..."
sleep 20
echo "✅ Prêt! Essayez d'accéder à https://llama.lalpha.ca"
