#!/bin/bash
# Script de vérification de sécurité
# Version: 1.0

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   RAPPORT DE SÉCURITÉ - Ubuntu Server     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"
echo ""

# 1. Système
echo -e "${YELLOW}[1] SYSTÈME${NC}"
echo "├─ Hostname: $(hostname)"
echo "├─ Uptime: $(uptime -p)"
echo "├─ Kernel: $(uname -r)"
echo "└─ Updates disponibles: $(apt list --upgradable 2>/dev/null | grep -c upgradable)"
echo ""

# 2. Firewall UFW
echo -e "${YELLOW}[2] FIREWALL (UFW)${NC}"
if sudo ufw status | grep -q "Status: active"; then
    echo -e "├─ Status: ${GREEN}✓ ACTIF${NC}"
    echo "├─ Politique par défaut:"
    sudo ufw status verbose | grep "Default:" | sed 's/^/│  /'
    echo "└─ Règles actives: $(sudo ufw status numbered | grep -c '\[')"
else
    echo -e "├─ Status: ${RED}✗ INACTIF${NC}"
    echo -e "└─ ${RED}ACTION REQUISE: Activer UFW${NC}"
fi
echo ""

# 3. Fail2Ban
echo -e "${YELLOW}[3] FAIL2BAN${NC}"
if systemctl is-active --quiet fail2ban; then
    echo -e "├─ Status: ${GREEN}✓ ACTIF${NC}"
    echo "├─ Jails actives:"
    sudo fail2ban-client status | grep "Jail list:" | sed 's/^.*://;s/,/\n│  ├─/g' | sed 's/^/│  ├─ /'
    echo "└─ IPs bannies actuellement:"
    for jail in $(sudo fail2ban-client status | grep "Jail list:" | sed 's/^.*://;s/,//g'); do
        banned=$(sudo fail2ban-client status $jail 2>/dev/null | grep "Currently banned:" | awk '{print $NF}')
        if [ "$banned" != "0" ]; then
            echo "   ├─ $jail: $banned IP(s)"
        fi
    done
else
    echo -e "├─ Status: ${RED}✗ INACTIF${NC}"
    echo -e "└─ ${RED}ACTION REQUISE: Installer/Activer Fail2Ban${NC}"
fi
echo ""

# 4. SSH
echo -e "${YELLOW}[4] SSH${NC}"
if systemctl is-active --quiet ssh; then
    echo -e "├─ Status: ${GREEN}✓ ACTIF${NC}"
    echo "├─ Port: $(sudo ss -tlnp | grep sshd | awk '{print $4}' | cut -d: -f2 | head -1)"
    echo "├─ PermitRootLogin: $(sudo grep "^PermitRootLogin" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/* 2>/dev/null | tail -1 | awk '{print $NF}')"
    echo "├─ PasswordAuth: $(sudo grep "^PasswordAuthentication" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/* 2>/dev/null | tail -1 | awk '{print $NF}')"
    echo "└─ Connexions actives: $(who | wc -l)"
else
    echo -e "└─ Status: ${RED}✗ INACTIF${NC}"
fi
echo ""

# 5. Ports ouverts
echo -e "${YELLOW}[5] PORTS OUVERTS${NC}"
echo "├─ Services écoutant sur toutes les interfaces (0.0.0.0):"
sudo ss -tlnp | grep "0.0.0.0" | awk '{print $4}' | cut -d: -f2 | sort -n | uniq | while read port; do
    service=$(sudo ss -tlnp | grep ":$port " | grep -oP 'users:\(\(".*?"' | cut -d'"' -f2 | head -1)
    if [ "$port" = "22" ] || [ "$port" = "3389" ]; then
        echo -e "│  ├─ ${RED}Port $port ($service) - CRITIQUE${NC}"
    elif [ "$port" = "25" ] || [ "$port" = "465" ] || [ "$port" = "587" ] || [ "$port" = "993" ]; then
        echo -e "│  ├─ ${YELLOW}Port $port ($service) - ATTENTION${NC}"
    else
        echo "│  ├─ Port $port ($service)"
    fi
done
echo "└─ Total: $(sudo ss -tlnp | grep "0.0.0.0" | wc -l) services"
echo ""

# 6. Docker
echo -e "${YELLOW}[6] DOCKER${NC}"
if systemctl is-active --quiet docker; then
    echo -e "├─ Status: ${GREEN}✓ ACTIF${NC}"
    echo "├─ Conteneurs running: $(docker ps --format '{{.Names}}' 2>/dev/null | wc -l)"
    echo "└─ Images: $(docker images -q 2>/dev/null | wc -l)"
else
    echo -e "└─ Status: ${RED}✗ INACTIF${NC}"
fi
echo ""

# 7. Mises à jour automatiques
echo -e "${YELLOW}[7] MISES À JOUR AUTO${NC}"
if [ -f "/etc/apt/apt.conf.d/50unattended-upgrades" ]; then
    echo -e "├─ Status: ${GREEN}✓ CONFIGURÉ${NC}"
    echo "└─ Config: /etc/apt/apt.conf.d/50unattended-upgrades"
else
    echo -e "├─ Status: ${RED}✗ NON CONFIGURÉ${NC}"
    echo -e "└─ ${RED}ACTION REQUISE: Configurer unattended-upgrades${NC}"
fi
echo ""

# 8. Dernières connexions
echo -e "${YELLOW}[8] DERNIÈRES CONNEXIONS${NC}"
echo "├─ Connexions SSH récentes:"
last -n 5 -w | head -5 | sed 's/^/│  /'
echo "└─ Tentatives échouées:"
sudo grep "Failed password" /var/log/auth.log 2>/dev/null | tail -3 | sed 's/^/   /' || echo "   Aucune"
echo ""

# 9. Utilisateurs
echo -e "${YELLOW}[9] UTILISATEURS${NC}"
echo "├─ Comptes avec shell:"
grep -v "nologin\|false" /etc/passwd | grep -v "^#" | cut -d: -f1 | sed 's/^/│  ├─ /'
echo "└─ Utilisateurs connectés: $(who | wc -l)"
echo ""

# 10. Espace disque
echo -e "${YELLOW}[10] DISQUE${NC}"
df -h / | tail -1 | awk '{print "├─ Utilisé: "$3" / "$2" ("$5")"}'
df -h / | tail -1 | awk '{print "└─ Disponible: "$4}'
echo ""

# 11. Charge système
echo -e "${YELLOW}[11] CHARGE SYSTÈME${NC}"
echo "├─ Load Average: $(uptime | awk -F'load average:' '{print $2}')"
echo "├─ CPU Usage: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)%"
echo "└─ RAM Usage: $(free | grep Mem | awk '{printf "%.1f%%", $3/$2 * 100.0}')"
echo ""

# RÉSUMÉ
echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            RÉSUMÉ ET ACTIONS               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"

ISSUES=0

# Vérifier UFW
if ! sudo ufw status | grep -q "Status: active"; then
    echo -e "${RED}❌ Activer le firewall UFW${NC}"
    ((ISSUES++))
fi

# Vérifier Fail2Ban
if ! systemctl is-active --quiet fail2ban; then
    echo -e "${RED}❌ Activer Fail2Ban${NC}"
    ((ISSUES++))
fi

# Vérifier SSH Root
if sudo grep -q "^PermitRootLogin yes" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/* 2>/dev/null; then
    echo -e "${RED}❌ Désactiver root login SSH${NC}"
    ((ISSUES++))
fi

# Vérifier RDP
if sudo ss -tlnp | grep -q ":3389"; then
    echo -e "${RED}❌ Port RDP (3389) ouvert - CRITIQUE${NC}"
    ((ISSUES++))
fi

# Vérifier updates
UPDATES=$(apt list --upgradable 2>/dev/null | grep -c upgradable)
if [ "$UPDATES" -gt 0 ]; then
    echo -e "${YELLOW}⚠️  $UPDATES mise(s) à jour disponible(s)${NC}"
fi

if [ $ISSUES -eq 0 ]; then
    echo -e "${GREEN}✓ Aucun problème critique détecté${NC}"
else
    echo -e "${RED}⚠️  $ISSUES problème(s) critique(s) à corriger${NC}"
fi

echo ""
echo -e "${BLUE}Rapport généré le: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo ""
