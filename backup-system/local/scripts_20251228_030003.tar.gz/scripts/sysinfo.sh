#!/bin/bash
echo "HOST:$(hostname)"
echo "UP:$(uptime -p)"
echo "CPU:$(grep "Model name" /proc/cpuinfo | head -1 | cut -d: -f2 | xargs)"
MEM=$(free -m | awk '/Mem:/{printf "%dGB total, %dGB used, %dGB free", $2/1024, $3/1024, $7/1024}')
echo "RAM:$MEM"
DISK=$(df -h / | awk 'NR==2{print $2" total, "$3" used, "$4" free ("$5")"}')
echo "DISK:$DISK"
echo "LOAD:$(cat /proc/loadavg | cut -d' ' -f1-3)"
GPU=$(nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv,noheader 2>/dev/null)
[ -n "$GPU" ] && echo "GPU:$GPU"
