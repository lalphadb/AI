#!/bin/bash
# Met à jour les stats GPU toutes les 5 secondes
while true; do
    nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits > /tmp/gpu-stats.txt 2>/dev/null
    sleep 5
done
