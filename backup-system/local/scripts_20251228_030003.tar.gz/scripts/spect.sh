#!/usr/bin/env bash
# ---------- CPU ----------
echo "=== CPU ========================================"
lscpu
echo
# ---------- RAM ----------
echo "=== RAM (barrettes, freq, ECC) ================="
sudo dmidecode -t memory | grep -E "Locator|Size|Speed|Manufacturer|Part Number|ECC"
echo
# ---------- GPU ----------
echo "=== GPU (NVIDIA) ==============================="
nvidia-smi -L
nvidia-smi -q -d MEMORY,TEMP,POWER,PCI
echo
# ---------- DISQUES ----------
echo "=== NVMe / SMART ==============================="
for d in /dev/nvme*n1; do
    echo "----- $d -----"
    sudo nvme smart-log "$d"
done
echo
# ---------- PCIe ----------
echo "=== PCIe (lanes, speed) ========================"
lspci -vv | grep -E "LnkCap|LnkSta" | grep -v "LnkCtl"
echo
# ---------- BRIDGES / CHIPSET ----------
echo "=== Chipset / bridges =========================="
lspci -t
echo
# ---------- TEMPÉRATURES ----------
echo "=== Sensors (CPU, GPU, NVMe) ==================="
sensors
echo
# ---------- BIOS / FIRMWARE ----------
echo "=== BIOS / UEFI ================================"
sudo dmidecode -t bios
echo
# ---------- ERREURS MATÉRIELLES ----------
echo "=== ECC / hardware errors ======================"
edac-util -v
