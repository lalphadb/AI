#!/usr/bin/env bash
set -euo pipefail

STACK_DIR="/home/lalpha/projets/infrastructure/4lb-docker-stack"

echo "═══════════════════════════════════════════════════"
echo "🚀 Déploiement Stack 4LB"
echo "═══════════════════════════════════════════════════"
echo ""

echo "📂 [1/7] Passage dans le dossier de la stack..."
cd "$STACK_DIR"

echo "🛑 [2/7] Arrêt propre de la stack existante..."
docker compose down

echo "🧹 [3/7] Nettoyage des ressources obsolètes..."
docker image prune -f
docker container prune -f

echo "📥 [4/7] Pull des nouvelles images..."
docker compose pull || true

echo "🔨 [5/7] Recréation complète des conteneurs..."
docker compose up -d --force-recreate --remove-orphans

echo "⏳ [6/7] Attente du démarrage de Traefik (30s)..."
sleep 30

echo "✅ [7/7] Statut des conteneurs :"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "📋 Logs Traefik (30 dernières lignes):"
docker logs --tail=30 traefik || true

echo ""
echo "═══════════════════════════════════════════════════"
echo "✅ Déploiement terminé"
echo "═══════════════════════════════════════════════════"
echo ""
echo "👉 Lancez maintenant : ~/scripts/docker/check_4lb_stack.sh"
