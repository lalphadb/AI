#!/bin/bash

# Script de vérification et démarrage automatique pour 4lb.ca
# ============================================================

echo "========================================"
echo "   4LB.CA - Vérification au démarrage  "
echo "========================================"
echo ""

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Fonction pour afficher les statuts
print_status() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $2"
    else
        echo -e "${RED}✗${NC} $2"
    fi
}

# 1. Vérifier Docker
echo "1. Vérification de Docker..."
if systemctl is-active --quiet docker; then
    print_status 0 "Docker est actif"
else
    print_status 1 "Docker n'est pas actif - Tentative de démarrage..."
    sudo systemctl start docker
    sleep 2
fi

# 2. Vérifier si nginx occupe le port 80
echo ""
echo "2. Vérification des ports..."
if sudo lsof -i :80 | grep -q nginx; then
    print_status 1 "Nginx occupe le port 80 - Arrêt de nginx..."
    sudo systemctl stop nginx
    sudo systemctl disable nginx
    print_status 0 "Nginx arrêté et désactivé"
else
    print_status 0 "Port 80 disponible"
fi

# 3. Démarrer les conteneurs Docker
echo ""
echo "3. Démarrage des conteneurs Docker..."
cd /home/lalpha/4lb.ca

# Arrêter tous les conteneurs d'abord
docker-compose down 2>/dev/null

# Démarrer tous les services
docker-compose up -d

# Attendre que les services démarrent
echo ""
echo "4. Attente du démarrage des services (30 secondes)..."
sleep 30

# 5. Vérifier l'état de tous les conteneurs
echo ""
echo "5. État des conteneurs:"
echo "------------------------"

# Liste des services à vérifier
services=("traefik" "laravel" "postgres" "redis" "ollama" "grafana" "prometheus" "mcp-server" "ai-optimizer")

for service in "${services[@]}"; do
    if docker ps | grep -q "$service"; then
        status=$(docker ps --filter "name=$service" --format "{{.Status}}" | head -1)
        if echo "$status" | grep -q "Up"; then
            print_status 0 "$service: $status"
        elif echo "$status" | grep -q "starting"; then
            echo -e "${YELLOW}⟳${NC} $service: Démarrage en cours..."
        else
            print_status 1 "$service: $status"
        fi
    else
        print_status 1 "$service: Non trouvé ou arrêté"
    fi
done

# 6. Test des URLs
echo ""
echo "6. Test d'accès aux services:"
echo "------------------------------"

# Fonction pour tester une URL
test_url() {
    local url=$1
    local name=$2
    
    if curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "$url" | grep -q "200\|301\|302\|401\|403"; then
        print_status 0 "$name: $url - Accessible"
    else
        print_status 1 "$name: $url - Non accessible"
    fi
}

# Tester les services web
test_url "http://localhost:80" "Site principal (4lb.ca)"
test_url "http://localhost:8081" "MCP Server (AI)"
test_url "http://localhost:3000" "Grafana"
test_url "http://localhost:9090" "Prometheus"
test_url "http://localhost:11434" "Ollama"

# 7. Afficher les logs des services en erreur
echo ""
echo "7. Services en erreur (le cas échéant):"
echo "----------------------------------------"

# Vérifier les conteneurs en redémarrage
restarting=$(docker ps --filter "status=restarting" --format "{{.Names}}" 2>/dev/null)
if [ ! -z "$restarting" ]; then
    echo -e "${RED}Conteneurs en redémarrage constant:${NC}"
    for container in $restarting; do
        echo "  - $container"
        echo "    Dernières lignes de log:"
        docker logs --tail 5 "$container" 2>&1 | sed 's/^/    /'
    done
else
    print_status 0 "Aucun conteneur en erreur"
fi

# 8. Résumé
echo ""
echo "========================================"
echo "        RÉSUMÉ DE VÉRIFICATION         "
echo "========================================"

total_containers=$(docker ps -a | grep "4lbca" | wc -l)
running_containers=$(docker ps | grep "4lbca" | wc -l)

echo "Conteneurs totaux: $total_containers"
echo "Conteneurs actifs: $running_containers"

if [ "$running_containers" -eq "$total_containers" ] && [ "$total_containers" -gt 0 ]; then
    echo -e "${GREEN}✓ Tous les services sont opérationnels !${NC}"
else
    echo -e "${YELLOW}⚠ Certains services nécessitent une attention${NC}"
fi

echo ""
echo "URLs d'accès:"
echo "-------------"
echo "• Site principal: https://4lb.ca"
echo "• Interface AI: https://ai.4lb.ca"
echo "• Grafana: https://grafana.4lb.ca"
echo "• Prometheus: https://prometheus.4lb.ca"
echo "• Traefik: https://traefik.4lb.ca"
echo ""
