#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Script de Backup Automatique - Infrastructure 4lb.ca
# Backup PostgreSQL, Volumes Docker, Configurations
# ═══════════════════════════════════════════════════════════════

set -e

# Configuration
BACKUP_DIR="/home/lalpha/4lb.ca/backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7
RETENTION_WEEKS=4
RETENTION_MONTHS=12

# Charger .env
cd /home/lalpha/4lb.ca
source .env

# ────────────────────────────────────────────────────────────────
# Fonctions
# ────────────────────────────────────────────────────────────────

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

# ────────────────────────────────────────────────────────────────
# Backup PostgreSQL
# ────────────────────────────────────────────────────────────────

backup_postgres() {
    log "Backup PostgreSQL..."
    
    local backup_file="${BACKUP_DIR}/daily/postgres_${DATE}.sql.gz"
    
    docker-compose exec -T postgres pg_dump -U ${DB_USERNAME} ${DB_DATABASE} | gzip > "$backup_file"
    
    log "✓ PostgreSQL sauvegardé: $(du -h $backup_file | cut -f1)"
}

# ────────────────────────────────────────────────────────────────
# Backup Volumes Docker
# ────────────────────────────────────────────────────────────────

backup_volumes() {
    log "Backup volumes Docker..."
    
    local volumes=("ollama_models" "redis_data" "grafana_data" "prometheus_data")
    
    for volume in "${volumes[@]}"; do
        local backup_file="${BACKUP_DIR}/daily/${volume}_${DATE}.tar.gz"
        
        docker run --rm \
            -v ${volume}:/data \
            -v ${BACKUP_DIR}/daily:/backup \
            alpine \
            tar czf /backup/$(basename $backup_file) -C /data .
        
        log "✓ Volume $volume sauvegardé"
    done
}

# ────────────────────────────────────────────────────────────────
# Backup Configurations
# ────────────────────────────────────────────────────────────────

backup_configs() {
    log "Backup configurations..."
    
    local backup_file="${BACKUP_DIR}/daily/configs_${DATE}.tar.gz"
    
    tar czf "$backup_file" \
        docker-compose.yml \
        .env \
        configs/ \
        scripts/
    
    log "✓ Configurations sauvegardées"
}

# ────────────────────────────────────────────────────────────────
# Upload vers S3 (si configuré)
# ────────────────────────────────────────────────────────────────

upload_to_s3() {
    if [ "${S3_ENABLED:-false}" = "true" ]; then
        log "Upload vers S3..."
        
        # TODO: Implémenter avec aws-cli ou rclone
        # aws s3 sync ${BACKUP_DIR}/daily/ s3://${S3_BUCKET}/daily/
        
        log "✓ Upload S3 terminé"
    fi
}

# ────────────────────────────────────────────────────────────────
# Nettoyage anciens backups
# ────────────────────────────────────────────────────────────────

cleanup_old_backups() {
    log "Nettoyage anciens backups..."
    
    # Daily: garder 7 jours
    find ${BACKUP_DIR}/daily -type f -mtime +${RETENTION_DAYS} -delete
    
    # Weekly: garder 4 semaines
    find ${BACKUP_DIR}/weekly -type f -mtime +$((RETENTION_WEEKS * 7)) -delete
    
    # Monthly: garder 12 mois
    find ${BACKUP_DIR}/monthly -type f -mtime +$((RETENTION_MONTHS * 30)) -delete
    
    log "✓ Nettoyage terminé"
}

# ────────────────────────────────────────────────────────────────
# Weekly/Monthly backups
# ────────────────────────────────────────────────────────────────

check_weekly_monthly() {
    local day_of_week=$(date +%u)
    local day_of_month=$(date +%d)
    
    # Weekly backup (dimanche)
    if [ "$day_of_week" -eq 7 ]; then
        log "Backup hebdomadaire..."
        cp -r ${BACKUP_DIR}/daily/* ${BACKUP_DIR}/weekly/
    fi
    
    # Monthly backup (1er du mois)
    if [ "$day_of_month" -eq 01 ]; then
        log "Backup mensuel..."
        cp -r ${BACKUP_DIR}/daily/* ${BACKUP_DIR}/monthly/
    fi
}

# ────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────

main() {
    log "════════════════════════════════════════════════════════"
    log "🔄 DÉBUT DU BACKUP"
    log "════════════════════════════════════════════════════════"
    
    # Créer répertoires si nécessaire
    mkdir -p ${BACKUP_DIR}/{daily,weekly,monthly}
    
    # Exécuter backups
    backup_postgres
    backup_volumes
    backup_configs
    upload_to_s3
    check_weekly_monthly
    cleanup_old_backups
    
    log "════════════════════════════════════════════════════════"
    log "✅ BACKUP TERMINÉ"
    log "════════════════════════════════════════════════════════"
}

main "$@"
