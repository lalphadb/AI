#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Script de Déploiement Automatisé - Infrastructure 4lb.ca
# Déploiement complet de A à Z avec vérifications
# ═══════════════════════════════════════════════════════════════

set -e  # Exit on error
set -u  # Exit on undefined variable

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
LOG_FILE="${PROJECT_ROOT}/logs/deploy_$(date +%Y%m%d_%H%M%S).log"

# ────────────────────────────────────────────────────────────────
# FONCTIONS UTILITAIRES
# ────────────────────────────────────────────────────────────────

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

check_command() {
    if ! command -v "$1" &> /dev/null; then
        log_error "Commande requise non trouvée: $1"
        return 1
    fi
    return 0
}

prompt_user() {
    local message="$1"
    local default="${2:-n}"
    
    read -p "$message [y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        return 0
    fi
    return 1
}

# ────────────────────────────────────────────────────────────────
# VÉRIFICATIONS PRÉALABLES
# ────────────────────────────────────────────────────────────────

check_prerequisites() {
    log "═══════════════════════════════════════════════════════════"
    log "🔍 VÉRIFICATION DES PRÉREQUIS"
    log "═══════════════════════════════════════════════════════════"
    
    # Docker
    if ! check_command docker; then
        log_error "Docker n'est pas installé. Installation requise."
        exit 1
    fi
    log "✓ Docker installé: $(docker --version)"
    
    # Docker Compose
    if ! check_command docker-compose && ! docker compose version &>/dev/null; then
        log_error "Docker Compose n'est pas installé."
        exit 1
    fi
    log "✓ Docker Compose installé"
    
    # NVIDIA Docker (optionnel mais recommandé)
    if command -v nvidia-smi &> /dev/null; then
        log "✓ NVIDIA GPU détecté: $(nvidia-smi --query-gpu=name --format=csv,noheader)"
        if ! docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi &>/dev/null; then
            log_warning "NVIDIA Docker runtime non configuré - GPU non disponible"
        else
            log "✓ NVIDIA Docker runtime configuré"
        fi
    else
        log_warning "Pas de GPU NVIDIA détecté - Mode CPU uniquement"
    fi
    
    # Espace disque
    local available_space=$(df -BG "$PROJECT_ROOT" | awk 'NR==2 {print $4}' | sed 's/G//')
    if [ "$available_space" -lt 50 ]; then
        log_error "Espace disque insuffisant: ${available_space}GB (50GB minimum requis)"
        exit 1
    fi
    log "✓ Espace disque: ${available_space}GB disponible"
    
    # RAM
    local total_ram=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$total_ram" -lt 16 ]; then
        log_warning "RAM faible: ${total_ram}GB (16GB recommandés)"
    else
        log "✓ RAM: ${total_ram}GB"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# CONFIGURATION ENVIRONNEMENT
# ────────────────────────────────────────────────────────────────

setup_environment() {
    log "═══════════════════════════════════════════════════════════"
    log "⚙️  CONFIGURATION ENVIRONNEMENT"
    log "═══════════════════════════════════════════════════════════"
    
    cd "$PROJECT_ROOT"
    
    # Vérifier .env
    if [ ! -f .env ]; then
        log_info "Fichier .env non trouvé, création depuis .env.example..."
        cp .env.example .env
        
        log_warning "⚠️  CONFIGURATION REQUISE !"
        log_warning "Veuillez éditer le fichier .env avec vos paramètres:"
        log_warning "  - ANTHROPIC_API_KEY"
        log_warning "  - DB_PASSWORD"
        log_warning "  - GRAFANA_PASSWORD"
        log_warning "  - APP_KEY (générer avec: openssl rand -base64 32)"
        log_warning ""
        
        if ! prompt_user "Avez-vous configuré le fichier .env ?"; then
            log_error "Configuration .env requise avant de continuer"
            log_info "Éditez: nano $PROJECT_ROOT/.env"
            exit 1
        fi
    else
        log "✓ Fichier .env existant"
    fi
    
    # Charger les variables
    set -a
    source .env
    set +a
    
    # Vérifier clés critiques
    if [ -z "${ANTHROPIC_API_KEY:-}" ] || [ "$ANTHROPIC_API_KEY" = "sk-ant-api03-YOUR_KEY_HERE" ]; then
        log_error "ANTHROPIC_API_KEY non configuré dans .env"
        exit 1
    fi
    log "✓ ANTHROPIC_API_KEY configuré"
    
    if [ -z "${DB_PASSWORD:-}" ] || [ "$DB_PASSWORD" = "CHANGE_ME_STRONG_PASSWORD_HERE" ]; then
        log_error "DB_PASSWORD non configuré dans .env"
        exit 1
    fi
    log "✓ DB_PASSWORD configuré"
    
    echo
}

# ────────────────────────────────────────────────────────────────
# CRÉATION STRUCTURE
# ────────────────────────────────────────────────────────────────

create_structure() {
    log "═══════════════════════════════════════════════════════════"
    log "📁 CRÉATION STRUCTURE RÉPERTOIRES"
    log "═══════════════════════════════════════════════════════════"
    
    # Créer répertoires nécessaires
    mkdir -p \
        data/{postgres,redis,ollama,mail} \
        logs/{nginx,laravel,optimizer,mcp} \
        backups/{daily,weekly,monthly} \
        shared/{models,uploads,cache} \
        configs/traefik
    
    # Permissions
    chmod 755 data backups logs shared
    chmod 700 data/postgres  # Sécurité PostgreSQL
    
    log "✓ Structure de répertoires créée"
    echo
}

# ────────────────────────────────────────────────────────────────
# TÉLÉCHARGEMENT MODÈLES LLM
# ────────────────────────────────────────────────────────────────

pull_llm_models() {
    log "═══════════════════════════════════════════════════════════"
    log "🤖 TÉLÉCHARGEMENT MODÈLES LLM"
    log "═══════════════════════════════════════════════════════════"
    
    local models="${OLLAMA_MODELS:-llama3.1:8b,mistral:7b}"
    
    log_info "Modèles à télécharger: $models"
    
    if prompt_user "Télécharger les modèles LLM maintenant? (peut prendre du temps)"; then
        # Démarrer temporairement Ollama
        docker-compose up -d ollama
        sleep 10
        
        IFS=',' read -ra MODEL_ARRAY <<< "$models"
        for model in "${MODEL_ARRAY[@]}"; do
            log "Téléchargement: $model..."
            docker-compose exec -T ollama ollama pull "$model" || log_warning "Échec: $model"
        done
        
        docker-compose stop ollama
        log "✓ Modèles téléchargés"
    else
        log_info "Téléchargement des modèles reporté"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# BUILD IMAGES
# ────────────────────────────────────────────────────────────────

build_images() {
    log "═══════════════════════════════════════════════════════════"
    log "🏗️  BUILD DES IMAGES DOCKER"
    log "═══════════════════════════════════════════════════════════"
    
    cd "$PROJECT_ROOT"
    
    log "Construction des images personnalisées..."
    docker-compose build --parallel || {
        log_error "Échec du build des images"
        exit 1
    }
    
    log "✓ Images construites avec succès"
    echo
}

# ────────────────────────────────────────────────────────────────
# DÉMARRAGE SERVICES
# ────────────────────────────────────────────────────────────────

start_services() {
    log "═══════════════════════════════════════════════════════════"
    log "🚀 DÉMARRAGE DES SERVICES"
    log "═══════════════════════════════════════════════════════════"
    
    cd "$PROJECT_ROOT"
    
    # Phase 1: Services de base
    log "Phase 1/4: Démarrage PostgreSQL, Redis..."
    docker-compose up -d postgres redis
    sleep 10
    
    # Phase 2: Monitoring
    log "Phase 2/4: Démarrage Prometheus, Grafana, Loki..."
    docker-compose up -d prometheus grafana loki promtail node-exporter cadvisor
    sleep 5
    
    # Phase 3: LLM Stack
    log "Phase 3/4: Démarrage Ollama, MCP Server..."
    docker-compose up -d ollama
    sleep 10
    docker-compose up -d mcp-server ai-optimizer
    sleep 5
    
    # Phase 4: Web & Proxy
    log "Phase 4/4: Démarrage Laravel, Traefik..."
    docker-compose up -d laravel laravel-worker traefik
    sleep 5
    
    # Vérifier GPU exporter si disponible
    if command -v nvidia-smi &> /dev/null; then
        docker-compose up -d nvidia-exporter || log_warning "GPU exporter non démarré"
    fi
    
    log "✓ Tous les services démarrés"
    echo
}

# ────────────────────────────────────────────────────────────────
# VÉRIFICATIONS SANTÉ
# ────────────────────────────────────────────────────────────────

health_checks() {
    log "═══════════════════════════════════════════════════════════"
    log "🏥 VÉRIFICATIONS SANTÉ DES SERVICES"
    log "═══════════════════════════════════════════════════════════"
    
    local max_attempts=30
    local attempt=1
    
    # PostgreSQL
    log "Vérification PostgreSQL..."
    while [ $attempt -le $max_attempts ]; do
        if docker-compose exec -T postgres pg_isready -U ${DB_USERNAME:-laravel} &>/dev/null; then
            log "✓ PostgreSQL OK"
            break
        fi
        sleep 2
        ((attempt++))
    done
    
    # Redis
    log "Vérification Redis..."
    if docker-compose exec -T redis redis-cli ping &>/dev/null; then
        log "✓ Redis OK"
    else
        log_warning "Redis non accessible"
    fi
    
    # Ollama
    log "Vérification Ollama..."
    if curl -sf http://localhost:11434/api/tags &>/dev/null; then
        log "✓ Ollama OK"
    else
        log_warning "Ollama non accessible"
    fi
    
    # Prometheus
    log "Vérification Prometheus..."
    if curl -sf http://localhost:9090/-/healthy &>/dev/null; then
        log "✓ Prometheus OK"
    else
        log_warning "Prometheus non accessible"
    fi
    
    # Grafana
    log "Vérification Grafana..."
    if curl -sf http://localhost:3000/api/health &>/dev/null; then
        log "✓ Grafana OK"
    else
        log_warning "Grafana non accessible"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# AFFICHAGE RÉSUMÉ
# ────────────────────────────────────────────────────────────────

display_summary() {
    log "═══════════════════════════════════════════════════════════"
    log "✅ DÉPLOIEMENT TERMINÉ AVEC SUCCÈS !"
    log "═══════════════════════════════════════════════════════════"
    
    echo ""
    log_info "🌐 URLS D'ACCÈS:"
    log_info "  • Application:    https://4lb.ca"
    log_info "  • Grafana:        https://grafana.4lb.ca (admin / ${GRAFANA_PASSWORD})"
    log_info "  • Prometheus:     https://prometheus.4lb.ca"
    log_info "  • Traefik:        https://traefik.4lb.ca"
    log_info "  • MCP API:        https://ai.4lb.ca"
    
    echo ""
    log_info "📊 COMMANDES UTILES:"
    log_info "  • Voir les services:  docker-compose ps"
    log_info "  • Voir les logs:      docker-compose logs -f [service]"
    log_info "  • Redémarrer:         docker-compose restart [service]"
    log_info "  • Arrêter tout:       docker-compose down"
    
    echo ""
    log_info "🔧 PROCHAINES ÉTAPES:"
    log_info "  1. Configurer DNS Cloudflare vers cette IP"
    log_info "  2. Attendre certificats SSL (Let's Encrypt)"
    log_info "  3. Créer application Laravel dans ./laravel/"
    log_info "  4. Configurer serveur email (DKIM, SPF, DMARC)"
    
    echo ""
    log "Log complet: $LOG_FILE"
    log "═══════════════════════════════════════════════════════════"
}

# ────────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────────

main() {
    clear
    log "═══════════════════════════════════════════════════════════"
    log "🚀 DÉPLOIEMENT INFRASTRUCTURE 4LB.CA"
    log "═══════════════════════════════════════════════════════════"
    log "Date: $(date)"
    log "User: $(whoami)"
    log "Path: $PROJECT_ROOT"
    log "═══════════════════════════════════════════════════════════"
    echo ""
    
    # Exécution des étapes
    check_prerequisites
    setup_environment
    create_structure
    build_images
    start_services
    health_checks
    display_summary
    
    log ""
    log "🎉 Déploiement terminé !"
}

# Exécution
main "$@"
