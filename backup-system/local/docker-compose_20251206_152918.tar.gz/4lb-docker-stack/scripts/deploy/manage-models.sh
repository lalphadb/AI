#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Gestionnaire de Modèles LLM - 4lb.ca
# Télécharger, lister, supprimer des modèles Ollama
# ═══════════════════════════════════════════════════════════════

set -e

PROJECT_ROOT="/home/lalpha/4lb.ca"
cd "$PROJECT_ROOT"

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# ────────────────────────────────────────────────────────────────
# Fonctions
# ────────────────────────────────────────────────────────────────

show_banner() {
    echo -e "${BLUE}"
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║         GESTIONNAIRE MODÈLES LLM - 4LB.CA           ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

list_models() {
    echo -e "${BLUE}📚 Modèles installés:${NC}"
    echo
    docker-compose exec ollama ollama list
    echo
}

pull_model() {
    local model="$1"
    
    if [ -z "$model" ]; then
        echo "Usage: $0 pull <nom_modèle>"
        echo
        echo "Modèles populaires:"
        echo "  • llama3.1:8b        - Modèle général rapide (4.7GB)"
        echo "  • llama3.1:70b       - Modèle puissant (40GB)"
        echo "  • mistral:7b         - Multilangue excellent (4.1GB)"
        echo "  • codellama:13b      - Spécialisé code (7.4GB)"
        echo "  • phi-3:medium       - Compact et rapide (7.9GB)"
        echo "  • gemma:7b           - Google Gemma (5.0GB)"
        echo
        return 1
    fi
    
    echo -e "${BLUE}📥 Téléchargement de $model...${NC}"
    docker-compose exec ollama ollama pull "$model"
    echo -e "${GREEN}✓ Modèle $model installé${NC}"
}

remove_model() {
    local model="$1"
    
    if [ -z "$model" ]; then
        echo "Usage: $0 remove <nom_modèle>"
        list_models
        return 1
    fi
    
    echo -e "${YELLOW}⚠️  Suppression de $model...${NC}"
    docker-compose exec ollama ollama rm "$model"
    echo -e "${GREEN}✓ Modèle $model supprimé${NC}"
}

test_model() {
    local model="$1"
    local prompt="${2:-Bonjour, comment ça va?}"
    
    if [ -z "$model" ]; then
        echo "Usage: $0 test <nom_modèle> [prompt]"
        list_models
        return 1
    fi
    
    echo -e "${BLUE}🧪 Test de $model...${NC}"
    echo -e "${BLUE}Prompt: $prompt${NC}"
    echo
    docker-compose exec ollama ollama run "$model" "$prompt"
}

model_info() {
    local model="$1"
    
    if [ -z "$model" ]; then
        echo "Usage: $0 info <nom_modèle>"
        list_models
        return 1
    fi
    
    echo -e "${BLUE}ℹ️  Informations sur $model:${NC}"
    docker-compose exec ollama ollama show "$model"
}

bulk_install() {
    echo -e "${BLUE}📦 Installation des modèles recommandés...${NC}"
    echo
    
    local models=(
        "llama3.1:8b"
        "mistral:7b"
        "codellama:13b"
        "phi-3:medium"
    )
    
    for model in "${models[@]}"; do
        echo -e "${BLUE}Téléchargement: $model${NC}"
        docker-compose exec ollama ollama pull "$model" || echo "Échec: $model"
        echo
    done
    
    echo -e "${GREEN}✓ Installation terminée${NC}"
    list_models
}

check_disk_space() {
    echo -e "${BLUE}💾 Espace disque utilisé par les modèles:${NC}"
    docker-compose exec ollama du -sh /root/.ollama/models 2>/dev/null || echo "Impossible de vérifier"
    echo
    
    echo -e "${BLUE}💾 Espace disque disponible:${NC}"
    df -h / | grep -v Filesystem
}

# ────────────────────────────────────────────────────────────────
# Menu principal
# ────────────────────────────────────────────────────────────────

show_menu() {
    echo
    echo "Commandes disponibles:"
    echo "  list              - Lister les modèles installés"
    echo "  pull <model>      - Télécharger un modèle"
    echo "  remove <model>    - Supprimer un modèle"
    echo "  test <model>      - Tester un modèle"
    echo "  info <model>      - Afficher infos d'un modèle"
    echo "  bulk              - Installer modèles recommandés"
    echo "  disk              - Vérifier espace disque"
    echo
    echo "Exemples:"
    echo "  $0 pull llama3.1:8b"
    echo "  $0 test mistral:7b \"Écris un poème\""
    echo "  $0 remove codellama:13b"
    echo
}

# ────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────

main() {
    show_banner
    
    local command="${1:-}"
    
    case "$command" in
        list|ls)
            list_models
            ;;
        pull|download|install)
            shift
            pull_model "$@"
            ;;
        remove|rm|delete)
            shift
            remove_model "$@"
            ;;
        test|run)
            shift
            test_model "$@"
            ;;
        info|show)
            shift
            model_info "$@"
            ;;
        bulk)
            bulk_install
            ;;
        disk|space)
            check_disk_space
            ;;
        help|--help|-h|"")
            show_menu
            ;;
        *)
            echo "Commande inconnue: $command"
            show_menu
            exit 1
            ;;
    esac
}

main "$@"
