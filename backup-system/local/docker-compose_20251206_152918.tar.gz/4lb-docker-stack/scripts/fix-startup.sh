#!/bin/bash

echo "================================================="
echo "  Configuration du démarrage automatique 4LB.CA "
echo "================================================="
echo ""

# Vérifier si on a les droits sudo
if ! sudo -n true 2>/dev/null; then
    echo "Ce script nécessite les droits sudo. Veuillez entrer votre mot de passe:"
    sudo true
fi

# 1. Désactiver nginx au démarrage
echo "1. Désactivation de nginx au démarrage..."
sudo systemctl stop nginx
sudo systemctl disable nginx
echo "   ✓ Nginx désactivé"

# 2. Corriger le problème de logs dans les Dockerfiles
echo ""
echo "2. Correction des problèmes de logs Docker..."
cd /home/lalpha/4lb.ca

# Créer un override pour Laravel
cat > docker/laravel/fix-logs.sh << 'SCRIPT'
#!/bin/sh
mkdir -p /var/log/supervisor
touch /var/log/supervisor/supervisord.log
exec "$@"
SCRIPT
chmod +x docker/laravel/fix-logs.sh

# 3. Reconstruire les images si nécessaire
echo ""
echo "3. Reconstruction des images Docker..."
docker-compose build laravel laravel-worker 2>/dev/null || true

# 4. Mettre à jour le service systemd
echo ""
echo "4. Mise à jour du service systemd..."
sudo cp /home/lalpha/4lbca-docker-fixed.service /etc/systemd/system/4lbca-docker.service
sudo systemctl daemon-reload
sudo systemctl enable 4lbca-docker.service
echo "   ✓ Service systemd mis à jour"

# 5. Créer un cron de vérification
echo ""
echo "5. Configuration du cron de vérification..."
(crontab -l 2>/dev/null | grep -v "startup-check.sh"; echo "@reboot sleep 60 && /home/lalpha/4lb.ca/scripts/startup-check.sh > /home/lalpha/4lb.ca/logs/startup-check.log 2>&1") | crontab -
echo "   ✓ Cron de vérification configuré"

# 6. Créer un script de monitoring
cat > /home/lalpha/4lb.ca/scripts/monitor.sh << 'MONITOR'
#!/bin/bash
# Script de monitoring continu

while true; do
    # Vérifier si les conteneurs critiques sont en cours d'exécution
    for service in traefik laravel postgres redis; do
        if ! docker ps | grep -q "$service"; then
            echo "$(date): Service $service est arrêté - Redémarrage..." >> /home/lalpha/4lb.ca/logs/monitor.log
            cd /home/lalpha/4lb.ca && docker-compose up -d $service
        fi
    done
    
    # Vérifier les conteneurs en redémarrage constant
    restarting=$(docker ps --filter "status=restarting" --format "{{.Names}}")
    for container in $restarting; do
        restart_count=$(docker inspect $container | grep -c "RestartCount")
        if [ "$restart_count" -gt 5 ]; then
            echo "$(date): Container $container en redémarrage constant - Recréation..." >> /home/lalpha/4lb.ca/logs/monitor.log
            docker stop $container
            docker rm $container
            cd /home/lalpha/4lb.ca && docker-compose up -d ${container#4lbca-}
        fi
    done
    
    sleep 300 # Vérifier toutes les 5 minutes
done
MONITOR
chmod +x /home/lalpha/4lb.ca/scripts/monitor.sh

# 7. Test immédiat
echo ""
echo "6. Test de démarrage..."
sudo systemctl restart 4lbca-docker.service
sleep 10

# Vérifier le statut
if sudo systemctl is-active --quiet 4lbca-docker.service; then
    echo "   ✓ Service démarré avec succès!"
else
    echo "   ✗ Problème détecté, vérification des logs..."
    sudo journalctl -u 4lbca-docker.service --no-pager -n 20
fi

echo ""
echo "================================================="
echo "           Configuration terminée !              "
echo "================================================="
echo ""
echo "Actions effectuées:"
echo "  • Nginx désactivé au démarrage"
echo "  • Service systemd 4lbca-docker corrigé"
echo "  • Cron de vérification ajouté"
echo "  • Scripts de monitoring créés"
echo ""
echo "Au prochain démarrage du PC:"
echo "  1. Docker démarrera automatiquement"
echo "  2. Nginx ne démarrera pas"
echo "  3. Tous vos conteneurs 4lb.ca démarreront"
echo "  4. Un log de vérification sera créé"
echo ""
echo "Pour vérifier maintenant: ./scripts/startup-check.sh"
echo "Pour surveiller en continu: ./scripts/monitor.sh &"
echo ""
