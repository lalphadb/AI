#!/bin/bash

echo "Correction du problème de Laravel..."

# Arrêter les conteneurs Laravel problématiques
docker stop laravel 4lbca-laravel-worker-1 4lbca-laravel-worker-2 4lbca-laravel-worker-3 ai-optimizer 2>/dev/null

# Créer les répertoires de logs dans les conteneurs
for container in laravel 4lbca-laravel-worker-1 4lbca-laravel-worker-2 4lbca-laravel-worker-3; do
    echo "Création du répertoire de logs pour $container..."
    docker run --rm -v 4lbca_laravel_app:/var/www/html alpine mkdir -p /var/www/html/storage/logs
done

# Modifier temporairement le docker-compose pour ajouter un entrypoint
cd /home/lalpha/4lb.ca

# Sauvegarder le docker-compose original
cp docker-compose.yml docker-compose.yml.backup

# Ajouter un script d'initialisation
cat > docker/laravel/entrypoint.sh << 'ENTRYPOINT'
#!/bin/sh
mkdir -p /var/log/supervisor
touch /var/log/supervisor/supervisord.log
chown -R www-data:www-data /var/log/supervisor
exec docker-php-entrypoint "$@"
ENTRYPOINT
chmod +x docker/laravel/entrypoint.sh

# Redémarrer les services
docker-compose up -d laravel laravel-worker ai-optimizer

echo "Attente de 10 secondes..."
sleep 10

# Vérifier l'état
echo ""
echo "État des services Laravel:"
docker ps --filter "name=laravel" --format "table {{.Names}}\t{{.Status}}"
docker ps --filter "name=worker" --format "table {{.Names}}\t{{.Status}}"
docker ps --filter "name=ai-optimizer" --format "table {{.Names}}\t{{.Status}}"

echo ""
echo "Terminé!"
