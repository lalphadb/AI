#!/bin/bash

# Extensions essentielles
code-server --install-extension saoudrizwan.claude-dev
code-server --install-extension Continue.continue
code-server --install-extension GitHub.github-vscode-theme
code-server --install-extension PKief.material-icon-theme
code-server --install-extension esbenp.prettier-vscode
code-server --install-extension ms-python.python
code-server --install-extension ms-python.black-formatter
code-server --install-extension dbaeumer.vscode-eslint
code-server --install-extension bradlc.vscode-tailwindcss
code-server --install-extension ritwickdey.LiveServer

echo "✅ Extensions installées avec succès"
