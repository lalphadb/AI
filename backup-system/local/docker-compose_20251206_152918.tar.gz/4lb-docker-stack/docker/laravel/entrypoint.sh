#!/bin/sh
mkdir -p /var/log/supervisor
touch /var/log/supervisor/supervisord.log
chown -R www-data:www-data /var/log/supervisor
exec docker-php-entrypoint "$@"
