# 🌩️ Configuration Cloudflare pour 4lb.ca

## 📋 Vue d'Ensemble

Ce guide détaille la configuration complète de Cloudflare pour votre infrastructure 4lb.ca.

## 🔧 Étape 1 : Configuration DNS

### Enregistrements A (IPv4)

Connectez-vous à Cloudflare et configurez les enregistrements suivants :

| Type | Nom | Valeur | Proxy | TTL |
|------|-----|--------|-------|-----|
| A | @ | 1.1.4.12 | ✅ Proxied | Auto |
| A | www | 1.1.4.12 | ✅ Proxied | Auto |
| A | ai | 1.1.4.12 | ✅ Proxied | Auto |
| A | grafana | 1.1.4.12 | ✅ Proxied | Auto |
| A | prometheus | 1.1.4.12 | ✅ Proxied | Auto |
| A | traefik | 1.1.4.12 | ✅ Proxied | Auto |
| A | mail | 1.1.4.12 | ❌ DNS only | Auto |

**Note :** Le serveur mail ne doit PAS être proxied pour éviter les problèmes SMTP.

### Enregistrements MX (Email)

| Type | Nom | Priorité | Valeur | Proxy | TTL |
|------|-----|----------|--------|-------|-----|
| MX | @ | 10 | mail.4lb.ca | ❌ DNS only | Auto |

### Enregistrements TXT (Sécurité Email)

#### SPF (Sender Policy Framework)

```
Type: TXT
Nom: @
Valeur: v=spf1 mx a ip4:1.1.4.12 ~all
```

#### DMARC (Domain-based Message Authentication)

```
Type: TXT
Nom: _dmarc
Valeur: v=DMARC1; p=quarantine; rua=mailto:dmarc@4lb.ca; ruf=mailto:dmarc@4lb.ca; fo=1
```

#### DKIM (DomainKeys Identified Mail)

Générer d'abord la clé DKIM sur votre serveur :

```bash
docker-compose exec mail setup config dkim
```

Puis ajouter :

```
Type: TXT
Nom: mail._domainkey
Valeur: v=DKIM1; k=rsa; p=VOTRE_CLE_PUBLIQUE_ICI
```

## 🔒 Étape 2 : SSL/TLS

### Mode SSL/TLS

1. Aller dans **SSL/TLS** → **Overview**
2. Sélectionner **Full (strict)**

### Configuration Edge Certificates

1. **SSL/TLS** → **Edge Certificates**
2. Activer :
   - ✅ Always Use HTTPS
   - ✅ HTTP Strict Transport Security (HSTS)
   - ✅ Minimum TLS Version : TLS 1.2
   - ✅ Opportunistic Encryption
   - ✅ TLS 1.3

### HSTS Configuration

```
Max Age: 12 months
Include subdomains: ✅
Preload: ✅
No-Sniff: ✅
```

## 🛡️ Étape 3 : Firewall & Sécurité

### Firewall Rules

Créer les règles suivantes dans **Security** → **WAF** → **Custom rules** :

#### Règle 1 : Bloquer pays à risque

```
Rule name: Block High-Risk Countries
Expression: 
  (ip.geoip.country in {"CN" "RU" "KP"})

Action: Block
```

#### Règle 2 : Rate Limiting API

```
Rule name: Rate Limit API
Expression:
  (http.request.uri.path contains "/api/")

Action: Rate Limit
  Requests: 100 per 60 seconds
```

#### Règle 3 : Protection Admin

```
Rule name: Protect Admin Areas
Expression:
  (http.request.uri.path contains "/admin" or 
   http.request.uri.path contains "/wp-admin")

Action: Challenge (Managed)
```

### Security Level

1. **Security** → **Settings**
2. Security Level : **High**
3. Challenge Passage : 30 minutes

### Bot Fight Mode

1. **Security** → **Bots**
2. Activer **Bot Fight Mode**

## ⚡ Étape 4 : Performance & Caching

### Caching Configuration

1. **Caching** → **Configuration**
2. Caching Level : **Standard**
3. Browser Cache TTL : **4 hours**

### Cache Rules

Créer des règles personnalisées :

#### Images & Assets

```
Rule name: Cache Images
Match:
  Hostname equals 4lb.ca
  AND
  File Extension matches (jpg|jpeg|png|gif|webp|svg|ico|css|js|woff|woff2|ttf)

Then:
  Eligible for cache: Yes
  Edge TTL: 1 month
  Browser TTL: 1 week
```

#### API Responses

```
Rule name: No Cache API
Match:
  URI Path contains /api/

Then:
  Eligible for cache: No
```

### Auto Minify

1. **Speed** → **Optimization**
2. Auto Minify :
   - ✅ JavaScript
   - ✅ CSS
   - ✅ HTML

### Brotli Compression

1. **Speed** → **Optimization**
2. ✅ Enable Brotli

### Early Hints

1. **Speed** → **Optimization**
2. ✅ Enable Early Hints

## 🚀 Étape 5 : Page Rules (Optionnel)

### Règle 1 : HTTPS Redirect

```
URL: http://*4lb.ca/*
Settings:
  - Always Use HTTPS
```

### Règle 2 : Cache Everything Homepage

```
URL: 4lb.ca/
Settings:
  - Cache Level: Cache Everything
  - Edge Cache TTL: 2 hours
```

### Règle 3 : Bypass Cache Admin

```
URL: *4lb.ca/admin*
Settings:
  - Cache Level: Bypass
```

## 📊 Étape 6 : Analytics & Monitoring

### Web Analytics

1. **Analytics & Logs** → **Web Analytics**
2. Activer **Cloudflare Web Analytics**

### Real-time Logs (Optionnel - Payant)

Si vous avez un plan Pro ou supérieur :

1. **Analytics & Logs** → **Logs**
2. Configurer Logpush vers votre destination

## 🔄 Étape 7 : Load Balancing (Optionnel)

Si vous avez plusieurs serveurs :

1. **Traffic** → **Load Balancing**
2. Créer un Load Balancer avec pools de serveurs
3. Configurer Health Checks

## 📧 Étape 8 : Email Routing (Optionnel)

Pour rediriger les emails :

1. **Email** → **Email Routing**
2. Activer Email Routing
3. Configurer des règles de redirection

## ✅ Vérification Configuration

### Test DNS

```bash
# Vérifier enregistrements A
dig 4lb.ca
dig www.4lb.ca
dig ai.4lb.ca

# Vérifier MX
dig MX 4lb.ca

# Vérifier SPF
dig TXT 4lb.ca
```

### Test SSL

```bash
# Vérifier certificat SSL
openssl s_client -connect 4lb.ca:443 -servername 4lb.ca

# Ou utiliser en ligne
# https://www.ssllabs.com/ssltest/
```

### Test Email

```bash
# Tester SPF
nslookup -type=TXT 4lb.ca

# Tester DKIM
nslookup -type=TXT mail._domainkey.4lb.ca
```

## 🎯 Configuration Recommandée Finale

| Paramètre | Valeur |
|-----------|--------|
| SSL Mode | Full (strict) |
| Min TLS | 1.2 |
| HSTS | Activé (12 mois) |
| Security Level | High |
| Bot Fight | Activé |
| Auto Minify | JS/CSS/HTML |
| Brotli | Activé |
| Early Hints | Activé |

## 🔧 Configuration Avancée (Optionnel)

### Workers (Custom Logic)

Si besoin de logique personnalisée :

1. **Workers & Pages** → **Create Worker**
2. Écrire votre Worker JavaScript
3. Ajouter route trigger

### Argo Smart Routing (Payant)

Pour améliorer les performances :

1. **Traffic** → **Argo**
2. Activer Argo Smart Routing

### Rate Limiting Advanced

Pour protection DDoS avancée :

1. **Security** → **WAF** → **Rate limiting rules**
2. Créer règles granulaires par endpoint

## 📞 Support

- Documentation : https://developers.cloudflare.com/
- Status : https://www.cloudflarestatus.com/
- Support : https://dash.cloudflare.com/?to=/:account/support

## 🎉 C'est Terminé !

Votre configuration Cloudflare pour 4lb.ca est maintenant complète et optimisée pour :

✅ Performance maximale  
✅ Sécurité renforcée  
✅ SSL/TLS strict  
✅ Protection DDoS  
✅ Email sécurisé  
✅ Analytics détaillées  

Temps de propagation DNS : **5-30 minutes**
