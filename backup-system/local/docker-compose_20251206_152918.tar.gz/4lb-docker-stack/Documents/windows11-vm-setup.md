# 🖥️ Installation VM Windows 11 pour Cronus Zen

## 📋 Prérequis

Votre système :
- ✅ CPU : AMD Ryzen 9 7900X (12 cœurs) - Excellent !
- ✅ RAM : 91 GB - Largement suffisant
- ✅ GPU : RTX 5070 Ti - Parfait
- ✅ Stockage : 2TB + 1TB - Aucun problème

---

## 🔧 Étape 1 : Installation VirtualBox

```bash
# Mettre à jour les paquets
sudo apt update

# Installer VirtualBox et Extension Pack
sudo apt install virtualbox virtualbox-ext-pack virtualbox-guest-additions-iso -y

# Ajouter votre utilisateur au groupe vboxusers (pour USB)
sudo usermod -aG vboxusers $USER

# Vérifier l'installation
VBoxManage --version
```

**⚠️ IMPORTANT :** Après avoir ajouté au groupe, vous devez **redémarrer votre session** :
```bash
# Option 1 : Redémarrer la session
# Déconnectez-vous et reconnectez-vous

# Option 2 : Reboot (plus sûr)
sudo reboot
```

---

## 💿 Étape 2 : Télécharger Windows 11 ISO

### Option A : Téléchargement Direct

```bash
# Créer un dossier pour les ISOs
mkdir -p ~/VMs/ISOs
cd ~/VMs/ISOs

# Télécharger Windows 11 (lien officiel Microsoft)
# Allez sur : https://www.microsoft.com/software-download/windows11
# Ou utilisez wget avec un lien direct :

wget -O Windows11.iso "https://software.download.prss.microsoft.com/dbazure/Win11_23H2_English_x64v2.iso?t=..."
# Note : Le lien change régulièrement, utilisez le site officiel
```

### Option B : Via le Navigateur

1. Ouvrez Firefox sur votre serveur (si GUI disponible)
2. Allez sur : https://www.microsoft.com/software-download/windows11
3. Téléchargez l'ISO (environ 6 GB)
4. Sauvegardez dans `~/VMs/ISOs/`

---

## 🖥️ Étape 3 : Créer la VM Windows 11

### Script Automatique

Créez ce script : `~/create-win11-vm.sh`

```bash
#!/bin/bash

# Configuration
VM_NAME="Windows11-CronusZen"
VM_RAM=8192        # 8 GB (ajustez selon besoin)
VM_VRAM=128        # 128 MB VRAM
VM_CPUS=4          # 4 cœurs CPU
VM_DISK_SIZE=80000 # 80 GB
ISO_PATH="$HOME/VMs/ISOs/Windows11.iso"
VM_DIR="$HOME/VMs"

# Créer le dossier VM
mkdir -p "$VM_DIR"

# Créer la VM
VBoxManage createvm --name "$VM_NAME" --ostype Windows11_64 --register --basefolder "$VM_DIR"

# Configuration matérielle
VBoxManage modifyvm "$VM_NAME" \
    --memory $VM_RAM \
    --vram $VM_VRAM \
    --cpus $VM_CPUS \
    --clipboard bidirectional \
    --draganddrop bidirectional \
    --boot1 dvd \
    --boot2 disk \
    --boot3 none \
    --boot4 none \
    --firmware efi \
    --rtcuseutc on \
    --graphicscontroller vmsvga \
    --audio-driver pulse \
    --audiocontroller hda \
    --audio-enabled on

# Activer USB 3.0 (IMPORTANT pour Cronus Zen)
VBoxManage modifyvm "$VM_NAME" --usb on --usbehci on --usbxhci on

# Créer le disque virtuel
VBoxManage createhd --filename "$VM_DIR/$VM_NAME/$VM_NAME.vdi" --size $VM_DISK_SIZE --variant Standard

# Ajouter contrôleur SATA
VBoxManage storagectl "$VM_NAME" --name "SATA" --add sata --controller IntelAhci --portcount 2

# Attacher le disque
VBoxManage storageattach "$VM_NAME" --storagectl "SATA" --port 0 --device 0 --type hdd --medium "$VM_DIR/$VM_NAME/$VM_NAME.vdi"

# Attacher l'ISO Windows 11
VBoxManage storageattach "$VM_NAME" --storagectl "SATA" --port 1 --device 0 --type dvddrive --medium "$ISO_PATH"

# Configuration réseau (NAT par défaut)
VBoxManage modifyvm "$VM_NAME" --nic1 nat

# Activer PAE/NX (requis pour Windows 11)
VBoxManage modifyvm "$VM_NAME" --pae on

# Bypass TPM requirement Windows 11 (IMPORTANT!)
VBoxManage modifyvm "$VM_NAME" --tpm-type 2.0
VBoxManage modifyvm "$VM_NAME" --secure-boot on

echo "✅ VM $VM_NAME créée avec succès!"
echo "📁 Emplacement: $VM_DIR/$VM_NAME"
echo ""
echo "🚀 Pour démarrer : VBoxManage startvm '$VM_NAME' --type gui"
echo "   Ou utilisez l'interface graphique VirtualBox"
```

**Rendre le script exécutable et lancer :**

```bash
chmod +x ~/create-win11-vm.sh
~/create-win11-vm.sh
```

---

## 🎮 Étape 4 : Démarrer et Installer Windows 11

### Lancer la VM

```bash
# Via ligne de commande
VBoxManage startvm "Windows11-CronusZen" --type gui

# Ou via l'interface graphique
virtualbox &
# Puis double-cliquez sur la VM
```

### Installation Windows 11

1. **Démarrage sur ISO** : La VM boot sur l'ISO Windows 11
2. **Langue et clavier** : Choisissez Français/English
3. **Installer maintenant**
4. **Clé produit** : 
   - Cliquez "Je n'ai pas de clé produit"
   - Vous pourrez activer plus tard
5. **Version** : Choisissez "Windows 11 Home" ou "Pro"
6. **Type d'installation** : "Personnalisée"
7. **Disque** : Sélectionnez le disque virtuel (80 GB)
8. **Installation** : Patientez 15-20 minutes
9. **Configuration initiale** : 
   - Créez un compte local (pas besoin de compte Microsoft)
   - Désactivez les trucs inutiles (Cortana, télémétrie, etc.)

### Bypass TPM/Secure Boot (si problème)

Si Windows 11 refuse de s'installer :

**Pendant l'installation, appuyez sur Shift+F10** pour ouvrir CMD, puis :

```cmd
reg add HKLM\SYSTEM\Setup\LabConfig /v BypassTPMCheck /t REG_DWORD /d 1 /f
reg add HKLM\SYSTEM\Setup\LabConfig /v BypassSecureBootCheck /t REG_DWORD /d 1 /f
reg add HKLM\SYSTEM\Setup\LabConfig /v BypassRAMCheck /t REG_DWORD /d 1 /f
exit
```

Puis continuez l'installation normalement.

---

## 🔌 Étape 5 : Configuration USB pour Cronus Zen

### Une fois Windows 11 installé :

1. **Éteindre la VM** (depuis Windows : Démarrer → Arrêter)

2. **Créer un filtre USB pour Cronus Zen** :

```bash
# Brancher votre Cronus Zen sur le serveur Ubuntu

# Lister les périphériques USB
lsusb

# Cherchez le Cronus Zen (exemple : "Collective Minds")
# Notez le VendorID et ProductID (format: 1234:5678)

# Ajouter un filtre USB permanent à la VM
VBoxManage usbfilter add 0 \
    --target "Windows11-CronusZen" \
    --name "Cronus Zen" \
    --vendorid "2e24" \
    --productid "0652"
    
# Note: Remplacez vendorid et productid par les vraies valeurs
```

3. **Redémarrer la VM**

4. **Dans Windows :** Le Cronus Zen sera automatiquement passé à la VM !

---

## 📦 Étape 6 : Installer Cronus Zen Studio dans Windows

### Dans la VM Windows 11 :

1. **Ouvrir un navigateur** (Edge)
2. **Aller sur** : https://www.cronusmax.com/
3. **Télécharger** : Cronus Zen Studio (dernière version)
4. **Installer** : Double-cliquez sur le .exe
5. **Brancher le Zen** : Il sera détecté automatiquement
6. **Mettre à jour le firmware** si demandé

---

## ⚙️ Optimisations Recommandées

### Dans VirtualBox

```bash
# Allouer plus de RAM si besoin (16 GB)
VBoxManage modifyvm "Windows11-CronusZen" --memory 16384

# Allouer plus de CPU (6 cœurs)
VBoxManage modifyvm "Windows11-CronusZen" --cpus 6

# Activer la 3D acceleration
VBoxManage modifyvm "Windows11-CronusZen" --accelerate3d on

# Augmenter VRAM pour meilleure performance graphique
VBoxManage modifyvm "Windows11-CronusZen" --vram 256
```

### Dans Windows 11

1. **Désactiver les effets visuels** :
   - Panneau de configuration → Système → Paramètres système avancés
   - Performances → Ajuster pour de meilleures performances

2. **Désactiver Windows Update automatique** (optionnel)

3. **Installer Guest Additions** :
   - Dans la VM : Menu Périphériques → Insérer l'image CD des Additions invité
   - Installer depuis le CD virtuel
   - Redémarrer
   - Bénéfice : Meilleure résolution, copier-coller, partage de fichiers

---

## 🎯 Résumé des Commandes Rapides

```bash
# Démarrer la VM
VBoxManage startvm "Windows11-CronusZen" --type gui

# Arrêter la VM (depuis Ubuntu)
VBoxManage controlvm "Windows11-CronusZen" poweroff

# Sauvegarder l'état (suspend)
VBoxManage controlvm "Windows11-CronusZen" savestate

# Liste des VMs
VBoxManage list vms

# Info sur une VM
VBoxManage showvminfo "Windows11-CronusZen"

# Liste périphériques USB disponibles
VBoxManage list usbhost

# Snapshot (sauvegarde)
VBoxManage snapshot "Windows11-CronusZen" take "Fresh Install"
```

---

## 🔧 Dépannage

### Problème : "VT-x is not available"

```bash
# Vérifier la virtualisation
egrep -c '(vmx|svm)' /proc/cpuinfo
# Si > 0, c'est activé

# Si besoin, activer dans le BIOS :
# Redémarrer → Appuyer sur Del/F2 → Chercher "Virtualization" → Activer
```

### Problème : USB ne fonctionne pas

```bash
# Vérifier que vous êtes dans le groupe vboxusers
groups $USER

# Si "vboxusers" n'apparaît pas :
sudo usermod -aG vboxusers $USER
# Puis redémarrer la session
```

### Problème : VM très lente

1. Allouer plus de RAM et CPU (voir Optimisations)
2. Activer 3D acceleration
3. Installer Guest Additions
4. Désactiver Hyper-V dans Windows (si activé)

---

## 📱 Accès à Distance (Optionnel)

Si vous voulez accéder à la VM depuis un autre PC :

```bash
# Activer RDP dans la VM
VBoxManage modifyvm "Windows11-CronusZen" --vrde on --vrdeport 5000

# Se connecter depuis un autre PC :
# Utilisez un client RDP et connectez-vous à :
# IP_DU_SERVEUR:5000
```

---

## ✅ Checklist Finale

- [ ] VirtualBox installé
- [ ] Extension Pack installé
- [ ] Utilisateur dans groupe vboxusers
- [ ] ISO Windows 11 téléchargé
- [ ] VM créée avec script
- [ ] Windows 11 installé dans la VM
- [ ] Guest Additions installées
- [ ] Cronus Zen détecté en USB
- [ ] Zen Studio installé
- [ ] Firmware Zen à jour

---

## 🎮 Profitez de votre Cronus Zen !

Une fois tout configuré :
1. Démarrez la VM quand vous voulez utiliser le Zen
2. Le Zen sera automatiquement connecté à Windows
3. Programmez vos scripts dans Zen Studio
4. Fermez la VM quand terminé (savestate pour plus rapide)

**Temps total d'installation : ~1-2 heures**

Besoin d'aide ? Demandez-moi ! 🚀
