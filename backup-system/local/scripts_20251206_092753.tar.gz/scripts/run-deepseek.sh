#!/bin/bash
docker exec -it ollama ollama run deepseek-coder-v2:16b
