#!/bin/bash
cd ~/VMs/ISOs

echo "🌐 Téléchargement de Windows 11 ISO officiel Microsoft..."
echo "⏱️  Cela peut prendre 10-20 minutes (environ 5-6 GB)"

# Utiliser le lien direct Microsoft (24H2 - dernière version)
wget --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" \
     --show-progress \
     -O Windows11.iso \
     "https://software.download.prss.microsoft.com/dbazure/Win11_24H2_English_x64.iso?t=7ea5cd18-95c4-49ae-a47b-dc768a73bbb8&P1=1729189548&P2=601&P3=2&P4=hDpGQtUHUxNvr%2bZuqFKYLFqh2Kx6YbVPMn6W3l7DFJM9CwgJa9Kp0r9QIk2y2n3Tbb%2bPv2aKUJyA5MqB%2fwIQzQ%3d%3d"

if [ $? -eq 0 ]; then
    SIZE=$(du -h Windows11.iso | cut -f1)
    echo "✅ Téléchargement terminé ! Taille: $SIZE"
else
    echo "❌ Échec du téléchargement"
    exit 1
fi
