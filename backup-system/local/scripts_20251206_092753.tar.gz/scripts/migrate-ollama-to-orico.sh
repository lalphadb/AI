#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# Script : Migration Ollama vers disque ORICO (nvme0n1)
# Date : 2 décembre 2025
# ═══════════════════════════════════════════════════════════════

set -e  # Arrêter en cas d'erreur

echo "🚀 Migration des modèles Ollama vers disque ORICO"
echo "═══════════════════════════════════════════════════"
echo ""

# ─────────────────────────────────────────────────────────────
# ÉTAPE 1 : Vérifier que c'est bien le bon disque
# ─────────────────────────────────────────────────────────────
echo "📋 Vérification du disque ORICO..."
DISK="/dev/nvme0n1"
DISK_MODEL=$(lsblk -nd -o MODEL $DISK 2>/dev/null || echo "Unknown")

echo "   Disque : $DISK"
echo "   Modèle : $DISK_MODEL"

if [[ ! "$DISK_MODEL" =~ "ORICO" ]]; then
    echo "⚠️  ATTENTION : Le disque ne semble pas être un ORICO !"
    read -p "   Continuer quand même ? (oui/non) : " confirm
    if [[ "$confirm" != "oui" ]]; then
        echo "❌ Annulé."
        exit 1
    fi
fi

# ─────────────────────────────────────────────────────────────
# ÉTAPE 2 : Confirmation finale
# ─────────────────────────────────────────────────────────────
echo ""
echo "⚠️  ATTENTION : Ceci va FORMATER $DISK"
echo "   TOUTES LES DONNÉES sur ce disque seront EFFACÉES !"
echo ""
read -p "   Taper 'FORMATER' pour confirmer : " confirm

if [[ "$confirm" != "FORMATER" ]]; then
    echo "❌ Annulé."
    exit 1
fi

# ─────────────────────────────────────────────────────────────
# ÉTAPE 3 : Trouver l'emplacement actuel d'Ollama
# ─────────────────────────────────────────────────────────────
echo ""
echo "🔍 Recherche des modèles Ollama..."

# Chercher dans les emplacements possibles
OLLAMA_MODELS=""
for location in \
    "/usr/share/ollama/.ollama/models" \
    "/var/lib/ollama/models" \
    "$HOME/.ollama/models" \
    "/root/.ollama/models"; do

    if sudo test -d "$location" 2>/dev/null; then
        SIZE=$(sudo du -sh "$location" 2>/dev/null | cut -f1)
        if [[ -n "$SIZE" ]] && [[ "$SIZE" != "0" ]]; then
            echo "   ✅ Trouvé : $location ($SIZE)"
            OLLAMA_MODELS="$location"
            break
        fi
    fi
done

if [[ -z "$OLLAMA_MODELS" ]]; then
    echo "   ℹ️  Aucun modèle trouvé, on créera le dossier directement"
    OLLAMA_MODELS="/usr/share/ollama/.ollama/models"
fi

# ─────────────────────────────────────────────────────────────
# ÉTAPE 4 : Arrêter Ollama
# ─────────────────────────────────────────────────────────────
echo ""
echo "🛑 Arrêt d'Ollama..."
sudo systemctl stop ollama
sleep 2

# ─────────────────────────────────────────────────────────────
# ÉTAPE 5 : Formater le disque ORICO
# ─────────────────────────────────────────────────────────────
echo ""
echo "💾 Formatage du disque ORICO en ext4..."
echo "   Suppression des partitions existantes..."
sudo wipefs -a $DISK

echo "   Création d'une nouvelle partition..."
sudo parted -s $DISK mklabel gpt
sudo parted -s $DISK mkpart primary ext4 0% 100%

echo "   Formatage en ext4..."
sudo mkfs.ext4 -F ${DISK}p1 -L "OLLAMA_MODELS"

# ─────────────────────────────────────────────────────────────
# ÉTAPE 6 : Créer le point de montage
# ─────────────────────────────────────────────────────────────
echo ""
echo "📁 Création du point de montage..."
MOUNT_POINT="/mnt/ollama-models"
sudo mkdir -p $MOUNT_POINT

# ─────────────────────────────────────────────────────────────
# ÉTAPE 7 : Monter le disque
# ─────────────────────────────────────────────────────────────
echo "🔗 Montage du disque..."
sudo mount ${DISK}p1 $MOUNT_POINT

# Vérifier le montage
if ! mountpoint -q $MOUNT_POINT; then
    echo "❌ Erreur : Le disque n'a pas pu être monté !"
    exit 1
fi

echo "   ✅ Disque monté sur $MOUNT_POINT"

# ─────────────────────────────────────────────────────────────
# ÉTAPE 8 : Configurer le montage automatique
# ─────────────────────────────────────────────────────────────
echo ""
echo "⚙️  Configuration du montage automatique..."
UUID=$(sudo blkid -s UUID -o value ${DISK}p1)

# Sauvegarder fstab
sudo cp /etc/fstab /etc/fstab.backup-$(date +%Y%m%d-%H%M%S)

# Ajouter la ligne si elle n'existe pas
if ! grep -q "$UUID" /etc/fstab; then
    echo "UUID=$UUID $MOUNT_POINT ext4 defaults,noatime 0 2" | sudo tee -a /etc/fstab
    echo "   ✅ Ajouté à /etc/fstab"
else
    echo "   ℹ️  Déjà dans /etc/fstab"
fi

# ─────────────────────────────────────────────────────────────
# ÉTAPE 9 : Déplacer les modèles (si existants)
# ─────────────────────────────────────────────────────────────
echo ""
if sudo test -d "$OLLAMA_MODELS" && [[ "$(sudo du -s "$OLLAMA_MODELS" | cut -f1)" -gt 1000 ]]; then
    echo "📦 Déplacement des modèles existants..."
    sudo rsync -avh --progress "$OLLAMA_MODELS/" "$MOUNT_POINT/"

    # Sauvegarder l'ancien dossier
    BACKUP_DIR="${OLLAMA_MODELS}.backup-$(date +%Y%m%d-%H%M%S)"
    sudo mv "$OLLAMA_MODELS" "$BACKUP_DIR"
    echo "   ✅ Ancien dossier sauvegardé : $BACKUP_DIR"
else
    echo "📁 Création de la structure de dossiers..."
fi

# Créer la structure nécessaire
sudo mkdir -p "$MOUNT_POINT/manifests"
sudo mkdir -p "$MOUNT_POINT/blobs"

# ─────────────────────────────────────────────────────────────
# ÉTAPE 10 : Configurer Ollama pour utiliser le nouveau chemin
# ─────────────────────────────────────────────────────────────
echo ""
echo "⚙️  Configuration d'Ollama..."

# Créer le dossier de override systemd si nécessaire
sudo mkdir -p /etc/systemd/system/ollama.service.d

# Créer le fichier de configuration
cat << EOF | sudo tee /etc/systemd/system/ollama.service.d/override.conf
[Service]
Environment="OLLAMA_MODELS=$MOUNT_POINT"
EOF

echo "   ✅ Variable OLLAMA_MODELS=$MOUNT_POINT configurée"

# ─────────────────────────────────────────────────────────────
# ÉTAPE 11 : Définir les permissions
# ─────────────────────────────────────────────────────────────
echo ""
echo "🔐 Configuration des permissions..."
sudo chown -R ollama:ollama $MOUNT_POINT
sudo chmod -R 755 $MOUNT_POINT

# ─────────────────────────────────────────────────────────────
# ÉTAPE 12 : Redémarrer Ollama
# ─────────────────────────────────────────────────────────────
echo ""
echo "🔄 Redémarrage d'Ollama..."
sudo systemctl daemon-reload
sudo systemctl start ollama

# Attendre qu'Ollama soit prêt
echo "   Attente du démarrage d'Ollama..."
for i in {1..30}; do
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        echo "   ✅ Ollama est prêt !"
        break
    fi
    sleep 1
done

# ─────────────────────────────────────────────────────────────
# ÉTAPE 13 : Vérification finale
# ─────────────────────────────────────────────────────────────
echo ""
echo "🧪 Vérification finale..."
echo ""
echo "📊 Espace disque ORICO :"
df -h $MOUNT_POINT

echo ""
echo "📦 Modèles Ollama :"
ollama list

echo ""
echo "═══════════════════════════════════════════════════"
echo "✅ MIGRATION TERMINÉE AVEC SUCCÈS !"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📍 Emplacement des modèles : $MOUNT_POINT"
echo "💾 Disque : $DISK (ORICO avec dissipateur)"
echo "📊 Espace disponible : $(df -h $MOUNT_POINT | tail -1 | awk '{print $4}')"
echo ""
echo "🔥 Prochaine étape : Installer qwen3-vl:32b"
echo "   Commande : ollama pull qwen3-vl:32b"
echo ""
