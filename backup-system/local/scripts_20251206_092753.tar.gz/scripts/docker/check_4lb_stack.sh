#!/usr/bin/env bash
set -euo pipefail

echo "═══════════════════════════════════════════════════"
echo "🔍 Vérification Stack 4LB"
echo "═══════════════════════════════════════════════════"
echo ""

echo "📦 [1/5] Conteneurs Docker :"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "🌐 [2/5] Traefik en cours d'exécution ?"
if docker ps | grep -q traefik; then
    echo "✅ Traefik est actif"
else
    echo "❌ Traefik n'est PAS actif !"
fi

echo ""
echo "📋 [3/5] Logs Traefik (40 dernières lignes) :"
docker logs --tail=40 traefik 2>&1 || echo "❌ Impossible de lire les logs Traefik"

echo ""
echo "🔗 [4/5] Test des services exposés via Traefik :"
declare -a urls=(
    "https://4lb.ca"
    "https://code.4lb.ca"
    "https://llm.4lb.ca"
    "https://grafana.4lb.ca"
    "https://prometheus.4lb.ca"
    "https://jsr.4lb.ca"
)

for url in "${urls[@]}"; do
    echo -n "  → $url ... "
    if http_code=$(curl -k -s -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null); then
        if [[ "$http_code" == "200" ]] || [[ "$http_code" == "302" ]] || [[ "$http_code" == "301" ]]; then
            echo "✅ HTTP $http_code"
        else
            echo "⚠️  HTTP $http_code"
        fi
    else
        echo "❌ Échec connexion"
    fi
done

echo ""
echo "💾 [5/5] Espace disque ORICO :"
df -h /mnt/ollama-models 2>/dev/null || echo "⚠️  Disque ORICO non monté"

echo ""
echo "═══════════════════════════════════════════════════"
echo "✅ Vérification terminée"
echo "═══════════════════════════════════════════════════"
