#!/bin/bash
# Configuration des alertes email (Fail2Ban + Logwatch)

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Ce script doit être exécuté en tant que root${NC}"
    echo "Utilisez: sudo bash $0"
    exit 1
fi

echo -e "${CYAN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          Configuration Alertes Email                      ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Demander l'email
read -p "Entrez votre adresse email pour recevoir les alertes: " email

if [ -z "$email" ]; then
    echo -e "${RED}Email requis !${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}[1/3] Configuration Fail2Ban...${NC}"

# Backup de la config actuelle
if [ -f /etc/fail2ban/jail.local ]; then
    cp /etc/fail2ban/jail.local /etc/fail2ban/jail.local.backup.$(date +%Y%m%d)
fi

# Configurer Fail2Ban avec alertes email
cat > /etc/fail2ban/jail.local << FAIL2BANEOF
[DEFAULT]
# Email pour les alertes
destemail = $email
sender = fail2ban@$(hostname)

# Action avec email
action = %(action_mwl)s

# Ban time: 1 heure
bantime = 3600

# Fenêtre: 10 minutes
findtime = 600

# Max tentatives
maxretry = 5

# IPs à ignorer
ignoreip = 127.0.0.1/8 ::1 10.10.10.0/25 192.168.1.0/26

[sshd]
enabled = true
port = 22
logpath = /var/log/auth.log
maxretry = 3
bantime = 7200
action = %(action_mwl)s

[postfix]
enabled = true
port = smtp,465,submission
logpath = /var/log/mail.log
maxretry = 5

[dovecot]
enabled = true
port = pop3,pop3s,imap,imaps,submission,465,sieve
logpath = /var/log/mail.log
maxretry = 5

[nginx-http-auth]
enabled = true
port = http,https
logpath = /var/log/nginx/error.log

[nginx-badbots]
enabled = true
port = http,https
logpath = /var/log/nginx/access.log
maxretry = 2

[recidive]
enabled = true
logpath = /var/log/fail2ban.log
banaction = %(banaction_allports)s
bantime = 604800
findtime = 86400
maxretry = 3
FAIL2BANEOF

systemctl restart fail2ban

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Fail2Ban configuré avec alertes email${NC}"
else
    echo -e "${RED}✗ Erreur lors de la configuration Fail2Ban${NC}"
fi

echo ""
echo -e "${YELLOW}[2/3] Installation et configuration Logwatch...${NC}"

# Installer Logwatch
apt install -y logwatch

# Configurer Logwatch
mkdir -p /etc/logwatch/conf
cat > /etc/logwatch/conf/logwatch.conf << LOGWATCHEOF
# Email de destination
MailTo = $email

# Email d'envoi
MailFrom = logwatch@$(hostname)

# Niveau de détail (Low, Med, High)
Detail = High

# Service de mail
mailer = "sendmail -t"

# Range (Yesterday, Today, All)
Range = yesterday

# Format (text ou html)
Format = text

# Services à surveiller
Service = All
LOGWATCHEOF

# Créer le cron job
cat > /etc/cron.daily/00logwatch << 'CRONEOF'
#!/bin/bash
/usr/sbin/logwatch --output mail
CRONEOF
chmod +x /etc/cron.daily/00logwatch

echo -e "${GREEN}✓ Logwatch installé et configuré${NC}"

echo ""
echo -e "${YELLOW}[3/3] Configuration du système mail (postfix)...${NC}"

# Vérifier si postfix est installé
if ! command -v postfix &> /dev/null; then
    echo "Installation de postfix..."
    DEBIAN_FRONTEND=noninteractive apt install -y postfix mailutils
fi

# Configuration basique postfix pour relayer via votre serveur mail
cat > /etc/postfix/main.cf.minimal << 'POSTFIXEOF'
# Configuration minimaliste Postfix pour envoi d'alertes
myhostname = $(hostname -f)
relayhost = [127.0.0.1]:25
inet_interfaces = loopback-only
inet_protocols = ipv4
POSTFIXEOF

echo -e "${GREEN}✓ Postfix configuré${NC}"

# Tester l'envoi d'un email
echo ""
echo -e "${YELLOW}Test d'envoi d'email...${NC}"
echo "Ceci est un email de test depuis le serveur $(hostname)" | mail -s "Test Alertes - Sécurité Serveur" $email 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Email de test envoyé à $email${NC}"
    echo -e "${GREEN}  Vérifiez votre boîte mail (peut prendre quelques minutes)${NC}"
else
    echo -e "${YELLOW}⚠ Problème lors de l'envoi du test${NC}"
    echo "  Vérifiez que votre serveur mail Docker fonctionne"
fi

echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              Configuration Terminée !                      ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}Alertes configurées pour: ${CYAN}$email${NC}"
echo ""
echo -e "${YELLOW}Vous recevrez des emails pour:${NC}"
echo "  • Bannissements Fail2Ban"
echo "  • Rapport quotidien Logwatch"
echo "  • Tentatives de connexion suspectes"
echo ""
echo -e "${YELLOW}Commandes utiles:${NC}"
echo "  • Statut Fail2Ban: ${CYAN}sudo fail2ban-client status${NC}"
echo "  • Tester Logwatch: ${CYAN}sudo /usr/sbin/logwatch --detail High --mailto $email --range today${NC}"
echo "  • Voir les bans: ${CYAN}sudo fail2ban-client status sshd${NC}"
echo ""
