#!/bin/bash

# Script pour ajouter une clé SSH au UDM-Pro via l'API UniFi

echo "🔑 Ajout de clé SSH au UDM-Pro via API UniFi"
echo ""

# Configuration
UDM_HOST="10.10.10.1"
UDM_PORT="443"

# Demander la clé API
echo "📋 Entrez votre clé API UniFi (celle que vous avez créée dans l'interface web):"
read -r API_KEY

# Lire la clé SSH publique
SSH_PUB_KEY=$(cat ~/.ssh/id_rsa_udm.pub)

if [ -z "$SSH_PUB_KEY" ]; then
    echo "❌ Clé SSH publique non trouvée dans ~/.ssh/id_rsa_udm.pub"
    exit 1
fi

echo ""
echo "📤 Envoi de la clé SSH au UDM-Pro..."

# Ajouter la clé SSH via l'API
# Note: Cette approche peut varier selon la version UniFi OS
# Méthode 1: Via l'API system
RESPONSE=$(curl -k -s -X POST \
    "https://${UDM_HOST}:${UDM_PORT}/proxy/network/api/s/default/cmd/system" \
    -H "X-API-KEY: ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{
        \"cmd\": \"add-ssh-key\",
        \"key\": \"${SSH_PUB_KEY}\"
    }")

echo "Réponse API: $RESPONSE"

# Vérifier si la commande a réussi
if echo "$RESPONSE" | grep -q "ok"; then
    echo ""
    echo "✅ Clé SSH ajoutée avec succès!"
    echo ""
    echo "🧪 Testez maintenant:"
    echo "   ssh -i ~/.ssh/id_rsa_udm root@${UDM_HOST}"
else
    echo ""
    echo "⚠️  La commande API n'a pas fonctionné comme prévu."
    echo "   Vous devrez ajouter la clé manuellement via l'interface web."
fi
