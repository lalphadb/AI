# 📚 INDEX DOCUMENTATION

> **Chemin** : `/home/lalpha/documentation/`
> **Dernière mise à jour** : 14 décembre 2025

---

## 🎯 QUICK START - Unified Stack

```bash
# Gérer l'infrastructure
cd /home/lalpha/projets/infrastructure/unified-stack

./stack.sh up              # Démarrer tout
./stack.sh status          # Voir l'état
./stack.sh logs <service>  # Voir les logs
./stack.sh restart <svc>   # Redémarrer
./stack.sh test            # Tester les URLs
```

---

## 🏗️ Architecture

| Fichier | Description |
|---------|-------------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Vue complète de l'infrastructure (Unified Stack) |
| [CONTEXTE-SERVEUR.md](CONTEXTE-SERVEUR.md) | Prompt à copier pour les IA |
| [PROCEDURES-IA-SECURISEES.md](PROCEDURES-IA-SECURISEES.md) | Règles pour agents IA |

---

## 🤖 Agents IA

| Projet | Emplacement | Description |
|--------|-------------|-------------|
| **AI Orchestrator v2.5** | `/home/lalpha/projets/ai-tools/ai-orchestrator/` | Agent autonome avec mémoire sémantique (https://ai.4lb.ca) |
| **Self-Improvement** | `/home/lalpha/projets/ai-tools/self-improvement/` | Module auto-amélioration |
| **MCP Servers** | `/home/lalpha/projets/ai-tools/mcp-servers/` | 33 outils pour Claude Desktop |

---

## 📖 Guides Techniques

| Fichier | Description |
|---------|-------------|
| [AI-ORCHESTRATOR.md](guides/AI-ORCHESTRATOR.md) | 🆕 Guide Agent IA v2.5 (33 outils + mémoire sémantique) |
| [UNIFIED-STACK.md](guides/UNIFIED-STACK.md) | Guide stack unifiée |
| [MCP-SERVER-UDM-PRO.md](guides/MCP-SERVER-UDM-PRO.md) | Serveurs MCP et connexion UDM-Pro |
| [INSTALLATION-CONTINUE-DEV.md](guides/INSTALLATION-CONTINUE-DEV.md) | Agent IA Continue.dev |
| [README-SECURITE.md](guides/README-SECURITE.md) | Guide de sécurité serveur |
| [INSTALLATION_LLM_GUIDE.md](guides/INSTALLATION_LLM_GUIDE.md) | Installation LLM (Ollama, CUDA) |

---

## 📝 Comptes-rendus

| Fichier | Date | Description |
|---------|------|-------------|
| [SESSION-2025-12-14-MEMOIRE-SEMANTIQUE.md](comptes-rendus/SESSION-2025-12-14-MEMOIRE-SEMANTIQUE.md) | 14 déc | 🆕 Mémoire sémantique ChromaDB |
| [SESSION-2025-12-07-UNIFIED-STACK.md](comptes-rendus/SESSION-2025-12-07-UNIFIED-STACK.md) | 07 déc | Migration vers Unified Stack |
| [SESSION-2025-12-05-AGENT-4LB.md](comptes-rendus/SESSION-2025-12-05-AGENT-4LB.md) | 05 déc | Validation Agent 4LB |
| [SESSION-2025-12-02-CONTINUE-DEV.md](comptes-rendus/SESSION-2025-12-02-CONTINUE-DEV.md) | 02 déc | Migration Continue.dev |

---

## 🌐 Services Principaux

| Service | URL | Description |
|---------|-----|-------------|
| **AI Orchestrator** | https://ai.4lb.ca | Agent IA autonome v2.5 avec mémoire |
| **Open WebUI** | https://llm.4lb.ca | Chat LLM rapide |
| **Grafana** | https://grafana.4lb.ca | Dashboards |
| **Prometheus** | https://prometheus.4lb.ca | Métriques |
| **Code Server** | https://code.4lb.ca | IDE VS Code web |
| **JSR Dev** | https://jsr.4lb.ca | Site client dev |
| **JSR Prod** | https://jsr-solutions.ca | Site client production |
| **Traefik** | https://traefik.4lb.ca | Dashboard proxy |

---

## 🗂️ Structure Infrastructure

```
/home/lalpha/projets/infrastructure/
├── unified-stack/              # ⭐ STACK PRINCIPALE
│   ├── docker-compose.yml      # 14 services
│   ├── .env                    # Variables
│   ├── stack.sh                # Script gestion
│   └── configs/
│       ├── prometheus/
│       └── traefik/
│
└── 4lb-docker-stack/           # 📦 Archive (ancienne)
```

---

## 🔗 Liens Utiles

### Dossiers Principaux
- **Unified Stack** : `/home/lalpha/projets/infrastructure/unified-stack/`
- **AI Tools** : `/home/lalpha/projets/ai-tools/`
- **MCP Servers** : `/home/lalpha/projets/ai-tools/mcp-servers/`
- **Clients** : `/home/lalpha/projets/clients/`

### Fichiers de Config
- **Docker Compose** : `/home/lalpha/projets/infrastructure/unified-stack/docker-compose.yml`
- **Prometheus** : `/home/lalpha/projets/infrastructure/unified-stack/configs/prometheus/prometheus.yml`
- **Claude MCP** : `~/.config/Claude/claude_desktop_config.json`

---

## 📊 Résumé Infrastructure

| Métrique | Valeur |
|----------|--------|
| **Conteneurs** | 14 services |
| **Réseau** | unified-net (192.168.200.0/24) |
| **Modèles LLM** | 5 locaux + 3 cloud (~70 GB) |
| **Outils MCP** | 33 |
| **Outils AI Orchestrator** | 33 |
| **Mémoire IA** | ChromaDB (sémantique) |

---

## 🧠 Nouveautés v2.5 (14 décembre 2025)

### Mémoire Sémantique
L'AI Orchestrator dispose maintenant d'une **mémoire persistante** basée sur ChromaDB :

- **Stockage** : `memory_store(key, value)` → ChromaDB avec embeddings
- **Recherche** : `memory_recall(query)` → Recherche par similarité
- **Embeddings** : all-MiniLM-L6-v2 (ONNX)
- **Collection** : `ai_orchestrator_memory`

### Commandes utiles
```bash
# Vérifier le nombre de mémoires
docker exec ai-orchestrator-backend python3 -c "
import chromadb
client = chromadb.HttpClient(host='chromadb', port=8000)
col = client.get_or_create_collection('ai_orchestrator_memory')
print(f'Mémoires: {col.count()}')
"
```

---

*Index mis à jour le 14 décembre 2025*
