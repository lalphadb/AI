# 🚀 Installation Continue.dev - Agent IA Autonome

> **Date** : 2 décembre 2025
> **Version** : Continue.dev v0.9+
> **Objectif** : Agent IA autonome dans VS Code avec accès aux 33 outils MCP

---

## 📋 Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Prérequis](#prérequis)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Utilisation](#utilisation)
6. [Outils MCP disponibles](#outils-mcp-disponibles)
7. [Dépannage](#dépannage)

---

## 🎯 Vue d'ensemble

**Continue.dev** est un agent IA autonome qui s'intègre dans VS Code et te permet :

- ✅ **Chat avec Ollama** (qwen, deepseek, llama-vision)
- ✅ **Utiliser Claude API** pour les tâches complexes
- ✅ **Accès aux 33 outils MCP** (Docker, fichiers, UDM-Pro, ChromaDB, système)
- ✅ **Génération/édition de code** intelligente
- ✅ **Autocomplétion** avec IA
- ✅ **Agent autonome** comme Claude Code

**Architecture :**

```
┌─────────────────────────────────────┐
│         VS Code Desktop             │
│                                     │
│  ┌───────────────────────────────┐ │
│  │      Continue.dev             │ │
│  │    (Extension installée)      │ │
│  └───────────────────────────────┘ │
│              │                      │
│              ├─────────┬───────────┤
│              ▼         ▼           ▼
│          Ollama    Claude API   MCP Servers
│       (localhost)  (optionnel)  (33 outils)
└─────────────────────────────────────┘
```

---

## ✅ Prérequis

Tout est déjà prêt sur ton serveur !

- ✅ **VS Code Desktop** installé
- ✅ **Ollama** (localhost:11434) avec 4 modèles
- ✅ **4 MCP Servers** (ubuntu-mcp, filesystem-mcp, udm-pro-mcp, chromadb-mcp)
- ✅ **Fichiers de config** créés dans `~/.continue/`

---

## 📥 Installation

### Étape 1 : Installer l'extension Continue.dev

**Méthode 1 : Via VS Code (recommandé)**

1. Ouvre **VS Code**
2. Va dans **Extensions** (Ctrl+Shift+X)
3. Cherche "**Continue**"
4. Clique sur **Install**

**Méthode 2 : Via terminal**

```bash
code --install-extension continue.continue
```

### Étape 2 : Vérifier l'installation

1. Redémarre VS Code
2. Tu devrais voir l'icône **Continue** dans la barre latérale gauche
3. Clique dessus pour ouvrir le panneau

---

## ⚙️ Configuration

Les fichiers de configuration sont **déjà créés** dans `~/.continue/` !

### Fichier 1 : `~/.continue/config.json`

**Modèles configurés :**

| Modèle | Usage | Source |
|--------|-------|--------|
| Qwen 2.5 Coder 32B | Code principal | Ollama (local) |
| DeepSeek Coder 33B | Édition de code | Ollama (local) |
| Llama 3.2 Vision 11B | Analyse d'images | Ollama (local) |
| Claude Sonnet 4 | Chat complexe | API (optionnel) |

**Pour activer Claude API (optionnel) :**

1. Ouvre `~/.continue/config.json`
2. Trouve `"apiKey": "ANTHROPIC_API_KEY"`
3. Remplace par ta vraie clé API Anthropic
4. Ou laisse vide pour utiliser uniquement Ollama

### Fichier 2 : `~/.continue/mcp.json`

**MCP Servers configurés :**

| Serveur | Outils | Statut |
|---------|--------|--------|
| ubuntu-server | 12 outils système | ✅ Actif |
| filesystem | 4 outils fichiers | ✅ Actif |
| udm-pro | 8 outils UniFi | ✅ Actif |
| chromadb | 9 outils vectoriels | ✅ Actif |

**Total : 33 outils disponibles !**

---

## 🎮 Utilisation

### Démarrer Continue.dev

1. Ouvre **VS Code**
2. Clique sur l'icône **Continue** (barre latérale gauche)
3. Le panneau de chat s'ouvre

### Chat simple

```
Toi: Explique-moi ce fichier
```

Continue.dev va lire le fichier ouvert et l'expliquer.

### Utiliser les outils MCP

```
Toi: Liste tous les conteneurs Docker actifs
```

Continue.dev va utiliser l'outil `docker_list` du MCP server.

```
Toi: Montre-moi l'utilisation du CPU et RAM
```

Continue.dev va utiliser l'outil `system_info`.

```
Toi: Connecte-toi au UDM-Pro et montre les clients actifs
```

Continue.dev va utiliser `udm_exec` pour se connecter.

### Édition de code

```
Toi: /edit Ajoute des commentaires à cette fonction
```

Continue.dev va modifier le fichier directement.

### Autocomplétion

Juste commence à taper, Continue.dev va suggérer automatiquement !

### Commandes personnalisées

| Commande | Description |
|----------|-------------|
| `/test` | Génère des tests unitaires |
| `/docs` | Génère de la documentation |
| `/optimize` | Optimise le code |
| `/security` | Audit de sécurité |
| `/cmd` | Génère une commande shell |
| `/commit` | Génère un message de commit |

---

## 🔧 Outils MCP Disponibles

### 🖥️ Ubuntu Server (12 outils)

| Outil | Description |
|-------|-------------|
| `system_info` | CPU, RAM, disque, réseau |
| `list_processes` | Processus actifs |
| `execute_command` | Exécuter commande bash |
| `service_status` | Statut service systemd |
| `service_control` | Contrôler un service |
| `disk_usage` | Usage disque |
| `network_info` | Infos réseau |
| `log_analyzer` | Analyser logs |
| `docker_status` | Conteneurs Docker |
| `file_search` | Chercher fichiers |
| `security_check` | Audit sécurité |
| `backup_manager` | Gestion sauvegardes |

### 📁 Filesystem (4 outils)

| Outil | Description |
|-------|-------------|
| `analyze_directory` | Fichiers inutilisés |
| `find_duplicates` | Doublons |
| `check_dependencies` | Dépendances non utilisées |
| `disk_usage` | Usage disque détaillé |

### 🌐 UDM-Pro (8 outils)

| Outil | Description |
|-------|-------------|
| `udm_connection_test` | Tester connexion SSH |
| `udm_exec` | Exécuter commande |
| `udm_status` | Statut UDM-Pro |
| `udm_network_info` | VLANs, clients |
| `udm_device_list` | Appareils UniFi |
| `udm_logs` | Logs système |
| `udm_backup_config` | Sauvegarder config |
| `udm_firewall_rules` | Règles firewall |

### 🗄️ ChromaDB (9 outils)

| Outil | Description |
|-------|-------------|
| `chroma_list_collections` | Lister collections |
| `chroma_create_collection` | Créer collection |
| `chroma_delete_collection` | Supprimer collection |
| `chroma_add_documents` | Ajouter documents |
| `chroma_query` | Recherche sémantique |
| `chroma_get_documents` | Récupérer documents |
| `chroma_delete_documents` | Supprimer documents |
| `store_memory` | Stocker un souvenir |
| `recall_memory` | Rappeler souvenirs |

---

## 🐛 Dépannage

### Continue.dev ne voit pas Ollama

**Problème** : "Cannot connect to Ollama"

**Solution** :
```bash
# Vérifier qu'Ollama tourne
systemctl status ollama

# Tester l'API
curl http://localhost:11434/api/tags
```

Si ça ne marche pas, redémarre Ollama :
```bash
sudo systemctl restart ollama
```

### MCP Servers ne se connectent pas

**Problème** : Outils MCP indisponibles

**Solution** :
```bash
# Vérifier que les MCP servers sont compilés
cd /home/lalpha/projets/ai-tools/mcp-servers/ubuntu-mcp
npm run build

cd /home/lalpha/projets/ai-tools/mcp-servers/filesystem-mcp
npm run build

cd /home/lalpha/projets/ai-tools/mcp-servers/udm-pro-mcp
npm run build

cd /home/lalpha/projets/ai-tools/mcp-servers/chromadb-mcp
npm run build
```

### Continue.dev lent

**Solution** : Utilise les modèles locaux pour les tâches simples, Claude API pour les tâches complexes.

Dans le chat Continue.dev, tu peux changer de modèle :
- Clique sur le nom du modèle en haut
- Choisis "Qwen 2.5 Coder 32B" pour les tâches rapides

### Autocomplétion ne marche pas

**Solution** :
1. Ouvre les **Settings VS Code**
2. Cherche "Continue"
3. Active "Enable Tab Autocomplete"

---

## 🎯 Exemples d'utilisation

### Exemple 1 : Analyser l'infrastructure Docker

```
Toi: Liste tous les conteneurs Docker et analyse leur état
```

Continue.dev va :
1. Utiliser `docker_status` (MCP)
2. Lister les conteneurs
3. Analyser les problèmes potentiels

### Exemple 2 : Optimiser un fichier

```
Toi: Analyse ce fichier et propose des optimisations
```

Continue.dev va :
1. Lire le fichier
2. Analyser le code
3. Suggérer des améliorations
4. Optionnellement les appliquer

### Exemple 3 : Créer un script de monitoring

```
Toi: Crée un script bash qui :
- Vérifie l'usage CPU/RAM
- Liste les conteneurs Docker
- Envoie une alerte si CPU > 80%
```

Continue.dev va :
1. Utiliser `system_info` pour comprendre le système
2. Générer le script
3. Le tester
4. L'optimiser

### Exemple 4 : Gérer le UDM-Pro

```
Toi: Connecte-toi au UDM-Pro et montre-moi les clients sur le VLAN 2
```

Continue.dev va :
1. Utiliser `udm_connection_test`
2. Exécuter `udm_network_info`
3. Filtrer les résultats pour VLAN 2

---

## 📚 Ressources

- **Documentation Continue.dev** : https://continue.dev/docs
- **MCP Servers locaux** : `/home/lalpha/projets/ai-tools/mcp-servers/`
- **Config Continue.dev** : `~/.continue/`
- **Logs VS Code** : Help → Toggle Developer Tools → Console

---

## 🎉 Résumé

Tu as maintenant un **agent IA autonome** dans VS Code avec :

- ✅ **4 modèles LLM** (3 locaux + Claude API optionnel)
- ✅ **33 outils MCP** pour gérer ton infrastructure
- ✅ **Autocomplétion IA**
- ✅ **Génération/édition de code** intelligente
- ✅ **Chat contextuel**

**Continue.dev remplace** :
- ❌ Bolt.DIY (supprimé)
- ❌ MCP Server Docker inutile (supprimé)
- ✅ Agent autonome comme Claude Code

**Tu gardes** :
- ✅ Open WebUI (llm.4lb.ca) pour chat rapide
- ✅ Claude Desktop pour utilisation standalone
- ✅ Tous tes MCP servers (maintenant utilisés par Continue.dev)

---

*Guide créé le 2 décembre 2025*
