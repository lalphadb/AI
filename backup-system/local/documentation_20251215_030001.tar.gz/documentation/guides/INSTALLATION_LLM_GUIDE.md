# 🚀 GUIDE LLM - lalpha-server-1

> **Dernière mise à jour** : 1er décembre 2025  
> **Statut** : ✅ Ollama installé et opérationnel

---

## 📋 Configuration Matérielle

| Composant | Spécification | Capacité LLM |
|-----------|---------------|--------------|
| **CPU** | AMD Ryzen 9 7900X (12c/24t @ 5.74 GHz) | ✅ Excellent |
| **GPU** | NVIDIA RTX 5070 Ti - 16 GB VRAM | ✅ Optimal |
| **RAM** | 64 GB DDR5 | ✅ Excellent |
| **Stockage** | ~1.7 TB NVMe disponibles | ✅ Excellent |
| **Driver NVIDIA** | 580.65.06 | ✅ Installé |

### Capacités LLM

Avec cette configuration, le serveur peut exécuter :

| Modèle | Taille | Statut |
|--------|--------|--------|
| Llama 3.3 70B (Q4) | ~40 GB | ✅ Supporté |
| Mixtral 8x22B (Q4) | ~80 GB | ✅ Supporté |
| Qwen2.5 72B (Q4) | ~40 GB | ✅ Supporté |
| Modèles ≤30B (FP16) | Variable | ✅ Full precision |

---

## 🤖 Ollama

### Installation

```bash
# Installer Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Vérifier
ollama --version
```

### Modèles Installés

| Modèle | Taille | Usage |
|--------|--------|-------|
| `qwen2.5-coder:32b-instruct-q4_K_M` | 19 GB | Code (principal) |
| `deepseek-coder:33b-instruct-q4_K_M` | 18 GB | Code (alternatif) |
| `llama3.2-vision:11b-instruct-q8_0` | 12 GB | Vision + texte |
| `nomic-embed-text:latest` | 274 MB | Embeddings RAG |

### Commandes Essentielles

```bash
# Lister les modèles
ollama list

# Télécharger un modèle
ollama pull qwen2.5-coder:32b

# Exécuter un modèle
ollama run qwen2.5-coder:32b

# Supprimer un modèle
ollama rm <model>

# Voir les modèles en cours
ollama ps

# API status
curl http://localhost:11434/api/tags
```

### Configuration Service

```bash
# Statut
sudo systemctl status ollama

# Redémarrer
sudo systemctl restart ollama

# Logs
journalctl -u ollama -f
```

---

## 🌐 Open WebUI

### Accès

| Type | URL |
|------|-----|
| **Public** | https://llm.4lb.ca |
| **Local** | http://localhost:8080 |

### Configuration Ollama dans Open WebUI

1. **Settings** → **Connexions** → **API Ollama**
2. Activer l'API Ollama
3. URL : `http://host.docker.internal:11434`
4. Enregistrer et recharger

### Conteneur Docker

```bash
# Statut
docker ps | grep open-webui

# Logs
docker logs -f open-webui

# Redémarrer
docker restart open-webui
```

---

## 🔧 CUDA & GPU

### Vérification GPU

```bash
# Info GPU
nvidia-smi

# Processus GPU
nvidia-smi --query-compute-apps=pid,name,used_memory --format=csv

# Surveillance continue
watch -n 1 nvidia-smi
```

### CUDA

```bash
# Version CUDA
nvcc --version

# Test CUDA
python3 -c "import torch; print(f'CUDA: {torch.cuda.is_available()}')"
```

---

## 📊 Optimisation Performance

### Paramètres Ollama

Variables d'environnement (`/etc/systemd/system/ollama.service.d/override.conf`) :

```ini
[Service]
Environment="OLLAMA_NUM_PARALLEL=4"
Environment="OLLAMA_MAX_LOADED_MODELS=2"
Environment="OLLAMA_GPU_OVERHEAD=512"
```

Appliquer :
```bash
sudo systemctl daemon-reload
sudo systemctl restart ollama
```

### Modèles Quantifiés Recommandés

| Taille Modèle | Quantification | VRAM Requis |
|---------------|----------------|-------------|
| 7B | Q8_0 | ~8 GB |
| 13B | Q4_K_M | ~8 GB |
| 33B | Q4_K_M | ~18 GB |
| 70B | Q4_K_M | ~40 GB |

---

## 🔍 Dépannage

### Ollama ne démarre pas

```bash
# Vérifier le service
sudo systemctl status ollama

# Logs détaillés
journalctl -u ollama -e

# Redémarrer
sudo systemctl restart ollama
```

### GPU non détecté

```bash
# Vérifier driver
nvidia-smi

# Réinstaller driver si nécessaire
sudo apt install --reinstall nvidia-driver-580
```

### Modèle trop lent

```bash
# Vérifier utilisation GPU
nvidia-smi

# Si CPU utilisé au lieu de GPU, vérifier CUDA
ollama run <model> --verbose
```

### Open WebUI ne voit pas les modèles

1. Vérifier Ollama : `curl http://localhost:11434/api/tags`
2. Vérifier réseau Docker : `docker network inspect traefik-net`
3. Redémarrer : `docker restart open-webui`

---

## 🔗 Références

- [ARCHITECTURE.md](../ARCHITECTURE.md) - Vue infrastructure
- [Ollama Documentation](https://ollama.com/library)
- [Open WebUI Docs](https://docs.openwebui.com/)

---

*Documentation mise à jour le 1er décembre 2025*
