# 📋 Compte-rendu Session - 29 novembre 2025

## 🎯 Objectif : Sécurisation et optimisation réseau UniFi

---

## ✅ Tâches complétées

### 1. Sécurité globale UDM-Pro

| Élément | Action | Statut |
|---------|--------|--------|
| UPnP | Désactivé | ✅ |
| NAT-PMP | Désactivé | ✅ |
| DHCP Guard | Activé sur tous les réseaux | ✅ |
| Geo-IP Filtering | Activé (CN, RU, KP, etc.) | ✅ |

### 2. Spanning Tree Protocol (STP)

| Switch | Priorité | Rôle |
|--------|----------|------|
| UDM-Pro | 4096 | Root Bridge |
| US 24 | 8192 | Distribution |
| US 8 PoE 150W | 12288 | Secondaire |
| USW Flex Mini | 32768 | Accès (limité) |

### 3. Création réseau IoT (VLAN 60)

| Paramètre | Valeur |
|-----------|--------|
| Nom | IoT |
| VLAN | 60 |
| Sous-réseau | 172.16.60.60/27 |
| DHCP Guard | ✅ Activé |
| IGMP Snooping | ✅ Activé |
| MDNS | ✅ Activé |

**WiFi IoT-Network créé :**
- Bande : 2.4 GHz uniquement
- Optimisation : Mode IoT
- Limite bande passante : 10 Mbps ↓ / 5 Mbps ↑

### 4. Création réseau Work (VLAN 70)

| Paramètre | Valeur |
|-----------|--------|
| Nom | Work |
| VLAN | 70 |
| Sous-réseau | 172.16.70.1/29 |
| Usage | Télétravail (PC entreprise isolé) |
| DHCP Guard | ✅ Activé |
| MDNS | ❌ Désactivé |

**Appareil assigné :** Work_isa (PC télétravail)

### 5. Règles Firewall créées

| Règle | Action | Source → Destination |
|-------|--------|----------------------|
| Allow Home to IoT | ✅ Autoriser | Home → IoT |
| Block IoT to All LANs | ❌ Bloquer | IoT → Home, Admin |
| Block Work to All LANs | ❌ Bloquer | Work → Home, Admin, IoT |

**Ordre des règles corrigé** (Allow avant Block)

### 6. Gaming - Xbox NAT Ouvert

| Console | IP fixe | Port | NAT |
|---------|---------|------|-----|
| Xbox Series S | 10.10.10.64 | 3074 (UDP) | ✅ Ouvert |
| Xbox One X | 10.10.10.4 | 49460 (UDP) | ✅ Ouvert |

### 7. VPN WireGuard vérifié

| VPN | Port | Statut |
|-----|------|--------|
| VPN-Maison | 51821 | ✅ Actif |
| WG-Root3d UDM Pro | 51820 | ⚠️ Aucun utilisateur |

**Utilisateur configuré :** iPhone (192.168.3.2)

---

## 📊 Architecture réseau finale

```
Internet
    │
    ▼
┌─────────────────────────────────────────────┐
│           UDM-Pro (192.168.1.1)             │
│   WireGuard: 51821 | IPS/IDS: Actif         │
└─────────────────────────────────────────────┘
    │
    ├── VLAN 1  - Admin     (192.168.1.0/26)   - Management UniFi
    ├── VLAN 2  - Home      (10.10.10.0/25)    - Réseau principal
    ├── VLAN 50 - Deeper    (172.16.50.0/28)   - VPN décentralisé
    ├── VLAN 60 - IoT       (172.16.60.60/27)  - Objets connectés
    └── VLAN 70 - Work      (172.16.70.0/29)   - Télétravail isolé
```

---

## 📋 Tâches restantes (optionnel)

| Priorité | Tâche | Notes |
|----------|-------|-------|
| 🚨 | Fermer ports NAS 5000/5001 | Utiliser VPN à la place |
| ⚠️ | Migrer appareils IoT | Reconnecter au WiFi IoT-Network |
| 💡 | Désactiver WiFi inutilisés | UID, element-... |
| 💡 | Nettoyer Docker | ~24 GB récupérable |
| 💡 | Mise à jour kernel | 6.17.0-6 → 6.17.0-7 |

---

## 🔗 Documentation associée

- [MCP-SERVER-UDM-PRO.md](../guides/MCP-SERVER-UDM-PRO.md) - Connexion MCP
- [Guide-Securisation-UniFi-Forteresse.docx](../Guide-Securisation-UniFi-Forteresse.docx) - Guide complet

---

*Session terminée le 29 novembre 2025 à 17h30*
