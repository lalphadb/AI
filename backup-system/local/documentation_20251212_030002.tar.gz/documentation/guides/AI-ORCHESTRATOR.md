# 🤖 Agent IA Orchestrateur v2.0

> **URL** : https://ai.4lb.ca
> **Version** : 2.0.0
> **Date** : 6 décembre 2025

---

## 🎯 Fonctionnalités v2.0

### Nouvelles fonctionnalités
| Fonction | Description |
|----------|-------------|
| 🤖 **Sélection AUTO** | L'agent choisit automatiquement le meilleur modèle |
| 📎 **Upload fichiers** | Images, code, logs, JSON, etc. |
| 👁️ **Analyse d'images** | Via modèle vision (Llama 3.2 Vision) |
| 💬 **Historique** | Conversations sauvegardées |
| 📋 **Copier** | Bouton copie rapide des réponses |
| 🔄 **WebSocket** | Communication temps réel |

---

## 📊 Architecture

### Couches techniques

- **Backend FastAPI (`ai-orchestrator-backend`)**
  - Hébergé via `infrastructure/unified-stack/docker-compose.yml`
  - Écoute uniquement sur le port interne **8001**
  - Exposé publiquement par Traefik via le routeur `ai-api@docker` (`Host(ai.4lb.ca)` + `/api|/ws|/tools|/models|/health`)
  - Connecté au réseau `unified-net` + au réseau `bridge` pour contacter `host.docker.internal:11434` (Ollama sur l'hôte)
- **Frontend Nginx (`ai-orchestrator-frontend`)**
  - Serre les assets Web sur le port 80 interne
  - Traefik publie `Host(ai.4lb.ca)` → service `ai@docker`
  - Proxy local (`ai-tools/ai-orchestrator/nginx.conf`) vers `http://ai-orchestrator-backend:8001` sans passer par une IP fixe
- **Traefik**
  - Déployé dans la même stack (`./stack.sh up ai`)
  - Certificats Let's Encrypt, redirection HTTPS par défaut
  - Fichier dynamique équivalent disponible dans `infrastructure/4lb-docker-stack/configs/traefik/dynamic/ai-orchestrator.yml`

```
┌─────────────────────────────────────────────────────────┐
│                    Interface Web v2                      │
│     - Sélecteur modèle (AUTO + 4 modèles)              │
│     - Upload fichiers/images                            │
│     - Historique conversations                          │
│     - Bouton copier                                     │
│     - WebSocket temps réel                              │
└─────────────────────────────────────────────────────────┘
                         │ WebSocket
                         ▼
┌─────────────────────────────────────────────────────────┐
│              FastAPI Backend v2.0                        │
│     - Boucle ReAct autonome                             │
│     - 26 outils intégrés                                │
│     - Sélection automatique de modèle                   │
│     - Gestion fichiers uploadés                         │
│     - SQLite pour persistance                           │
└─────────────────────────────────────────────────────────┘
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
     ┌─────────┐   ┌──────────┐   ┌──────────┐
     │ Ollama  │   │  Docker  │   │ UDM-Pro  │
     │ (LLMs)  │   │  Socket  │   │  (SSH)   │
     └─────────┘   └──────────┘   └──────────┘
```

---

## 🎮 Modèles Disponibles

| Mode | Modèle | Usage |
|------|--------|-------|
| 🤖 **AUTO** | Sélection intelligente | Analyse la tâche et choisit le meilleur |
| 💻 **Qwen Coder** | qwen2.5-coder:32b | Code, scripts, debug |
| 🧠 **DeepSeek** | deepseek-coder:33b | Algorithmes complexes |
| 👁️ **Llama Vision** | llama3.2-vision:11b | Analyse d'images |
| 🎨 **Qwen Vision** | qwen3-vl:32b | Vision multimodale |

### Sélection automatique
En mode AUTO, le système analyse :
- Mots-clés dans la demande
- Présence de fichiers/images attachés
- Type de tâche demandée

---

## 🔧 Outils Disponibles (26)

### Système
| Outil | Description |
|-------|-------------|
| `execute_command` | Exécuter une commande bash |
| `system_info` | CPU, RAM, disque, GPU |
| `disk_usage` | Analyse espace disque |
| `service_status` | Statut service systemd |
| `service_control` | Start/stop/restart service |
| `network_scan` | Ports ouverts |

### Fichiers
| Outil | Description |
|-------|-------------|
| `read_file` | Lire un fichier |
| `write_file` | Écrire dans un fichier |
| `list_directory` | Lister un répertoire |
| `search_files` | Rechercher fichiers |
| `create_script` | Créer script exécutable |
| `analyze_file` | Analyser fichier uploadé |
| `analyze_image` | Analyser image avec vision |

### Docker
| Outil | Description |
|-------|-------------|
| `docker_status` | État des conteneurs |
| `docker_logs` | Logs d'un conteneur |
| `docker_restart` | Redémarrer conteneur |

### Réseau (UDM-Pro)
| Outil | Description |
|-------|-------------|
| `udm_status` | Statut UDM-Pro |
| `udm_network_info` | VLANs, configuration |
| `udm_clients` | Clients connectés |

### LLM
| Outil | Description |
|-------|-------------|
| `ollama_list` | Modèles installés |
| `ollama_run` | Requête sur un modèle |

### Utilitaires
| Outil | Description |
|-------|-------------|
| `memory_store` | Stocker en mémoire |
| `memory_recall` | Rappeler de la mémoire |
| `web_request` | Requête HTTP GET/POST |
| `git_status` | Statut git |
| `final_answer` | Réponse finale |

---

## 📎 Upload de Fichiers

### Types supportés
- **Images** : PNG, JPG, GIF, WebP, BMP
- **Texte** : TXT, MD, JSON, YAML, LOG, CSV
- **Code** : PY, JS, TS, SH, PHP, HTML, CSS

### Utilisation
1. Cliquer sur 📎 ou glisser-déposer
2. Le fichier est uploadé et un ID est généré
3. L'agent peut analyser le fichier avec `analyze_file(file_id="...")`
4. Pour les images : `analyze_image(image_id="...", question="...")`

---

## 💬 Historique des Conversations

- Sauvegarde automatique en SQLite
- Liste dans la barre latérale
- Reprise de conversation possible
- Suppression individuelle

---

## 🚀 Exemples d'utilisation

### Analyse système
```
"Montre-moi l'état du serveur : CPU, RAM, disque et GPU"
```

### Gestion Docker
```
"Liste les conteneurs Docker et montre les logs de Traefik"
```

### Analyse d'image
```
[Upload une capture d'écran]
"Analyse cette image et dis-moi ce que tu vois"
```

### Création de script
```
"Crée un script de monitoring Docker avec alertes"
```

### Réseau
```
"Connecte-toi au UDM-Pro et montre les VLANs configurés"
```

---

## ⚙️ Maintenance & Exploitation

### Démarrer / redémarrer uniquement l'orchestrateur
```bash
cd /home/lalpha/projets/infrastructure/unified-stack
./stack.sh up ai            # démarre traefik/postgres/redis + frontend/backend
./stack.sh restart ai-orchestrator-backend   # redémarrage ciblé après mise à jour
./stack.sh status           # vue rapide des conteneurs
```

### Vérifications après démarrage
1. **Santé backend**  
   `curl -k https://ai.4lb.ca/health` → doit retourner un JSON `{"status":"healthy", ...}`
2. **Frontend**  
   `curl -k https://ai.4lb.ca` → réponse HTTP 200 avec la page HTML.
3. **Conteneurs**  
   `docker ps --filter name=ai-orchestrator --format 'table {{.Names}}\t{{.Status}}'`
4. **Traefik**  
   `docker exec traefik wget -qO- http://localhost:8080/api/http/routers | jq '.[] | select(.name|test("ai"))'`

### Points de vigilance
- Toujours utiliser le port **8001** côté backend (healthcheck, labels Traefik, proxy Nginx).
- Le frontend et le backend doivent partager le réseau `unified-net` afin que `ai-orchestrator-backend` soit résolu via DNS Docker.
- `stack.sh` connecte automatiquement le backend au réseau `bridge` pour permettre l'accès à `host.docker.internal:11434` (Ollama). Ne pas retirer cette étape si vous déployez ailleurs.
- En cas de mise à jour de Traefik ou de migration vers un autre host, vérifier que le record DNS `ai.4lb.ca` pointe bien vers l'IP publique courante.

---

## 📡 API Endpoints

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `/health` | GET | Statut du service |
| `/models` | GET | Liste des modèles |
| `/tools` | GET | Liste des outils |
| `/api/upload` | POST | Upload fichier |
| `/api/chat` | POST | Chat synchrone |
| `/api/conversations` | GET | Liste conversations |
| `/api/conversations/{id}` | GET/PUT/DELETE | Gestion conversation |
| `/ws/chat` | WebSocket | Chat temps réel |

---

## 🔐 Sécurité

⚠️ L'agent a accès complet au système :
- Exécution de commandes bash
- Accès Docker socket
- SSH vers UDM-Pro
- Lecture/écriture fichiers

**Recommandations** :
- Restreindre l'accès à l'URL
- Ajouter authentification (Phase 2)
- Surveiller les logs

---

## 📁 Fichiers

| Fichier | Lignes | Description |
|---------|--------|-------------|
| `backend/main.py` | 1160 | Backend FastAPI |
| `frontend/index.html` | 831 | Interface web |
| `docker-compose.yml` | 50 | Configuration Docker |

---

## 🐛 Dépannage

### WebSocket déconnecté
- Vérifier que le backend tourne : `docker ps`
- Vérifier les logs : `docker logs ai-orchestrator-backend`

### Modèle ne répond pas
- Vérifier Ollama : `curl http://10.10.10.46:11434/api/tags`
- Vérifier le modèle existe : `ollama list`

### Upload échoue
- Vérifier le volume Docker : `docker volume ls`
- Vérifier les permissions

---

## 📝 Changelog

### v2.0.0 (6 décembre 2025)
- ✅ Sélection automatique de modèle
- ✅ Upload fichiers et images
- ✅ Analyse d'images avec vision
- ✅ Historique des conversations
- ✅ Bouton copier
- ✅ Interface améliorée
- ✅ 26 outils (vs 19 en v1)

### v1.0.0 (5 décembre 2025)
- Version initiale
- Boucle ReAct
- 19 outils
- Interface basique

---

*Documentation mise à jour le 6 décembre 2025*
