# 🖥️ Documentation Complète - Serveur lalpha-server-1

> **Dernière mise à jour** : 1er décembre 2025  
> **OS** : Ubuntu 25.10 (Oracular)  
> **Domaine** : 4lb.ca

---

## 📋 Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [URLs et accès](#urls-et-accès)
3. [Conteneurs Docker](#conteneurs-docker)
4. [Stack LLM](#stack-llm)
5. [Monitoring](#monitoring)
6. [MCP Servers](#mcp-servers)
7. [Projets hébergés](#projets-hébergés)
8. [Commandes utiles](#commandes-utiles)

---

## 🎯 Vue d'ensemble

### Spécifications

| Composant | Valeur |
|-----------|--------|
| **CPU** | AMD Ryzen 9 7900X (12c/24t) |
| **GPU** | NVIDIA RTX 5070 Ti (16 GB) |
| **RAM** | 64 GB DDR5 |
| **Stockage** | ~1.7 TB NVMe |
| **IP** | 10.10.10.46 (VLAN 2) |

### Services Principaux

| Service | Statut | Description |
|---------|--------|-------------|
| Traefik | ✅ | Reverse proxy + SSL |
| Open WebUI | ✅ | Interface LLM |
| Bolt.DIY | ✅ | IDE IA |
| Ollama | ✅ | Serveur LLM |
| MCP Server v3 | ✅ | Outils intelligents |
| ChromaDB | ✅ | Base vectorielle |
| Prometheus | ✅ | Métriques |
| Grafana | ✅ | Dashboards |

---

## 🌐 URLs et Accès

### URLs Publiques (HTTPS)

| Service | URL |
|---------|-----|
| Portail | https://4lb.ca |
| Open WebUI | https://llm.4lb.ca |
| Bolt.DIY | https://bolt.4lb.ca |
| Grafana | https://grafana.4lb.ca |
| Prometheus | https://prometheus.4lb.ca |
| JSR | https://jsr.4lb.ca |

### URLs Locales

| Service | Port |
|---------|------|
| Traefik Dashboard | 8080 |
| Open WebUI | 8080 |
| MCP Server | 3000 |
| Ollama | 11434 |
| ChromaDB | 8000 |
| Prometheus | 9090 |
| Grafana | 3001 |

---

## 🐳 Conteneurs Docker

### Actifs

| Conteneur | Image | Ports |
|-----------|-------|-------|
| traefik | traefik:v3.1 | 80, 443, 8080 |
| open-webui | ghcr.io/open-webui/open-webui:main | 8080 |
| bolt-diy | boltdiy-bolt-diy | 5173 |
| mcp-server | mcp-server:intelligent-v3 | 3000 |
| chromadb | chromadb-with-healthcheck | 8000 |
| prometheus | prom/prometheus | 9090 |
| grafana | grafana/grafana | 3001 |
| ai-postgres | postgres:16-alpine | 5432 |
| ai-redis | redis:7-alpine | 6379 |
| jsr-dev | jsr:latest | 8082 |

### Commandes Docker

```bash
# État
docker ps -a

# Logs
docker logs -f <container>

# Redémarrer
docker restart <container>

# Stats
docker stats --no-stream

# Nettoyer
docker system prune -af
```

---

## 🤖 Stack LLM

### Ollama

**Port** : 11434

| Modèle | Taille | Usage |
|--------|--------|-------|
| qwen2.5-coder:32b | 19 GB | Code |
| deepseek-coder:33b | 18 GB | Code |
| llama3.2-vision:11b | 12 GB | Vision |
| nomic-embed-text | 274 MB | RAG |

```bash
ollama list
ollama run qwen2.5-coder:32b
```

### Open WebUI

- **URL** : https://llm.4lb.ca
- **Config Ollama** : `http://host.docker.internal:11434`

---

## 📊 Monitoring

### Prometheus

- **Port** : 9090
- **Config** : `/home/lalpha/projets/infrastructure/4lb-docker-stack/prometheus/`

### Grafana

- **Port** : 3001
- **URL** : https://grafana.4lb.ca

### Métriques collectées

- Node Exporter (système)
- cAdvisor (Docker)
- Traefik (HTTP)

---

## 🔌 MCP Servers

### Claude Desktop (4 serveurs)

| Serveur | Outils | SDK |
|---------|--------|-----|
| ubuntu-mcp | 12 | 1.23.0 |
| udm-pro-mcp | 8 | 1.23.0 |
| filesystem-mcp | 4 | 1.23.0 |
| chromadb-mcp | 9 | 1.23.0 |

### Open WebUI (Docker)

| Serveur | Port | Version |
|---------|------|---------|
| mcp-server | 3000 | v3.0 (intelligent) |

**Fonctionnalités v3.0** :
- Auto-correction typos
- Validation préalable chemins
- Mémoire SQLite
- Suggestions intelligentes

---

## 📁 Projets Hébergés

### JSR Déneigement

- **URL** : https://jsr.4lb.ca
- **Chemin** : `/home/lalpha/projets/clients/jsr/`
- **Stack** : React + Vite + Nodemailer

### Infrastructure

- **Chemin** : `/home/lalpha/projets/infrastructure/4lb-docker-stack/`
- **Contient** : Docker Compose, Traefik, Prometheus

---

## 🚀 Commandes Utiles

### Système

```bash
# Ressources
htop
nvidia-smi

# Disque
df -h
du -sh /home/lalpha/*

# Réseau
ss -tlnp
```

### Services

```bash
# Ollama
sudo systemctl status ollama
sudo systemctl restart ollama

# Docker
docker ps -a
docker stats
```

### Logs

```bash
# Système
sudo journalctl -f

# Docker
docker logs -f <container>

# Traefik
docker logs -f traefik
```

---

## 🔐 Sécurité

- **UFW** : Firewall
- **Fail2Ban** : Protection brute-force
- **Traefik** : SSL/TLS automatique

Voir : [README-SECURITE.md](README-SECURITE.md)

---

## 🔗 Documentation Liée

- [ARCHITECTURE.md](../ARCHITECTURE.md) - Vue complète infrastructure
- [MCP-SERVER-UDM-PRO.md](MCP-SERVER-UDM-PRO.md) - Serveurs MCP pour Unifi dream machine pro
- [INSTALLATION_LLM_GUIDE.md](INSTALLATION_LLM_GUIDE.md) - Guide LLM
- [README-SECURITE.md](README-SECURITE.md) - Sécurité

---

*Documentation mise à jour le 1er décembre 2025*
