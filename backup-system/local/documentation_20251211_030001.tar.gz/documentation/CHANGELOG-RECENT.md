# 📋 Changelog Infrastructure Récent

> Généré automatiquement le 2025-12-07 18:35
> Période: derniers 7 jours
## 🔴 Changements Majeurs


## 📊 Résumé

- **Total changements:** 5
- **Par catégorie:** infrastructure: 4,docker: 1,
- **Composants modifiés:** chromadb,claude-memory,infra-log,unified-stack,

