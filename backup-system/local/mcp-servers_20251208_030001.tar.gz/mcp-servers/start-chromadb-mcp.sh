#!/bin/bash
cd /home/lalpha/projets/ai-tools/mcp-servers/chromadb-mcp
exec node index.js
