#!/bin/bash
# Script pour résoudre le problème de réseaux Docker saturés
# Usage: sudo bash fix-docker-networks.sh

set -e

echo "🔧 Correction des réseaux Docker"
echo "================================"

# 1. Backup
echo "1. Backup de la config actuelle..."
cp /etc/docker/daemon.json /etc/docker/daemon.json.backup.$(date +%Y%m%d)

# 2. Nouvelle config avec plus de subnets
echo "2. Mise à jour daemon.json..."
cat > /etc/docker/daemon.json << 'DAEMON'
{
    "default-address-pools": [
        {"base": "172.17.0.0/12", "size": 24},
        {"base": "192.168.128.0/17", "size": 24}
    ],
    "icc": false,
    "live-restore": true,
    "log-driver": "json-file",
    "log-opts": {
        "max-file": "3",
        "max-size": "10m"
    },
    "runtimes": {
        "nvidia": {
            "args": [],
            "path": "nvidia-container-runtime"
        }
    },
    "userland-proxy": false
}
DAEMON

# 3. Nettoyage réseaux inutilisés
echo "3. Nettoyage des réseaux inutilisés..."
docker network prune -f

# 4. Redémarrage Docker (live-restore garde les conteneurs)
echo "4. Redémarrage Docker..."
systemctl restart docker

echo ""
echo "✅ Configuration appliquée!"
echo "   - Pool 1: 172.17.0.0/12 (~4096 réseaux possibles)"
echo "   - Pool 2: 192.168.128.0/17 (~512 réseaux possibles)"
echo ""
echo "Vérification:"
docker info 2>/dev/null | grep -A5 "Default Address Pools"
