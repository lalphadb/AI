#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║     CONFIGURER OLLAMA POUR ACCÈS RÉSEAU (DOCKER)             ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Couleurs
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}[1/4]${NC} Configuration d'Ollama pour écouter sur toutes les interfaces..."

# Créer le fichier de service systemd override
sudo mkdir -p /etc/systemd/system/ollama.service.d/
sudo tee /etc/systemd/system/ollama.service.d/override.conf > /dev/null << 'EOFSVC'
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"
EOFSVC

echo -e "${GREEN}✓ Configuration créée${NC}"
echo ""

echo -e "${YELLOW}[2/4]${NC} Rechargement de systemd..."
sudo systemctl daemon-reload
echo -e "${GREEN}✓ Systemd rechargé${NC}"
echo ""

echo -e "${YELLOW}[3/4]${NC} Redémarrage d'Ollama..."
sudo systemctl restart ollama
sleep 2
echo -e "${GREEN}✓ Ollama redémarré${NC}"
echo ""

echo -e "${YELLOW}[4/4]${NC} Vérification..."
if curl -s --max-time 2 http://10.10.10.46:11434/api/tags > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Ollama accessible sur http://10.10.10.46:11434${NC}"
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo -e "║  ${GREEN}✓ SUCCÈS! Ollama accessible depuis le réseau${NC}            ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
    echo "📋 Configuration pour Open WebUI:"
    echo "   Section: API Ollama"
    echo "   URL: http://10.10.10.46:11434"
    echo "   Activer: ✅"
else
    echo -e "${YELLOW}⚠ Ollama ne répond pas encore sur le réseau${NC}"
    echo "Attendez 5 secondes et réessayez..."
fi
