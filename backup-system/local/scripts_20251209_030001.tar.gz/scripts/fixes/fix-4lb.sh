#!/bin/bash
sudo tee /etc/nginx/sites-available/4lb.ca << 'EOF'
server {
    listen 80;
    server_name 4lb.ca www.4lb.ca;
    root /var/www/4lb.ca;
    index index.html;
    location / {
        try_files $uri $uri/ =404;
    }
}
EOF

sudo mkdir -p /var/www/4lb.ca

sudo tee /var/www/4lb.ca/index.html << 'EOF'
<!DOCTYPE html>
<html><head><title>4lb.ca</title></head>
<body style="font-family:sans-serif;max-width:800px;margin:50px auto;padding:20px">
<h1>✅ 4lb.ca Active</h1>
<p><strong>IP:</strong> 1.1.4.12</p>
<p><strong>Services:</strong> Ollama, PostgreSQL, Redis, Grafana</p>
</body></html>
EOF

sudo ln -sf /etc/nginx/sites-available/4lb.ca /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
echo "✅ Site activé"
