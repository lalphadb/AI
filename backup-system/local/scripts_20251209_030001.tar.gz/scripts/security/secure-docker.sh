#!/bin/bash
# Sécurisation de Docker

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}═══════════════════════════════════════${NC}"
echo -e "${YELLOW}    Sécurisation Docker${NC}"
echo -e "${YELLOW}═══════════════════════════════════════${NC}"
echo ""

if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Ce script doit être exécuté en tant que root${NC}"
    exit 1
fi

# 1. Limiter les logs Docker
echo -e "${YELLOW}[1/5] Configuration des logs Docker...${NC}"
cat > /etc/docker/daemon.json << 'DOCKEREOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "live-restore": true,
  "userland-proxy": false,
  "icc": false,
  "default-address-pools": [
    {
      "base": "172.17.0.0/16",
      "size": 24
    }
  ]
}
DOCKEREOF

# 2. Sécurisation des conteneurs
echo -e "${YELLOW}[2/5] Création du profil AppArmor pour Docker...${NC}"
if command -v aa-status &> /dev/null; then
    echo "AppArmor détecté"
else
    apt install -y apparmor apparmor-utils
fi

# 3. Audit Docker
echo -e "${YELLOW}[3/5] Installation Docker Bench Security...${NC}"
if [ ! -d "/opt/docker-bench-security" ]; then
    git clone https://github.com/docker/docker-bench-security.git /opt/docker-bench-security
    chmod +x /opt/docker-bench-security/docker-bench-security.sh
fi

# 4. Nettoyage Docker
echo -e "${YELLOW}[4/5] Nettoyage Docker...${NC}"
docker system prune -af --volumes

# 5. Redémarrage
echo -e "${YELLOW}[5/5] Redémarrage Docker...${NC}"
systemctl restart docker

echo ""
echo -e "${GREEN}✓ Docker sécurisé !${NC}"
echo ""
echo -e "${YELLOW}Pour auditer Docker:${NC}"
echo "  cd /opt/docker-bench-security && sudo ./docker-bench-security.sh"
echo ""
echo -e "${YELLOW}Pour voir les logs Docker:${NC}"
echo "  docker logs <container_name>"
echo ""
