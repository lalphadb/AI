#!/bin/bash

echo "=== Test du serveur MCP-GPT avec SSE ==="
echo ""

TOKEN="f3a7c0e14e7b8cfaab12d09b9d8c4361d8cba41e78f2edfd2c6c7c9ab12de5cc"

echo "1. Test de l'endpoint racine (page web):"
curl -s http://localhost:9091/ | head -5
echo ""

echo "2. Test de connexion SSE (5 secondes):"
timeout 5 curl -N -H "Authorization: Bearer $TOKEN" http://localhost:9091/sse 2>&1 | head -10
echo ""

echo "3. Test de l'endpoint /mcp avec initialize:"
curl -X POST http://localhost:9091/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test-client","version":"1.0.0"}}}' 2>&1 | grep -v "^%" | tail -1
echo ""

echo "✅ Tests terminés!"
