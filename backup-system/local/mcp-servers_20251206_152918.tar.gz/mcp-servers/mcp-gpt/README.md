# MCP GPT Task Server

Ce projet fournit un serveur [Model Context Protocol](https://github.com/modelcontextprotocol) permettant à un agent (OpenAI, Claude, etc.) d'exécuter en toute sécurité des tâches prédéfinies sur votre machine.

## Installation

```bash
cd /home/lalpha/projets/mcp-gpt
npm install
```

## Configuration

1. Créez un fichier `.env` en vous basant sur l'exemple ci-dessous :

   ```ini
   MCP_TOKEN=token-super-secret
   PORT=9090
   MCP_TASKS_FILE=./configs/tasks.json
   MCP_DEFAULT_TIMEOUT=15000
   MCP_MAX_OUTPUT=10000
   MCP_ALLOWED_COMMANDS=/usr/bin/uptime,/usr/bin/df
   ```

2. Définissez les tâches autorisées dans `configs/tasks.json` (exemples fournis).
   Chaque tâche correspond à une commande autorisée (chemin absolu) et à ses arguments par défaut.

## Lancement

```bash
npm run start:tasks
```

Le serveur écoute sur `http://localhost:9090/mcp` et exige le header `Authorization: Bearer <MCP_TOKEN>`.

## Outils disponibles

- `list_tasks` : renvoie la liste des tâches définies dans le fichier de configuration.
- `run_task` : exécute une tâche préconfigurée en option avec des arguments complémentaires.
- `run_allowed_command` : exécute une commande whitelistée via `MCP_ALLOWED_COMMANDS`.
- `uptime` : expose un outil simple pour connaître le temps de fonctionnement du serveur.

## Endpoints additionnels

- `GET /healthz` : vérifie que le fichier des tâches est accessible.

## Logique de sécurité

- Toutes les commandes doivent être autorisées explicitement (fichier JSON ou variable d'environnement).
- Les sorties sont tronquées à `MCP_MAX_OUTPUT` caractères.
- Timeout configurable par tâche et via l'input de l'outil.

Adaptez les tâches proposées à vos propres scripts/commandes, puis rechargez le fichier pour que les nouveaux éléments soient pris en compte.
