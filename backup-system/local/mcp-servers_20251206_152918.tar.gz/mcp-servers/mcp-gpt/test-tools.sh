#!/bin/bash

TOKEN="f3a7c0e14e7b8cfaab12d09b9d8c4361d8cba41e78f2edfd2c6c7c9ab12de5cc"
BASE_URL="http://localhost:9091/mcp"

echo "=== Test des outils MCP ==="
echo ""

# 1. Initialize
echo "1. Initialize le serveur:"
SESSION=$(curl -s -X POST $BASE_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test-client","version":"1.0.0"}}}')
echo $SESSION | jq '.'
echo ""

# 2. Liste des outils
echo "2. Liste des outils disponibles:"
curl -s -X POST $BASE_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' | jq '.'
echo ""

# 3. Test uptime
echo "3. Test de l'outil 'uptime':"
curl -s -X POST $BASE_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"uptime","arguments":{}}}' | jq '.'
echo ""

# 4. Test run_allowed ls
echo "4. Test de l'outil 'run_allowed' avec ls:"
curl -s -X POST $BASE_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"run_allowed","arguments":{"command":"ls","args":["-la","/tmp"]}}}' | jq '.'
echo ""

echo "✅ Tests terminés!"
