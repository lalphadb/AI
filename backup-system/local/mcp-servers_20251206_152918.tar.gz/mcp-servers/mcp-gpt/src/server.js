import express from "express";
import dotenv from "dotenv";
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

dotenv.config({ path: "/opt/mcp/mcp-server/gpt/.env" }); // charge secrets
const execFileAsync = promisify(execFile);

const TOKEN = process.env.MCP_TOKEN;
const PORT = parseInt(process.env.PORT || "9090", 10);

// --- MCP server ---
const server = new McpServer({
  name: "mcp-gpt",
  version: "1.0.0",
});

// Tool 1 : uptime (lecture seule)
server.registerTool(
  "uptime",
  {
    title: "Uptime",
    description: "Affiche le temps de fonctionnement du système",
    inputSchema: z.object({}).strict(),
    outputSchema: z.object({ uptime: z.string() }),
  },
  async () => {
    const { stdout } = await execFileAsync("/usr/bin/uptime", ["-p"]);
    const output = { uptime: stdout.trim() };
    return {
      content: [{ type: "text", text: output.uptime }],
      structuredContent: output,
    };
  }
);

// Tool 2 : run_allowed (liste blanche stricte)
const AllowedCmd = z.enum(["ls", "df", "du"]);
server.registerTool(
  "run_allowed",
  {
    title: "Commande whitelist",
    description: "Exécute une commande autorisée (ls, df, du)",
    inputSchema: z.object({
      command: AllowedCmd,
      args: z.array(z.string()).optional().default([]),
    }),
    outputSchema: z.object({ stdout: z.string() }),
  },
  async ({ command, args }) => {
    const { stdout } = await execFileAsync(`/usr/bin/${command}`, args, { timeout: 8000 });
    const output = { stdout: stdout.slice(0, 5000) };
    return {
      content: [{ type: "text", text: output.stdout }],
      structuredContent: output,
    };
  }
);

// --- Express + Streamable HTTP transport (/mcp) ---
const app = express();
app.use(express.json());

// Auth Bearer simple
app.use((req, res, next) => {
  if (!TOKEN) return res.status(500).send("MCP_TOKEN non défini");
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${TOKEN}`) return res.status(401).send("Non autorisé");
  next();
});

// Endpoint MCP (JSON-RPC over HTTP, streamable)
app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });
  res.on("close", () => {
    transport.close();
  });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

app.listen(PORT, () => {
  console.log(`✅ MCP server (streamable HTTP) sur http://localhost:${PORT}/mcp`);
});
