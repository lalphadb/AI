import express from "express";
import dotenv from "dotenv";
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, "../.env") });

const execFileAsync = promisify(execFile);

const TOKEN = process.env.MCP_TOKEN;
const PORT = parseInt(process.env.PORT || "9091", 10);

// --- MCP server ---
const server = new McpServer({
  name: "mcp-gpt",
  version: "1.0.0",
});

// Tool 1 : uptime (lecture seule)
server.registerTool(
  "uptime",
  "Affiche le temps de fonctionnement du système",
  { type: "object", properties: {}, required: [] },
  async () => {
    const { stdout } = await execFileAsync("/usr/bin/uptime", ["-p"]);
    return {
      content: [{ type: "text", text: stdout.trim() }],
    };
  }
);

// Tool 2 : run_allowed (liste blanche stricte)
server.registerTool(
  "run_allowed",
  "Exécute une commande autorisée (ls, df, du, ps, hostname)",
  {
    type: "object",
    properties: {
      command: {
        type: "string",
        enum: ["ls", "df", "du", "ps", "hostname"],
        description: "Commande à exécuter",
      },
      args: {
        type: "array",
        items: { type: "string" },
        description: "Arguments de la commande",
      },
    },
    required: ["command"],
  },
  async ({ command, args = [] }) => {
    const { stdout } = await execFileAsync(`/usr/bin/${command}`, args, { timeout: 8000 });
    return {
      content: [{ type: "text", text: stdout.slice(0, 5000) }],
    };
  }
);

// --- Express + transports ---
const app = express();
app.use(express.json());

// Auth Bearer simple
app.use((req, res, next) => {
  // Skip auth pour la page d'accueil
  if (req.path === "/" && req.method === "GET") {
    return next();
  }
  if (!TOKEN) return res.status(500).send("MCP_TOKEN non défini");
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${TOKEN}`) return res.status(401).send("Non autorisé");
  next();
});

// Endpoint SSE
app.get("/sse", async (req, res) => {
  console.log("📡 Nouvelle connexion SSE");
  const transport = new SSEServerTransport("/messages", res);
  res.on("close", () => {
    console.log("🔌 Connexion SSE fermée");
    transport.close();
  });
  await server.connect(transport);
});

// Messages pour SSE
app.post("/messages", async (req, res) => {
  console.log("📨 Message SSE reçu:", req.body);
  res.json({ status: "received" });
});

// Endpoint MCP (JSON-RPC over HTTP, streamable)
app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });
  res.on("close", () => {
    transport.close();
  });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

// Page de test
app.get("/", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>MCP-GPT SSE Server</title>
        <style>
          body { font-family: Arial; margin: 40px; background: #f5f5f5; }
          .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          h1 { color: #333; }
          .status { padding: 15px; margin: 20px 0; border-radius: 5px; }
          .connected { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
          .disconnected { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
          button { padding: 12px 24px; margin: 10px 5px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
          button:hover { background: #0056b3; }
          pre { background: #f4f4f4; padding: 20px; border-radius: 5px; overflow: auto; max-height: 400px; }
          .endpoint { background: #e7f3ff; padding: 10px; margin: 10px 0; border-radius: 5px; font-family: monospace; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>🚀 MCP-GPT Server avec SSE</h1>
          <p><strong>Port:</strong> ${PORT} | <strong>Token:</strong> ${TOKEN ? TOKEN.substring(0, 15) + "..." : "Non défini"}</p>
          
          <div class="endpoint">
            <strong>SSE Endpoint:</strong> http://localhost:${PORT}/sse<br>
            <strong>MCP Endpoint:</strong> http://localhost:${PORT}/mcp
          </div>
          
          <div class="status disconnected" id="status">
            <strong>Status:</strong> <span id="connection">Déconnecté</span>
          </div>
          
          <h2>🧪 Tests Interactifs</h2>
          <button onclick="testSSE()">📡 Tester SSE</button>
          <button onclick="testInit()">🔧 Initialize</button>
          <button onclick="testTools()">📋 Lister Outils</button>
          <button onclick="testUptime()">⏱️ Test Uptime</button>
          <button onclick="testLs()">📂 Test ls /tmp</button>
          <button onclick="clearResults()">🗑️ Effacer</button>
          
          <h3>📊 Résultats:</h3>
          <pre id="results">Cliquez sur un bouton pour démarrer un test...</pre>
        </div>
        
        <script>
          const resultsEl = document.getElementById('results');
          const statusEl = document.getElementById('status');
          const connectionEl = document.getElementById('connection');
          const TOKEN = '${TOKEN}';
          
          function log(msg) {
            resultsEl.textContent += msg + '\\n';
            resultsEl.scrollTop = resultsEl.scrollHeight;
          }
          
          function clearResults() {
            resultsEl.textContent = 'Résultats effacés...\\n';
          }
          
          async function testSSE() {
            clearResults();
            log('🔄 Test SSE en cours...');
            log('Connexion à /sse avec authentification Bearer...');
            
            try {
              const response = await fetch('/sse', {
                headers: { 'Authorization': 'Bearer ' + TOKEN }
              });
              
              if (!response.ok) {
                log('❌ Erreur: ' + response.status + ' ' + response.statusText);
                return;
              }
              
              statusEl.className = 'status connected';
              connectionEl.textContent = 'Connecté à SSE';
              log('✅ Connexion SSE établie!');
              
              const reader = response.body.getReader();
              const decoder = new TextDecoder();
              
              setTimeout(() => {
                reader.cancel();
                statusEl.className = 'status disconnected';
                connectionEl.textContent = 'Déconnecté';
                log('⏹️ Test SSE terminé (timeout 5s)');
              }, 5000);
              
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                const text = decoder.decode(value);
                log('📨 ' + text.trim());
              }
            } catch (err) {
              log('❌ Erreur: ' + err.message);
              statusEl.className = 'status disconnected';
              connectionEl.textContent = 'Erreur';
            }
          }
          
          async function mcpRequest(method, params = {}) {
            const response = await fetch('/mcp', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/event-stream',
                'Authorization': 'Bearer ' + TOKEN
              },
              body: JSON.stringify({
                jsonrpc: '2.0',
                id: Date.now(),
                method,
                params
              })
            });
            return await response.json();
          }
          
          async function testInit() {
            clearResults();
            log('🔄 Initialisation du serveur MCP...');
            try {
              const result = await mcpRequest('initialize', {
                protocolVersion: '2024-11-05',
                capabilities: {},
                clientInfo: { name: 'web-test-client', version: '1.0.0' }
              });
              log('✅ Réponse:');
              log(JSON.stringify(result, null, 2));
            } catch (err) {
              log('❌ Erreur: ' + err.message);
            }
          }
          
          async function testTools() {
            clearResults();
            log('🔄 Liste des outils disponibles...');
            try {
              const result = await mcpRequest('tools/list');
              log('✅ Outils disponibles:');
              log(JSON.stringify(result, null, 2));
            } catch (err) {
              log('❌ Erreur: ' + err.message);
            }
          }
          
          async function testUptime() {
            clearResults();
            log('🔄 Test de l\\'outil uptime...');
            try {
              const result = await mcpRequest('tools/call', {
                name: 'uptime',
                arguments: {}
              });
              log('✅ Résultat:');
              log(JSON.stringify(result, null, 2));
            } catch (err) {
              log('❌ Erreur: ' + err.message);
            }
          }
          
          async function testLs() {
            clearResults();
            log('🔄 Test de l\\'outil run_allowed (ls /tmp)...');
            try {
              const result = await mcpRequest('tools/call', {
                name: 'run_allowed',
                arguments: {
                  command: 'ls',
                  args: ['-la', '/tmp']
                }
              });
              log('✅ Résultat:');
              log(JSON.stringify(result, null, 2));
            } catch (err) {
              log('❌ Erreur: ' + err.message);
            }
          }
        </script>
      </body>
    </html>
  `);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ MCP server avec SSE démarré!`);
  console.log(`📡 SSE: http://0.0.0.0:${PORT}/sse`);
  console.log(`🔧 MCP: http://0.0.0.0:${PORT}/mcp`);
  console.log(`🌐 Web: http://0.0.0.0:${PORT}/`);
  console.log(`🔑 Token: ${TOKEN ? TOKEN.substring(0, 15) + "..." : "Non défini"}`);
});
