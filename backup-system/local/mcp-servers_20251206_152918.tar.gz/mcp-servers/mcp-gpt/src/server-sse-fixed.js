import express from "express";
import dotenv from "dotenv";
import { z } from "zod";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, "../.env") });

const execFileAsync = promisify(execFile);

const TOKEN = process.env.MCP_TOKEN;
const PORT = parseInt(process.env.PORT || "9091", 10);

// --- MCP server ---
const server = new Server(
  {
    name: "mcp-gpt",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Tool handlers
server.setRequestHandler("tools/list", async () => {
  return {
    tools: [
      {
        name: "uptime",
        description: "Affiche le temps de fonctionnement du système",
        inputSchema: {
          type: "object",
          properties: {},
          required: [],
        },
      },
      {
        name: "run_allowed",
        description: "Exécute une commande autorisée (ls, df, du, ps, hostname)",
        inputSchema: {
          type: "object",
          properties: {
            command: {
              type: "string",
              enum: ["ls", "df", "du", "ps", "hostname"],
              description: "Commande à exécuter",
            },
            args: {
              type: "array",
              items: { type: "string" },
              description: "Arguments de la commande",
              default: [],
            },
          },
          required: ["command"],
        },
      },
    ],
  };
});

server.setRequestHandler("tools/call", async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "uptime") {
    const { stdout } = await execFileAsync("/usr/bin/uptime", ["-p"]);
    return {
      content: [
        {
          type: "text",
          text: stdout.trim(),
        },
      ],
    };
  }

  if (name === "run_allowed") {
    const { command, args: cmdArgs = [] } = args;
    const { stdout } = await execFileAsync(`/usr/bin/${command}`, cmdArgs, { 
      timeout: 8000 
    });
    return {
      content: [
        {
          type: "text",
          text: stdout.slice(0, 5000),
        },
      ],
    };
  }

  throw new Error(`Unknown tool: ${name}`);
});

// --- Express app ---
const app = express();
app.use(express.json());

// Auth middleware (skip for GET /)
app.use((req, res, next) => {
  if (req.path === "/" && req.method === "GET") {
    return next();
  }
  if (!TOKEN) return res.status(500).send("MCP_TOKEN non défini");
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${TOKEN}`) return res.status(401).send("Non autorisé");
  next();
});

// Endpoint SSE (Server-Sent Events)
app.get("/sse", async (req, res) => {
  console.log("📡 Nouvelle connexion SSE");
  
  const transport = new SSEServerTransport("/messages", res);
  
  res.on("close", () => {
    console.log("🔌 Connexion SSE fermée");
    transport.close();
  });
  
  await server.connect(transport);
});

// Endpoint pour envoyer des messages au serveur MCP via SSE
app.post("/messages", async (req, res) => {
  console.log("📨 Message reçu:", req.body);
  res.json({ status: "received" });
});

// Endpoint HTTP classique (pour compatibilité)
app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });
  res.on("close", () => {
    transport.close();
  });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

// Page de test
app.get("/", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>MCP-GPT SSE Test</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          .status { padding: 10px; margin: 10px 0; }
          .connected { background: #d4edda; color: #155724; }
          .disconnected { background: #f8d7da; color: #721c24; }
          button { padding: 10px 20px; margin: 10px 5px; }
          pre { background: #f4f4f4; padding: 15px; overflow: auto; }
        </style>
      </head>
      <body>
        <h1>🚀 MCP-GPT Server - Test SSE</h1>
        <p>Token: ${TOKEN ? TOKEN.substring(0, 10) + "..." : "Non défini"}</p>
        
        <div class="status" id="status">
          Status: <span id="connection">Déconnecté</span>
        </div>
        
        <h2>Tests disponibles</h2>
        <button onclick="testSSE()">Tester SSE</button>
        <button onclick="testTools()">Lister les outils</button>
        <button onclick="testUptime()">Test uptime</button>
        <button onclick="testLs()">Test ls /tmp</button>
        
        <h3>Résultats:</h3>
        <pre id="results"></pre>
        
        <script>
          const resultsEl = document.getElementById('results');
          const TOKEN = '${TOKEN}';
          
          function log(msg) {
            resultsEl.textContent += msg + '\\n';
          }
          
          async function testSSE() {
            resultsEl.textContent = '';
            log('Test SSE en cours...');
            
            const response = await fetch('/sse', {
              headers: { 'Authorization': 'Bearer ' + TOKEN }
            });
            
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            
            setTimeout(() => {
              reader.cancel();
              log('SSE test terminé (timeout 5s)');
            }, 5000);
            
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              log('SSE: ' + decoder.decode(value));
            }
          }
          
          async function mcpRequest(method, params = {}) {
            const response = await fetch('/mcp', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/event-stream',
                'Authorization': 'Bearer ' + TOKEN
              },
              body: JSON.stringify({
                jsonrpc: '2.0',
                id: Date.now(),
                method,
                params
              })
            });
            return await response.json();
          }
          
          async function testTools() {
            resultsEl.textContent = '';
            log('Liste des outils...');
            const result = await mcpRequest('tools/list');
            log(JSON.stringify(result, null, 2));
          }
          
          async function testUptime() {
            resultsEl.textContent = '';
            log('Test uptime...');
            const result = await mcpRequest('tools/call', {
              name: 'uptime',
              arguments: {}
            });
            log(JSON.stringify(result, null, 2));
          }
          
          async function testLs() {
            resultsEl.textContent = '';
            log('Test ls /tmp...');
            const result = await mcpRequest('tools/call', {
              name: 'run_allowed',
              arguments: {
                command: 'ls',
                args: ['-la', '/tmp']
              }
            });
            log(JSON.stringify(result, null, 2));
          }
        </script>
      </body>
    </html>
  `);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ MCP server avec SSE sur http://0.0.0.0:${PORT}`);
  console.log(`📡 Endpoint SSE: http://0.0.0.0:${PORT}/sse`);
  console.log(`🔧 Endpoint MCP: http://0.0.0.0:${PORT}/mcp`);
  console.log(`🌐 Test page: http://0.0.0.0:${PORT}/`);
  console.log(`🔑 Token: ${TOKEN ? TOKEN.substring(0, 10) + "..." : "Non défini"}`);
});
