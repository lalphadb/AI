import "dotenv/config";
import express from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { promises as fs } from "fs";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

const TOKEN = process.env.MCP_TOKEN;
const PORT = Number.parseInt(process.env.PORT ?? "9090", 10);
const TASKS_FILE = process.env.MCP_TASKS_FILE ?? path.resolve(process.cwd(), "configs/tasks.json");
const DEFAULT_TIMEOUT = Number.parseInt(process.env.MCP_DEFAULT_TIMEOUT ?? "15000", 10);
const MAX_OUTPUT = Number.parseInt(process.env.MCP_MAX_OUTPUT ?? "10000", 10);
const ALLOWED_COMMANDS = (process.env.MCP_ALLOWED_COMMANDS ?? "")
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

const TaskSchema = z.object({
  id: z.string(),
  description: z.string().optional(),
  command: z.string(),
  args: z.array(z.string()).optional(),
  cwd: z.string().optional(),
  env: z.record(z.string()).optional(),
  timeoutMs: z.number().int().positive().optional(),
});

type TaskDefinition = z.infer<typeof TaskSchema>;

async function readTasks(): Promise<TaskDefinition[]> {
  try {
    const raw = await fs.readFile(TASKS_FILE, "utf-8");
    const json = JSON.parse(raw);
    return z.array(TaskSchema).parse(json);
  } catch (error) {
    const reason = error instanceof Error ? error.message : "unknown error";
    throw new Error(`Impossible de charger ${TASKS_FILE}: ${reason}`);
  }
}

async function runCommand(command: string, args: string[], options: { cwd?: string; env?: NodeJS.ProcessEnv; timeout: number }) {
  const execOptions = {
    cwd: options.cwd,
    env: options.env,
    timeout: options.timeout,
    maxBuffer: MAX_OUTPUT,
  };

  try {
    const { stdout, stderr } = await execFileAsync(command, args, execOptions);
    return {
      success: true as const,
      code: 0,
      stdout,
      stderr,
    };
  } catch (error) {
    if (typeof error === "object" && error && "stdout" in error && "stderr" in error) {
      const execError = error as { stdout: string; stderr: string; code?: number; signal?: NodeJS.Signals };
      return {
        success: false as const,
        code: execError.code ?? -1,
        stdout: execError.stdout,
        stderr: execError.stderr || `Process exited with signal ${execError.signal ?? "unknown"}`,
      };
    }
    throw error;
  }
}

const server = new McpServer({
  name: "mcp-gpt-task-runner",
  version: "1.0.0",
});

server.registerTool(
  "list_tasks",
  {
    title: "Lister les tâches",
    description: "Affiche les tâches configurées dans le fichier tasks.json",
    inputSchema: z.object({}).strict(),
    outputSchema: z.object({
      tasks: z.array(
        z.object({
          id: z.string(),
          description: z.string().optional(),
          command: z.string(),
          args: z.array(z.string()).optional(),
        })
      ),
    }),
  },
  async () => {
    const tasks = await readTasks();
    const summary = tasks
      .map((task) => `• ${task.id}${task.description ? ` — ${task.description}` : ""}`)
      .join("\n");
    return {
      content: summary ? [{ type: "text", text: summary }] : [{ type: "text", text: "Aucune tâche configurée." }],
      structuredContent: {
        tasks: tasks.map((task) => ({
          id: task.id,
          description: task.description,
          command: task.command,
          args: task.args,
        })),
      },
    };
  }
);

server.registerTool(
  "run_task",
  {
    title: "Exécuter une tâche",
    description: "Lance une commande préconfigurée depuis tasks.json",
    inputSchema: z
      .object({
        id: z.string(),
        extraArgs: z.array(z.string()).optional(),
        timeoutMs: z.number().int().positive().max(120000).optional(),
      })
      .strict(),
    outputSchema: z.object({
      id: z.string(),
      command: z.string(),
      args: z.array(z.string()),
      code: z.number(),
      stdout: z.string(),
      stderr: z.string(),
      success: z.boolean(),
    }),
  },
  async ({ id, extraArgs = [], timeoutMs }) => {
    const tasks = await readTasks();
    const task = tasks.find((item) => item.id === id);
    if (!task) {
      throw new Error(`Tâche inconnue: ${id}`);
    }

    const args = [...(task.args ?? []), ...extraArgs];
    const timeout = timeoutMs ?? task.timeoutMs ?? DEFAULT_TIMEOUT;
    const env = { ...process.env, ...task.env };

    const result = await runCommand(task.command, args, { cwd: task.cwd, env, timeout });
    const contentLines = [
      `Commande: ${task.command} ${args.join(" ")}`.trim(),
      `Code de sortie: ${result.code}`,
      result.stdout ? `--- stdout ---\n${result.stdout.slice(0, MAX_OUTPUT)}` : "stdout vide",
      result.stderr ? `--- stderr ---\n${result.stderr.slice(0, MAX_OUTPUT)}` : "stderr vide",
    ];

    return {
      content: [{ type: "text", text: contentLines.join("\n\n") }],
      structuredContent: {
        id,
        command: task.command,
        args,
        code: result.code,
        stdout: result.stdout.slice(0, MAX_OUTPUT),
        stderr: result.stderr.slice(0, MAX_OUTPUT),
        success: result.success,
      },
    };
  }
);

const AllowedCommandSchema = z.object({
  command: z.string(),
  args: z.array(z.string()).optional(),
  timeoutMs: z.number().int().positive().max(60000).optional(),
});

server.registerTool(
  "run_allowed_command",
  {
    title: "Commande autorisée",
    description: "Exécute une commande déclarée dans MCP_ALLOWED_COMMANDS",
    inputSchema: AllowedCommandSchema,
    outputSchema: z.object({
      command: z.string(),
      args: z.array(z.string()),
      code: z.number(),
      stdout: z.string(),
      stderr: z.string(),
      success: z.boolean(),
    }),
  },
  async ({ command, args = [], timeoutMs }) => {
    const allowed = new Set(ALLOWED_COMMANDS);
    if (!allowed.has(command)) {
      throw new Error(`Commande non autorisée: ${command}`);
    }

    const timeout = timeoutMs ?? DEFAULT_TIMEOUT;
    const result = await runCommand(command, args, { timeout, cwd: undefined, env: process.env });
    const preview = result.stdout.trim() || result.stderr.trim() || "(pas de sortie)";

    return {
      content: [{ type: "text", text: preview.slice(0, MAX_OUTPUT) }],
      structuredContent: {
        command,
        args,
        code: result.code,
        stdout: result.stdout.slice(0, MAX_OUTPUT),
        stderr: result.stderr.slice(0, MAX_OUTPUT),
        success: result.success,
      },
    };
  }
);

server.registerTool(
  "uptime",
  {
    title: "Uptime",
    description: "Affiche le temps de fonctionnement du serveur",
    inputSchema: z.object({}).strict(),
    outputSchema: z.object({ uptime: z.string() }),
  },
  async () => {
    const result = await runCommand("/usr/bin/uptime", ["-p"], { timeout: DEFAULT_TIMEOUT, cwd: undefined, env: process.env });
    const uptime = result.stdout.trim();
    return {
      content: [{ type: "text", text: uptime }],
      structuredContent: { uptime },
    };
  }
);

const app = express();
app.use(express.json());

app.use((req, res, next) => {
  if (!TOKEN) {
    return res.status(500).send("MCP_TOKEN non défini");
  }
  const authHeader = req.headers.authorization ?? "";
  if (authHeader !== `Bearer ${TOKEN}`) {
    return res.status(401).send("Non autorisé");
  }
  return next();
});

app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });
  res.on("close", () => {
    transport.close();
  });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

app.get("/healthz", async (_req, res) => {
  try {
    await fs.access(TASKS_FILE);
    res.json({ status: "ok" });
  } catch (error) {
    const reason = error instanceof Error ? error.message : "unknown";
    res.status(500).json({ status: "error", reason });
  }
});

app.listen(PORT, () => {
  console.log(`✅ MCP task server disponible sur http://localhost:${PORT}/mcp`);
});
