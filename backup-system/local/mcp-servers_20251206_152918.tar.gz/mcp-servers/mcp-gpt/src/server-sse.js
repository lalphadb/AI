import express from "express";
import dotenv from "dotenv";
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, "../.env") });

const execFileAsync = promisify(execFile);

const TOKEN = process.env.MCP_TOKEN;
const PORT = parseInt(process.env.PORT || "9091", 10);

// --- MCP server ---
const server = new McpServer({
  name: "mcp-gpt",
  version: "1.0.0",
});

// Tool 1 : uptime
server.registerTool(
  "uptime",
  {
    title: "Uptime",
    description: "Affiche le temps de fonctionnement du système",
    inputSchema: z.object({}).strict(),
    outputSchema: z.object({ uptime: z.string() }),
  },
  async () => {
    const { stdout } = await execFileAsync("/usr/bin/uptime", ["-p"]);
    const output = { uptime: stdout.trim() };
    return {
      content: [{ type: "text", text: output.uptime }],
      structuredContent: output,
    };
  }
);

// Tool 2 : run_allowed
const AllowedCmd = z.enum(["ls", "df", "du", "ps", "hostname"]);
server.registerTool(
  "run_allowed",
  {
    title: "Commande whitelist",
    description: "Exécute une commande autorisée (ls, df, du, ps, hostname)",
    inputSchema: z.object({
      command: AllowedCmd,
      args: z.array(z.string()).optional().default([]),
    }),
    outputSchema: z.object({ stdout: z.string() }),
  },
  async ({ command, args }) => {
    const { stdout } = await execFileAsync(`/usr/bin/${command}`, args, { timeout: 8000 });
    const output = { stdout: stdout.slice(0, 5000) };
    return {
      content: [{ type: "text", text: output.stdout }],
      structuredContent: output,
    };
  }
);

// --- Express app ---
const app = express();
app.use(express.json());

// Auth middleware (skip for GET /)
app.use((req, res, next) => {
  if (req.path === "/" && req.method === "GET") {
    return next();
  }
  if (!TOKEN) return res.status(500).send("MCP_TOKEN non défini");
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${TOKEN}`) return res.status(401).send("Non autorisé");
  next();
});

// Endpoint SSE (Server-Sent Events)
app.get("/sse", async (req, res) => {
  console.log("📡 Nouvelle connexion SSE");
  
  const transport = new SSEServerTransport("/messages", res);
  
  res.on("close", () => {
    console.log("🔌 Connexion SSE fermée");
    transport.close();
  });
  
  await server.connect(transport);
});

// Endpoint pour envoyer des messages au serveur MCP via SSE
app.post("/messages", async (req, res) => {
  console.log("📨 Message reçu:", req.body);
  res.json({ status: "received" });
});

// Endpoint HTTP classique (pour compatibilité)
app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });
  res.on("close", () => {
    transport.close();
  });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

// Page de test
app.get("/", (req, res) => {
  res.send(`
    <html>
      <head><title>MCP-GPT SSE Test</title></head>
      <body>
        <h1>MCP-GPT Server - Test SSE</h1>
        <p>Token: ${TOKEN ? TOKEN.substring(0, 10) + "..." : "Non défini"}</p>
        <div id="status">Status: <span id="connection">Disconnected</span></div>
        <div id="messages"></div>
        <hr>
        <h2>Test connexion avec authentification</h2>
        <button onclick="testSSE()">Tester SSE avec auth</button>
        <div id="test-result"></div>
        <script>
          function testSSE() {
            const resultDiv = document.getElementById('test-result');
            resultDiv.innerHTML = 'Test en cours...';
            
            fetch('/sse', {
              headers: {
                'Authorization': 'Bearer ${TOKEN}'
              }
            }).then(response => {
              resultDiv.innerHTML = 'Réponse: ' + response.status + ' ' + response.statusText;
            }).catch(err => {
              resultDiv.innerHTML = 'Erreur: ' + err.message;
            });
          }
        </script>
      </body>
    </html>
  `);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ MCP server avec SSE sur http://0.0.0.0:${PORT}`);
  console.log(`📡 Endpoint SSE: http://0.0.0.0:${PORT}/sse`);
  console.log(`🔧 Endpoint MCP: http://0.0.0.0:${PORT}/mcp`);
  console.log(`🌐 Test page: http://0.0.0.0:${PORT}/`);
  console.log(`🔑 Token: ${TOKEN ? TOKEN.substring(0, 10) + "..." : "Non défini"}`);
});
