import express from "express";
import SSE from "express-sse";
import { z } from "zod";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { Tool } from "@modelcontextprotocol/sdk/types.js";
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

// --- Variables d’environnement ---
const TOKEN = process.env.MCP_TOKEN;
const PORT = process.env.PORT || 8080;

// --- Initialisation du serveur MCP ---
const mcp = new Server({ name: "mcp-gpt", version: "1.0.0" });

// --- Tool #1 : uptime ---
mcp.tool("uptime", "Affiche le temps de fonctionnement du système", async () => {
  const { stdout } = await execFileAsync("/usr/bin/uptime", ["-p"]);
  return { content: [{ type: "text", text: stdout.trim() }] };
});

// --- Tool #2 : run_allowed (liste blanche) ---
const AllowedCmd = z.enum(["ls", "df", "du"]);
mcp.tool(
  "run_allowed",
  "Exécute une commande autorisée (ls, df, du)",
  async ({ command, args = [] }: { command: z.infer<typeof AllowedCmd>; args?: string[] }) => {
    AllowedCmd.parse(command);
    const { stdout } = await execFileAsync(`/usr/bin/${command}`, args, { timeout: 8000 });
    return { content: [{ type: "text", text: stdout.slice(0, 5000) }] };
  },
  {
    schema: {
      type: "object",
      properties: {
        command: { type: "string", enum: AllowedCmd.options },
        args: { type: "array", items: { type: "string" } },
      },
      required: ["command"],
    } satisfies Tool["inputSchema"],
  }
);

// --- Serveur Express + SSE ---
const app = express();
const sse = new SSE();

app.use((req, res, next) => {
  if (!TOKEN) return res.status(500).send("MCP_TOKEN non défini");
  const auth = req.headers.authorization || "";
  if (auth !== `Bearer ${TOKEN}`) return res.status(401).send("Non autorisé");
  next();
});

app.get("/sse", (req, res) => mcp.handleSSE(req, res, sse));
app.post("/call_tool", express.json(), async (req, res) => {
  const result = await mcp.handleCallTool(req.body);
  res.json(result);
});

app.listen(PORT, () => console.log(`✅ MCP server en écoute sur le port ${PORT}`));
