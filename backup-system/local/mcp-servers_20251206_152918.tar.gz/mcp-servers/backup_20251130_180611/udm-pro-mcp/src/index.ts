#!/usr/bin/env node
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import { Client } from 'ssh2';
import * as fs from 'fs';
import * as path from 'path';
import { homedir } from 'os';

// Configuration SSH
const SSH_CONFIG = {
  host: '10.10.10.1',
  port: 22,
  username: 'root',
  privateKeyPath: path.join(homedir(), '.ssh', 'id_rsa_udm'),
};

// Outils disponibles
const TOOLS: Tool[] = [
  {
    name: 'udm_connection_test',
    description: 'Tester la connexion SSH au UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {}
    }
  },
  {
    name: 'udm_exec',
    description: 'Exécuter une commande sur le UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {
        command: {
          type: 'string',
          description: 'Commande à exécuter sur le UDM-Pro'
        },
        timeout: {
          type: 'number',
          description: 'Timeout en millisecondes',
          default: 30000
        }
      },
      required: ['command']
    }
  },
  {
    name: 'udm_status',
    description: 'Obtenir le statut complet du UDM-Pro (système, réseau, clients)',
    inputSchema: {
      type: 'object',
      properties: {
        detailed: {
          type: 'boolean',
          description: 'Inclure des informations détaillées',
          default: false
        }
      }
    }
  },
  {
    name: 'udm_network_info',
    description: 'Obtenir les informations réseau du UDM-Pro (interfaces, VLANs, clients)',
    inputSchema: {
      type: 'object',
      properties: {
        include_clients: {
          type: 'boolean',
          description: 'Inclure la liste des clients connectés',
          default: false
        }
      }
    }
  },
  {
    name: 'udm_device_list',
    description: 'Lister tous les appareils UniFi gérés par le UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {}
    }
  },
  {
    name: 'udm_logs',
    description: 'Consulter les logs système du UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {
        lines: {
          type: 'number',
          description: 'Nombre de lignes à récupérer',
          default: 50
        },
        filter: {
          type: 'string',
          description: 'Filtrer les logs (grep pattern)'
        }
      }
    }
  },
  {
    name: 'udm_backup_config',
    description: 'Créer une sauvegarde de la configuration du UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {
        destination: {
          type: 'string',
          description: 'Chemin de destination pour le backup',
          default: '/tmp'
        }
      }
    }
  },
  {
    name: 'udm_firewall_rules',
    description: 'Lister les règles de firewall du UDM-Pro',
    inputSchema: {
      type: 'object',
      properties: {}
    }
  }
];

class UDMProMCPServer {
  private server: Server;
  private sshClient: Client | null = null;

  constructor() {
    this.server = new Server(
      {
        name: 'udm-pro-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupHandlers();
    this.setupErrorHandling();
  }

  private setupErrorHandling(): void {
    this.server.onerror = (error) => {
      console.error('[MCP Error]', error);
    };

    process.on('SIGINT', async () => {
      if (this.sshClient) {
        this.sshClient.end();
      }
      await this.server.close();
      process.exit(0);
    });
  }

  private async executeSSHCommand(command: string, timeout: number = 30000): Promise<{ stdout: string; stderr: string; success: boolean }> {
    return new Promise((resolve, reject) => {
      const client = new Client();
      let stdout = '';
      let stderr = '';

      const timer = setTimeout(() => {
        client.end();
        reject(new Error(`Command timeout after ${timeout}ms`));
      }, timeout);

      client.on('ready', () => {
        client.exec(command, (err, stream) => {
          if (err) {
            clearTimeout(timer);
            client.end();
            reject(err);
            return;
          }

          stream.on('close', (code: number) => {
            clearTimeout(timer);
            client.end();
            resolve({
              stdout: stdout.trim(),
              stderr: stderr.trim(),
              success: code === 0
            });
          });

          stream.on('data', (data: Buffer) => {
            stdout += data.toString();
          });

          stream.stderr.on('data', (data: Buffer) => {
            stderr += data.toString();
          });
        });
      });

      client.on('error', (err) => {
        clearTimeout(timer);
        reject(err);
      });

      // Lire la clé privée
      let privateKey: Buffer;
      try {
        privateKey = fs.readFileSync(SSH_CONFIG.privateKeyPath);
      } catch (error) {
        clearTimeout(timer);
        reject(new Error(`Cannot read private key at ${SSH_CONFIG.privateKeyPath}: ${error}`));
        return;
      }

      client.connect({
        host: SSH_CONFIG.host,
        port: SSH_CONFIG.port,
        username: SSH_CONFIG.username,
        privateKey: privateKey,
      });
    });
  }

  private setupHandlers(): void {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: TOOLS,
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      try {
        const { name, arguments: args } = request.params;

        switch (name) {
          case 'udm_connection_test':
            return await this.handleConnectionTest();
          case 'udm_exec':
            return await this.handleExec(args);
          case 'udm_status':
            return await this.handleStatus(args);
          case 'udm_network_info':
            return await this.handleNetworkInfo(args);
          case 'udm_device_list':
            return await this.handleDeviceList();
          case 'udm_logs':
            return await this.handleLogs(args);
          case 'udm_backup_config':
            return await this.handleBackupConfig(args);
          case 'udm_firewall_rules':
            return await this.handleFirewallRules();
          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        return {
          content: [
            {
              type: 'text',
              text: `Error: ${errorMessage}`,
            },
          ],
        };
      }
    });
  }

  private async handleConnectionTest() {
    try {
      const result = await this.executeSSHCommand('hostname && uname -a');
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: true,
              message: 'SSH connection successful',
              hostname: result.stdout.split('\n')[0],
              system: result.stdout.split('\n')[1],
            }, null, 2),
          },
        ],
      };
    } catch (error) {
      throw new Error(`SSH connection failed: ${error}`);
    }
  }

  private async handleExec(args: any) {
    const { command, timeout = 30000 } = args;

    if (!command) {
      throw new Error('Command is required');
    }

    try {
      const result = await this.executeSSHCommand(command, timeout);
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              command,
              stdout: result.stdout,
              stderr: result.stderr,
              success: result.success
            }, null, 2),
          },
        ],
      };
    } catch (error) {
      throw new Error(`Command execution failed: ${error}`);
    }
  }

  private async handleStatus(args: any) {
    const { detailed = false } = args;

    try {
      const commands = [
        'uptime',
        'df -h',
        'free -h',
        'top -bn1 | head -20'
      ];

      if (detailed) {
        commands.push('ps aux | head -20');
        commands.push('netstat -tuln | head -20');
      }

      const result = await this.executeSSHCommand(commands.join(' && echo "---" && '));

      return {
        content: [
          {
            type: 'text',
            text: result.stdout,
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to get UDM status: ${error}`);
    }
  }

  private async handleNetworkInfo(args: any) {
    const { include_clients = false } = args;

    try {
      let command = 'ip addr show && echo "---" && ip route show';
      
      if (include_clients) {
        // Commande UniFi pour lister les clients (peut varier selon la version)
        command += ' && echo "---" && ubnt-tools list-stations';
      }

      const result = await this.executeSSHCommand(command);

      return {
        content: [
          {
            type: 'text',
            text: result.stdout,
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to get network info: ${error}`);
    }
  }

  private async handleDeviceList() {
    try {
      // Commande pour lister les appareils UniFi
      const result = await this.executeSSHCommand('ubnt-device-discovery');

      return {
        content: [
          {
            type: 'text',
            text: result.stdout || 'No devices found or command not available',
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to list devices: ${error}`);
    }
  }

  private async handleLogs(args: any) {
    const { lines = 50, filter } = args;

    try {
      let command = `tail -n ${lines} /var/log/messages`;
      
      if (filter) {
        command += ` | grep "${filter}"`;
      }

      const result = await this.executeSSHCommand(command);

      return {
        content: [
          {
            type: 'text',
            text: result.stdout || 'No logs found',
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to get logs: ${error}`);
    }
  }

  private async handleBackupConfig(args: any) {
    const { destination = '/tmp' } = args;

    try {
      const timestamp = new Date().toISOString().replace(/:/g, '-').split('.')[0];
      const backupFile = `udm-backup-${timestamp}.tar.gz`;
      const command = `tar -czf ${destination}/${backupFile} /data/unifi/data/backup/autobackup/* 2>/dev/null || echo "Backup created but some files may be missing"`;

      const result = await this.executeSSHCommand(command);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: true,
              backupFile: `${destination}/${backupFile}`,
              message: result.stdout || 'Backup created',
            }, null, 2),
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to backup config: ${error}`);
    }
  }

  private async handleFirewallRules() {
    try {
      const result = await this.executeSSHCommand('iptables -L -n -v');

      return {
        content: [
          {
            type: 'text',
            text: result.stdout,
          },
        ],
      };
    } catch (error) {
      throw new Error(`Failed to get firewall rules: ${error}`);
    }
  }

  async run(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error('UDM-Pro MCP Server running on stdio');
  }
}

const server = new UDMProMCPServer();
server.run().catch(console.error);
