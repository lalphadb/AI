import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { ChromaClient } from "chromadb";

const CHROMA_HOST = process.env.CHROMA_HOST || "localhost";
const CHROMA_PORT = process.env.CHROMA_PORT || "8000";

const client = new ChromaClient({
  path: `http://${CHROMA_HOST}:${CHROMA_PORT}`
});

const server = new Server(
  { name: "chromadb-mcp", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

// Définition des outils
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "create_collection",
      description: "Créer une nouvelle collection dans ChromaDB pour stocker des documents",
      inputSchema: {
        type: "object",
        properties: {
          name: { type: "string", description: "Nom de la collection" },
          metadata: { type: "object", description: "Métadonnées optionnelles" }
        },
        required: ["name"]
      }
    },
    {
      name: "list_collections",
      description: "Lister toutes les collections disponibles dans ChromaDB",
      inputSchema: { type: "object", properties: {} }
    },
    {
      name: "add_documents",
      description: "Ajouter des documents à une collection avec embeddings automatiques",
      inputSchema: {
        type: "object",
        properties: {
          collection: { type: "string", description: "Nom de la collection" },
          documents: { 
            type: "array", 
            items: { type: "string" },
            description: "Liste des documents texte à ajouter" 
          },
          ids: { 
            type: "array", 
            items: { type: "string" },
            description: "IDs uniques pour chaque document" 
          },
          metadatas: { 
            type: "array", 
            items: { type: "object" },
            description: "Métadonnées pour chaque document" 
          }
        },
        required: ["collection", "documents", "ids"]
      }
    },
    {
      name: "search_documents",
      description: "Rechercher des documents similaires dans une collection par requête textuelle",
      inputSchema: {
        type: "object",
        properties: {
          collection: { type: "string", description: "Nom de la collection" },
          query: { type: "string", description: "Texte de recherche" },
          n_results: { type: "number", description: "Nombre de résultats (défaut: 5)" }
        },
        required: ["collection", "query"]
      }
    },
    {
      name: "delete_collection",
      description: "Supprimer une collection et tous ses documents",
      inputSchema: {
        type: "object",
        properties: {
          name: { type: "string", description: "Nom de la collection à supprimer" }
        },
        required: ["name"]
      }
    },
    {
      name: "get_collection_info",
      description: "Obtenir les informations et statistiques d'une collection",
      inputSchema: {
        type: "object",
        properties: {
          name: { type: "string", description: "Nom de la collection" }
        },
        required: ["name"]
      }
    }
  ]
}));

// Gestionnaire des appels d'outils
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case "create_collection": {
        const collection = await client.createCollection({
          name: args.name,
          metadata: args.metadata || {}
        });
        return {
          content: [{
            type: "text",
            text: `✅ Collection "${args.name}" créée avec succès!`
          }]
        };
      }

      case "list_collections": {
        const collections = await client.listCollections();
        if (collections.length === 0) {
          return {
            content: [{
              type: "text",
              text: "Aucune collection trouvée dans ChromaDB."
            }]
          };
        }
        const list = collections.map(c => `- ${c.name}`).join("\n");
        return {
          content: [{
            type: "text",
            text: `📚 Collections disponibles:\n${list}`
          }]
        };
      }

      case "add_documents": {
        const collection = await client.getOrCreateCollection({ name: args.collection });
        await collection.add({
          ids: args.ids,
          documents: args.documents,
          metadatas: args.metadatas || args.documents.map(() => ({}))
        });
        return {
          content: [{
            type: "text",
            text: `✅ ${args.documents.length} document(s) ajouté(s) à la collection "${args.collection}"`
          }]
        };
      }

      case "search_documents": {
        const collection = await client.getCollection({ name: args.collection });
        const results = await collection.query({
          queryTexts: [args.query],
          nResults: args.n_results || 5
        });
        
        if (!results.documents[0] || results.documents[0].length === 0) {
          return {
            content: [{
              type: "text",
              text: `Aucun résultat trouvé pour "${args.query}" dans "${args.collection}"`
            }]
          };
        }

        const formattedResults = results.documents[0].map((doc, i) => {
          const distance = results.distances?.[0]?.[i]?.toFixed(4) || "N/A";
          const id = results.ids[0][i];
          return `[${i+1}] (score: ${distance}) ID: ${id}\n${doc}\n`;
        }).join("\n---\n");

        return {
          content: [{
            type: "text",
            text: `🔍 Résultats pour "${args.query}":\n\n${formattedResults}`
          }]
        };
      }

      case "delete_collection": {
        await client.deleteCollection({ name: args.name });
        return {
          content: [{
            type: "text",
            text: `🗑️ Collection "${args.name}" supprimée.`
          }]
        };
      }

      case "get_collection_info": {
        const collection = await client.getCollection({ name: args.name });
        const count = await collection.count();
        return {
          content: [{
            type: "text",
            text: `📊 Collection "${args.name}":\n- Documents: ${count}\n- ID: ${collection.id}`
          }]
        };
      }

      default:
        return {
          content: [{ type: "text", text: `Outil inconnu: ${name}` }],
          isError: true
        };
    }
  } catch (error) {
    return {
      content: [{ type: "text", text: `Erreur: ${error.message}` }],
      isError: true
    };
  }
});

// Démarrage du serveur
const transport = new StdioServerTransport();
await server.connect(transport);
console.error("ChromaDB MCP Server démarré");
