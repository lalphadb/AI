#!/usr/bin/env node
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import { exec } from 'child_process';
import { promisify } from 'util';
import si from 'systeminformation';
import * as fs from 'fs/promises';
import * as path from 'path';

const execAsync = promisify(exec);

// Définition des outils disponibles
const TOOLS: Tool[] = [
  {
    name: 'system_info',
    description: 'Obtenir des informations détaillées sur le système Ubuntu (CPU, mémoire, disque, OS)',
    inputSchema: {
      type: 'object',
      properties: {
        category: {
          type: 'string',
          enum: ['all', 'cpu', 'memory', 'disk', 'os', 'network'],
          description: 'Catégorie d\'informations à récupérer',
          default: 'all'
        }
      }
    }
  },
  {
    name: 'list_processes',
    description: 'Lister les processus en cours d\'exécution avec détails (PID, CPU, mémoire)',
    inputSchema: {
      type: 'object',
      properties: {
        sortBy: {
          type: 'string',
          enum: ['cpu', 'memory', 'name'],
          description: 'Critère de tri',
          default: 'cpu'
        },
        limit: {
          type: 'number',
          description: 'Nombre de processus à retourner',
          default: 20
        }
      }
    }
  },
  {
    name: 'execute_command',
    description: 'Exécuter une commande shell sur le serveur Ubuntu',
    inputSchema: {
      type: 'object',
      properties: {
        command: {
          type: 'string',
          description: 'Commande à exécuter'
        },
        timeout: {
          type: 'number',
          description: 'Timeout en millisecondes',
          default: 30000
        }
      },
      required: ['command']
    }
  },
  {
    name: 'service_status',
    description: 'Vérifier le statut d\'un service systemd',
    inputSchema: {
      type: 'object',
      properties: {
        service: {
          type: 'string',
          description: 'Nom du service (ex: nginx, apache2, mysql)'
        }
      },
      required: ['service']
    }
  },
  {
    name: 'service_control',
    description: 'Contrôler un service systemd (start, stop, restart, enable, disable)',
    inputSchema: {
      type: 'object',
      properties: {
        service: {
          type: 'string',
          description: 'Nom du service'
        },
        action: {
          type: 'string',
          enum: ['start', 'stop', 'restart', 'enable', 'disable', 'reload'],
          description: 'Action à effectuer'
        }
      },
      required: ['service', 'action']
    }
  },
  {
    name: 'disk_usage',
    description: 'Analyser l\'utilisation du disque par répertoire',
    inputSchema: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'Chemin du répertoire à analyser',
          default: '/'
        },
        depth: {
          type: 'number',
          description: 'Profondeur de l\'analyse',
          default: 1
        }
      }
    }
  },
  {
    name: 'network_info',
    description: 'Obtenir des informations réseau (interfaces, connexions actives, ports ouverts)',
    inputSchema: {
      type: 'object',
      properties: {
        detailed: {
          type: 'boolean',
          description: 'Inclure les détails des connexions',
          default: false
        }
      }
    }
  },
  {
    name: 'log_analyzer',
    description: 'Analyser les logs système',
    inputSchema: {
      type: 'object',
      properties: {
        logFile: {
          type: 'string',
          description: 'Chemin du fichier de log',
          default: '/var/log/syslog'
        },
        lines: {
          type: 'number',
          description: 'Nombre de lignes à récupérer',
          default: 100
        },
        filter: {
          type: 'string',
          description: 'Filtrer les logs (grep pattern)'
        }
      }
    }
  },
  {
    name: 'docker_status',
    description: 'Obtenir le statut des conteneurs Docker',
    inputSchema: {
      type: 'object',
      properties: {
        all: {
          type: 'boolean',
          description: 'Inclure les conteneurs arrêtés',
          default: false
        }
      }
    }
  },
  {
    name: 'file_search',
    description: 'Rechercher des fichiers sur le système',
    inputSchema: {
      type: 'object',
      properties: {
        directory: {
          type: 'string',
          description: 'Répertoire de recherche',
          default: '/home'
        },
        pattern: {
          type: 'string',
          description: 'Pattern de recherche (nom de fichier)'
        },
        maxDepth: {
          type: 'number',
          description: 'Profondeur maximale',
          default: 5
        }
      },
      required: ['pattern']
    }
  },
  {
    name: 'security_check',
    description: 'Vérifier la sécurité du système (updates, ports ouverts, users)',
    inputSchema: {
      type: 'object',
      properties: {
        checkType: {
          type: 'string',
          enum: ['updates', 'ports', 'users', 'firewall', 'all'],
          description: 'Type de vérification',
          default: 'all'
        }
      }
    }
  },
  {
    name: 'backup_manager',
    description: 'Gérer les sauvegardes (créer, lister, restaurer)',
    inputSchema: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['create', 'list', 'info'],
          description: 'Action de backup'
        },
        source: {
          type: 'string',
          description: 'Répertoire source pour backup'
        },
        destination: {
          type: 'string',
          description: 'Destination du backup'
        }
      },
      required: ['action']
    }
  }
];

class UbuntuMCPServer {
  private server: Server;

  constructor() {
    this.server = new Server(
      {
        name: 'ubuntu-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupHandlers();
    this.setupErrorHandling();
  }

  private setupErrorHandling(): void {
    this.server.onerror = (error) => {
      console.error('[MCP Error]', error);
    };

    process.on('SIGINT', async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  private setupHandlers(): void {
    // Handler pour lister les outils
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: TOOLS,
    }));

    // Handler pour appeler les outils
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      try {
        const { name, arguments: args } = request.params;
        
        switch (name) {
          case 'system_info':
            return await this.handleSystemInfo(args);
          case 'list_processes':
            return await this.handleListProcesses(args);
          case 'execute_command':
            return await this.handleExecuteCommand(args);
          case 'service_status':
            return await this.handleServiceStatus(args);
          case 'service_control':
            return await this.handleServiceControl(args);
          case 'disk_usage':
            return await this.handleDiskUsage(args);
          case 'network_info':
            return await this.handleNetworkInfo(args);
          case 'log_analyzer':
            return await this.handleLogAnalyzer(args);
          case 'docker_status':
            return await this.handleDockerStatus(args);
          case 'file_search':
            return await this.handleFileSearch(args);
          case 'security_check':
            return await this.handleSecurityCheck(args);
          case 'backup_manager':
            return await this.handleBackupManager(args);
          default:
            throw new Error(`Outil inconnu: ${name}`);
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
        return {
          content: [
            {
              type: 'text',
              text: `Erreur: ${errorMessage}`,
            },
          ],
        };
      }
    });
  }

  private async handleSystemInfo(args: any) {
    const category = args?.category || 'all';
    const info: any = {};

    try {
      if (category === 'all' || category === 'cpu') {
        info.cpu = await si.cpu();
        info.cpuLoad = await si.currentLoad();
      }
      if (category === 'all' || category === 'memory') {
        info.memory = await si.mem();
      }
      if (category === 'all' || category === 'disk') {
        info.diskLayout = await si.diskLayout();
        info.fsSize = await si.fsSize();
      }
      if (category === 'all' || category === 'os') {
        info.os = await si.osInfo();
        info.versions = await si.versions();
      }
      if (category === 'all' || category === 'network') {
        info.networkInterfaces = await si.networkInterfaces();
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(info, null, 2),
          },
        ],
      };
    } catch (error) {
      throw new Error(`Erreur lors de la récupération des informations système: ${error}`);
    }
  }

  private async handleListProcesses(args: any) {
    const sortBy = args?.sortBy || 'cpu';
    const limit = args?.limit || 20;

    try {
      const processes = await si.processes();
      let sorted = processes.list;

      // Trier selon le critère
      if (sortBy === 'cpu') {
        sorted.sort((a, b) => (b.cpu || 0) - (a.cpu || 0));
      } else if (sortBy === 'memory') {
        sorted.sort((a, b) => (b.mem || 0) - (a.mem || 0));
      } else if (sortBy === 'name') {
        sorted.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
      }

      // Limiter le nombre de résultats
      const limitedProcesses = sorted.slice(0, limit);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              total: processes.all,
              running: processes.running,
              processes: limitedProcesses.map(p => ({
                pid: p.pid,
                name: p.name,
                cpu: p.cpu,
                mem: p.mem,
                state: p.state,
                command: p.command
              }))
            }, null, 2),
          },
        ],
      };
    } catch (error) {
      throw new Error(`Erreur lors de la récupération des processus: ${error}`);
    }
  }

  private async handleExecuteCommand(args: any) {
    const { command, timeout = 30000 } = args;

    if (!command) {
      throw new Error('Commande requise');
    }

    try {
      const { stdout, stderr } = await execAsync(command, {
        timeout,
        maxBuffer: 1024 * 1024 * 10, // 10MB
      });

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              command,
              stdout: stdout.trim(),
              stderr: stderr.trim(),
              success: true
            }, null, 2),
          },
        ],
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              command,
              stdout: error.stdout?.trim() || '',
              stderr: error.stderr?.trim() || error.message,
              success: false
            }, null, 2),
          },
        ],
      };
    }
  }

  private async handleServiceStatus(args: any) {
    const { service } = args;

    if (!service) {
      throw new Error('Nom du service requis');
    }

    try {
      const { stdout } = await execAsync(`systemctl status ${service}`);
      return {
        content: [
          {
            type: 'text',
            text: stdout,
          },
        ],
      };
    } catch (error: any) {
      // systemctl status retourne un code d'erreur si le service n'est pas actif
      return {
        content: [
          {
            type: 'text',
            text: error.stdout || error.message,
          },
        ],
      };
    }
  }

  private async handleServiceControl(args: any) {
    const { service, action } = args;

    if (!service || !action) {
      throw new Error('Service et action requis');
    }

    try {
      const { stdout, stderr } = await execAsync(`sudo systemctl ${action} ${service}`);
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              service,
              action,
              success: true,
              output: stdout || stderr
            }, null, 2),
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors du contrôle du service: ${error.message}`);
    }
  }

  private async handleDiskUsage(args: any) {
    const { path: dirPath = '/', depth = 1 } = args;

    try {
      const { stdout } = await execAsync(`du -h --max-depth=${depth} ${dirPath} | sort -hr`);
      return {
        content: [
          {
            type: 'text',
            text: stdout,
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors de l'analyse du disque: ${error.message}`);
    }
  }

  private async handleNetworkInfo(args: any) {
    const { detailed = false } = args;

    try {
      const networkInterfaces = await si.networkInterfaces();
      const networkStats = await si.networkStats();
      
      let result: any = {
        interfaces: networkInterfaces,
        stats: networkStats
      };

      if (detailed) {
        const { stdout: connections } = await execAsync('ss -tuln');
        result.connections = connections;
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors de la récupération des informations réseau: ${error.message}`);
    }
  }

  private async handleLogAnalyzer(args: any) {
    const { logFile = '/var/log/syslog', lines = 100, filter } = args;

    try {
      let command = `tail -n ${lines} ${logFile}`;
      if (filter) {
        command += ` | grep "${filter}"`;
      }

      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: 'text',
            text: stdout,
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors de l'analyse des logs: ${error.message}`);
    }
  }

  private async handleDockerStatus(args: any) {
    const { all = false } = args;

    try {
      const command = all ? 'docker ps -a --format json' : 'docker ps --format json';
      const { stdout } = await execAsync(command);
      
      // Parse each line as JSON
      const containers = stdout.trim().split('\n')
        .filter(line => line.trim())
        .map(line => JSON.parse(line));

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({ containers }, null, 2),
          },
        ],
      };
    } catch (error: any) {
      if (error.message.includes('command not found')) {
        return {
          content: [
            {
              type: 'text',
              text: 'Docker n\'est pas installé sur ce système',
            },
          ],
        };
      }
      throw new Error(`Erreur lors de la récupération du statut Docker: ${error.message}`);
    }
  }

  private async handleFileSearch(args: any) {
    const { directory = '/home', pattern, maxDepth = 5 } = args;

    if (!pattern) {
      throw new Error('Pattern de recherche requis');
    }

    try {
      const { stdout } = await execAsync(
        `find ${directory} -maxdepth ${maxDepth} -name "${pattern}" 2>/dev/null`
      );
      return {
        content: [
          {
            type: 'text',
            text: stdout || 'Aucun fichier trouvé',
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors de la recherche de fichiers: ${error.message}`);
    }
  }

  private async handleSecurityCheck(args: any) {
    const { checkType = 'all' } = args;
    const results: any = {};

    try {
      if (checkType === 'all' || checkType === 'updates') {
        try {
          const { stdout } = await execAsync('apt list --upgradable 2>/dev/null | grep -c upgradable');
          results.updates = {
            available: parseInt(stdout.trim()) || 0
          };
        } catch (e) {
          results.updates = { error: 'Impossible de vérifier les mises à jour' };
        }
      }

      if (checkType === 'all' || checkType === 'ports') {
        const { stdout } = await execAsync('ss -tuln | grep LISTEN');
        results.openPorts = stdout;
      }

      if (checkType === 'all' || checkType === 'users') {
        const { stdout } = await execAsync('cat /etc/passwd | grep -v nologin | grep -v false');
        results.users = stdout;
      }

      if (checkType === 'all' || checkType === 'firewall') {
        try {
          const { stdout } = await execAsync('sudo ufw status');
          results.firewall = stdout;
        } catch (e) {
          results.firewall = 'UFW non disponible ou non installé';
        }
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(results, null, 2),
          },
        ],
      };
    } catch (error: any) {
      throw new Error(`Erreur lors de la vérification de sécurité: ${error.message}`);
    }
  }

  private async handleBackupManager(args: any) {
    const { action, source, destination } = args;

    try {
      switch (action) {
        case 'create':
          if (!source || !destination) {
            throw new Error('Source et destination requises pour créer un backup');
          }
          const timestamp = new Date().toISOString().replace(/:/g, '-');
          const backupName = `backup-${timestamp}.tar.gz`;
          const backupPath = path.join(destination, backupName);
          
          const { stdout } = await execAsync(`tar -czf ${backupPath} ${source}`);
          return {
            content: [
              {
                type: 'text',
                text: JSON.stringify({
                  action: 'create',
                  success: true,
                  backupPath,
                  message: 'Backup créé avec succès'
                }, null, 2),
              },
            ],
          };

        case 'list':
          const listPath = destination || '/home/backups';
          const { stdout: files } = await execAsync(`ls -lh ${listPath}/*.tar.gz 2>/dev/null || echo "Aucun backup trouvé"`);
          return {
            content: [
              {
                type: 'text',
                text: files,
              },
            ],
          };

        case 'info':
          if (!source) {
            throw new Error('Chemin du backup requis');
          }
          const { stdout: info } = await execAsync(`tar -tzf ${source} | head -20`);
          return {
            content: [
              {
                type: 'text',
                text: `Contenu du backup ${source}:\n${info}`,
              },
            ],
          };

        default:
          throw new Error(`Action inconnue: ${action}`);
      }
    } catch (error: any) {
      throw new Error(`Erreur lors de la gestion du backup: ${error.message}`);
    }
  }

  async run(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error('Ubuntu MCP Server running on stdio');
  }
}

const server = new UbuntuMCPServer();
server.run().catch(console.error);
