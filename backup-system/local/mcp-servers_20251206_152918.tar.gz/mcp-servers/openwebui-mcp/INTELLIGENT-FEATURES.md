# 🧠 Serveur MCP Intelligent

## ✨ Nouveautés - Version 2.0

Votre serveur MCP a été transformé en un système **intelligent et autonome** avec mémoire persistante et capacités avancées.

## 🎯 Nouvelles Fonctionnalités

### 1. 🧠 Mémoire Intelligente (`IntelligentMemory`)

**Système de mémoire persistante avec SQLite**

- **Stockage automatique** de toutes les interactions
- **Rappel contextuel** des informations
- **Apprentissage** des patterns et solutions
- **Base de données** : `/tmp/memory.db` (persistante pendant la vie du conteneur)

**Tables :**
- `memories` : Historique complet des actions
- `learnings` : Solutions apprises et leur efficacité
- `conversations` : Historique des dialogues
- `system_state` : État du système à différents moments

**Outils disponibles :**
```json
{
  "name": "remember",
  "description": "Mémoriser une information importante",
  "input": {
    "key": "Clé de la mémoire",
    "value": "Valeur à mémoriser",
    "context": "Contexte additionnel (optionnel)"
  }
}
```

```json
{
  "name": "recall",
  "description": "Rappeler une information mémorisée",
  "input": {
    "query": "Ce que vous cherchez"
  }
}
```

### 2. 🤖 Agent Intelligent (`IntelligentAgent`)

**Système de prise de décision autonome**

- **Analyse automatique** des problèmes
- **Génération d'actions** avec évaluation des risques
- **Auto-diagnostic** toutes les 5 minutes
- **Apprentissage** des solutions efficaces

**Outil disponible :**
```json
{
  "name": "intelligent_analysis",
  "description": "Analyser un problème et proposer des solutions",
  "input": {
    "problem": "Description du problème",
    "context": "Contexte additionnel (optionnel)"
  },
  "output": {
    "analysis": "Analyse détaillée",
    "actions": "Liste d'actions recommandées avec niveau de risque",
    "confidence": "Niveau de confiance (0-1)",
    "reasoning": "Raisonnement derrière les recommandations"
  }
}
```

### 3. 🌐 Générateur de Services Web (`WebServiceGenerator`)

**Création automatique de sites web, APIs, applications**

**Outil disponible :**
```json
{
  "name": "create_web_service",
  "description": "Créer un service web (site, API, application)",
  "input": {
    "name": "Nom du service",
    "type": "static | api | fullstack | proxy",
    "port": "Port d'écoute (ex: 8080)",
    "domain": "Nom de domaine (optionnel)"
  }
}
```

**Types de services :**

- **`static`** : Site web statique avec Nginx
  - HTML/CSS/JS moderne
  - Design responsive
  - Déploiement instantané

- **`api`** : API REST avec Express.js
  - Endpoints CRUD
  - CORS configuré
  - Health checks

- **`fullstack`** : Application Next.js
  - TypeScript + Tailwind CSS
  - SSR/SSG
  - App Router

- **`proxy`** : Reverse proxy Nginx
  - Load balancing
  - SSL/TLS ready
  - Configuration personnalisable

**Tous les services sont automatiquement :**
- ✅ Dockerisés
- ✅ Sur le réseau `traefik-net`
- ✅ Avec redémarrage automatique
- ✅ Intégrés avec Traefik (si domaine fourni)

### 4. 💻 Générateur de Code (`CodeGenerator`)

**Génération de code à partir de descriptions en langage naturel**

**Outil disponible :**
```json
{
  "name": "generate_code",
  "description": "Générer du code à partir d'une description",
  "input": {
    "description": "Description de ce que doit faire le code",
    "language": "typescript | javascript | python | bash | html | css",
    "type": "function | class | script | component | config",
    "save": true/false,
    "filename": "nom_du_fichier.ext (si save=true)"
  }
}
```

**Types de code générés :**

- **`function`** : Fonctions complètes
  - API calls
  - Manipulation de fichiers
  - Traitement de données
  - Requêtes base de données

- **`class`** : Classes avec méthodes CRUD
  - Typescript/JavaScript classes
  - Python classes
  - Méthodes complètes

- **`script`** : Scripts exécutables
  - Bash scripts avec logs
  - Python scripts avec logging
  - Gestion d'erreurs intégrée

- **`component`** : Composants React
  - Hooks (useState, useEffect)
  - Props typés
  - Style moderne

- **`config`** : Fichiers de configuration
  - Docker Compose
  - Nginx
  - Application configs

**Détection intelligente :**
- Le générateur analyse votre description et choisit le meilleur pattern
- Exemples pré-configurés pour API, DB, fichiers, etc.
- Code avec bonnes pratiques et gestion d'erreurs

## 🔄 Surveillance Autonome

Le système lance automatiquement un **auto-diagnostic toutes les 5 minutes** :

- ✅ Vérification de l'état du système
- ✅ Détection des problèmes potentiels
- ✅ Apprentissage automatique des solutions
- ✅ Mémorisation des diagnostics

**Activation :**
```
🧠 Système de surveillance autonome activé
```

## 📊 Exemples d'Utilisation

### Exemple 1 : Créer un site web

```
Utilisateur: "Crée-moi un site web vitrine pour mon entreprise"

Assistant appelle: create_web_service
{
  "name": "mon-entreprise",
  "type": "static",
  "port": 8080,
  "domain": "monentreprise.com"
}

Résultat:
✅ Service web 'mon-entreprise' créé avec succès
🌐 URL: http://monentreprise.com
```

### Exemple 2 : Générer une API

```
Utilisateur: "J'ai besoin d'une fonction pour récupérer des données depuis une API"

Assistant appelle: generate_code
{
  "description": "fonction pour récupérer des données depuis une API",
  "language": "typescript",
  "type": "function",
  "save": true,
  "filename": "api-fetcher.ts"
}

Résultat:
✨ Code généré avec fetch(), gestion d'erreurs, typage TypeScript
💾 Sauvegardé dans: /home/lalpha/generated-code/api-fetcher.ts
```

### Exemple 3 : Analyser un problème

```
Utilisateur: "Mon conteneur Docker redémarre sans arrêt"

Assistant appelle: intelligent_analysis
{
  "problem": "conteneur Docker redémarre sans arrêt",
  "context": "logs montrent erreur ECONNREFUSED"
}

Résultat:
🔍 Analyse intelligente:
**Problème:** Erreur de connexion réseau
**Confiance:** 85%
**Actions recommandées:**
1. [low] Vérifier la configuration réseau
2. [medium] Redémarrer le service dépendant
3. [low] Analyser les logs détaillés
💡 Solution apprise: Vérifier que le service dépendant est sur le même réseau Docker
```

### Exemple 4 : Mémoire persistante

```
# Mémoriser
Assistant appelle: remember
{
  "key": "serveur-production",
  "value": "IP: 192.168.1.100, Port: 8080",
  "context": "Serveur Node.js principal"
}

# Plus tard...
Assistant appelle: recall
{
  "query": "serveur production"
}

Résultat:
🧠 Mémoires trouvées:
📝 serveur-production: IP: 192.168.1.100, Port: 8080
   Serveur Node.js principal
   (mémorisé le 19/01/2025 à 15:30)
```

## 🏗️ Architecture

```
ServerAdminServer
├── 🧠 IntelligentMemory (SQLite)
│   ├── remember()
│   ├── recall()
│   ├── learn()
│   └── findSolution()
│
├── 🤖 IntelligentAgent
│   ├── analyzeProblem()
│   ├── generateActions()
│   ├── executeAction()
│   └── runAutoDiagnostic() [every 5min]
│
├── 🌐 WebServiceGenerator
│   ├── createStaticSite()
│   ├── createAPIService()
│   ├── createFullStackApp()
│   └── createReverseProxy()
│
└── 💻 CodeGenerator
    ├── generateFunction()
    ├── generateClass()
    ├── generateScript()
    ├── generateComponent()
    └── generateConfig()
```

## 🚀 Déploiement

Le serveur est déployé avec :

```bash
docker run -d \
  --name mcp-server \
  --network traefik-net \
  --restart unless-stopped \
  --pid=host \
  --privileged \
  -v /:/host:ro \
  -v /var/run/docker.sock:/var/run/docker.sock:ro \
  mcp-server:latest
```

**Accès :**
- Depuis le réseau Docker : `http://mcp-server:3000`
- OpenAPI spec : `http://mcp-server:3000/openapi.json`
- Diagnostic : `http://mcp-server:3000/api/diagnose`
- System info : `http://mcp-server:3000/api/system-info`

## 📝 Logs de Démarrage

```
📁 Tentative d'accès au répertoire: /tmp
📄 Chemin de la base: /tmp/memory.db
✓ Répertoire existant: /tmp
   Permissions: 41777
✓ Base de données ouverte: /tmp/memory.db
🧠 Système de surveillance autonome activé
Serveur MCP Admin HTTP démarré sur le port 3000
Serveur MCP Admin prêt et opérationnel
```

## 🎓 Apprentissage Continu

Le système **apprend de chaque interaction** :

1. **Mémorise** toutes les commandes exécutées
2. **Analyse** les succès et échecs
3. **Apprend** les patterns qui fonctionnent
4. **Propose** automatiquement les meilleures solutions

Plus vous l'utilisez, plus il devient intelligent ! 🧠✨

## 📊 Outils Disponibles dans Open WebUI

Après configuration, vous aurez accès à **25+ outils** dont :

**Standard :**
- `system_info` : Infos complètes du système
- `run_command` : Exécuter des commandes
- `check_service_status` : Statut des services
- `diagnose_system` : Diagnostic système
- `read_file`, `write_file`, `list_directory`
- `check_docker_containers`
- `analyze_logs`
- `monitor_resources`
- `backup_file`

**Intelligent (Nouveaux) :**
- `remember` : Mémoriser des infos
- `recall` : Rappeler des infos
- `create_web_service` : Créer des services web
- `generate_code` : Générer du code
- `intelligent_analysis` : Analyse intelligente

## 🔮 Prochaines Évolutions

- [ ] Générateur de serveurs mail (Postfix/Dovecot)
- [ ] Intégration avec LLM local pour génération de code plus avancée
- [ ] Dashboard web pour visualiser la mémoire et l'apprentissage
- [ ] API pour accéder aux learnings depuis l'extérieur
- [ ] Backup automatique de la base de données
- [ ] Système de notifications (Slack, Discord, Email)

## 🎉 Conclusion

Votre serveur MCP est maintenant **bien plus qu'un simple gestionnaire de serveur** :

✅ Il a une **mémoire** persistante  
✅ Il **apprend** de ses expériences  
✅ Il **crée** des services web automatiquement  
✅ Il **génère** du code à partir de descriptions  
✅ Il **analyse** et **résout** des problèmes de manière autonome  
✅ Il se **surveille** lui-même en arrière-plan  

**Bienvenue dans l'ère du serveur intelligent ! 🚀**
