# 🔍 Diagnostic de l'Erreur Open WebUI

## ❌ Erreur Actuelle
"Échec de la connexion" avec l'URL `http://host.docker.internal:3000`

## 🔧 Solutions à Tester

### Solution 1: Utiliser l'IP directe du serveur
Au lieu de `host.docker.internal:3000`, utilisez:
```
http://10.10.10.46:3000/mcp
```

**Raison**: `host.docker.internal` ne fonctionne que sur Docker Desktop (Windows/Mac), pas sur Linux.

### Solution 2: Utiliser l'IP de l'interface Docker
Si Open WebUI est dans Docker sur Linux:
```
http://172.17.0.1:3000/mcp
```

### Solution 3: Vérifier le réseau Docker
```bash
# Trouver l'IP du host depuis le conteneur Open WebUI
docker exec <container-id-openwebui> ip route | grep default
```

### Solution 4: Utiliser le nom d'hôte
```
http://lalpha-server-1:3000/mcp
```

## 🧪 Tests de Connectivité

### Test 1: Depuis le host
```bash
curl http://localhost:3000/health
# Devrait retourner: {"status":"ok",...}
```

### Test 2: Depuis l'intérieur du conteneur Open WebUI
```bash
docker exec <container-openwebui> curl http://172.17.0.1:3000/health
# OU
docker exec <container-openwebui> curl http://10.10.10.46:3000/health
```

### Test 3: Vérifier le firewall
```bash
sudo ufw status
# Si actif, ajouter:
sudo ufw allow 3000/tcp
```

## 📋 Configuration Recommandée pour Open WebUI

### Configuration A: IP Directe (RECOMMANDÉ)
```json
{
  "name": "Server Admin MCP",
  "url": "http://10.10.10.46:3000/mcp",
  "description": "Administration système intelligente",
  "enabled": true
}
```

### Configuration B: Interface Docker
```json
{
  "name": "Server Admin MCP",
  "url": "http://172.17.0.1:3000/mcp",
  "description": "Administration système intelligente",
  "enabled": true
}
```

### Configuration C: Gateway Docker
```json
{
  "name": "Server Admin MCP",
  "url": "http://172.17.0.1:3000/mcp",
  "description": "Administration système intelligente",
  "enabled": true
}
```

## 🔍 Commandes de Diagnostic

### 1. Vérifier quel réseau Docker utilise Open WebUI
```bash
docker inspect <container-openwebui> | grep -A 20 Networks
```

### 2. Vérifier si le port 3000 est accessible
```bash
sudo netstat -tlnp | grep 3000
```

### 3. Tester depuis le conteneur
```bash
# Obtenir l'ID du conteneur Open WebUI
docker ps | grep open-webui

# Tester la connexion
docker exec <container-id> curl -v http://10.10.10.46:3000/health
```

## ⚡ Solution Rapide

**ESSAYEZ CECI EN PREMIER:**

Dans Open WebUI, changez l'URL de:
```
http://host.docker.internal:3000
```

à:
```
http://10.10.10.46:3000/mcp
```

Puis cliquez sur "Enregistrer".

## 🐳 Alternative: Exposer le serveur dans le réseau Docker

Si rien ne fonctionne, vous pouvez mettre le serveur MCP dans le même réseau Docker qu'Open WebUI:

```bash
# Trouver le réseau d'Open WebUI
docker inspect <openwebui-container> | grep NetworkMode

# Créer un conteneur pour le serveur MCP
docker run -d \
  --name mcp-server \
  --network <network-openwebui> \
  -v /home/lalpha/projets/openWebUI-mcp:/app \
  -w /app \
  node:20 \
  node dist/index.js

# Utiliser ensuite l'URL:
http://mcp-server:3000/mcp
```

## 📝 Checklist de Dépannage

- [ ] Le serveur MCP est actif: `ps aux | grep "node dist/index.js"`
- [ ] Le port 3000 écoute: `netstat -tlnp | grep 3000`
- [ ] Le health check fonctionne: `curl http://localhost:3000/health`
- [ ] Le firewall autorise le port 3000: `sudo ufw status`
- [ ] Le conteneur Open WebUI peut atteindre le host: `docker exec ... curl ...`
- [ ] L'URL dans Open WebUI se termine par `/mcp`
- [ ] Le type est bien "MCP Streamable HTTP"

## 🎯 Action Immédiate

**ÉTAPE 1**: Dans Open WebUI, changez l'URL en:
```
http://10.10.10.46:3000/mcp
```

**ÉTAPE 2**: Cliquez sur "Enregistrer"

**ÉTAPE 3**: Actualisez la page

Si ça ne fonctionne toujours pas, testez depuis le conteneur:
```bash
docker ps | grep webui
docker exec -it <container-id> curl http://10.10.10.46:3000/health
```

Et partagez le résultat !
