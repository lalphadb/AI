#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
  InitializeRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { exec, execSync } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import os from "os";
import express from "express";
import cors from "cors";
import { IntelligentMemory } from "./intelligence/memory.js";
import { IntelligentAgent } from "./intelligence/agent.js";
import { WebServiceGenerator } from "./intelligence/webgen.js";
import { CodeGenerator } from "./intelligence/codegen.js";

const execAsync = promisify(exec);

class ServerAdminServer {
  private server: Server;
  private app: express.Application;
  private memory: IntelligentMemory;
  private agent: IntelligentAgent;
  private webGen: WebServiceGenerator;
  private codeGen: CodeGenerator;

  constructor() {
    // Initialiser Express
    this.app = express();
    this.app.use(cors({
      origin: '*',
      methods: ['GET', 'POST', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization'],
      credentials: true
    }));
    this.app.use(express.json());

    // Initialiser les systèmes intelligents
    this.memory = new IntelligentMemory();
    this.agent = new IntelligentAgent(this.memory);
    this.webGen = new WebServiceGenerator();
    this.codeGen = new CodeGenerator();

    this.server = new Server(
      {
        name: "server-admin-mcp-intelligent",
        version: "2.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupHttpRoutes();
    this.setupToolHandlers();
    this.setupRequestHandlers();

    // Démarrer l'auto-diagnostic en arrière-plan
    this.startBackgroundMonitoring();
  }

  private setupHttpRoutes() {
    // Route de santé pour vérifier que le serveur fonctionne
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        server: 'server-admin-mcp',
        version: '1.0.0',
        timestamp: new Date().toISOString()
      });
    });

    // OpenAPI/Swagger spec pour Open WebUI
    this.app.get('/openapi.json', (req, res) => {
      res.json(this.generateOpenAPISpec());
    });

    // Route principale MCP pour Open WebUI (SSE)
    this.app.post('/mcp', async (req, res) => {
      try {
        const request = req.body;

        // Configuration SSE pour Open WebUI
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        // Traiter les requêtes MCP selon leur type
        let response: any;

        switch (request.method) {
          case 'initialize':
            response = await this.handleInitialize(request);
            break;

          case 'tools/list':
            response = await this.handleListTools(request);
            break;

          case 'tools/call':
            response = await this.handleCallTool(request);
            break;

          case 'notifications/initialized':
            // Notification sans réponse requise
            res.status(204).end();
            return;

          case 'ping':
            response = { jsonrpc: "2.0", id: request.id, result: { status: "pong" } };
            break;

          default:
            console.warn(`Méthode MCP non supportée (ignorée): ${request.method}`);
            response = {
              jsonrpc: "2.0",
              id: request.id,
              error: {
                code: -32601,
                message: `Méthode non supportée: ${request.method}`
              }
            };
        }

        res.json(response);
      } catch (error) {
        console.error('Erreur MCP:', error);
        res.status(500).json({
          error: {
            code: -32000,
            message: 'Erreur interne du serveur MCP',
            data: error instanceof Error ? error.message : String(error)
          }
        });
      }
    });

    // Endpoint SSE pour compatibilité Open WebUI
    this.app.get('/sse', (req, res) => {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('Access-Control-Allow-Origin', '*');

      // Envoyer un message de connexion
      res.write(`data: ${JSON.stringify({ type: 'connected', server: 'server-admin-mcp' })}\n\n`);

      // Garder la connexion ouverte
      const keepAlive = setInterval(() => {
        res.write(`data: ${JSON.stringify({ type: 'ping' })}\n\n`);
      }, 30000);

      req.on('close', () => {
        clearInterval(keepAlive);
      });
    });

    // Route OPTIONS pour CORS
    this.app.options('/mcp', (req, res) => {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
      res.sendStatus(204);
    });

    // API REST pour Open WebUI (plus compatible que MCP)
    this.app.post('/api/diagnose', async (req, res) => {
      try {
        const result = await this.diagnoseSystem({});
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    this.app.get('/api/system-info', async (req, res) => {
      try {
        const result = await this.systemInfo({});
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    this.app.post('/api/run-command', async (req, res) => {
      try {
        const { command } = req.body;
        const result = await this.runCommand({ command });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ===== NOUVEAUX ENDPOINTS REST POUR OPEN WEBUI =====

    // Liste des outils disponibles
    this.app.get('/api/tools', async (req, res) => {
      try {
        const tools = await this.handleListTools({ id: 1, method: 'tools/list' });
        res.json({ success: true, tools: tools.result.tools });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Exécuteur générique d'outils
    this.app.post('/api/tools/execute', async (req, res) => {
      try {
        const { tool, arguments: args } = req.body;
        const result = await this.handleCallTool({
          id: 1,
          method: 'tools/call',
          params: { name: tool, arguments: args || {} }
        });
        res.json({ success: true, result: result.result });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Fichiers: Lecture
    this.app.post('/api/files/read', async (req, res) => {
      try {
        const { path } = req.body;
        const result = await this.readFile({ path });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Fichiers: Écriture
    this.app.post('/api/files/write', async (req, res) => {
      try {
        const { path, content } = req.body;
        const result = await this.writeFile({ path, content });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Logs: Analyse
    this.app.post('/api/logs/analyze', async (req, res) => {
      try {
        const { logPath, pattern } = req.body;
        const result = await this.analyzeLogs({ logPath, pattern });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Docker: Liste des conteneurs
    this.app.get('/api/docker/containers', async (req, res) => {
      try {
        const all = req.query.all === 'true';
        const result = await this.checkDockerContainers({ all });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Système: Diagnostic
    this.app.post('/api/system/diagnose', async (req, res) => {
      try {
        const result = await this.diagnoseSystem({});
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Système: Info
    this.app.get('/api/system/info', async (req, res) => {
      try {
        const result = await this.systemInfo({});
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Système: Ressources
    this.app.get('/api/system/resources', async (req, res) => {
      try {
        const result = await this.monitorResources({});
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // Commande: Exécution
    this.app.post('/api/command/execute', async (req, res) => {
      try {
        const { command } = req.body;
        const result = await this.runCommand({ command });
        res.json({ success: true, data: result.content[0].text });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ===== ROUTES DYNAMIQUES POUR TOUS LES OUTILS (Open WebUI) =====
    // Chaque outil a son propre endpoint /api/tool/{nom}
    this.app.post('/api/tool/:toolName', async (req, res) => {
      try {
        const toolName = req.params.toolName;
        const args = req.body || {};
        
        const result = await this.handleCallTool({
          id: 1,
          method: 'tools/call',
          params: { name: toolName, arguments: args }
        });
        
        res.json({ success: true, result: result.result });
      } catch (error: any) {
        res.status(500).json({ success: false, error: error.message });
      }
    });
  }

  private async handleInitialize(request: any) {
    return {
      jsonrpc: "2.0",
      id: request.id,
      result: {
        protocolVersion: "2024-11-05",
        capabilities: {
          tools: {}
        },
        serverInfo: {
          name: "server-admin-mcp",
          version: "1.0.0"
        }
      }
    };
  }

  private async handleListTools(request: any) {
    return {
      jsonrpc: "2.0",
      id: request.id,
      result: {
        tools: [
          {
            name: "run_command",
            description: "Exécuter une commande système Linux et retourner le résultat",
            inputSchema: {
              type: "object",
              properties: {
                command: {
                  type: "string",
                  description: "La commande à exécuter"
                },
                timeout: {
                  type: "number",
                  description: "Timeout en millisecondes (défaut: 30000)",
                  default: 30000
                }
              },
              required: ["command"]
            }
          },
          {
            name: "check_service_status",
            description: "Vérifier le statut d'un service systemd",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service systemd"
                }
              },
              required: ["service"]
            }
          },
          {
            name: "restart_service",
            description: "Redémarrer un service systemd",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service systemd"
                }
              },
              required: ["service"]
            }
          },
          {
            name: "check_disk_usage",
            description: "Vérifier l'utilisation du disque",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin à vérifier (défaut: /)",
                  default: "/"
                }
              }
            }
          },
          {
            name: "check_memory_usage",
            description: "Vérifier l'utilisation de la mémoire",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "check_network_connections",
            description: "Vérifier les connexions réseau actives",
            inputSchema: {
              type: "object",
              properties: {
                port: {
                  type: "number",
                  description: "Filtrer par port spécifique"
                }
              }
            }
          },
          {
            name: "check_docker_containers",
            description: "Lister et vérifier le statut des conteneurs Docker",
            inputSchema: {
              type: "object",
              properties: {
                all: {
                  type: "boolean",
                  description: "Inclure les conteneurs arrêtés",
                  default: false
                }
              }
            }
          },
          {
            name: "diagnose_system",
            description: "Diagnostiquer l'état général du système",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "read_file",
            description: "Lire le contenu d'un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier à lire"
                },
                encoding: {
                  type: "string",
                  description: "Encodage du fichier (utf8, ascii, etc.)",
                  default: "utf8"
                }
              },
              required: ["path"]
            }
          },
          {
            name: "write_file",
            description: "Écrire du contenu dans un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier à écrire"
                },
                content: {
                  type: "string",
                  description: "Contenu à écrire dans le fichier"
                },
                encoding: {
                  type: "string",
                  description: "Encodage du fichier",
                  default: "utf8"
                }
              },
              required: ["path", "content"]
            }
          },
          {
            name: "list_directory",
            description: "Lister le contenu d'un répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du répertoire à lister",
                  default: "."
                },
                recursive: {
                  type: "boolean",
                  description: "Lister récursivement les sous-répertoires",
                  default: false
                }
              }
            }
          },
          {
            name: "create_directory",
            description: "Créer un nouveau répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du répertoire à créer"
                },
                recursive: {
                  type: "boolean",
                  description: "Créer les répertoires parents si nécessaire",
                  default: true
                }
              },
              required: ["path"]
            }
          },
          {
            name: "delete_file",
            description: "Supprimer un fichier ou répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier/répertoire à supprimer"
                },
                recursive: {
                  type: "boolean",
                  description: "Supprimer récursivement (pour les répertoires)",
                  default: false
                }
              },
              required: ["path"]
            }
          },
          {
            name: "search_files",
            description: "Rechercher des fichiers par nom ou contenu",
            inputSchema: {
              type: "object",
              properties: {
                pattern: {
                  type: "string",
                  description: "Motif de recherche (nom de fichier ou contenu)"
                },
                path: {
                  type: "string",
                  description: "Répertoire de départ pour la recherche",
                  default: "."
                },
                type: {
                  type: "string",
                  description: "Type de recherche: 'name' ou 'content'",
                  enum: ["name", "content"],
                  default: "name"
                }
              },
              required: ["pattern"]
            }
          },
          {
            name: "analyze_logs",
            description: "Analyser les logs système pour détecter des erreurs",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service dont analyser les logs (optionnel)"
                },
                lines: {
                  type: "number",
                  description: "Nombre de lignes à analyser",
                  default: 100
                }
              }
            }
          },
          {
            name: "smart_diagnose",
            description: "Diagnostic intelligent avec suggestions de correction",
            inputSchema: {
              type: "object",
              properties: {
                component: {
                  type: "string",
                  description: "Composant à diagnostiquer (docker, network, disk, memory, services)"
                }
              }
            }
          },
          {
            name: "auto_fix",
            description: "Correction automatique des problèmes détectés",
            inputSchema: {
              type: "object",
              properties: {
                problem_type: {
                  type: "string",
                  description: "Type de problème à corriger"
                },
                confirm: {
                  type: "boolean",
                  description: "Confirmer l'application des corrections",
                  default: false
                }
              },
              required: ["problem_type"]
            }
          },
          {
            name: "monitor_resources",
            description: "Surveillance en temps réel des ressources système",
            inputSchema: {
              type: "object",
              properties: {
                duration: {
                  type: "number",
                  description: "Durée de surveillance en secondes",
                  default: 30
                },
                interval: {
                  type: "number",
                  description: "Intervalle entre les mesures en secondes",
                  default: 5
                }
              }
            }
          },
          {
            name: "backup_file",
            description: "Créer une sauvegarde d'un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin du fichier à sauvegarder"
                },
                backup_dir: {
                  type: "string",
                  description: "Répertoire de sauvegarde",
                  default: "./backups"
                }
              },
              required: ["path"]
            }
          },
          {
            name: "system_info",
            description: "Informations complètes sur le système",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "remember",
            description: "Mémoriser une information importante",
            inputSchema: {
              type: "object",
              properties: {
                key: {
                  type: "string",
                  description: "Clé de la mémoire"
                },
                value: {
                  type: "string",
                  description: "Valeur à mémoriser"
                },
                context: {
                  type: "string",
                  description: "Contexte additionnel"
                }
              },
              required: ["key", "value"]
            }
          },
          {
            name: "recall",
            description: "Rappeler une information mémorisée",
            inputSchema: {
              type: "object",
              properties: {
                query: {
                  type: "string",
                  description: "Ce que vous cherchez"
                }
              },
              required: ["query"]
            }
          },
          {
            name: "create_web_service",
            description: "Créer un service web (site, API, application)",
            inputSchema: {
              type: "object",
              properties: {
                name: {
                  type: "string",
                  description: "Nom du service"
                },
                type: {
                  type: "string",
                  enum: ["static", "api", "fullstack", "proxy"],
                  description: "Type de service web"
                },
                port: {
                  type: "number",
                  description: "Port d'écoute"
                },
                domain: {
                  type: "string",
                  description: "Nom de domaine (optionnel)"
                }
              },
              required: ["name", "type", "port"]
            }
          },
          {
            name: "generate_code",
            description: "Générer du code à partir d'une description",
            inputSchema: {
              type: "object",
              properties: {
                description: {
                  type: "string",
                  description: "Description de ce que doit faire le code"
                },
                language: {
                  type: "string",
                  enum: ["typescript", "javascript", "python", "bash", "html", "css"],
                  description: "Langage de programmation"
                },
                type: {
                  type: "string",
                  enum: ["function", "class", "script", "component", "config"],
                  description: "Type de code à générer"
                },
                save: {
                  type: "boolean",
                  description: "Sauvegarder dans un fichier ?"
                },
                filename: {
                  type: "string",
                  description: "Nom du fichier (si save=true)"
                }
              },
              required: ["description", "language", "type"]
            }
          },
          {
            name: "intelligent_analysis",
            description: "Analyser un problème et proposer des solutions",
            inputSchema: {
              type: "object",
              properties: {
                problem: {
                  type: "string",
                  description: "Description du problème"
                },
                context: {
                  type: "string",
                  description: "Contexte additionnel"
                }
              },
              required: ["problem"]
            }
          }
        ]
      }
    };
  }

  private async handleCallTool(request: any) {
    const { name, arguments: args } = request.params;

    try {
      let result: any;

      switch (name) {
        case "run_command":
          result = await this.runCommand(args);
          break;
        case "check_service_status":
          result = await this.checkServiceStatus(args);
          break;
        case "restart_service":
          result = await this.restartService(args);
          break;
        case "check_disk_usage":
          result = await this.checkDiskUsage(args);
          break;
        case "check_memory_usage":
          result = await this.checkMemoryUsage(args);
          break;
        case "check_network_connections":
          result = await this.checkNetworkConnections(args);
          break;
        case "check_docker_containers":
          result = await this.checkDockerContainers(args);
          break;
        case "diagnose_system":
          result = await this.diagnoseSystem(args);
          break;
        case "read_file":
          result = await this.readFile(args);
          break;
        case "write_file":
          result = await this.writeFile(args);
          break;
        case "list_directory":
          result = await this.listDirectory(args);
          break;
        case "create_directory":
          result = await this.createDirectory(args);
          break;
        case "delete_file":
          result = await this.deleteFile(args);
          break;
        case "search_files":
          result = await this.searchFiles(args);
          break;
        case "analyze_logs":
          result = await this.analyzeLogs(args);
          break;
        case "smart_diagnose":
          result = await this.smartDiagnose(args);
          break;
        case "auto_fix":
          result = await this.autoFix(args);
          break;
        case "monitor_resources":
          result = await this.monitorResources(args);
          break;
        case "backup_file":
          result = await this.backupFile(args);
          break;
        case "system_info":
          result = await this.systemInfo(args);
          break;
        case "remember":
          result = await this.rememberInfo(args);
          break;
        case "recall":
          result = await this.recallInfo(args);
          break;
        case "create_web_service":
          result = await this.createWebService(args);
          break;
        case "generate_code":
          result = await this.generateCode(args);
          break;
        case "intelligent_analysis":
          result = await this.intelligentAnalysis(args);
          break;
        default:
          throw new McpError(
            ErrorCode.MethodNotFound,
            `Outil inconnu: ${name}`
          );
      }

      return {
        jsonrpc: "2.0",
        id: request.id,
        result: result
      };
    } catch (error) {
      throw new McpError(
        ErrorCode.InternalError,
        `Erreur lors de l'exécution de ${name}: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }

  private setupToolHandlers() {
    // Tool: run_command - Exécuter une commande système
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: "run_command",
            description: "Exécuter une commande système Linux et retourner le résultat",
            inputSchema: {
              type: "object",
              properties: {
                command: {
                  type: "string",
                  description: "La commande à exécuter"
                },
                timeout: {
                  type: "number",
                  description: "Timeout en millisecondes (défaut: 30000)",
                  default: 30000
                }
              },
              required: ["command"]
            }
          },
          {
            name: "check_service_status",
            description: "Vérifier le statut d'un service systemd",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service systemd"
                }
              },
              required: ["service"]
            }
          },
          {
            name: "restart_service",
            description: "Redémarrer un service systemd",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service systemd"
                }
              },
              required: ["service"]
            }
          },
          {
            name: "check_disk_usage",
            description: "Vérifier l'utilisation du disque",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin à vérifier (défaut: /)",
                  default: "/"
                }
              }
            }
          },
          {
            name: "check_memory_usage",
            description: "Vérifier l'utilisation de la mémoire",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "check_network_connections",
            description: "Vérifier les connexions réseau actives",
            inputSchema: {
              type: "object",
              properties: {
                port: {
                  type: "number",
                  description: "Filtrer par port spécifique"
                }
              }
            }
          },
          {
            name: "check_docker_containers",
            description: "Lister et vérifier le statut des conteneurs Docker",
            inputSchema: {
              type: "object",
              properties: {
                all: {
                  type: "boolean",
                  description: "Inclure les conteneurs arrêtés",
                  default: false
                }
              }
            }
          },
          {
            name: "diagnose_system",
            description: "Diagnostiquer l'état général du système",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "read_file",
            description: "Lire le contenu d'un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier à lire"
                },
                encoding: {
                  type: "string",
                  description: "Encodage du fichier (utf8, ascii, etc.)",
                  default: "utf8"
                }
              },
              required: ["path"]
            }
          },
          {
            name: "write_file",
            description: "Écrire du contenu dans un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier à écrire"
                },
                content: {
                  type: "string",
                  description: "Contenu à écrire dans le fichier"
                },
                encoding: {
                  type: "string",
                  description: "Encodage du fichier",
                  default: "utf8"
                }
              },
              required: ["path", "content"]
            }
          },
          {
            name: "list_directory",
            description: "Lister le contenu d'un répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du répertoire à lister",
                  default: "."
                },
                recursive: {
                  type: "boolean",
                  description: "Lister récursivement les sous-répertoires",
                  default: false
                }
              }
            }
          },
          {
            name: "create_directory",
            description: "Créer un nouveau répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du répertoire à créer"
                },
                recursive: {
                  type: "boolean",
                  description: "Créer les répertoires parents si nécessaire",
                  default: true
                }
              },
              required: ["path"]
            }
          },
          {
            name: "delete_file",
            description: "Supprimer un fichier ou répertoire",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin absolu du fichier/répertoire à supprimer"
                },
                recursive: {
                  type: "boolean",
                  description: "Supprimer récursivement (pour les répertoires)",
                  default: false
                }
              },
              required: ["path"]
            }
          },
          {
            name: "search_files",
            description: "Rechercher des fichiers par nom ou contenu",
            inputSchema: {
              type: "object",
              properties: {
                pattern: {
                  type: "string",
                  description: "Motif de recherche (nom de fichier ou contenu)"
                },
                path: {
                  type: "string",
                  description: "Répertoire de départ pour la recherche",
                  default: "."
                },
                type: {
                  type: "string",
                  description: "Type de recherche: 'name' ou 'content'",
                  enum: ["name", "content"],
                  default: "name"
                }
              },
              required: ["pattern"]
            }
          },
          {
            name: "analyze_logs",
            description: "Analyser les logs système pour détecter des erreurs",
            inputSchema: {
              type: "object",
              properties: {
                service: {
                  type: "string",
                  description: "Nom du service dont analyser les logs (optionnel)"
                },
                lines: {
                  type: "number",
                  description: "Nombre de lignes à analyser",
                  default: 100
                }
              }
            }
          },
          {
            name: "smart_diagnose",
            description: "Diagnostic intelligent avec suggestions de correction",
            inputSchema: {
              type: "object",
              properties: {
                component: {
                  type: "string",
                  description: "Composant à diagnostiquer (docker, network, disk, memory, services)"
                }
              }
            }
          },
          {
            name: "auto_fix",
            description: "Correction automatique des problèmes détectés",
            inputSchema: {
              type: "object",
              properties: {
                problem_type: {
                  type: "string",
                  description: "Type de problème à corriger"
                },
                confirm: {
                  type: "boolean",
                  description: "Confirmer l'application des corrections",
                  default: false
                }
              },
              required: ["problem_type"]
            }
          },
          {
            name: "monitor_resources",
            description: "Surveillance en temps réel des ressources système",
            inputSchema: {
              type: "object",
              properties: {
                duration: {
                  type: "number",
                  description: "Durée de surveillance en secondes",
                  default: 30
                },
                interval: {
                  type: "number",
                  description: "Intervalle entre les mesures en secondes",
                  default: 5
                }
              }
            }
          },
          {
            name: "backup_file",
            description: "Créer une sauvegarde d'un fichier",
            inputSchema: {
              type: "object",
              properties: {
                path: {
                  type: "string",
                  description: "Chemin du fichier à sauvegarder"
                },
                backup_dir: {
                  type: "string",
                  description: "Répertoire de sauvegarde",
                  default: "./backups"
                }
              },
              required: ["path"]
            }
          },
          {
            name: "system_info",
            description: "Informations complètes sur le système",
            inputSchema: {
              type: "object",
              properties: {}
            }
          }
        ]
      };
    });

    // Handler pour l'exécution des outils
    this.server.setRequestHandler(CallToolRequestSchema, async (request: any) => {
      const { name, arguments: args } = request.params;

      try {
        switch (name) {
          case "run_command":
            return await this.runCommand(args);
          case "check_service_status":
            return await this.checkServiceStatus(args);
          case "restart_service":
            return await this.restartService(args);
          case "check_disk_usage":
            return await this.checkDiskUsage(args);
          case "check_memory_usage":
            return await this.checkMemoryUsage(args);
          case "check_network_connections":
            return await this.checkNetworkConnections(args);
          case "check_docker_containers":
            return await this.checkDockerContainers(args);
          case "diagnose_system":
            return await this.diagnoseSystem(args);
          case "read_file":
            return await this.readFile(args);
          case "write_file":
            return await this.writeFile(args);
          case "list_directory":
            return await this.listDirectory(args);
          case "create_directory":
            return await this.createDirectory(args);
          case "delete_file":
            return await this.deleteFile(args);
          case "search_files":
            return await this.searchFiles(args);
          case "analyze_logs":
            return await this.analyzeLogs(args);
          case "smart_diagnose":
            return await this.smartDiagnose(args);
          case "auto_fix":
            return await this.autoFix(args);
          case "monitor_resources":
            return await this.monitorResources(args);
          case "backup_file":
            return await this.backupFile(args);
          case "system_info":
            return await this.systemInfo(args);
          default:
            throw new McpError(
              ErrorCode.MethodNotFound,
              `Outil inconnu: ${name}`
            );
        }
      } catch (error) {
        throw new McpError(
          ErrorCode.InternalError,
          `Erreur lors de l'exécution de ${name}: ${error instanceof Error ? error.message : String(error)}`
        );
      }
    });
  }

  private setupRequestHandlers() {
    // Gestionnaire pour les requêtes d'initialisation
    this.server.setRequestHandler(InitializeRequestSchema, async (request: any) => {
      return {
        protocolVersion: "2024-11-05",
        capabilities: {
          tools: {}
        },
        serverInfo: {
          name: "server-admin-mcp",
          version: "1.0.0"
        }
      };
    });
  }

  private async runCommand(args: any) {
    const { command, timeout = 30000 } = args;

    try {
      const { stdout, stderr } = await execAsync(command, {
        timeout,
        maxBuffer: 1024 * 1024 * 10 // 10MB buffer
      });

      return {
        content: [
          {
            type: "text",
            text: `Commande exécutée: ${command}\n\nSortie standard:\n${stdout}\n\nErreurs:\n${stderr}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de l'exécution de: ${command}\n\nCode: ${error.code}\nMessage: ${error.message}\n\nSortie: ${error.stdout || ''}\nErreurs: ${error.stderr || ''}`
          }
        ]
      };
    }
  }

  private async checkServiceStatus(args: any) {
    const { service } = args;
    const command = `systemctl status ${service} --no-pager -l`;

    try {
      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: "text",
            text: `Statut du service ${service}:\n\n${stdout}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la vérification du service ${service}:\n${error.message}`
          }
        ]
      };
    }
  }

  private async restartService(args: any) {
    const { service } = args;

    try {
      // Vérifier si le service existe
      await execAsync(`systemctl status ${service} --no-pager`);

      // Redémarrer le service
      const { stdout: restartOutput } = await execAsync(`sudo systemctl restart ${service}`);

      // Vérifier le nouveau statut
      const { stdout: statusOutput } = await execAsync(`systemctl status ${service} --no-pager -l`);

      return {
        content: [
          {
            type: "text",
            text: `Service ${service} redémarré avec succès!\n\nNouveau statut:\n${statusOutput}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors du redémarrage du service ${service}:\n${error.message}`
          }
        ]
      };
    }
  }

  private async checkDiskUsage(args: any) {
    const { path = "/" } = args;
    const command = `df -h ${path}`;

    try {
      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: "text",
            text: `Utilisation du disque pour ${path}:\n\n${stdout}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la vérification du disque: ${error.message}`
          }
        ]
      };
    }
  }

  private async checkMemoryUsage(args: any) {
    const command = "free -h && echo && vmstat 1 5";

    try {
      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: "text",
            text: `Utilisation de la mémoire:\n\n${stdout}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la vérification de la mémoire: ${error.message}`
          }
        ]
      };
    }
  }

  private async checkNetworkConnections(args: any) {
    const { port } = args;
    const command = port
      ? `netstat -tlnp | grep :${port} || ss -tlnp | grep :${port}`
      : "netstat -tlnp || ss -tlnp";

    try {
      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: "text",
            text: `Connexions réseau ${port ? `sur le port ${port}` : 'actives'}:\n\n${stdout}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la vérification réseau: ${error.message}`
          }
        ]
      };
    }
  }

  private async checkDockerContainers(args: any) {
    const { all = false } = args;
    const command = `docker ps ${all ? '-a' : ''} --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"`;

    try {
      const { stdout } = await execAsync(command);
      return {
        content: [
          {
            type: "text",
            text: `Conteneurs Docker ${all ? '(tous)' : '(actifs seulement)'}:\n\n${stdout}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la vérification Docker: ${error.message}`
          }
        ]
      };
    }
  }

  private async diagnoseSystem(args: any) {
    const diagnostics = [];

    try {
      // Vérifier la charge système
      const { stdout: loadAvg } = await execAsync("uptime");
      diagnostics.push(`Charge système: ${loadAvg.trim()}`);

      // Vérifier l'utilisation du disque
      const { stdout: diskUsage } = await execAsync("df -h / | tail -1");
      diagnostics.push(`Utilisation disque: ${diskUsage.trim()}`);

      // Vérifier la mémoire
      const { stdout: memory } = await execAsync("free -h | grep Mem");
      diagnostics.push(`Mémoire: ${memory.trim()}`);

      // Vérifier les services critiques
      const criticalServices = ['docker', 'ollama', 'traefik'];
      for (const service of criticalServices) {
        try {
          const { stdout: status } = await execAsync(`systemctl is-active ${service}`);
          diagnostics.push(`Service ${service}: ${status.trim()}`);
        } catch {
          diagnostics.push(`Service ${service}: non trouvé ou inactif`);
        }
      }

      // Vérifier les conteneurs Docker
      try {
        const { stdout: containers } = await execAsync("docker ps -q | wc -l");
        diagnostics.push(`Conteneurs Docker actifs: ${containers.trim()}`);
      } catch {
        diagnostics.push("Docker: non disponible");
      }

    } catch (error: any) {
      diagnostics.push(`Erreur de diagnostic: ${error.message}`);
    }

    return {
      content: [
        {
          type: "text",
          text: `Diagnostique système:\n\n${diagnostics.join('\n')}`
        }
      ]
    };
  }

  private async fixCommonIssues(args: any) {
    const { issues = [] } = args;
    const fixes = [];

    for (const issue of issues) {
      try {
        switch (issue) {
          case "docker_containers_down":
            const { stdout: restarted } = await execAsync("docker restart $(docker ps -aq)");
            fixes.push(`Conteneurs Docker redémarrés: ${restarted}`);
            break;

          case "low_disk_space":
            fixes.push("Nettoyage du cache apt...");
            await execAsync("sudo apt autoremove -y && sudo apt autoclean");
            fixes.push("Cache apt nettoyé");
            break;

          case "high_memory_usage":
            fixes.push("Redémarrage des services gourmands en mémoire...");
            // Logique pour identifier et redémarrer les services problématiques
            break;

          default:
            fixes.push(`Problème "${issue}" non reconnu`);
        }
      } catch (error: any) {
        fixes.push(`Erreur lors de la correction de "${issue}": ${error.message}`);
      }
    }

    return {
      content: [
        {
          type: "text",
          text: `Corrections appliquées:\n\n${fixes.join('\n')}`
        }
      ]
    };
  }

  // === OUTILS SYSTÈME DE FICHIERS ===

  private async readFile(args: any) {
    const { path, encoding = "utf8" } = args;

    try {
      const content = await fs.readFile(path, encoding);
      return {
        content: [
          {
            type: "text",
            text: `Contenu du fichier ${path}:\n\n${content}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la lecture du fichier ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async writeFile(args: any) {
    const { path, content, encoding = "utf8" } = args;

    try {
      await fs.writeFile(path, content, encoding);
      return {
        content: [
          {
            type: "text",
            text: `Fichier ${path} écrit avec succès (${content.length} caractères)`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de l'écriture du fichier ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async listDirectory(args: any) {
    const { path = ".", recursive = false } = args;

    try {
      const items = recursive
        ? await this.listDirectoryRecursive(path)
        : await fs.readdir(path, { withFileTypes: true });

      const formatted = items.map((item: any) => {
        if (recursive) {
          return item;
        }
        const type = item.isDirectory() ? "[DIR]" : "[FILE]";
        return `${type} ${item.name}`;
      });

      return {
        content: [
          {
            type: "text",
            text: `Contenu du répertoire ${path}:\n\n${formatted.join('\n')}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la lecture du répertoire ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async listDirectoryRecursive(dirPath: string): Promise<string[]> {
    const results: string[] = [];

    async function traverse(currentPath: string, prefix = "") {
      const items = await fs.readdir(currentPath, { withFileTypes: true });

      for (const item of items) {
        const fullPath = `${currentPath}/${item.name}`;
        const displayPath = `${prefix}${item.name}`;

        if (item.isDirectory()) {
          results.push(`[DIR]  ${displayPath}/`);
          await traverse(fullPath, `${prefix}${item.name}/`);
        } else {
          results.push(`[FILE] ${displayPath}`);
        }
      }
    }

    await traverse(dirPath);
    return results;
  }

  private async createDirectory(args: any) {
    const { path, recursive = true } = args;

    try {
      await fs.mkdir(path, { recursive });
      return {
        content: [
          {
            type: "text",
            text: `Répertoire ${path} créé avec succès`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la création du répertoire ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async deleteFile(args: any) {
    const { path, recursive = false } = args;

    try {
      const stats = await fs.stat(path);

      if (stats.isDirectory() && !recursive) {
        return {
          content: [
            {
              type: "text",
              text: `Erreur: ${path} est un répertoire. Utilisez recursive=true pour le supprimer.`
            }
          ]
        };
      }

      if (stats.isDirectory()) {
        await fs.rmdir(path, { recursive: true });
      } else {
        await fs.unlink(path);
      }

      return {
        content: [
          {
            type: "text",
            text: `${stats.isDirectory() ? 'Répertoire' : 'Fichier'} ${path} supprimé avec succès`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la suppression de ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async searchFiles(args: any) {
    const { pattern, path = ".", type = "name" } = args;

    try {
      if (type === "content") {
        return await this.searchInFiles(pattern, path);
      } else {
        return await this.searchByName(pattern, path);
      }
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de la recherche: ${error.message}`
          }
        ]
      };
    }
  }

  private async searchByName(pattern: string, startPath: string) {
    const results: string[] = [];

    async function search(currentPath: string) {
      try {
        const items = await fs.readdir(currentPath, { withFileTypes: true });

        for (const item of items) {
          const fullPath = `${currentPath}/${item.name}`;

          if (item.name.includes(pattern)) {
            results.push(`${item.isDirectory() ? '[DIR]' : '[FILE]'} ${fullPath}`);
          }

          if (item.isDirectory() && !item.name.startsWith('.')) {
            await search(fullPath);
          }
        }
      } catch (error) {
        // Ignorer les erreurs d'accès
      }
    }

    await search(startPath);

    return {
      content: [
        {
          type: "text",
          text: `Résultats de recherche pour "${pattern}" dans ${startPath}:\n\n${results.length > 0 ? results.join('\n') : 'Aucun résultat trouvé'}`
        }
      ]
    };
  }

  private async searchInFiles(pattern: string, startPath: string) {
    const results: string[] = [];

    async function search(currentPath: string) {
      try {
        const items = await fs.readdir(currentPath, { withFileTypes: true });

        for (const item of items) {
          const fullPath = `${currentPath}/${item.name}`;

          if (item.isFile()) {
            try {
              const content = await fs.readFile(fullPath, 'utf8');
              if (content.includes(pattern)) {
                const lines = content.split('\n');
                const matchingLines = lines
                  .map((line, index) => ({ line, index: index + 1 }))
                  .filter(({ line }) => line.includes(pattern))
                  .slice(0, 5); // Limiter à 5 résultats par fichier

                results.push(`📄 ${fullPath}:`);
                matchingLines.forEach(({ line, index }) => {
                  results.push(`  Ligne ${index}: ${line.trim()}`);
                });
                results.push('');
              }
            } catch (error) {
              // Ignorer les fichiers non lisibles
            }
          } else if (item.isDirectory() && !item.name.startsWith('.')) {
            await search(fullPath);
          }
        }
      } catch (error) {
        // Ignorer les erreurs d'accès
      }
    }

    await search(startPath);

    return {
      content: [
        {
          type: "text",
          text: `Résultats de recherche du contenu "${pattern}" dans ${startPath}:\n\n${results.length > 0 ? results.join('\n') : 'Aucun résultat trouvé'}`
        }
      ]
    };
  }

  // === OUTILS D'ANALYSE ET DIAGNOSTIC INTELLIGENT ===

  private async analyzeLogs(args: any) {
    const { service, lines = 100 } = args;

    try {
      let logContent: string;

      // Carte des services vers leurs fichiers de logs
      const logFiles: { [key: string]: string } = {
        'fail2ban': '/host/var/log/fail2ban.log',
        'nginx': '/host/var/log/nginx/error.log',
        'apache': '/host/var/log/apache2/error.log',
        'syslog': '/host/var/log/syslog',
        'auth': '/host/var/log/auth.log',
        'docker': '/host/var/log/docker.log'
      };

      if (service && logFiles[service]) {
        // Lire le fichier de log spécifique avec tail pour éviter les gros fichiers
        const logPath = logFiles[service];
        try {
          const { stdout } = await execAsync(`tail -n ${lines} ${logPath}`);
          logContent = stdout;
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `Erreur: impossible de lire le fichier de log ${logPath}: ${error.message}`
              }
            ]
          };
        }
      } else if (service) {
        // Service non reconnu, essayer journalctl si disponible (sinon erreur explicite)
        try {
          const { stdout } = await execAsync(`journalctl -u ${service} --no-pager -n ${lines}`);
          logContent = stdout;
        } catch {
          return {
            content: [
              {
                type: "text",
                text: `Service '${service}' non reconnu. Services disponibles: ${Object.keys(logFiles).join(', ')}\n\nUtilisez l'outil 'read_file' pour lire directement un fichier de log avec son chemin complet.`
              }
            ]
          };
        }
      } else {
        // Logs système généraux - lire syslog avec tail
        try {
          const { stdout } = await execAsync(`tail -n ${lines} /host/var/log/syslog`);
          logContent = stdout;
        } catch (error: any) {
          return {
            content: [
              {
                type: "text",
                text: `Erreur: impossible de lire /host/var/log/syslog: ${error.message}`
              }
            ]
          };
        }
      }

      // Analyse intelligente des logs
      const analysis = this.analyzeLogContent(logContent);

      return {
        content: [
          {
            type: "text",
            text: `Analyse des logs ${service ? `du service ${service}` : 'système'}:\n\n${analysis}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors de l'analyse des logs: ${error.message}`
          }
        ]
      };
    }
  }

  private analyzeLogContent(logs: string): string {
    const lines = logs.split('\n').filter(line => line.trim());
    const errors: string[] = [];
    const warnings: string[] = [];
    const issues: { [key: string]: number } = {};

    for (const line of lines) {
      const lowerLine = line.toLowerCase();

      if (lowerLine.includes('error') || lowerLine.includes('failed') || lowerLine.includes('exception')) {
        errors.push(line);
      } else if (lowerLine.includes('warning') || lowerLine.includes('warn')) {
        warnings.push(line);
      }

      // Détection de patterns courants
      if (lowerLine.includes('connection refused')) {
        issues['connection_refused'] = (issues['connection_refused'] || 0) + 1;
      }
      if (lowerLine.includes('permission denied')) {
        issues['permission_denied'] = (issues['permission_denied'] || 0) + 1;
      }
      if (lowerLine.includes('out of memory')) {
        issues['out_of_memory'] = (issues['out_of_memory'] || 0) + 1;
      }
      if (lowerLine.includes('disk space')) {
        issues['disk_space'] = (issues['disk_space'] || 0) + 1;
      }
    }

    let analysis = `📊 Analyse des ${lines.length} lignes de logs:\n\n`;

    if (errors.length > 0) {
      analysis += `🚨 ${errors.length} erreurs détectées:\n`;
      errors.slice(0, 5).forEach(error => {
        analysis += `  • ${error}\n`;
      });
      analysis += '\n';
    }

    if (warnings.length > 0) {
      analysis += `⚠️  ${warnings.length} avertissements:\n`;
      warnings.slice(0, 3).forEach(warning => {
        analysis += `  • ${warning}\n`;
      });
      analysis += '\n';
    }

    if (Object.keys(issues).length > 0) {
      analysis += `🔍 Problèmes identifiés:\n`;
      for (const [issue, count] of Object.entries(issues)) {
        analysis += `  • ${issue.replace('_', ' ')}: ${count} occurrence(s)\n`;
      }
      analysis += '\n';
    }

    if (errors.length === 0 && warnings.length === 0) {
      analysis += `✅ Aucun problème critique détecté dans les logs analysés.\n`;
    }

    return analysis;
  }

  private async smartDiagnose(args: any) {
    const { component } = args;
    const diagnosis: string[] = [];
    const recommendations: string[] = [];

    try {
      switch (component) {
        case 'docker':
          await this.diagnoseDocker(diagnosis, recommendations);
          break;
        case 'network':
          await this.diagnoseNetwork(diagnosis, recommendations);
          break;
        case 'disk':
          await this.diagnoseDisk(diagnosis, recommendations);
          break;
        case 'memory':
          await this.diagnoseMemory(diagnosis, recommendations);
          break;
        case 'services':
          await this.diagnoseServices(diagnosis, recommendations);
          break;
        default:
          diagnosis.push("Composant non reconnu. Utilisez: docker, network, disk, memory, ou services");
      }

      return {
        content: [
          {
            type: "text",
            text: `🔍 Diagnostic intelligent - ${component}:\n\n📋 État:\n${diagnosis.join('\n')}\n\n💡 Recommandations:\n${recommendations.join('\n')}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `Erreur lors du diagnostic de ${component}: ${error.message}`
          }
        ]
      };
    }
  }

  private async diagnoseDocker(diagnosis: string[], recommendations: string[]) {
    try {
      // Vérifier si Docker fonctionne
      const { stdout: dockerVersion } = await execAsync("docker --version");
      diagnosis.push(`✅ Docker installé: ${dockerVersion.trim()}`);

      // Vérifier les conteneurs
      const { stdout: containers } = await execAsync("docker ps -a --format 'table {{.Names}}\t{{.Status}}'");
      const lines = containers.split('\n').slice(1); // Skip header
      const running = lines.filter(line => line.includes('Up')).length;
      const total = lines.length - 1; // -1 for header

      diagnosis.push(`📦 Conteneurs: ${running}/${total} actifs`);

      if (running < total) {
        diagnosis.push("⚠️ Certains conteneurs sont arrêtés");
        recommendations.push("• Redémarrer les conteneurs arrêtés: docker restart $(docker ps -aq --filter 'status=exited')");
      }

      // Vérifier l'espace disque Docker
      const { stdout: diskUsage } = await execAsync("docker system df");
      diagnosis.push(`💾 Utilisation disque Docker:\n${diskUsage}`);

    } catch (error: any) {
      diagnosis.push(`❌ Problème Docker: ${error.message}`);
      recommendations.push("• Vérifier que Docker est installé et démarré");
      recommendations.push("• sudo systemctl start docker");
    }
  }

  private async diagnoseNetwork(diagnosis: string[], recommendations: string[]) {
    try {
      // Vérifier les interfaces réseau
      const { stdout: interfaces } = await execAsync("ip addr show | grep -E '^[0-9]+:' | cut -d' ' -f2 | tr -d ':'");
      diagnosis.push(`🌐 Interfaces réseau: ${interfaces.split('\n').join(', ')}`);

      // Tester la connectivité
      const { stdout: ping } = await execAsync("ping -c 3 8.8.8.8");
      if (ping.includes("3 received")) {
        diagnosis.push("✅ Connectivité Internet: OK");
      } else {
        diagnosis.push("❌ Connectivité Internet: Problème détecté");
        recommendations.push("• Vérifier la configuration réseau");
        recommendations.push("• Redémarrer NetworkManager: sudo systemctl restart NetworkManager");
      }

      // Ports ouverts
      const { stdout: ports } = await execAsync("netstat -tlnp | grep LISTEN | wc -l");
      diagnosis.push(`🔌 Ports ouverts: ${ports.trim()}`);

    } catch (error: any) {
      diagnosis.push(`❌ Erreur réseau: ${error.message}`);
    }
  }

  private async diagnoseDisk(diagnosis: string[], recommendations: string[]) {
    try {
      const { stdout: diskUsage } = await execAsync("df -h / | tail -1");
      const parts = diskUsage.trim().split(/\s+/);
      const usedPercent = parts[4];

      diagnosis.push(`💾 Utilisation disque: ${usedPercent} utilisé`);

      const percentNum = parseInt(usedPercent);
      if (percentNum > 90) {
        diagnosis.push("🚨 Espace disque critique!");
        recommendations.push("• Nettoyer le cache: sudo apt autoremove && sudo apt autoclean");
        recommendations.push("• Supprimer les fichiers temporaires: sudo rm -rf /tmp/*");
        recommendations.push("• Vérifier les gros fichiers: du -h / | sort -hr | head -10");
      } else if (percentNum > 80) {
        diagnosis.push("⚠️ Espace disque élevé");
        recommendations.push("• Considérer un nettoyage préventif");
      }

    } catch (error: any) {
      diagnosis.push(`❌ Erreur disque: ${error.message}`);
    }
  }

  private async diagnoseMemory(diagnosis: string[], recommendations: string[]) {
    try {
      const { stdout: memory } = await execAsync("free -h | grep Mem");
      const parts = memory.trim().split(/\s+/);
      const total = parts[0];
      const used = parts[1];
      const free = parts[2];

      diagnosis.push(`🧠 Mémoire: ${used}/${total} utilisé (${free} libre)`);

      // Calculer le pourcentage
      const usedBytes = this.parseMemorySize(used);
      const totalBytes = this.parseMemorySize(total);
      const percentUsed = (usedBytes / totalBytes) * 100;

      if (percentUsed > 90) {
        diagnosis.push("🚨 Mémoire critique!");
        recommendations.push("• Identifier les processus gourmands: ps aux --sort=-%mem | head -10");
        recommendations.push("• Redémarrer des services si nécessaire");
        recommendations.push("• Considérer l'ajout de RAM");
      } else if (percentUsed > 80) {
        diagnosis.push("⚠️ Utilisation mémoire élevée");
        recommendations.push("• Monitorer les processus consommateurs");
      }

    } catch (error: any) {
      diagnosis.push(`❌ Erreur mémoire: ${error.message}`);
    }
  }

  private async diagnoseServices(diagnosis: string[], recommendations: string[]) {
    const criticalServices = ['docker', 'ollama', 'traefik', 'nginx', 'sshd'];

    for (const service of criticalServices) {
      try {
        const { stdout: status } = await execAsync(`systemctl is-active ${service}`);
        if (status.trim() === 'active') {
          diagnosis.push(`✅ ${service}: actif`);
        } else {
          diagnosis.push(`❌ ${service}: ${status.trim()}`);
          recommendations.push(`• Redémarrer ${service}: sudo systemctl restart ${service}`);
        }
      } catch {
        diagnosis.push(`⚠️ ${service}: non trouvé`);
      }
    }
  }

  private parseMemorySize(size: string): number {
    const units = { 'G': 1024 * 1024 * 1024, 'M': 1024 * 1024, 'K': 1024, 'B': 1 };
    const match = size.match(/^(\d+(?:\.\d+)?)\s*([GMKB]?)/i);
    if (!match) return 0;

    const value = parseFloat(match[1]);
    const unit = match[2].toUpperCase() || 'B';
    return value * (units[unit as keyof typeof units] || 1);
  }

  private async autoFix(args: any) {
    const { problem_type, confirm = false } = args;

    if (!confirm) {
      return {
        content: [
          {
            type: "text",
            text: `🔒 Correction automatique désactivée. Utilisez confirm=true pour appliquer les corrections.\n\nType de problème: ${problem_type}\n\nActions proposées:\n${this.getFixActions(problem_type)}`
          }
        ]
      };
    }

    const results: string[] = [];

    try {
      switch (problem_type) {
        case 'docker_containers':
          results.push("Redémarrage des conteneurs arrêtés...");
          const { stdout: restartResult } = await execAsync("docker restart $(docker ps -aq --filter 'status=exited')");
          results.push(`✅ ${restartResult}`);
          break;

        case 'disk_space':
          results.push("Nettoyage du système...");
          await execAsync("sudo apt autoremove -y && sudo apt autoclean");
          results.push("✅ Cache apt nettoyé");

          await execAsync("sudo rm -rf /tmp/*");
          results.push("✅ Fichiers temporaires supprimés");
          break;

        case 'memory':
          results.push("Redémarrage des services gourmands...");
          // Identifier et redémarrer les services problématiques
          const { stdout: topMem } = await execAsync("ps aux --sort=-%mem | head -5 | awk 'NR>1 {print $11}'");
          const services = topMem.split('\n').filter(s => s);
          for (const service of services.slice(0, 2)) { // Max 2 services
            try {
              await execAsync(`sudo systemctl restart ${service}`);
              results.push(`✅ Service ${service} redémarré`);
            } catch {
              results.push(`⚠️ Impossible de redémarrer ${service}`);
            }
          }
          break;

        case 'network':
          results.push("Redémarrage NetworkManager...");
          await execAsync("sudo systemctl restart NetworkManager");
          results.push("✅ NetworkManager redémarré");
          break;

        default:
          results.push(`❌ Type de problème non reconnu: ${problem_type}`);
      }

      return {
        content: [
          {
            type: "text",
            text: `🔧 Corrections automatiques appliquées pour: ${problem_type}\n\n${results.join('\n')}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `❌ Erreur lors de la correction automatique: ${error.message}`
          }
        ]
      };
    }
  }

  private getFixActions(problemType: string): string {
    const actions: { [key: string]: string[] } = {
      'docker_containers': [
        '• Redémarrer tous les conteneurs arrêtés',
        '• Vérifier les logs des conteneurs défaillants'
      ],
      'disk_space': [
        '• Nettoyer le cache apt',
        '• Supprimer les fichiers temporaires',
        '• Identifier les gros fichiers'
      ],
      'memory': [
        '• Redémarrer les processus les plus gourmands',
        '• Vérifier la configuration swap'
      ],
      'network': [
        '• Redémarrer NetworkManager',
        '• Vérifier la configuration DNS'
      ]
    };

    return actions[problemType]?.join('\n') || '• Aucune action automatique disponible';
  }

  private async monitorResources(args: any) {
    const { duration = 30, interval = 5 } = args;
    const measurements: any[] = [];
    const startTime = Date.now();

    for (let i = 0; i < duration / interval; i++) {
      try {
        const timestamp = new Date().toISOString();

        // CPU
        const { stdout: cpu } = await execAsync("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1}'");

        // Mémoire
        const { stdout: memory } = await execAsync("free | grep Mem | awk '{printf \"%.1f\", $3/$2 * 100.0}'");

        // Disque
        const { stdout: disk } = await execAsync("df / | tail -1 | awk '{print $5}' | sed 's/%//'");

        // Réseau (interfaces actives)
        const { stdout: network } = await execAsync("ip -s link | grep -A 1 'state UP' | grep -v 'state UP' | wc -l");

        measurements.push({
          time: timestamp,
          cpu: `${cpu.trim()}%`,
          memory: `${memory.trim()}%`,
          disk: `${disk.trim()}%`,
          network_interfaces: network.trim()
        });

        if (i < (duration / interval) - 1) {
          await new Promise(resolve => setTimeout(resolve, interval * 1000));
        }
      } catch (error) {
        measurements.push({
          time: new Date().toISOString(),
          error: `Erreur de mesure: ${error instanceof Error ? error.message : String(error)}`
        });
      }
    }

    const summary = measurements.map(m =>
      m.error ? `❌ ${m.time}: ${m.error}` :
        `📊 ${m.time}: CPU=${m.cpu}, RAM=${m.memory}, Disk=${m.disk}, Net=${m.network_interfaces} interfaces`
    ).join('\n');

    return {
      content: [
        {
          type: "text",
          text: `📈 Monitoring des ressources (${duration}s, intervalle: ${interval}s):\n\n${summary}`
        }
      ]
    };
  }

  private async backupFile(args: any) {
    const { path, backup_dir = "./backups" } = args;

    try {
      // Créer le répertoire de sauvegarde
      await fs.mkdir(backup_dir, { recursive: true });

      // Générer un nom de sauvegarde unique
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const fileName = path.split('/').pop();
      const backupPath = `${backup_dir}/${fileName}.backup.${timestamp}`;

      // Copier le fichier
      await fs.copyFile(path, backupPath);

      // Vérifier que la sauvegarde est réussie
      const stats = await fs.stat(backupPath);

      return {
        content: [
          {
            type: "text",
            text: `✅ Sauvegarde créée avec succès:\n📁 ${backupPath}\n📏 Taille: ${stats.size} bytes\n📅 ${new Date(stats.mtime).toLocaleString()}`
          }
        ]
      };
    } catch (error: any) {
      return {
        content: [
          {
            type: "text",
            text: `❌ Erreur lors de la sauvegarde de ${path}: ${error.message}`
          }
        ]
      };
    }
  }

  private async systemInfo(args: any) {
    const info: string[] = [];

    try {
      // Informations système de base du HOST
      const { stdout: hostRelease } = await execAsync("cat /host/etc/os-release | grep PRETTY_NAME | cut -d'\"' -f2");
      const { stdout: kernelVersion } = await execAsync("uname -r");
      info.push(`🖥️  Système: ${hostRelease.trim()} (Kernel ${kernelVersion.trim()})`);

      const { stdout: uptime } = await execAsync("cat /host/proc/uptime | cut -d' ' -f1");
      const uptimeSeconds = Math.floor(parseFloat(uptime));
      info.push(`⏱️  Uptime: ${Math.floor(uptimeSeconds / 3600)}h ${Math.floor((uptimeSeconds % 3600) / 60)}m`);

      // RAM du système hôte
      const { stdout: memInfo } = await execAsync("cat /host/proc/meminfo | grep -E 'MemTotal|MemAvailable'");
      const memLines = memInfo.split('\n');
      const memTotal = parseInt(memLines[0].match(/\d+/)?.[0] || '0') / 1024 / 1024;
      const memAvail = parseInt(memLines[1].match(/\d+/)?.[0] || '0') / 1024 / 1024;
      info.push(`💾 RAM: ${memTotal.toFixed(1)}GB total, ${memAvail.toFixed(1)}GB disponible`);

      // CPU du système hôte
      const { stdout: cpuModel } = await execAsync("cat /host/proc/cpuinfo | grep 'model name' | head -1 | cut -d':' -f2");
      const { stdout: cpuCores } = await execAsync("cat /host/proc/cpuinfo | grep processor | wc -l");
      info.push(`\n⚡ CPU: ${cpuModel.trim()} (${cpuCores.trim()} cores)`);

      // Carte graphique - plusieurs méthodes
      try {
        // Méthode 1: Via lspci dans le host
        const { stdout: gpu } = await execAsync("chroot /host lspci 2>/dev/null | grep -i 'vga\\|3d\\|display' || echo ''");
        if (gpu.trim()) {
          info.push(`🎮 GPU: ${gpu.trim()}`);
        } else {
          // Méthode 2: Via /sys
          try {
            const { stdout: gpuSys } = await execAsync("find /host/sys/class/drm/card*/device -name vendor -o -name device 2>/dev/null | head -4");
            if (gpuSys.trim()) {
              info.push(`🎮 GPU: Détecté (voir /sys/class/drm pour détails)`);
            } else {
              info.push(`🎮 GPU: Non détecté`);
            }
          } catch {
            info.push(`🎮 GPU: Non détecté`);
          }
        }
      } catch (err) {
        // Méthode 3: Nvidia
        try {
          const { stdout: nvidia } = await execAsync("nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null || echo ''");
          if (nvidia.trim()) {
            info.push(`🎮 GPU: ${nvidia.trim()} (NVIDIA)`);
          } else {
            info.push(`🎮 GPU: Non détecté (lspci non disponible dans le conteneur)`);
          }
        } catch {
          info.push(`🎮 GPU: Non détecté (lspci non disponible dans le conteneur)`);
        }
      }

      // Carte mère (DMI)
      try {
        const { stdout: motherboard } = await execAsync("cat /host/sys/class/dmi/id/board_name 2>/dev/null || echo 'Non disponible'");
        const { stdout: boardVendor } = await execAsync("cat /host/sys/class/dmi/id/board_vendor 2>/dev/null || echo ''");
        info.push(`🔧 Carte mère: ${boardVendor.trim()} ${motherboard.trim()}`);
      } catch {
        info.push(`🔧 Carte mère: Non disponible`);
      }

      // Disques du système hôte
      const { stdout: diskInfo } = await execAsync("df -h /host | tail -1");
      info.push(`\n💽 Disque racine: ${diskInfo.trim()}`);

      // Réseau
      const { stdout: networkInfo } = await execAsync("ip route show default 2>/dev/null || echo 'Non disponible'");
      info.push(`\n🌐 Réseau: ${networkInfo.trim()}`);

      // Docker (si disponible)
      try {
        const { stdout: dockerInfo } = await execAsync("docker ps | wc -l");
        info.push(`\n🐳 Conteneurs Docker: ${(parseInt(dockerInfo) - 1)} actifs`);
      } catch {
        info.push(`\n🐳 Docker: non disponible`);
      }

    } catch (error: any) {
      info.push(`❌ Erreur lors de la collecte d'informations: ${error.message}`);
    }

    return {
      content: [
        {
          type: "text",
          text: `📋 Informations système complètes:\n\n${info.join('\n')}`
        }
      ]
    };
  }

  // Surveillance autonome en arrière-plan
  private startBackgroundMonitoring() {
    // Auto-diagnostic toutes les 5 minutes
    setInterval(async () => {
      try {
        const diagnostic = await this.agent.runAutoDiagnostic();
        await this.memory.learn('auto-diagnostic', diagnostic);
      } catch (error) {
        console.error('Erreur auto-diagnostic:', error);
      }
    }, 5 * 60 * 1000);

    console.error('🧠 Système de surveillance autonome activé');
  }

  // Mémoriser une information
  private async rememberInfo(args: any) {
    const { key, value, context } = args;

    this.memory.remember({
      type: 'conversation',
      content: `${key}: ${value}`,
      context: context,
      timestamp: new Date()
    });

    return {
      content: [
        {
          type: "text",
          text: `✅ Information mémorisée: ${key}`
        }
      ]
    };
  }

  // Rappeler une information
  private async recallInfo(args: any) {
    const { query } = args;

    const memories = this.memory.recall(query);

    if (memories.length === 0) {
      return {
        content: [
          {
            type: "text",
            text: `❌ Aucune mémoire trouvée pour: ${query}`
          }
        ]
      };
    }

    const result = memories.map(m =>
      `📝 ${m.content}\n   ${m.context || ''}\n   (mémorisé le ${new Date(m.timestamp).toLocaleString()})`
    ).join('\n\n');

    return {
      content: [
        {
          type: "text",
          text: `🧠 Mémoires trouvées:\n\n${result}`
        }
      ]
    };
  }

  // Créer un service web
  private async createWebService(args: any) {
    const { name, type, port, domain } = args;

    const result = await this.webGen.createWebService({
      name,
      type,
      port,
      domain
    });

    // Mémoriser la création du service
    this.memory.remember({
      type: 'decision',
      content: `Service ${name} (${type}) créé sur le port ${port}`,
      context: `URL: ${result.url}`,
      timestamp: new Date()
    });

    return {
      content: [
        {
          type: "text",
          text: result.success
            ? `✅ ${result.message}\n🌐 URL: ${result.url}`
            : `❌ ${result.message}`
        }
      ]
    };
  }

  // Générer du code
  private async generateCode(args: any) {
    const { description, language, type, save, filename } = args;

    const result = await this.codeGen.generateCode({
      description,
      language,
      type
    });

    let response = `✨ Code généré:\n\n\`\`\`${language}\n${result.code}\n\`\`\`\n\n📝 ${result.explanation}`;

    // Sauvegarder si demandé
    if (save && filename) {
      const filePath = await this.codeGen.saveCode(result.code, filename);
      response += `\n\n💾 Sauvegardé dans: ${filePath}`;

      // Mémoriser
      this.memory.remember({
        type: 'decision',
        content: `Code généré: ${description}`,
        context: `Fichier: ${filePath}`,
        timestamp: new Date()
      });
    }

    return {
      content: [
        {
          type: "text",
          text: response
        }
      ]
    };
  }

  // Analyse intelligente d'un problème
  private async intelligentAnalysis(args: any) {
    const { problem, context } = args;

    const decision = await this.agent.analyzeProblem(problem);

    let response = `🔍 Analyse intelligente:\n\n`;
    response += `**Problème:** ${decision.problem}\n`;
    response += `**Analyse:** ${decision.analysis}\n`;
    response += `**Confiance:** ${(decision.confidence * 100).toFixed(0)}%\n`;
    response += `**Raisonnement:** ${decision.reasoning}\n\n`;
    response += `**Actions recommandées:**\n`;

    decision.proposedActions.forEach((action, i) => {
      response += `${i + 1}. [${action.risk}] ${action.type}: ${action.description}\n`;
      if (action.command) {
        response += `   Commande: \`${action.command}\`\n`;
      }
      response += `   Réversible: ${action.reversible ? '✓' : '✗'}\n`;
    });

    // Chercher des solutions apprises
    const solution = this.memory.findSolution(problem);
    if (solution) {
      response += `\n\n💡 Solution apprise:\n`;
      response += `${solution.solution} (confiance: ${(solution.confidence * 100).toFixed(0)}%)\n`;
    }

    // Mémoriser l'analyse
    this.memory.remember({
      type: 'decision',
      content: `Analyse: ${problem}`,
      context: context || decision.analysis,
      result: JSON.stringify(decision.proposedActions),
      timestamp: new Date()
    });

    return {
      content: [
        {
          type: "text",
          text: response
        }
      ]
    };
  }

  async run() {
    // Démarrer le serveur HTTP sur le port 3000
    const httpServer = this.app.listen(3000, '0.0.0.0', () => {
      console.error("Serveur MCP Admin HTTP démarré sur le port 3000");
    });

    // Attendre que le serveur soit prêt
    await new Promise((resolve) => {
      httpServer.on('listening', resolve);
    });

    console.error("Serveur MCP Admin prêt et opérationnel");
  }

  private generateOpenAPISpec() {
    // Liste des 25 outils MCP
    const toolsList = [
      {
        name: "run_command",
        description: "Exécuter une commande système Linux et retourner le résultat",
        inputSchema: {
          type: "object",
          properties: {
            command: { type: "string", description: "La commande à exécuter" },
            timeout: { type: "number", description: "Timeout en millisecondes (défaut: 30000)" }
          },
          required: ["command"]
        }
      },
      {
        name: "check_service_status",
        description: "Vérifier le statut d'un service systemd",
        inputSchema: {
          type: "object",
          properties: {
            service: { type: "string", description: "Nom du service systemd" }
          },
          required: ["service"]
        }
      },
      {
        name: "restart_service",
        description: "Redémarrer un service systemd",
        inputSchema: {
          type: "object",
          properties: {
            service: { type: "string", description: "Nom du service systemd" }
          },
          required: ["service"]
        }
      },
      {
        name: "check_disk_usage",
        description: "Vérifier l'utilisation du disque",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin à vérifier (défaut: /)" }
          }
        }
      },
      {
        name: "check_memory_usage",
        description: "Vérifier l'utilisation de la mémoire",
        inputSchema: { type: "object", properties: {} }
      },
      {
        name: "check_network_connections",
        description: "Vérifier les connexions réseau actives",
        inputSchema: {
          type: "object",
          properties: {
            port: { type: "number", description: "Filtrer par port spécifique" }
          }
        }
      },
      {
        name: "check_docker_containers",
        description: "Lister et vérifier le statut des conteneurs Docker",
        inputSchema: {
          type: "object",
          properties: {
            all: { type: "boolean", description: "Inclure les conteneurs arrêtés" }
          }
        }
      },
      {
        name: "diagnose_system",
        description: "Diagnostiquer l'état général du système",
        inputSchema: { type: "object", properties: {} }
      },
      {
        name: "read_file",
        description: "Lire le contenu d'un fichier",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin absolu du fichier à lire" },
            encoding: { type: "string", description: "Encodage du fichier" }
          },
          required: ["path"]
        }
      },
      {
        name: "write_file",
        description: "Écrire du contenu dans un fichier",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin absolu du fichier" },
            content: { type: "string", description: "Contenu à écrire" }
          },
          required: ["path", "content"]
        }
      },
      {
        name: "list_directory",
        description: "Lister le contenu d'un répertoire",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin du répertoire" },
            recursive: { type: "boolean", description: "Lister récursivement" }
          }
        }
      },
      {
        name: "create_directory",
        description: "Créer un nouveau répertoire",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin du répertoire à créer" },
            recursive: { type: "boolean", description: "Créer les parents" }
          },
          required: ["path"]
        }
      },
      {
        name: "delete_file",
        description: "Supprimer un fichier ou répertoire",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Chemin à supprimer" },
            recursive: { type: "boolean", description: "Supprimer récursivement" }
          },
          required: ["path"]
        }
      },
      {
        name: "search_files",
        description: "Rechercher des fichiers par nom ou contenu",
        inputSchema: {
          type: "object",
          properties: {
            pattern: { type: "string", description: "Motif de recherche" },
            path: { type: "string", description: "Répertoire de départ" },
            type: { type: "string", description: "Type: name ou content" }
          },
          required: ["pattern"]
        }
      },
      {
        name: "analyze_logs",
        description: "Analyser les logs système pour détecter des erreurs",
        inputSchema: {
          type: "object",
          properties: {
            service: { type: "string", description: "Service à analyser" },
            lines: { type: "number", description: "Nombre de lignes" }
          }
        }
      },
      {
        name: "smart_diagnose",
        description: "Diagnostic intelligent avec suggestions de correction",
        inputSchema: {
          type: "object",
          properties: {
            component: { type: "string", description: "Composant à diagnostiquer" }
          }
        }
      },
      {
        name: "auto_fix",
        description: "Correction automatique des problèmes détectés",
        inputSchema: {
          type: "object",
          properties: {
            problem_type: { type: "string", description: "Type de problème" },
            confirm: { type: "boolean", description: "Confirmer les corrections" }
          },
          required: ["problem_type"]
        }
      },
      {
        name: "monitor_resources",
        description: "Surveillance en temps réel des ressources système",
        inputSchema: {
          type: "object",
          properties: {
            duration: { type: "number", description: "Durée en secondes" },
            interval: { type: "number", description: "Intervalle entre mesures" }
          }
        }
      },
      {
        name: "backup_file",
        description: "Créer une sauvegarde d'un fichier",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Fichier à sauvegarder" },
            backup_dir: { type: "string", description: "Répertoire de backup" }
          },
          required: ["path"]
        }
      },
      {
        name: "system_info",
        description: "Informations complètes sur le système",
        inputSchema: { type: "object", properties: {} }
      },
      {
        name: "remember",
        description: "Mémoriser une information importante",
        inputSchema: {
          type: "object",
          properties: {
            key: { type: "string", description: "Clé de la mémoire" },
            value: { type: "string", description: "Valeur à mémoriser" },
            context: { type: "string", description: "Contexte" }
          },
          required: ["key", "value"]
        }
      },
      {
        name: "recall",
        description: "Rappeler une information mémorisée",
        inputSchema: {
          type: "object",
          properties: {
            query: { type: "string", description: "Ce que vous cherchez" }
          },
          required: ["query"]
        }
      },
      {
        name: "create_web_service",
        description: "Créer un service web (site, API, application)",
        inputSchema: {
          type: "object",
          properties: {
            name: { type: "string", description: "Nom du service" },
            type: { type: "string", description: "Type: static, api, fullstack, proxy" },
            port: { type: "number", description: "Port d'écoute" },
            domain: { type: "string", description: "Nom de domaine" }
          },
          required: ["name", "type", "port"]
        }
      },
      {
        name: "generate_code",
        description: "Générer du code à partir d'une description",
        inputSchema: {
          type: "object",
          properties: {
            description: { type: "string", description: "Ce que doit faire le code" },
            language: { type: "string", description: "Langage de programmation" },
            type: { type: "string", description: "Type: function, class, script" },
            save: { type: "boolean", description: "Sauvegarder?" },
            filename: { type: "string", description: "Nom du fichier" }
          },
          required: ["description", "language", "type"]
        }
      },
      {
        name: "intelligent_analysis",
        description: "Analyser un problème et proposer des solutions",
        inputSchema: {
          type: "object",
          properties: {
            problem: { type: "string", description: "Description du problème" },
            context: { type: "string", description: "Contexte additionnel" }
          },
          required: ["problem"]
        }
      }
    ];

    // Générer dynamiquement les paths pour chaque outil
    const paths: any = {};
    
    for (const tool of toolsList) {
      const pathKey = `/api/tool/${tool.name}`;
      const hasRequired = (tool.inputSchema as any).required?.length > 0;
      const hasProps = Object.keys((tool.inputSchema as any).properties || {}).length > 0;
      
      paths[pathKey] = {
        post: {
          summary: tool.description,
          operationId: tool.name,
          tags: [this.getToolCategory(tool.name)],
          ...(hasProps ? {
            requestBody: {
              required: hasRequired,
              content: {
                'application/json': {
                  schema: tool.inputSchema
                }
              }
            }
          } : {}),
          responses: {
            '200': {
              description: 'Résultat',
              content: { 'application/json': { schema: { type: 'object' } } }
            }
          }
        }
      };
    }

    return {
      openapi: '3.0.0',
      info: {
        title: 'Server Admin MCP - 25 Outils Intelligents',
        version: '3.0.0',
        description: '25 outils: système, fichiers, Docker, logs, mémoire, web, code'
      },
      servers: [{ url: 'http://mcp-server:3000' }],
      paths,
      tags: [
        { name: 'System', description: 'Administration système' },
        { name: 'Files', description: 'Gestion fichiers' },
        { name: 'Docker', description: 'Conteneurs Docker' },
        { name: 'Services', description: 'Services systemd' },
        { name: 'Network', description: 'Réseau' },
        { name: 'Logs', description: 'Analyse logs' },
        { name: 'Memory', description: 'Mémoire IA' },
        { name: 'WebDev', description: 'Création web' },
        { name: 'CodeGen', description: 'Génération code' },
        { name: 'Intelligence', description: 'IA et auto-fix' }
      ]
    };
  }

  private getToolCategory(toolName: string): string {
    const categories: { [key: string]: string } = {
      'run_command': 'System', 'system_info': 'System', 'diagnose_system': 'System',
      'check_disk_usage': 'System', 'check_memory_usage': 'System', 'monitor_resources': 'System',
      'check_service_status': 'Services', 'restart_service': 'Services',
      'check_docker_containers': 'Docker', 'check_network_connections': 'Network',
      'read_file': 'Files', 'write_file': 'Files', 'list_directory': 'Files',
      'create_directory': 'Files', 'delete_file': 'Files', 'search_files': 'Files', 'backup_file': 'Files',
      'analyze_logs': 'Logs', 'smart_diagnose': 'Intelligence', 'auto_fix': 'Intelligence',
      'intelligent_analysis': 'Intelligence', 'remember': 'Memory', 'recall': 'Memory',
      'create_web_service': 'WebDev', 'generate_code': 'CodeGen'
    };
    return categories[toolName] || 'Other';
  }
}

// Démarrer le serveur
const server = new ServerAdminServer();
server.run().catch(console.error);