/**
 * Générateur intelligent de services web
 * Crée automatiquement des sites web, APIs, serveurs
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';

const execAsync = promisify(exec);

export interface WebServiceConfig {
  name: string;
  type: 'static' | 'api' | 'fullstack' | 'proxy';
  domain?: string;
  port: number;
  framework?: 'express' | 'fastify' | 'nginx' | 'apache';
  features?: string[];
}

export class WebServiceGenerator {
  private projectsDir = '/home/lalpha/web-services';

  async createWebService(config: WebServiceConfig): Promise<{ success: boolean; message: string; url: string }> {
    try {
      // Créer le répertoire du projet
      const projectPath = path.join(this.projectsDir, config.name);
      await fs.mkdir(projectPath, { recursive: true });

      let result: string;

      switch (config.type) {
        case 'static':
          result = await this.createStaticSite(projectPath, config);
          break;
        case 'api':
          result = await this.createAPIService(projectPath, config);
          break;
        case 'fullstack':
          result = await this.createFullStackApp(projectPath, config);
          break;
        case 'proxy':
          result = await this.createReverseProxy(projectPath, config);
          break;
        default:
          throw new Error(`Type de service non supporté: ${config.type}`);
      }

      // Créer un conteneur Docker pour le service
      await this.dockerize(projectPath, config);

      // Configurer le reverse proxy (Traefik)
      if (config.domain) {
        await this.configureReverseProxy(config);
      }

      const url = config.domain || `http://localhost:${config.port}`;

      return {
        success: true,
        message: `Service web '${config.name}' créé avec succès`,
        url
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Erreur: ${error.message}`,
        url: ''
      };
    }
  }

  // Créer un site statique
  private async createStaticSite(projectPath: string, config: WebServiceConfig): Promise<string> {
    // Créer structure HTML simple mais élégante
    const indexHtml = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${config.name}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .container {
            text-align: center;
            padding: 2rem;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        }
        h1 { font-size: 3rem; margin-bottom: 1rem; }
        p { font-size: 1.2rem; opacity: 0.9; }
        .status { margin-top: 2rem; }
        .pulse {
            width: 20px;
            height: 20px;
            background: #4ade80;
            border-radius: 50%;
            display: inline-block;
            margin-right: 10px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 ${config.name}</h1>
        <p>Votre site web est en ligne et opérationnel</p>
        <div class="status">
            <span class="pulse"></span>
            <span>Service actif</span>
        </div>
    </div>
</body>
</html>`;

    await fs.writeFile(path.join(projectPath, 'index.html'), indexHtml);

    // Créer un Dockerfile simple avec Nginx
    const dockerfile = `FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
EXPOSE 80`;

    await fs.writeFile(path.join(projectPath, 'Dockerfile'), dockerfile);

    return 'Site statique créé';
  }

  // Créer une API REST
  private async createAPIService(projectPath: string, config: WebServiceConfig): Promise<string> {
    const framework = config.framework || 'express';

    if (framework === 'express') {
      // Package.json
      const packageJson = {
        name: config.name,
        version: '1.0.0',
        type: 'module',
        main: 'server.js',
        scripts: {
          start: 'node server.js'
        },
        dependencies: {
          express: '^4.18.0',
          cors: '^2.8.5'
        }
      };

      await fs.writeFile(
        path.join(projectPath, 'package.json'),
        JSON.stringify(packageJson, null, 2)
      );

      // Server.js - API intelligente avec endpoints de base
      const serverJs = `import express from 'express';
import cors from 'cors';

const app = express();
const PORT = ${config.port};

app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Info
app.get('/api/info', (req, res) => {
  res.json({
    name: '${config.name}',
    version: '1.0.0',
    endpoints: ['/health', '/api/info', '/api/data']
  });
});

// Example data endpoint
app.get('/api/data', (req, res) => {
  res.json({
    message: 'Voici vos données',
    data: [
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' }
    ]
  });
});

// POST example
app.post('/api/data', (req, res) => {
  const item = req.body;
  res.status(201).json({
    message: 'Item créé',
    item: { ...item, id: Date.now() }
  });
});

app.listen(PORT, () => {
  console.log(\`🚀 API ${config.name} démarrée sur le port \${PORT}\`);
});`;

      await fs.writeFile(path.join(projectPath, 'server.js'), serverJs);

      // Dockerfile
      const dockerfile = `FROM node:20-alpine
WORKDIR /app
COPY package.json ./
RUN npm install
COPY . .
EXPOSE ${config.port}
CMD ["npm", "start"]`;

      await fs.writeFile(path.join(projectPath, 'Dockerfile'), dockerfile);
    }

    return 'API REST créée';
  }

  // Créer une application full-stack
  private async createFullStackApp(projectPath: string, config: WebServiceConfig): Promise<string> {
    // Créer un projet Next.js basique
    await execAsync(`cd ${projectPath} && npx create-next-app@latest . --typescript --tailwind --app --no-src-dir --import-alias "@/*"`);
    
    return 'Application full-stack créée';
  }

  // Créer un reverse proxy
  private async createReverseProxy(projectPath: string, config: WebServiceConfig): Promise<string> {
    const nginxConf = `events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:8080;
    }

    server {
        listen ${config.port};
        server_name ${config.domain || 'localhost'};

        location / {
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
    }
}`;

    await fs.writeFile(path.join(projectPath, 'nginx.conf'), nginxConf);

    const dockerfile = `FROM nginx:alpine
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE ${config.port}`;

    await fs.writeFile(path.join(projectPath, 'Dockerfile'), dockerfile);

    return 'Reverse proxy créé';
  }

  // Dockeriser le service
  private async dockerize(projectPath: string, config: WebServiceConfig): Promise<void> {
    // Build l'image
    await execAsync(`cd ${projectPath} && docker build -t ${config.name}:latest .`);

    // Créer et démarrer le conteneur
    const dockerRunCmd = `docker run -d \
      --name ${config.name} \
      --network traefik-net \
      --restart unless-stopped \
      -p ${config.port}:${config.port} \
      ${config.domain ? `-l "traefik.enable=true" -l "traefik.http.routers.${config.name}.rule=Host(\`${config.domain}\`)"` : ''} \
      ${config.name}:latest`;

    await execAsync(dockerRunCmd);
  }

  // Configurer Traefik
  private async configureReverseProxy(config: WebServiceConfig): Promise<void> {
    // Traefik est déjà configuré, il détecte automatiquement via les labels Docker
    console.log(`Traefik configuré pour ${config.domain}`);
  }

  // Lister tous les services web créés
  async listServices(): Promise<any[]> {
    try {
      const { stdout } = await execAsync(`docker ps --filter "network=traefik-net" --format "{{.Names}}\t{{.Status}}\t{{.Ports}}"`);
      return stdout.split('\n').filter(line => line.trim()).map(line => {
        const [name, status, ports] = line.split('\t');
        return { name, status, ports };
      });
    } catch {
      return [];
    }
  }
}
