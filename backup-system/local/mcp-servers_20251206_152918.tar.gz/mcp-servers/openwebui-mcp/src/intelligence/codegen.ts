/**
 * Générateur de code intelligent
 * Génère du code à partir de descriptions en langage naturel
 */

import fs from 'fs/promises';
import path from 'path';

export interface CodeRequest {
  description: string;
  language: 'typescript' | 'javascript' | 'python' | 'bash' | 'html' | 'css';
  type: 'function' | 'class' | 'script' | 'component' | 'config';
  features?: string[];
}

export class CodeGenerator {
  // Génère du code basé sur une description
  async generateCode(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    switch (request.type) {
      case 'function':
        return this.generateFunction(request);
      case 'class':
        return this.generateClass(request);
      case 'script':
        return this.generateScript(request);
      case 'component':
        return this.generateComponent(request);
      case 'config':
        return this.generateConfig(request);
      default:
        throw new Error(`Type non supporté: ${request.type}`);
    }
  }

  private async generateFunction(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    const desc = request.description.toLowerCase();
    
    // Détection intelligente de ce que l'utilisateur veut
    if (desc.includes('api') || desc.includes('http') || desc.includes('fetch')) {
      return this.createAPIFunction(request);
    }
    if (desc.includes('base de données') || desc.includes('database') || desc.includes('sql')) {
      return this.createDatabaseFunction(request);
    }
    if (desc.includes('fichier') || desc.includes('file') || desc.includes('lire') || desc.includes('read')) {
      return this.createFileFunction(request);
    }
    
    // Fonction générique
    return this.createGenericFunction(request);
  }

  private createAPIFunction(request: CodeRequest): { code: string; explanation: string } {
    if (request.language === 'typescript') {
      const code = `async function fetchData(url: string, options?: RequestInit): Promise<any> {
  try {
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers
      },
      ...options
    });
    
    if (!response.ok) {
      throw new Error(\`HTTP error! status: \${response.status}\`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erreur lors de la requête:', error);
    throw error;
  }
}

// Utilisation:
// const data = await fetchData('https://api.example.com/data');`;

      return {
        code,
        explanation: 'Fonction pour effectuer des requêtes HTTP avec gestion d\'erreurs'
      };
    }
    
    return { code: '', explanation: 'Langage non supporté pour ce type de fonction' };
  }

  private createDatabaseFunction(request: CodeRequest): { code: string; explanation: string } {
    if (request.language === 'typescript') {
      const code = `import Database from 'better-sqlite3';

interface QueryOptions {
  db: string;
  table: string;
  where?: Record<string, any>;
}

function query(options: QueryOptions): any[] {
  const db = new Database(options.db);
  
  try {
    let sql = \`SELECT * FROM \${options.table}\`;
    const params: any[] = [];
    
    if (options.where) {
      const conditions = Object.keys(options.where).map(key => {
        params.push(options.where![key]);
        return \`\${key} = ?\`;
      });
      sql += \` WHERE \${conditions.join(' AND ')}\`;
    }
    
    const stmt = db.prepare(sql);
    const rows = stmt.all(...params);
    
    return rows;
  } finally {
    db.close();
  }
}

// Utilisation:
// const users = query({ db: 'data.db', table: 'users', where: { active: 1 } });`;

      return {
        code,
        explanation: 'Fonction pour interroger une base de données SQLite avec conditions'
      };
    }
    
    return { code: '', explanation: 'Langage non supporté pour ce type de fonction' };
  }

  private createFileFunction(request: CodeRequest): { code: string; explanation: string } {
    if (request.language === 'typescript') {
      const code = `import fs from 'fs/promises';
import path from 'path';

async function readFileContent(filePath: string): Promise<string> {
  try {
    const absolutePath = path.resolve(filePath);
    const content = await fs.readFile(absolutePath, 'utf-8');
    return content;
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      throw new Error(\`Fichier non trouvé: \${filePath}\`);
    }
    throw error;
  }
}

async function writeFileContent(filePath: string, content: string): Promise<void> {
  try {
    const absolutePath = path.resolve(filePath);
    const dir = path.dirname(absolutePath);
    
    // Créer le répertoire si nécessaire
    await fs.mkdir(dir, { recursive: true });
    
    await fs.writeFile(absolutePath, content, 'utf-8');
  } catch (error) {
    console.error('Erreur lors de l\\'écriture:', error);
    throw error;
  }
}

// Utilisation:
// const content = await readFileContent('data.txt');
// await writeFileContent('output.txt', 'Hello World');`;

      return {
        code,
        explanation: 'Fonctions pour lire et écrire des fichiers avec gestion d\'erreurs'
      };
    }
    
    return { code: '', explanation: 'Langage non supporté pour ce type de fonction' };
  }

  private createGenericFunction(request: CodeRequest): { code: string; explanation: string } {
    // Extraction du nom de fonction depuis la description
    const words = request.description.split(' ');
    const functionName = words[0] || 'processData';
    
    if (request.language === 'typescript') {
      const code = `function ${functionName}(input: any): any {
  // TODO: Implémenter la logique pour: ${request.description}
  
  console.log('Traitement de:', input);
  
  return {
    success: true,
    result: input
  };
}

// Utilisation:
// const result = ${functionName}(data);`;

      return {
        code,
        explanation: `Fonction générique: ${request.description}`
      };
    }
    
    return { code: '', explanation: 'Langage non supporté' };
  }

  private async generateClass(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    if (request.language === 'typescript') {
      const className = this.extractClassName(request.description);
      
      const code = `class ${className} {
  private data: any[] = [];
  
  constructor() {
    console.log('${className} initialisé');
  }
  
  // Ajouter des données
  add(item: any): void {
    this.data.push(item);
  }
  
  // Récupérer toutes les données
  getAll(): any[] {
    return [...this.data];
  }
  
  // Chercher par ID
  findById(id: number): any | undefined {
    return this.data.find(item => item.id === id);
  }
  
  // Supprimer par ID
  deleteById(id: number): boolean {
    const index = this.data.findIndex(item => item.id === id);
    if (index !== -1) {
      this.data.splice(index, 1);
      return true;
    }
    return false;
  }
  
  // Obtenir le nombre d'éléments
  count(): number {
    return this.data.length;
  }
}

// Utilisation:
// const manager = new ${className}();
// manager.add({ id: 1, name: 'Item 1' });
// console.log(manager.getAll());`;

      return {
        code,
        explanation: `Classe ${className} avec méthodes CRUD de base`
      };
    }
    
    return { code: '', explanation: 'Langage non supporté' };
  }

  private async generateScript(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    if (request.language === 'bash') {
      const code = `#!/bin/bash

# ${request.description}

set -e  # Arrêter en cas d'erreur

echo "Démarrage du script..."

# Variables
SCRIPT_DIR="$(cd "$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="\${SCRIPT_DIR}/script.log"

# Fonction de log
log() {
  echo "[\$(date '+%Y-%m-%d %H:%M:%S')] \$1" | tee -a "\${LOG_FILE}"
}

# Fonction principale
main() {
  log "Exécution..."
  
  # TODO: Implémenter la logique pour: ${request.description}
  
  log "Terminé avec succès"
}

# Exécution
main "\$@"`;

      return {
        code,
        explanation: `Script Bash: ${request.description}`
      };
    }
    
    if (request.language === 'python') {
      const code = `#!/usr/bin/env python3
"""
${request.description}
"""

import sys
import logging
from typing import Any

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main() -> int:
    """Fonction principale"""
    try:
        logger.info("Démarrage du script")
        
        # TODO: Implémenter la logique pour: ${request.description}
        
        logger.info("Script terminé avec succès")
        return 0
        
    except Exception as e:
        logger.error(f"Erreur: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())`;

      return {
        code,
        explanation: `Script Python: ${request.description}`
      };
    }
    
    return { code: '', explanation: 'Langage non supporté pour les scripts' };
  }

  private async generateComponent(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    if (request.language === 'typescript') {
      const componentName = this.extractClassName(request.description);
      
      const code = `import React, { useState, useEffect } from 'react';

interface ${componentName}Props {
  title?: string;
  data?: any[];
}

export const ${componentName}: React.FC<${componentName}Props> = ({ title = 'Component', data = [] }) => {
  const [items, setItems] = useState<any[]>(data);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // TODO: Charger les données si nécessaire
    setItems(data);
  }, [data]);

  return (
    <div className="container">
      <h1>{title}</h1>
      
      {loading ? (
        <div>Chargement...</div>
      ) : (
        <div className="items">
          {items.length === 0 ? (
            <p>Aucun élément</p>
          ) : (
            items.map((item, index) => (
              <div key={index} className="item">
                {JSON.stringify(item)}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};`;

      return {
        code,
        explanation: `Composant React ${componentName} avec state et props`
      };
    }
    
    return { code: '', explanation: 'Langage non supporté pour les composants' };
  }

  private async generateConfig(request: CodeRequest): Promise<{ code: string; explanation: string }> {
    const desc = request.description.toLowerCase();
    
    if (desc.includes('docker')) {
      const code = `version: '3.8'

services:
  app:
    build: .
    container_name: my-app
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    networks:
      - app-network

networks:
  app-network:
    driver: bridge`;

      return {
        code,
        explanation: 'Configuration Docker Compose pour une application'
      };
    }
    
    if (desc.includes('nginx')) {
      const code = `server {
    listen 80;
    server_name example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}`;

      return {
        code,
        explanation: 'Configuration Nginx en reverse proxy'
      };
    }
    
    return { code: '', explanation: 'Type de configuration non reconnu' };
  }

  private extractClassName(description: string): string {
    // Extraire un nom de classe potentiel de la description
    const words = description.split(' ').filter(w => w.length > 2);
    if (words.length > 0) {
      const name = words[0].charAt(0).toUpperCase() + words[0].slice(1);
      return name.replace(/[^a-zA-Z0-9]/g, '');
    }
    return 'MyClass';
  }

  // Sauvegarder le code généré dans un fichier
  async saveCode(code: string, filename: string, directory: string = '/home/lalpha/generated-code'): Promise<string> {
    try {
      await fs.mkdir(directory, { recursive: true });
      const filePath = path.join(directory, filename);
      await fs.writeFile(filePath, code);
      return filePath;
    } catch (error: any) {
      throw new Error(`Erreur lors de la sauvegarde: ${error.message}`);
    }
  }
}
