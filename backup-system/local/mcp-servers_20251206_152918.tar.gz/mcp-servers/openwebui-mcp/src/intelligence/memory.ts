/**
 * Système de mémoire intelligente avec SQLite
 * Stocke l'historique, les apprentissages et le contexte
 */

import sqlite3 from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

export interface MemoryEntry {
  id?: number;
  timestamp: Date;
  type: 'command' | 'conversation' | 'decision' | 'learning' | 'error';
  content: string;
  context?: string;
  result?: string;
  tags?: string[];
}

export class IntelligentMemory {
  private db: sqlite3.Database;

  constructor(dbPath: string = '/tmp/memory.db') {
    // Créer le répertoire si nécessaire
    const dir = path.dirname(dbPath);
    console.error(`📁 Tentative d'accès au répertoire: ${dir}`);
    console.error(`📄 Chemin de la base: ${dbPath}`);
    
    try {
      if (!fs.existsSync(dir)) {
        console.error(`📁 Création du répertoire: ${dir}`);
        fs.mkdirSync(dir, { recursive: true });
      } else {
        console.error(`✓ Répertoire existant: ${dir}`);
        const stats = fs.statSync(dir);
        console.error(`   Permissions: ${stats.mode.toString(8)}`);
      }
    } catch (error: any) {
      console.error('❌ Erreur création répertoire:', error.message);
      // Utiliser un chemin temporaire
      console.error('⚠️  Utilisation de /tmp comme fallback');
      dbPath = '/tmp/memory.db';
    }
    
    try {
      this.db = new sqlite3(dbPath);
      console.error(`✓ Base de données ouverte: ${dbPath}`);
    } catch (error: any) {
      console.error(`❌ Impossible d'ouvrir la base: ${error.message}`);
      // Dernier recours: mode mémoire
      console.error('⚠️  Utilisation de la base en mémoire');
      this.db = new sqlite3(':memory:');
    }
    
    this.initializeDatabase();
  }

  private initializeDatabase() {
    // Table principale de mémoire
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        type TEXT NOT NULL,
        content TEXT NOT NULL,
        context TEXT,
        result TEXT,
        tags TEXT,
        embedding TEXT
      );

      CREATE TABLE IF NOT EXISTS learnings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pattern TEXT NOT NULL,
        solution TEXT NOT NULL,
        success_count INTEGER DEFAULT 0,
        last_used DATETIME,
        confidence REAL DEFAULT 0.5
      );

      CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        user_message TEXT,
        assistant_response TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS system_state (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
      CREATE INDEX IF NOT EXISTS idx_memories_timestamp ON memories(timestamp);
      CREATE INDEX IF NOT EXISTS idx_learnings_pattern ON learnings(pattern);
    `);
  }

  // Sauvegarder une action
  remember(entry: MemoryEntry): number {
    const stmt = this.db.prepare(`
      INSERT INTO memories (type, content, context, result, tags)
      VALUES (?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      entry.type,
      entry.content,
      entry.context || null,
      entry.result || null,
      entry.tags ? JSON.stringify(entry.tags) : null
    );
    
    return info.lastInsertRowid as number;
  }

  // Récupérer des souvenirs similaires
  recall(query: string, type?: string, limit: number = 10): MemoryEntry[] {
    let sql = `
      SELECT * FROM memories
      WHERE content LIKE ?
    `;
    const params: any[] = [`%${query}%`];

    if (type) {
      sql += ` AND type = ?`;
      params.push(type);
    }

    sql += ` ORDER BY timestamp DESC LIMIT ?`;
    params.push(limit);

    const stmt = this.db.prepare(sql);
    return stmt.all(...params) as MemoryEntry[];
  }

  // Apprendre d'un pattern
  learn(pattern: string, solution: string): void {
    const existing = this.db.prepare(`
      SELECT * FROM learnings WHERE pattern = ?
    `).get(pattern);

    if (existing) {
      this.db.prepare(`
        UPDATE learnings 
        SET success_count = success_count + 1,
            last_used = CURRENT_TIMESTAMP,
            confidence = MIN(1.0, confidence + 0.1)
        WHERE pattern = ?
      `).run(pattern);
    } else {
      this.db.prepare(`
        INSERT INTO learnings (pattern, solution, success_count, confidence)
        VALUES (?, ?, 1, 0.6)
      `).run(pattern, solution);
    }
  }

  // Trouver une solution apprise
  findSolution(pattern: string): { solution: string; confidence: number } | null {
    const result = this.db.prepare(`
      SELECT solution, confidence FROM learnings
      WHERE pattern LIKE ?
      ORDER BY confidence DESC, success_count DESC
      LIMIT 1
    `).get(`%${pattern}%`) as any;

    return result || null;
  }

  // Sauvegarder une conversation
  saveConversation(sessionId: string, userMessage: string, response: string): void {
    this.db.prepare(`
      INSERT INTO conversations (session_id, user_message, assistant_response)
      VALUES (?, ?, ?)
    `).run(sessionId, userMessage, response);
  }

  // Récupérer l'historique de conversation
  getConversationHistory(sessionId: string, limit: number = 20): any[] {
    return this.db.prepare(`
      SELECT * FROM conversations
      WHERE session_id = ?
      ORDER BY timestamp DESC
      LIMIT ?
    `).all(sessionId, limit);
  }

  // Sauvegarder l'état du système
  setState(key: string, value: any): void {
    const valueStr = typeof value === 'string' ? value : JSON.stringify(value);
    this.db.prepare(`
      INSERT OR REPLACE INTO system_state (key, value, updated_at)
      VALUES (?, ?, CURRENT_TIMESTAMP)
    `).run(key, valueStr);
  }

  // Récupérer l'état du système
  getState(key: string): any {
    const result = this.db.prepare(`
      SELECT value FROM system_state WHERE key = ?
    `).get(key) as any;

    if (!result) return null;

    try {
      return JSON.parse(result.value);
    } catch {
      return result.value;
    }
  }

  // Statistiques
  getStats(): any {
    return {
      totalMemories: this.db.prepare('SELECT COUNT(*) as count FROM memories').get() as any,
      totalLearnings: this.db.prepare('SELECT COUNT(*) as count FROM learnings').get() as any,
      totalConversations: this.db.prepare('SELECT COUNT(*) as count FROM conversations').get() as any,
      recentActivity: this.db.prepare(`
        SELECT type, COUNT(*) as count FROM memories
        WHERE timestamp > datetime('now', '-24 hours')
        GROUP BY type
      `).all()
    };
  }

  close() {
    this.db.close();
  }
}
