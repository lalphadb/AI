/**
 * Agent Intelligent - Prise de décision autonome
 * Analyse les situations et propose/exécute des actions
 */

import { IntelligentMemory } from './memory.js';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface Decision {
  problem: string;
  analysis: string;
  proposedActions: Action[];
  confidence: number;
  reasoning: string;
}

export interface Action {
  type: 'command' | 'config' | 'service' | 'code';
  description: string;
  command?: string;
  risk: 'low' | 'medium' | 'high';
  reversible: boolean;
}

export class IntelligentAgent {
  private memory: IntelligentMemory;
  private learningRate: number = 0.1;

  constructor(memory: IntelligentMemory) {
    this.memory = memory;
  }

  // Analyser un problème et proposer des solutions
  async analyzeProblem(problem: string): Promise<Decision> {
    // 1. Chercher dans la mémoire des cas similaires
    const similarCases = this.memory.recall(problem, 'decision', 5);
    
    // 2. Chercher des solutions apprises
    const learnedSolution = this.memory.findSolution(problem);

    // 3. Analyser le problème
    const analysis = await this.performAnalysis(problem);

    // 4. Générer des actions possibles
    const actions = await this.generateActions(problem, analysis);

    // 5. Calculer la confiance
    const confidence = this.calculateConfidence(similarCases, learnedSolution);

    const decision: Decision = {
      problem,
      analysis,
      proposedActions: actions,
      confidence,
      reasoning: this.generateReasoning(similarCases, learnedSolution, analysis)
    };

    // Sauvegarder la décision
    this.memory.remember({
      type: 'decision',
      content: problem,
      context: JSON.stringify(decision),
      timestamp: new Date()
    });

    return decision;
  }

  // Analyser l'état actuel du système
  private async performAnalysis(problem: string): Promise<string> {
    const checks: string[] = [];

    // Vérifier la charge système
    try {
      const { stdout: load } = await execAsync('cat /host/proc/loadavg');
      const loadAvg = parseFloat(load.split(' ')[0]);
      if (loadAvg > 4) {
        checks.push(`⚠️ Charge système élevée: ${loadAvg}`);
      }
    } catch {}

    // Vérifier la mémoire
    try {
      const { stdout: mem } = await execAsync("cat /host/proc/meminfo | grep MemAvailable");
      const memAvailKb = parseInt(mem.match(/\d+/)?.[0] || '0');
      const memAvailGb = memAvailKb / 1024 / 1024;
      if (memAvailGb < 2) {
        checks.push(`⚠️ Mémoire faible: ${memAvailGb.toFixed(1)}GB disponible`);
      }
    } catch {}

    // Vérifier le disque
    try {
      const { stdout: disk } = await execAsync("df /host | tail -1");
      const parts = disk.trim().split(/\s+/);
      const usedPercent = parseInt(parts[4]);
      if (usedPercent > 85) {
        checks.push(`⚠️ Disque plein: ${usedPercent}% utilisé`);
      }
    } catch {}

    // Vérifier Docker
    try {
      const { stdout: docker } = await execAsync("docker ps --filter 'status=exited' | wc -l");
      const stopped = parseInt(docker) - 1;
      if (stopped > 0) {
        checks.push(`⚠️ ${stopped} conteneurs arrêtés`);
      }
    } catch {}

    return checks.length > 0 
      ? checks.join('\n') 
      : '✅ Système en bon état général';
  }

  // Générer des actions possibles
  private async generateActions(problem: string, analysis: string): Promise<Action[]> {
    const actions: Action[] = [];

    // Patterns de problèmes courants
    if (problem.toLowerCase().includes('disque') || problem.toLowerCase().includes('disk') || analysis.includes('Disque plein')) {
      actions.push({
        type: 'command',
        description: 'Nettoyer les fichiers temporaires',
        command: 'find /tmp -type f -atime +7 -delete',
        risk: 'low',
        reversible: false
      });
      actions.push({
        type: 'command',
        description: 'Nettoyer les logs anciens',
        command: 'find /var/log -name "*.gz" -mtime +30 -delete',
        risk: 'low',
        reversible: false
      });
      actions.push({
        type: 'command',
        description: 'Nettoyer Docker',
        command: 'docker system prune -af --volumes',
        risk: 'medium',
        reversible: false
      });
    }

    if (problem.toLowerCase().includes('mémoire') || problem.toLowerCase().includes('memory') || analysis.includes('Mémoire faible')) {
      actions.push({
        type: 'command',
        description: 'Redémarrer les services gourmands',
        command: 'systemctl restart $(systemctl list-units --type=service --state=running | grep -E "high memory" | awk "{print $1}")',
        risk: 'medium',
        reversible: true
      });
      actions.push({
        type: 'command',
        description: 'Vider le cache',
        command: 'sync && echo 3 > /proc/sys/vm/drop_caches',
        risk: 'low',
        reversible: true
      });
    }

    if (problem.toLowerCase().includes('docker') || analysis.includes('conteneurs arrêtés')) {
      actions.push({
        type: 'command',
        description: 'Redémarrer les conteneurs arrêtés',
        command: 'docker restart $(docker ps -aq --filter "status=exited")',
        risk: 'low',
        reversible: true
      });
    }

    if (problem.toLowerCase().includes('service') && problem.toLowerCase().includes('down')) {
      const serviceName = problem.match(/service\s+(\w+)/)?.[1];
      if (serviceName) {
        actions.push({
          type: 'service',
          description: `Redémarrer le service ${serviceName}`,
          command: `systemctl restart ${serviceName}`,
          risk: 'medium',
          reversible: true
        });
      }
    }

    return actions;
  }

  // Calculer la confiance dans la décision
  private calculateConfidence(similarCases: any[], learnedSolution: any): number {
    let confidence = 0.5; // Base

    if (similarCases.length > 0) {
      confidence += 0.1 * Math.min(similarCases.length, 5);
    }

    if (learnedSolution) {
      confidence += learnedSolution.confidence * 0.3;
    }

    return Math.min(confidence, 0.95);
  }

  // Générer le raisonnement
  private generateReasoning(similarCases: any[], learnedSolution: any, analysis: string): string {
    const reasons: string[] = [];

    if (similarCases.length > 0) {
      reasons.push(`📚 J'ai traité ${similarCases.length} cas similaires par le passé`);
    }

    if (learnedSolution) {
      reasons.push(`🎓 Solution apprise avec ${(learnedSolution.confidence * 100).toFixed(0)}% de confiance`);
    }

    reasons.push(`🔍 Analyse actuelle: ${analysis}`);

    return reasons.join('\n');
  }

  // Exécuter une action de manière autonome
  async executeAction(action: Action, autoApprove: boolean = false): Promise<{ success: boolean; output: string }> {
    if (!autoApprove && action.risk !== 'low') {
      return {
        success: false,
        output: 'Action nécessite une approbation manuelle (risque > low)'
      };
    }

    try {
      if (action.command) {
        const { stdout, stderr } = await execAsync(action.command);
        
        // Apprendre de cette exécution réussie
        this.memory.learn(action.description, action.command);
        
        return {
          success: true,
          output: stdout || stderr || 'Commande exécutée avec succès'
        };
      }

      return {
        success: false,
        output: 'Type d\'action non supporté'
      };
    } catch (error: any) {
      this.memory.remember({
        type: 'error',
        content: `Échec d'exécution: ${action.description}`,
        context: action.command,
        result: error.message,
        timestamp: new Date()
      });

      return {
        success: false,
        output: `Erreur: ${error.message}`
      };
    }
  }

  // Auto-diagnostic et auto-correction
  async runAutoDiagnostic(): Promise<string> {
    const report: string[] = ['🤖 Auto-diagnostic intelligent\n'];

    // Détecter les problèmes
    const problems = await this.detectProblems();

    if (problems.length === 0) {
      report.push('✅ Aucun problème détecté');
      return report.join('\n');
    }

    report.push(`⚠️ ${problems.length} problème(s) détecté(s):\n`);

    for (const problem of problems) {
      report.push(`\n🔍 Problème: ${problem}`);
      
      const decision = await this.analyzeProblem(problem);
      report.push(`📊 Confiance: ${(decision.confidence * 100).toFixed(0)}%`);
      report.push(`💭 ${decision.reasoning}\n`);

      if (decision.proposedActions.length > 0) {
        report.push(`🔧 Actions proposées:`);
        
        for (const action of decision.proposedActions) {
          report.push(`  • ${action.description} (risque: ${action.risk})`);
          
          // Auto-exécuter les actions à faible risque
          if (action.risk === 'low') {
            const result = await this.executeAction(action, true);
            if (result.success) {
              report.push(`    ✅ Exécuté avec succès`);
            } else {
              report.push(`    ❌ Échec: ${result.output}`);
            }
          }
        }
      }
    }

    return report.join('\n');
  }

  // Détecter les problèmes automatiquement
  private async detectProblems(): Promise<string[]> {
    const problems: string[] = [];

    // Vérifier la charge
    try {
      const { stdout } = await execAsync('cat /host/proc/loadavg');
      const load = parseFloat(stdout.split(' ')[0]);
      if (load > 8) {
        problems.push(`Charge système critique: ${load}`);
      }
    } catch {}

    // Vérifier les services
    try {
      const { stdout } = await execAsync("systemctl list-units --failed --no-legend | wc -l");
      const failed = parseInt(stdout);
      if (failed > 0) {
        problems.push(`${failed} service(s) en échec`);
      }
    } catch {}

    // Vérifier Docker
    try {
      const { stdout } = await execAsync("docker ps --filter 'health=unhealthy' | wc -l");
      const unhealthy = parseInt(stdout) - 1;
      if (unhealthy > 0) {
        problems.push(`${unhealthy} conteneur(s) en mauvaise santé`);
      }
    } catch {}

    return problems;
  }
}
