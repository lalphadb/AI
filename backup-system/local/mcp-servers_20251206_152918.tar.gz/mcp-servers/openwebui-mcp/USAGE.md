# Exemples d'utilisation du Server Admin MCP

## 🚀 Démarrage Rapide

### Diagnostic Complet du Système
```
Fais un diagnostic complet de mon serveur et signale-moi tous les problèmes détectés
```

### Gestion des Services
```
Vérifie si Docker fonctionne, sinon redémarre-le automatiquement
```

### Monitoring des Ressources
```
Surveille l'utilisation CPU et mémoire pendant 60 secondes
```

## 📁 Gestion des Fichiers

### Explorer un Répertoire
```
Montre-moi le contenu du répertoire /home/lalpha/projets de façon récursive
```

### Rechercher des Fichiers
```
Cherche tous les fichiers contenant "config" dans le répertoire /etc
```

### Sauvegarde Automatique
```
Fais une sauvegarde du fichier /etc/nginx/nginx.conf
```

## 🔧 Diagnostic Intelligent

### Analyse par Composant
```
Diagnostique le composant Docker et donne-moi des recommandations
```

### Analyse des Logs
```
Analyse les 200 dernières lignes des logs système et détecte les erreurs
```

### Correction Automatique
```
Applique automatiquement les corrections pour les problèmes de disque
```

## 💡 Cas d'Usage Avancés

### Maintenance Préventive
```
1. Vérifie l'espace disque disponible
2. Si < 80%, nettoie automatiquement le cache système
3. Redémarre les services critiques si nécessaire
4. Génère un rapport de maintenance
```

### Dépannage d'Urgence
```
1. Diagnostique tous les composants critiques
2. Identifie les services défaillants
3. Applique les corrections automatiques disponibles
4. Redémarre les conteneurs Docker arrêtés
5. Vérifie que tout fonctionne à nouveau
```

### Monitoring Continu
```
Surveille les ressources système pendant 5 minutes avec un intervalle de 10 secondes
```

## 🎯 Commandes Spécialisées

### Pour les Développeurs
```
Cherche tous les fichiers .ts contenant "interface" dans src/
```

### Pour les Administrateurs Système
```
Liste tous les services systemd actifs et leur statut
```

### Pour le Debugging
```
Analyse les logs de traefik et identifie les erreurs de configuration
```

## ⚡ Automatisation Intelligente

Le serveur apprend automatiquement des patterns d'erreur et propose des corrections de plus en plus précises au fil du temps.

### Exemples de Corrections Automatiques :
- **Espace disque faible** → Nettoyage automatique du cache
- **Conteneurs arrêtés** → Redémarrage automatique
- **Mémoire pleine** → Redémarrage des processus gourmands
- **Services défaillants** → Tentative de redémarrage

## 🔒 Sécurité

Toutes les opérations sont journalisées et les corrections automatiques nécessitent une confirmation explicite (sauf mention contraire).

## 📊 Métriques et Rapports

Le serveur génère automatiquement des rapports détaillés avec :
- 📈 Tendances d'utilisation des ressources
- 🚨 Alertes et problèmes détectés
- ✅ Actions correctives appliquées
- 📋 Recommandations pour l'optimisation