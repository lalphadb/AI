#!/bin/bash
set -e

echo "🔧 Déploiement de ChromaDB avec healthcheck corrigé..."
echo ""

cd "$(dirname "$0")"

# Vérifier que Docker est disponible
if ! command -v docker &> /dev/null; then
    echo "❌ Docker n'est pas installé"
    exit 1
fi

# Vérifier que docker-compose est disponible
if ! command -v docker compose &> /dev/null && ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose n'est pas installé"
    exit 1
fi

# Build l'image ChromaDB avec curl
echo "📦 Construction de l'image ChromaDB avec curl..."
docker build -f Dockerfile.chromadb -t chromadb-with-healthcheck:latest .

# Arrêter l'ancien conteneur si il existe
if docker ps -a | grep -q chromadb; then
    echo "🛑 Arrêt de l'ancien conteneur ChromaDB..."
    docker stop chromadb || true
    docker rm chromadb || true
fi

# Déployer avec le nouveau compose
echo "🚀 Déploiement du nouveau conteneur..."
docker compose -f chromadb-compose.yml up -d

echo ""
echo "✅ ChromaDB déployé avec succès!"
echo ""
echo "📊 Vérification du statut..."
sleep 5
docker ps --filter "name=chromadb" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "🔍 Test du healthcheck..."
sleep 10
docker inspect chromadb --format '{{.State.Health.Status}}' || echo "Healthcheck en cours d'initialisation..."

echo ""
echo "✅ Configuration appliquée:"
echo "   - API v2 utilisée (v1 déprécié)"
echo "   - curl installé pour healthcheck"
echo "   - Réseau: traefik-net + 4lbca_backend"
echo "   - Domain: chromadb.4lb.ca"
echo "   - Auth token: mcp-chromadb-secret-2024"
echo ""
echo "🧪 Test de l'API:"
echo "   curl http://localhost:8000/api/v2/heartbeat"
echo "   curl -H 'X-Chroma-Token: mcp-chromadb-secret-2024' http://localhost:8000/api/v2"
