# 🔧 Installation de la Function MCP dans Open WebUI

## ⚠️ Problème identifié

Le modèle **ne peut pas utiliser directement** l'OpenAPI externe. Open WebUI nécessite des **Functions** dans son propre format.

## ✅ Solution : Installer la Function MCP

### Étape 1 : Copier le code de la function

Le fichier `openwebui-function-mcp.py` contient la function complète.

### Étape 2 : Dans Open WebUI

1. **Ouvrir** : <https://llm.4lb.ca>
2. **Aller dans** : Settings (⚙️) → Workspace → Functions
3. **Cliquer** : "+" (Create New Function)
4. **Coller** le contenu de `openwebui-function-mcp.py`
5. **Sauvegarder**

### Étape 3 : Activer la function dans le chat

1. Ouvrir une nouvelle conversation
2. Cliquer sur l'icône "🔧" (Tools) en haut
3. **Activer** la function "MCP Tools"
4. Maintenant le modèle peut utiliser les outils !

---

## 🧪 Tester immédiatement

Une fois la function activée, testez avec :

```
Lis le fichier /host/var/log/fail2ban.log et montre-moi les 20 dernières IPs bannies
```

**Le modèle devrait maintenant** :

1. Appeler la function `read_file("/host/var/log/fail2ban.log")`
2. Recevoir le contenu
3. Extraire les IPs bannies
4. Vous les afficher

---

## 🛠️ Outils disponibles dans la Function

La function expose **8 outils principaux** :

### 1. `read_file(path)`

Lire un fichier système

```python
read_file("/host/var/log/fail2ban.log")
```

### 2. `run_command(command)`

Exécuter une commande shell

```python
run_command("tail -n 50 /host/var/log/fail2ban.log | grep Ban")
```

### 3. `check_docker_containers(all_containers)`

Lister les conteneurs Docker

```python
check_docker_containers(all_containers=True)
```

### 4. `analyze_logs(service, lines)`

Analyser les logs d'un service

```python
analyze_logs("fail2ban", 100)
```

### 5. `system_info()`

Info système complètes

```python
system_info()
```

### 6. `diagnose_system()`

Diagnostic système complet

```python
diagnose_system()
```

### 7. `list_directory(path, recursive)`

Lister un répertoire

```python
list_directory("/var/log", False)
```

### 8. `check_system_resources()`

Vérifier CPU, mémoire, disque

```python
check_system_resources()
```

---

## 📋 Exemples de questions qui fonctionneront

Une fois la function activée :

### ✅ Logs

```
Analyse les logs fail2ban
Montre-moi les erreurs dans /var/log/syslog
Lis les 100 dernières lignes de /var/log/auth.log
```

### ✅ Docker

```
Liste tous les conteneurs Docker
Montre-moi les conteneurs arrêtés
Vérifie l'état de tous les conteneurs
```

### ✅ Système

```
Fais un diagnostic complet
Vérifie l'utilisation des ressources
Donne-moi les infos système complètes
```

### ✅ Fichiers

```
Liste le contenu de /var/log
Lis /etc/hostname
Cherche les fichiers .log dans /var/log
```

### ✅ Commandes

```
Exécute "uptime"
Lance "df -h" et montre le résultat
Vérifie les processus avec "ps aux | head -20"
```

---

## 🚀 Avantages de cette approche

### ✅ Native à Open WebUI

- Le modèle voit les outils comme des functions normales
- Pas besoin de configuration externe
- Intégration parfaite avec l'interface

### ✅ Contrôle fin

- Vous pouvez activer/désactiver les outils par conversation
- Gestion des permissions dans Open WebUI
- Logs d'utilisation dans Open WebUI

### ✅ Extensible

- Ajoutez facilement de nouveaux outils
- Modifiez les paramètres selon vos besoins
- Combinez avec d'autres functions

---

## 🔄 Ajouter plus d'outils

Pour exposer plus d'outils MCP, ajoutez des méthodes dans la class `Tools` :

```python
def mon_nouvel_outil(self, param: str) -> str:
    """
    Description de l'outil
    
    Args:
        param: Description du paramètre
    
    Returns:
        Le résultat
    """
    try:
        response = requests.post(
            f"{self.valves.MCP_SERVER_URL}/api/endpoint",
            json={"param": param},
            timeout=10
        )
        result = response.json()
        if result.get("success"):
            return result.get("data")
        else:
            return f"Erreur: {result.get('error')}"
    except Exception as e:
        return f"Erreur: {str(e)}"
```

Puis **Update** la function dans Open WebUI.

---

## 🐛 Troubleshooting

### Problème : "Function not found"

**Solution** : Vérifiez que la function est activée (🔧 icône dans le chat)

### Problème : "Connection refused"

**Solution** : Vérifiez que le conteneur MCP est accessible :

```bash
docker exec open-webui curl http://mcp-server:3000/health
```

### Problème : "Timeout"

**Solution** : Augmentez le timeout dans le code de la function :

```python
timeout=30  # au lieu de 10
```

### Problème : Le modèle n'utilise pas les outils

**Solution** :

1. Vérifiez que la function est bien activée (🔧)
2. Utilisez un modèle qui supporte les function calls (deepseek-coder, qwen, etc.)
3. Soyez explicite dans votre question : "Utilise l'outil read_file pour..."

---

## 📊 Vérifier que ça fonctionne

### Test 1 : Dans Open WebUI

Après avoir activé la function, demandez :

```
Liste les outils disponibles que tu peux utiliser
```

Le modèle devrait répondre avec la liste des 8 fonctions.

### Test 2 : Appel direct

```
Utilise read_file pour lire /etc/hostname
```

Vous devriez voir le modèle **appeler la function** (affiché dans l'interface) puis afficher le résultat.

### Test 3 : Cas réel

```
Analyse les logs fail2ban et dis-moi combien d'IPs ont été bannies aujourd'hui
```

Le modèle devrait :

1. Appeler `analyze_logs("fail2ban", 100)` ou `read_file("/host/var/log/fail2ban.log")`
2. Parser le résultat
3. Compter les IPs bannies aujourd'hui
4. Vous donner le nombre

---

## 🎉 Une fois installé

Après l'installation de cette function, **tout fonctionne nativement** :

- ✅ Le modèle voit les outils MCP
- ✅ Il les appelle automatiquement selon le contexte
- ✅ Les résultats sont intégrés dans la conversation
- ✅ L'historique d'utilisation est tracé dans Open WebUI

**C'est la solution professionnelle et la plus stable !** 🚀

---

## 📝 Fichiers du projet

```
openwebui-function-mcp.py    ← La function à installer dans Open WebUI
FUNCTION-INSTALL.md          ← Ce guide
```

Bonne utilisation ! 🎯
