"""
title: MCP Server Admin Pro
author: Lalpha
version: 3.0
description: Administration système complète, création de sites web et génération de code
"""

from typing import Optional, Callable, Any, Dict
from pydantic import BaseModel, Field
import requests
import json

class Function:
    """
    Outils d'administration système avancés via le serveur MCP Intelligent.
    Permet la gestion de fichiers, Docker, création de services web et génération de code.
    """
    
    class Valves(BaseModel):
        MCP_SERVER_URL: str = Field(
            default="http://mcp-server:3000",
            description="URL du serveur MCP (interne Docker)"
        )
    
    def __init__(self):
        self.valves = self.Valves()

    def _call_tool(self, tool_name: str, args: Dict[str, Any] = None) -> str:
        """Méthode générique pour appeler n'importe quel outil MCP"""
        if args is None:
            args = {}
            
        try:
            response = requests.post(
                f"{self.valves.MCP_SERVER_URL}/api/tools/execute",
                json={"tool": tool_name, "arguments": args},
                timeout=120  # Timeout long pour les tâches complexes
            )
            
            if response.status_code != 200:
                return f"Erreur HTTP {response.status_code}: {response.text}"
                
            result = response.json()
            if result.get("success"):
                # Le format MCP standard retourne { content: [ { type: 'text', text: '...' } ] }
                mcp_result = result.get("result", {})
                content = mcp_result.get("content", [])
                if content and len(content) > 0:
                    return content[0].get("text", "Action effectuée avec succès.")
                return "Action effectuée (aucune sortie)."
            else:
                return f"Erreur MCP: {result.get('error', 'Erreur inconnue')}"
        except Exception as e:
            return f"Erreur de connexion au serveur MCP: {str(e)}"

    # --- Outils Système ---

    def run_command(self, command: str) -> str:
        """Exécuter une commande shell sur le serveur (root)."""
        return self._call_tool("run_command", {"command": command})

    def system_info(self) -> str:
        """Obtenir un rapport complet sur l'état du système."""
        return self._call_tool("system_info", {"category": "all"})

    def diagnose_system(self) -> str:
        """Lancer un auto-diagnostic intelligent des problèmes."""
        return self._call_tool("diagnose_system", {})

    # --- Outils Docker ---

    def list_containers(self, all: bool = False) -> str:
        """Lister les conteneurs Docker."""
        return self._call_tool("check_docker_containers", {"all": all})

    # --- Outils Créatifs (Nouveau !) ---

    def create_web_service(self, name: str, type: str, port: int, domain: str = "") -> str:
        """
        Créer et déployer automatiquement un nouveau service web.
        Args:
            name: Nom du projet (ex: 'mon-site')
            type: Type de projet ('static', 'api', 'fullstack', 'proxy')
            port: Port à exposer
            domain: (Optionnel) Domaine pour Traefik
        """
        return self._call_tool("create_web_service", {
            "name": name,
            "type": type,
            "port": port,
            "domain": domain
        })

    def generate_code(self, description: str, language: str, filename: str = "") -> str:
        """
        Générer du code ou des scripts et les sauvegarder.
        Args:
            description: Ce que le code doit faire
            language: Langage (python, bash, javascript, etc.)
            filename: (Optionnel) Chemin où sauvegarder le fichier
        """
        return self._call_tool("generate_code", {
            "description": description,
            "language": language,
            "save": bool(filename),
            "filename": filename
        })

    # --- Mémoire (Nouveau !) ---

    def remember(self, info: str, context: str = "") -> str:
        """Mémoriser une information importante pour plus tard."""
        return self._call_tool("remember_info", {"key": "user_info", "value": info, "context": context})

    def recall(self, query: str) -> str:
        """Retrouver une information mémorisée."""
        return self._call_tool("recall_info", {"query": query})
