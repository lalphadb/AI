# 🔐 Configuration de la Clé API Ollama pour Modèles Cloud

## 📋 Résumé

La clé API `6e1719ab31be41caa0f66f51681a072e.xl_VS6J785TUmjjyjmOgLB5s` doit être configurée **sur le serveur Ollama** (192.168.100.1), pas dans Open WebUI.

---

## ✅ Solution: Configurer sur le Serveur Ollama

### Étape 1: Se connecter au serveur Ollama

```bash
# SSH vers le serveur qui héberge Ollama
ssh user@192.168.100.1
```

### Étape 2: Configurer la clé API Ollama

**Option A: Variable d'environnement (si Ollama tourne en service)**

```bash
# Éditer le service systemd
sudo systemctl edit ollama

# Ajouter:
[Service]
Environment="OLLAMA_API_KEY=6e1719ab31be41caa0f66f51681a072e.xl_VS6J785TUmjjyjmOgLB5s"

# Redémarrer
sudo systemctl daemon-reload
sudo systemctl restart ollama
```

**Option B: Docker (si Ollama tourne en conteneur)**

```bash
# Arrêter le conteneur Ollama
docker stop ollama

# Redémarrer avec la clé
docker run -d \
  --name ollama \
  --restart unless-stopped \
  -v ollama:/root/.ollama \
  -p 11434:11434 \
  -e OLLAMA_API_KEY="6e1719ab31be41caa0f66f51681a072e.xl_VS6J785TUmjjyjmOgLB5s" \
  ollama/ollama
```

**Option C: Authentification via CLI (recommandé)**

```bash
# Se connecter via l'URL fournie par Ollama
# Visite cette URL dans ton navigateur:
https://ollama.com/connect?name=lalpha-server-1&key=c3NoLWVkMjU1MTkgQUFBQUMzTnphQzFsWkRJMU5URTVBQUFBSU5IOWhyYk1xNlVtQ2diYTdYU2dvUFF0emRuYTI0bGxXV05ZZ1VEeVBYTVA=

# OU utilise la commande:
ollama login
# Puis entre la clé: 6e1719ab31be41caa0f66f51681a072e.xl_VS6J785TUmjjyjmOgLB5s
```

### Étape 3: Vérifier

```bash
# Tester un modèle cloud
ollama run kimi-k2:1t-cloud "hello"

# OU via API:
curl http://localhost:11434/api/generate -d '{
  "model":"kimi-k2:1t-cloud",
  "prompt":"test",
  "stream":false
}'
```

---

## 🔄 Ce qui a été fait

✅ Open WebUI redéployé avec configuration optimisée  
✅ Variable `OLLAMA_API_KEY` ajoutée à Open WebUI  
⚠️ **Mais l'authentification doit se faire sur le serveur Ollama lui-même**

---

## 📊 État Actuel

**Modèles fonctionnels:**
- ✅ `deepseek-coder:33b` (local)
- ✅ `qwen2.5-coder:32b-instruct-q4_K_M` (local)
- ✅ `llama3.2-vision:11b-instruct-q8_0` (local)

**Modèles nécessitant authentification Ollama:**
- ⚠️ `kimi-k2:1t-cloud` (requiert config sur 192.168.100.1)
- ⚠️ `qwen3-coder:480b-cloud` (requiert config sur 192.168.100.1)

---

## 🎯 Prochaine Étape

**Choisis une option:**

1. **Utiliser les modèles locaux** (déjà fonctionnels, aucune config)
   - Sélectionne `deepseek-coder:33b` ou `qwen2.5-coder:32b` dans Open WebUI

2. **Configurer l'auth Ollama** (pour les modèles cloud)
   - SSH vers 192.168.100.1
   - Exécute `ollama login` ou visite l'URL d'authentification
   - Redémarre Ollama

3. **Supprimer les modèles cloud** (si tu ne veux pas les utiliser)
   ```bash
   ssh user@192.168.100.1
   ollama rm kimi-k2:1t-cloud
   ollama rm qwen3-coder:480b-cloud
   ```

---

## 📝 Script Créé

- ✅ `redeploy-openwebui-with-key.sh` - Redéploie Open WebUI avec clé API

**Note:** La clé dans Open WebUI n'est utile que si le serveur Ollama est déjà authentifié.
