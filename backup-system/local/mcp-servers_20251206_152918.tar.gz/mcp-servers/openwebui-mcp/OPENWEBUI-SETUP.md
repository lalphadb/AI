# 🚀 Configuration Open WebUI avec MCP Intelligent

## 📋 Prérequis

- ✅ Serveur MCP déployé sur le réseau Docker `traefik-net`
- ✅ Open WebUI installé et accessible
- ✅ Accès administrateur à Open WebUI

## 🔧 Configuration

### Étape 1 : Accéder aux paramètres

1. Ouvrir Open WebUI
2. Cliquer sur votre profil (coin supérieur droit)
3. Aller dans **Settings** (Paramètres)
4. Naviguer vers **Admin Settings** → **Connections** ou **External Tools**

### Étape 2 : Ajouter le serveur MCP

**Type de connexion :** OpenAPI

**Configuration :**

```json
{
  "name": "MCP Server Intelligent",
  "type": "openapi",
  "url": "http://mcp-server:3000",
  "spec_url": "http://mcp-server:3000/openapi.json"
}
```

**OU si vous avez un champ de spécification OpenAPI :**

1. Récupérer la spécification :
   ```bash
   curl http://mcp-server:3000/openapi.json > openapi-spec.json
   ```

2. Copier le contenu dans le champ "OpenAPI Specification"

### Étape 3 : Vérifier la connexion

1. Sauvegarder la configuration
2. Tester avec une commande simple :
   ```
   Utilise l'outil system_info pour voir les informations du serveur
   ```

Si cela fonctionne, vous verrez les informations système !

## 🧠 Utilisation des Outils Intelligents

### 1. Mémoire Persistante

**Mémoriser une information :**
```
Mémorise que le serveur de production est à l'adresse 192.168.1.100 sur le port 8080
```

**Rappeler une information :**
```
Rappelle-moi les informations sur le serveur de production
```

### 2. Créer des Services Web

**Site web statique :**
```
Crée-moi un site web vitrine pour mon entreprise sur le port 8080
```

**API REST :**
```
Crée une API REST pour gérer des utilisateurs sur le port 3001
```

**Application full-stack :**
```
Crée une application Next.js complète sur le port 3002 avec le domaine monapp.local
```

### 3. Génération de Code

**Fonction TypeScript :**
```
Génère une fonction TypeScript pour récupérer des données depuis une API avec gestion d'erreurs
```

**Script Python :**
```
Génère un script Python pour analyser des logs et extraire les erreurs, sauvegarde-le dans analyze-logs.py
```

**Composant React :**
```
Crée un composant React pour afficher une liste d'articles avec pagination
```

**Configuration Docker :**
```
Génère une configuration Docker Compose pour une application Node.js avec PostgreSQL
```

### 4. Analyse Intelligente

**Diagnostic de problème :**
```
Analyse pourquoi mon conteneur Docker redémarre constamment
```

**Optimisation :**
```
Analyse l'utilisation de la mémoire et propose des optimisations
```

**Résolution de bug :**
```
J'ai une erreur "ECONNREFUSED" sur mon application, analyse le problème
```

## 🎯 Exemples de Conversations

### Exemple 1 : Projet Complet

**Vous :**
```
Je veux créer un blog. Crée-moi :
1. Un site web sur le port 8080
2. Une API pour gérer les articles sur le port 8081
3. Mémorise ces informations pour plus tard
```

**Résultat :**
- ✅ Site web créé et déployé
- ✅ API REST fonctionnelle
- ✅ Informations mémorisées

### Exemple 2 : Développement Assisté

**Vous :**
```
Génère-moi une fonction JavaScript pour uploader des fichiers vers un serveur avec barre de progression, puis crée un composant React qui l'utilise
```

**Résultat :**
- ✅ Fonction d'upload générée avec fetch() et progress events
- ✅ Composant React avec UI et gestion des états

### Exemple 3 : Debug et Correction

**Vous :**
```
Mon site web ne répond plus. Diagnostique le problème et propose des solutions
```

**Résultat :**
- 🔍 Analyse automatique du système
- 📊 Identification du problème (ex: mémoire pleine, service arrêté)
- 💡 Solutions proposées avec niveau de risque
- 🔧 Option de correction automatique

## 🛠️ Outils Disponibles

### Gestion Système (20+ outils)
- `system_info` - Informations complètes du système
- `run_command` - Exécuter des commandes
- `check_service_status` - État des services
- `restart_service` - Redémarrer des services
- `diagnose_system` - Diagnostic complet
- `check_disk_usage` - Utilisation disque
- `check_memory_usage` - Utilisation mémoire
- `check_docker_containers` - Conteneurs Docker
- `analyze_logs` - Analyse de logs
- `monitor_resources` - Monitoring temps réel

### Intelligence Artificielle (6 nouveaux outils)
- `remember` - Mémoriser des informations
- `recall` - Rappeler des informations
- `create_web_service` - Créer des services web
- `generate_code` - Générer du code
- `intelligent_analysis` - Analyse intelligente
- `smart_diagnose` - Diagnostic avec suggestions

### Fichiers
- `read_file` - Lire des fichiers
- `write_file` - Écrire dans des fichiers
- `list_directory` - Explorer les répertoires
- `create_directory` - Créer des répertoires
- `delete_file` - Supprimer des fichiers
- `search_files` - Rechercher des fichiers
- `backup_file` - Sauvegarder des fichiers

## 🔥 Astuces et Bonnes Pratiques

### 1. Utiliser la Mémoire
Mémorisez les configurations importantes pour y accéder rapidement :
```
Mémorise que mon serveur MySQL est sur mysql.local:3306, user=admin
```

Plus tard :
```
Rappelle-moi la config MySQL
```

### 2. Enchaîner les Actions
Demandez plusieurs actions en une fois :
```
Crée une API REST sur le port 4000, génère le code client TypeScript, et sauvegarde tout dans /home/user/projet
```

### 3. Profiter de l'Apprentissage
Le système apprend de vos interactions. Plus vous l'utilisez, mieux il comprend vos besoins !

### 4. Vérifier Avant d'Appliquer
Pour les commandes critiques, demandez d'abord l'analyse :
```
Analyse ce que fait cette commande avant de l'exécuter : rm -rf /data/*
```

## 🐛 Dépannage

### Le serveur ne répond pas

1. Vérifier que le conteneur tourne :
   ```bash
   docker ps | grep mcp-server
   ```

2. Vérifier les logs :
   ```bash
   docker logs mcp-server --tail 50
   ```

3. Redémarrer si nécessaire :
   ```bash
   docker restart mcp-server
   ```

### Les outils n'apparaissent pas dans Open WebUI

1. Vérifier l'URL de connexion (doit être `http://mcp-server:3000`)
2. Vérifier que Open WebUI et MCP sont sur le même réseau Docker
3. Rafraîchir la page Open WebUI
4. Vérifier la spec OpenAPI :
   ```bash
   curl http://mcp-server:3000/openapi.json
   ```

### Erreurs "Permission denied"

Le serveur MCP tourne avec les permissions du conteneur. Pour certaines opérations sensibles :
- Le serveur a accès en lecture seule à l'hôte via `/host`
- Utilisez des commandes appropriées pour les modifications système

## 📚 Documentation Complète

- **[Fonctionnalités Intelligentes](./INTELLIGENT-FEATURES.md)** - Guide complet des nouvelles capacités IA
- **[README](./README.md)** - Documentation générale
- **[Guide d'Utilisation](./USAGE.md)** - Exemples d'utilisation détaillés

## 🎉 C'est Tout !

Vous êtes maintenant prêt à utiliser votre serveur MCP intelligent !

Commencez par une commande simple :
```
Montre-moi les informations du système
```

Et explorez les possibilités ! 🚀
