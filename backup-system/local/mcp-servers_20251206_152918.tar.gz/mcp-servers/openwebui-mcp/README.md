# 🧠 Server Admin MCP - Serveur Intelligent Autonome

Un serveur MCP (Model Context Protocol) **ultra-intelligent et autonome** pour l'administration complète d'un serveur Linux, avec **mémoire persistante**, génération de code, création de services web, auto-diagnostic et monitoring en temps réel.

## 🎉 Version 2.0 - Intelligence Artificielle Avancée

Le serveur MCP est maintenant capable de :
- 🧠 **Mémoriser** et **apprendre** de ses interactions
- 🌐 **Créer automatiquement** des sites web, APIs et applications
- 💻 **Générer du code** à partir de descriptions en langage naturel
- 🤖 **S'auto-surveiller** et proposer des solutions intelligentes
- 📊 **Analyser** et **résoudre** des problèmes de manière autonome

👉 **[Voir la documentation complète des nouvelles fonctionnalités](./INTELLIGENT-FEATURES.md)**

## ✨ Fonctionnalités Avancées

### 🤖 Intelligence Artificielle Intégrée
- **Auto-diagnostic** : Analyse intelligente des problèmes système
- **Suggestions automatiques** : Recommandations contextuelles pour les corrections
- **Correction automatique** : Application sécurisée de fixes courants
- **Apprentissage adaptatif** : Amélioration continue des diagnostics

### 📁 Gestion Avancée des Fichiers
- **Lecture/écriture** de fichiers avec encodage flexible
- **Navigation récursive** dans les répertoires
- **Recherche intelligente** par nom ou contenu
- **Sauvegarde automatique** avec timestamp
- **Opérations sécurisées** avec gestion d'erreurs

### 🔍 Monitoring et Diagnostic
- **Surveillance temps réel** des ressources (CPU, RAM, disque, réseau)
- **Analyse de logs** avec détection de patterns d'erreur
- **Diagnostic par composant** (Docker, réseau, disque, mémoire, services)
- **Rapports détaillés** avec métriques et recommandations

### 🛠️ Outils Utiles et Intuitifs

#### Gestion Système
- **`run_command`** : Exécuter n'importe quelle commande système
- **`check_service_status`** : Vérifier l'état des services systemd
- **`restart_service`** : Redémarrer des services avec vérification
- **`system_info`** : Informations complètes sur le système

#### Système de Fichiers
- **`read_file`** : Lire le contenu des fichiers
- **`write_file`** : Écrire dans les fichiers
- **`list_directory`** : Explorer les répertoires (récursif optionnel)
- **`create_directory`** : Créer des répertoires
- **`delete_file`** : Supprimer fichiers/répertoires
- **`search_files`** : Recherche par nom ou contenu
- **`backup_file`** : Sauvegarde automatique des fichiers

#### Diagnostic Intelligent
- **`diagnose_system`** : Diagnostic général du système
- **`smart_diagnose`** : Diagnostic spécialisé par composant
- **`analyze_logs`** : Analyse intelligente des logs
- **`auto_fix`** : Correction automatique des problèmes
- **`monitor_resources`** : Surveillance en temps réel

#### Ressources et Monitoring
- **`check_disk_usage`** : Analyse de l'utilisation disque
- **`check_memory_usage`** : Monitorage de la mémoire
- **`check_network_connections`** : Inspection du réseau
- **`check_docker_containers`** : Gestion des conteneurs Docker

## Installation

1. **Cloner le repository**
   ```bash
   git clone <repository-url>
   cd openWebUI-mcp
   ```

2. **Installer les dépendances**
   ```bash
   npm install
   ```

3. **Compiler le projet**
   ```bash
   npm run build
   ```

## Configuration avec Open WebUI

### Méthode 1: Configuration manuelle

1. **Démarrer le serveur MCP**
   ```bash
   npm start
   ```

2. **Configurer Open WebUI**
   - Aller dans les paramètres d'Open WebUI
   - Section "External Tools" ou "MCP Servers"
   - Ajouter une nouvelle configuration :
     ```json
     {
       "command": "node",
       "args": ["/path/to/openWebUI-mcp/dist/index.js"],
       "env": {}
     }
     ```

### Méthode 2: Intégration Docker (recommandé)

Créer un conteneur pour le serveur MCP :

```dockerfile
FROM node:20-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY dist/ ./dist/
USER node

CMD ["node", "dist/index.js"]
```

## Utilisation

Une fois configuré, vous pouvez demander à Open WebUI de :

- **Diagnostiquer des problèmes** : "Vérifie l'état de mon serveur"
- **Redémarrer des services** : "Redémarre le service docker"
- **Analyser les ressources** : "Quelle est l'utilisation du disque ?"
- **Corriger automatiquement** : "Corrige les problèmes détectés"

## Exemples d'utilisation

### Diagnostiquer le système
```
Vérifie l'état général de mon serveur et signale les problèmes
```

### Gérer les services
```
Redémarre le service ollama s'il ne fonctionne pas
```

### Analyser les ressources
```
Montre-moi l'utilisation de la mémoire et du disque
```

### Corriger les problèmes
```
Diagnostique et corrige les problèmes courants sur le serveur
```

## Sécurité

⚠️ **Important** : Ce serveur MCP a accès complet à votre système. Utilisez-le uniquement dans un environnement de confiance.

- Le serveur s'exécute avec les permissions de l'utilisateur qui le lance
- Certaines commandes nécessitent `sudo`
- Vérifiez toujours les actions avant de les approuver

## Développement

### Structure du projet
```
openWebUI-mcp/
├── src/
│   └── index.ts          # Serveur MCP principal
├── dist/                 # Code compilé
├── package.json
├── tsconfig.json
└── README.md
```

### Scripts disponibles
- `npm run build` : Compiler TypeScript
- `npm run dev` : Développement avec rechargement
- `npm start` : Démarrer le serveur compilé
- `npm run clean` : Nettoyer les fichiers compilés

## Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :

- Signaler des bugs
- Proposer de nouvelles fonctionnalités
- Soumettre des pull requests

## Licence

MIT - Voir le fichier LICENSE pour plus de détails.