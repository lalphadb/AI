#!/bin/bash
set -e

echo "🔄 Redéploiement du serveur MCP avec accès système complet..."
echo ""

# Arrêter l'ancien MCP qui tourne en direct sur l'hôte
echo "🛑 Arrêt de l'ancien MCP server (processus hôte)..."
if pgrep -f "node dist/index.js" > /dev/null; then
    pkill -f "node dist/index.js" || true
    echo "   ✓ Ancien processus Node arrêté"
else
    echo "   ℹ Aucun processus Node trouvé"
fi

# Attendre que le port soit libéré
sleep 2

# Supprimer les anciens conteneurs MCP
echo "🗑️  Nettoyage des anciens conteneurs..."
docker ps -a | grep mcp-server | awk '{print $1}' | xargs -r docker rm -f 2>/dev/null || true

# Rebuild l'image avec Docker CLI
echo "🔨 Construction de l'image MCP avec Docker CLI..."
cd /home/lalpha/projets/openWebUI-mcp
docker build -t mcp-server:latest . -q

# Démarrer le nouveau conteneur
echo "🚀 Démarrage du nouveau conteneur MCP..."
docker run -d \
  --name mcp-server \
  --network traefik-net \
  --restart unless-stopped \
  --privileged \
  --pid host \
  -v /:/host:ro \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -p 3000:3000 \
  mcp-server:latest

echo ""
echo "⏳ Attente du démarrage (5 secondes)..."
sleep 5

# Vérifier le statut
echo ""
echo "📊 Statut du conteneur:"
docker ps --filter "name=mcp-server" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "🧪 Test de santé:"
curl -sS http://localhost:3000/health | head -50 || echo "❌ Health endpoint non accessible"

echo ""
echo "🔍 Test des capacités système:"
docker exec mcp-server docker ps --format "table {{.Names}}\t{{.Status}}" | head -5

echo ""
echo "✅ MCP Server redéployé avec succès!"
echo ""
echo "📋 Capacités activées:"
echo "   ✓ Accès privilégié au système hôte"
echo "   ✓ Visibilité de tous les processus (PID host)"
echo "   ✓ Accès au socket Docker"
echo "   ✓ Docker CLI installé"
echo "   ✓ Système de fichiers hôte monté en lecture seule (/host)"
echo ""
echo "🌐 API accessible sur:"
echo "   - http://localhost:3000"
echo "   - http://mcp-server:3000 (depuis traefik-net)"
