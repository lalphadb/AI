"""
id: mcp_bridge
title: MCP Bridge Tools
author: Lalpha
description: Outils pour interagir avec le serveur MCP - 25+ outils système intelligents
version: 1.0.0
"""

from typing import Optional, Union
import requests
from pydantic import BaseModel, Field


class Tools:
    def __init__(self):
        self.valves = self.Valves()

    class Valves(BaseModel):
        mcp_server_url: str = Field(
            default="http://mcp-server:3000",
            description="URL de base du serveur MCP accessible depuis Open WebUI",
        )

    # ----------- OUTILS FICHIERS ----------- #

    def read_file(self, path: str) -> dict:
        """
        Lit le contenu d'un fichier système via MCP.
        
        Args:
            path: Chemin absolu du fichier à lire (ex: /host/var/log/fail2ban.log)
        
        Returns:
            Dictionnaire avec le contenu du fichier ou une erreur
        """
        try:
            resp = requests.post(
                f"{self.valves.mcp_server_url}/api/files/read",
                json={"path": path},
                timeout=10,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "content": data.get("data", "")}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors de la lecture : {e}"}

    def list_directory(self, path: str = "/var/log", recursive: bool = False) -> dict:
        """
        Liste le contenu d'un répertoire système via MCP.
        
        Args:
            path: Chemin du répertoire à lister
            recursive: Lister récursivement les sous-dossiers
            
        Returns:
            Dictionnaire avec la liste des fichiers/dossiers
        """
        try:
            resp = requests.post(
                f"{self.valves.mcp_server_url}/api/files/list",
                json={"path": path, "recursive": recursive},
                timeout=10,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "entries": data.get("data", [])}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors du listing : {e}"}

    # ----------- OUTILS DOCKER ----------- #

    def list_docker_containers(self, all_containers: bool = False) -> dict:
        """
        Liste les conteneurs Docker via MCP.
        
        Args:
            all_containers: Inclure les conteneurs arrêtés
            
        Returns:
            Dictionnaire avec la liste des conteneurs Docker
        """
        try:
            resp = requests.get(
                f"{self.valves.mcp_server_url}/api/docker/containers",
                params={"all": str(all_containers).lower()},
                timeout=10,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "containers": data.get("data", [])}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors du listing des conteneurs : {e}"}

    # ----------- OUTILS SYSTÈME ----------- #

    def check_system_resources(self) -> dict:
        """
        Retourne l'utilisation des ressources système (CPU, RAM, disque) via MCP.
        
        Returns:
            Dictionnaire avec l'utilisation CPU/RAM/Disque du système
        """
        try:
            resp = requests.get(
                f"{self.valves.mcp_server_url}/api/system/resources",
                timeout=10,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "resources": data.get("data", {})}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors de la vérification des ressources : {e}"}

    def get_system_info(self) -> dict:
        """
        Obtient les informations complètes du système via MCP.
        
        Returns:
            Dictionnaire avec les informations détaillées du système
        """
        try:
            resp = requests.get(
                f"{self.valves.mcp_server_url}/api/system/info",
                timeout=10,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "system_info": data.get("data", {})}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors de la récupération des infos : {e}"}

    def diagnose_system(self) -> dict:
        """
        Effectue un diagnostic complet du système via MCP.
        
        Returns:
            Dictionnaire avec le rapport de diagnostic du système
        """
        try:
            resp = requests.get(
                f"{self.valves.mcp_server_url}/api/system/diagnose",
                timeout=20,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "diagnosis": data.get("data", {})}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors du diagnostic : {e}"}

    # ----------- OUTILS LOGS ----------- #

    def analyze_logs(self, service: str, lines: int = 50) -> dict:
        """
        Analyse les logs d'un service système via MCP.
        
        Args:
            service: Nom du service (fail2ban, nginx, syslog, auth, docker)
            lines: Nombre de lignes à analyser
            
        Returns:
            Dictionnaire avec l'analyse des logs du service
        """
        try:
            resp = requests.post(
                f"{self.valves.mcp_server_url}/api/logs/analyze",
                json={"service": service, "lines": lines},
                timeout=15,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "log_analysis": data.get("data", {})}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors de l'analyse des logs : {e}"}

    # ----------- OUTILS COMMANDES ----------- #

    def run_command(self, command: str) -> dict:
        """
        Exécute une commande système Linux via MCP.
        
        Args:
            command: La commande shell à exécuter
            
        Returns:
            Dictionnaire avec la sortie de la commande
        """
        try:
            resp = requests.post(
                f"{self.valves.mcp_server_url}/api/command/execute",
                json={"command": command},
                timeout=30,
            )
            data = resp.json()
            if data.get("success"):
                return {"success": True, "output": data.get("data", "")}
            return {"success": False, "error": data.get("error", "Erreur inconnue")}
        except Exception as e:
            return {"success": False, "error": f"Erreur lors de l'exécution : {e}"}