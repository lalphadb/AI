#!/usr/bin/env node
/**
 * MCP Server Intelligent v4.1
 * - 31 outils système
 * - Compatible Open WebUI MCP natif
 * - API REST complète
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import express, { Request, Response } from 'express';
import cors from 'cors';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import os from 'os';

const execAsync = promisify(exec);

// ============================================
// CONFIGURATION
// ============================================
const PORT = process.env.PORT || 3000;
const HOST_PATH = '/home/lalpha';

// ============================================
// INITIALISATION
// ============================================
const mcpServer = new McpServer({
  name: 'mcp-server-intelligent',
  version: '4.1.0'
});

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

// ============================================
// HELPERS
// ============================================
async function safeExec(command: string, timeout: number = 30000): Promise<{
  stdout: string;
  stderr: string;
  success: boolean;
}> {
  try {
    const { stdout, stderr } = await execAsync(command, {
      timeout,
      maxBuffer: 10 * 1024 * 1024,
      env: { ...process.env, PATH: '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin' }
    });
    return { stdout: stdout.trim(), stderr: stderr.trim(), success: true };
  } catch (error: any) {
    return { 
      stdout: '', 
      stderr: error.message || 'Erreur inconnue', 
      success: false 
    };
  }
}

// ============================================
// DÉFINITION DES 31 OUTILS
// ============================================
const TOOLS: Record<string, {
  description: string;
  schema: Record<string, any>;
  handler: (args: any) => Promise<any>;
}> = {
  // --- FICHIERS (7 outils) ---
  read_file: {
    description: 'Lit le contenu d\'un fichier',
    schema: { path: z.string().describe('Chemin du fichier') },
    handler: async (args: { path: string }) => {
      try {
        const content = await fs.readFile(args.path, 'utf-8');
        return { success: true, content };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },
  
  write_file: {
    description: 'Écrit du contenu dans un fichier',
    schema: { 
      path: z.string().describe('Chemin du fichier'),
      content: z.string().describe('Contenu à écrire')
    },
    handler: async (args: { path: string; content: string }) => {
      try {
        await fs.writeFile(args.path, args.content);
        return { success: true, message: `Fichier écrit: ${args.path}` };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },
  
  list_directory: {
    description: 'Liste le contenu d\'un répertoire',
    schema: { 
      path: z.string().default('/home/lalpha').describe('Chemin du répertoire'),
      recursive: z.boolean().default(false).describe('Lister récursivement')
    },
    handler: async (args: { path: string; recursive?: boolean }) => {
      try {
        const targetPath = args.path || '/home/lalpha';
        const entries = await fs.readdir(targetPath, { withFileTypes: true });
        const result = entries.map(e => ({
          name: e.name,
          type: e.isDirectory() ? 'directory' : 'file'
        }));
        return { success: true, entries: result };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },
  
  delete_file: {
    description: 'Supprime un fichier ou répertoire',
    schema: { path: z.string().describe('Chemin à supprimer') },
    handler: async (args: { path: string }) => {
      try {
        await fs.rm(args.path, { recursive: true });
        return { success: true, message: `Supprimé: ${args.path}` };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },
  
  copy_file: {
    description: 'Copie un fichier',
    schema: { 
      source: z.string().describe('Fichier source'),
      destination: z.string().describe('Destination')
    },
    handler: async (args: { source: string; destination: string }) => {
      try {
        await fs.copyFile(args.source, args.destination);
        return { success: true, message: `Copié: ${args.source} → ${args.destination}` };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },
  
  find_file: {
    description: 'Recherche des fichiers par nom',
    schema: { 
      pattern: z.string().describe('Pattern de recherche'),
      directory: z.string().default('/home/lalpha').describe('Répertoire de recherche')
    },
    handler: async (args: { pattern: string; directory: string }) => {
      const dir = args.directory || '/home/lalpha';
      const result = await safeExec(`find ${dir} -name "*${args.pattern}*" -type f 2>/dev/null | head -20`);
      return { success: result.success, files: result.stdout.split('\n').filter(f => f) };
    }
  },
  
  file_info: {
    description: 'Informations détaillées sur un fichier',
    schema: { path: z.string().describe('Chemin du fichier') },
    handler: async (args: { path: string }) => {
      try {
        const stat = await fs.stat(args.path);
        return {
          success: true,
          info: {
            size: stat.size,
            created: stat.birthtime,
            modified: stat.mtime,
            isDirectory: stat.isDirectory(),
            permissions: stat.mode.toString(8)
          }
        };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    }
  },

  // --- DOCKER (6 outils) ---
  docker_list: {
    description: 'Liste les conteneurs Docker',
    schema: { all: z.boolean().default(false).describe('Inclure les arrêtés') },
    handler: async (args: { all?: boolean }) => {
      const cmd = args.all ? 'docker ps -a --format "{{.Names}}\\t{{.Status}}\\t{{.Ports}}"' 
                           : 'docker ps --format "{{.Names}}\\t{{.Status}}\\t{{.Ports}}"';
      const result = await safeExec(cmd);
      return { success: result.success, containers: result.stdout };
    }
  },
  
  docker_logs: {
    description: 'Affiche les logs d\'un conteneur',
    schema: { 
      container: z.string().describe('Nom du conteneur'),
      lines: z.number().default(50).describe('Nombre de lignes')
    },
    handler: async (args: { container: string; lines?: number }) => {
      const lines = args.lines || 50;
      const result = await safeExec(`docker logs --tail ${lines} ${args.container} 2>&1`);
      return { success: result.success, logs: result.stdout || result.stderr };
    }
  },
  
  docker_restart: {
    description: 'Redémarre un conteneur Docker',
    schema: { container: z.string().describe('Nom du conteneur') },
    handler: async (args: { container: string }) => {
      const result = await safeExec(`docker restart ${args.container}`);
      return { success: result.success, message: result.stdout || result.stderr };
    }
  },
  
  docker_stop: {
    description: 'Arrête un conteneur Docker',
    schema: { container: z.string().describe('Nom du conteneur') },
    handler: async (args: { container: string }) => {
      const result = await safeExec(`docker stop ${args.container}`);
      return { success: result.success, message: result.stdout || result.stderr };
    }
  },
  
  docker_start: {
    description: 'Démarre un conteneur Docker',
    schema: { container: z.string().describe('Nom du conteneur') },
    handler: async (args: { container: string }) => {
      const result = await safeExec(`docker start ${args.container}`);
      return { success: result.success, message: result.stdout || result.stderr };
    }
  },
  
  docker_exec: {
    description: 'Exécute une commande dans un conteneur',
    schema: { 
      container: z.string().describe('Nom du conteneur'),
      command: z.string().describe('Commande à exécuter')
    },
    handler: async (args: { container: string; command: string }) => {
      const result = await safeExec(`docker exec ${args.container} ${args.command}`);
      return { success: result.success, output: result.stdout || result.stderr };
    }
  },

  // --- SYSTÈME (6 outils) ---
  system_info: {
    description: 'Informations complètes du système',
    schema: {},
    handler: async () => {
      const [hostname, uptime, loadavg] = await Promise.all([
        safeExec('hostname'),
        safeExec('uptime -p'),
        safeExec('cat /proc/loadavg')
      ]);
      return {
        success: true,
        info: {
          hostname: hostname.stdout,
          os: `${os.type()} ${os.release()}`,
          arch: os.arch(),
          cpus: os.cpus().length,
          totalMemory: `${Math.round(os.totalmem() / 1024 / 1024 / 1024)} GB`,
          freeMemory: `${Math.round(os.freemem() / 1024 / 1024 / 1024)} GB`,
          uptime: uptime.stdout,
          loadAvg: loadavg.stdout
        }
      };
    }
  },
  
  disk_usage: {
    description: 'Utilisation des disques',
    schema: {},
    handler: async () => {
      const result = await safeExec('df -h --output=source,size,used,avail,pcent,target | grep -v tmpfs');
      return { success: result.success, disks: result.stdout };
    }
  },
  
  memory_info: {
    description: 'Informations mémoire détaillées',
    schema: {},
    handler: async () => {
      const result = await safeExec('free -h');
      return { success: result.success, memory: result.stdout };
    }
  },
  
  cpu_info: {
    description: 'Informations CPU et charge',
    schema: {},
    handler: async () => {
      const [cpu, top] = await Promise.all([
        safeExec('lscpu | head -20'),
        safeExec('top -bn1 | head -5')
      ]);
      return { success: true, cpu: cpu.stdout, load: top.stdout };
    }
  },
  
  process_list: {
    description: 'Liste des processus actifs',
    schema: { limit: z.number().default(20).describe('Nombre de processus') },
    handler: async (args: { limit?: number }) => {
      const limit = args.limit || 20;
      const result = await safeExec(`ps aux --sort=-%mem | head -${limit + 1}`);
      return { success: result.success, processes: result.stdout };
    }
  },
  
  run_command: {
    description: 'Exécute une commande shell',
    schema: { 
      command: z.string().describe('Commande à exécuter'),
      timeout: z.number().default(30000).describe('Timeout en ms')
    },
    handler: async (args: { command: string; timeout?: number }) => {
      const timeout = args.timeout || 30000;
      const result = await safeExec(args.command, timeout);
      return { success: result.success, output: result.stdout, error: result.stderr };
    }
  },

  // --- LOGS (4 outils) ---
  analyze_logs: {
    description: 'Analyse les logs d\'un service',
    schema: { 
      service: z.string().describe('Service (fail2ban, nginx, syslog, auth, docker)'),
      lines: z.number().default(100).describe('Nombre de lignes')
    },
    handler: async (args: { service: string; lines?: number }) => {
      const lines = args.lines || 100;
      const logPaths: Record<string, string> = {
        fail2ban: '/var/log/fail2ban.log',
        nginx: '/var/log/nginx/access.log',
        syslog: '/var/log/syslog',
        auth: '/var/log/auth.log',
        docker: ''
      };
      
      if (args.service === 'docker') {
        const result = await safeExec(`journalctl -u docker --no-pager -n ${lines}`);
        return { success: result.success, logs: result.stdout };
      }
      
      const logPath = logPaths[args.service];
      if (!logPath) {
        return { success: false, error: `Service inconnu: ${args.service}` };
      }
      
      const result = await safeExec(`tail -n ${lines} ${logPath} 2>/dev/null || echo "Log non accessible"`);
      return { success: result.success, logs: result.stdout };
    }
  },
  
  tail_log: {
    description: 'Affiche les dernières lignes d\'un fichier log',
    schema: { 
      path: z.string().describe('Chemin du fichier log'),
      lines: z.number().default(50).describe('Nombre de lignes')
    },
    handler: async (args: { path: string; lines?: number }) => {
      const lines = args.lines || 50;
      const result = await safeExec(`tail -n ${lines} ${args.path}`);
      return { success: result.success, content: result.stdout };
    }
  },
  
  search_logs: {
    description: 'Recherche dans les logs',
    schema: { 
      pattern: z.string().describe('Pattern à rechercher'),
      path: z.string().default('/var/log/syslog').describe('Fichier log')
    },
    handler: async (args: { pattern: string; path?: string }) => {
      const logPath = args.path || '/var/log/syslog';
      const result = await safeExec(`grep -i "${args.pattern}" ${logPath} | tail -50`);
      return { success: result.success, matches: result.stdout };
    }
  },
  
  journalctl: {
    description: 'Consulte les logs systemd',
    schema: { 
      unit: z.string().optional().describe('Unité systemd'),
      lines: z.number().default(50).describe('Nombre de lignes')
    },
    handler: async (args: { unit?: string; lines?: number }) => {
      const lines = args.lines || 50;
      const cmd = args.unit 
        ? `journalctl -u ${args.unit} --no-pager -n ${lines}`
        : `journalctl --no-pager -n ${lines}`;
      const result = await safeExec(cmd);
      return { success: result.success, logs: result.stdout };
    }
  },

  // --- RÉSEAU (4 outils) ---
  network_info: {
    description: 'Informations réseau',
    schema: {},
    handler: async () => {
      const [ip, ports] = await Promise.all([
        safeExec('ip -4 addr show | grep inet'),
        safeExec('ss -tlnp | head -20')
      ]);
      return { success: true, addresses: ip.stdout, listening: ports.stdout };
    }
  },
  
  check_port: {
    description: 'Vérifie si un port est ouvert',
    schema: { port: z.number().describe('Numéro de port') },
    handler: async (args: { port: number }) => {
      const result = await safeExec(`ss -tlnp | grep :${args.port}`);
      return { 
        success: true, 
        open: result.stdout.length > 0,
        details: result.stdout || 'Port fermé'
      };
    }
  },
  
  ping_host: {
    description: 'Ping un hôte',
    schema: { 
      host: z.string().describe('Hôte à pinger'),
      count: z.number().default(3).describe('Nombre de pings')
    },
    handler: async (args: { host: string; count?: number }) => {
      const count = args.count || 3;
      const result = await safeExec(`ping -c ${count} ${args.host}`, 10000);
      return { success: result.success, result: result.stdout || result.stderr };
    }
  },
  
  dns_lookup: {
    description: 'Résolution DNS',
    schema: { domain: z.string().describe('Domaine à résoudre') },
    handler: async (args: { domain: string }) => {
      const result = await safeExec(`dig +short ${args.domain}`);
      return { success: result.success, addresses: result.stdout };
    }
  },

  // --- SÉCURITÉ (2 outils) ---
  fail2ban_status: {
    description: 'Statut de Fail2Ban',
    schema: {},
    handler: async () => {
      const result = await safeExec('fail2ban-client status 2>/dev/null || echo "Fail2Ban non installé"');
      return { success: result.success, status: result.stdout };
    }
  },
  
  firewall_status: {
    description: 'Statut du firewall UFW',
    schema: {},
    handler: async () => {
      const result = await safeExec('ufw status verbose 2>/dev/null || echo "UFW non disponible"');
      return { success: result.success, status: result.stdout };
    }
  },

  // --- SERVICES (2 outils) ---
  service_status: {
    description: 'Statut d\'un service systemd',
    schema: { service: z.string().describe('Nom du service') },
    handler: async (args: { service: string }) => {
      const result = await safeExec(`systemctl status ${args.service} --no-pager 2>&1 | head -20`);
      return { success: result.success, status: result.stdout };
    }
  },
  
  service_restart: {
    description: 'Redémarre un service systemd',
    schema: { service: z.string().describe('Nom du service') },
    handler: async (args: { service: string }) => {
      const result = await safeExec(`systemctl restart ${args.service}`);
      return { success: result.success, message: result.stdout || `Service ${args.service} redémarré` };
    }
  }
};

// Compte total
const TOOL_COUNT = Object.keys(TOOLS).length;

// ============================================
// API REST - FORMAT OPEN WEBUI COMPATIBLE
// ============================================

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    server: 'mcp-server-intelligent',
    version: '4.1.0',
    tools: TOOL_COUNT,
    timestamp: new Date().toISOString()
  });
});

// Liste des outils (format OpenAI-like pour Open WebUI)
app.get('/api/tools', (req: Request, res: Response) => {
  const tools = Object.entries(TOOLS).map(([name, tool]) => ({
    name,
    description: tool.description
  }));
  res.json({ success: true, count: tools.length, tools });
});

// ============ ENDPOINTS OPEN WEBUI MCP NATIF ============

// GET /api/tool/{name} - Open WebUI appelle ce format
app.get('/api/tool/:name', async (req: Request, res: Response) => {
  const toolName = req.params.name;
  
  if (!TOOLS[toolName]) {
    return res.status(404).json({ 
      error: `Outil inconnu: ${toolName}`,
      available: Object.keys(TOOLS)
    });
  }
  
  try {
    const result = await TOOLS[toolName].handler({});
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/tool/{name} - Avec paramètres
app.post('/api/tool/:name', async (req: Request, res: Response) => {
  const toolName = req.params.name;
  
  if (!TOOLS[toolName]) {
    return res.status(404).json({ 
      error: `Outil inconnu: ${toolName}`,
      available: Object.keys(TOOLS)
    });
  }
  
  try {
    const result = await TOOLS[toolName].handler(req.body || {});
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ============ ENDPOINT ORIGINAL ============

// POST /api/tools/execute - Format original
app.post('/api/tools/execute', async (req: Request, res: Response) => {
  const { tool, arguments: args } = req.body;
  
  if (!tool || !TOOLS[tool]) {
    return res.status(400).json({ 
      success: false, 
      error: `Outil inconnu: ${tool}. Outils disponibles: ${Object.keys(TOOLS).join(', ')}`
    });
  }
  
  try {
    const result = await TOOLS[tool].handler(args || {});
    res.json({ success: true, result });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ ENDPOINTS LEGACY ============

app.get('/api/docker/containers', async (req, res) => {
  const all = req.query.all === 'true';
  const result = await TOOLS.docker_list.handler({ all });
  res.json({ success: true, data: result.containers });
});

app.get('/api/system/info', async (req, res) => {
  const result = await TOOLS.system_info.handler();
  res.json({ success: true, data: result.info });
});

app.get('/api/system/resources', async (req, res) => {
  const [mem, disk] = await Promise.all([
    TOOLS.memory_info.handler(),
    TOOLS.disk_usage.handler()
  ]);
  res.json({ success: true, data: { memory: mem.memory, disk: disk.disks } });
});

// ============================================
// MCP PROTOCOL (pour Claude Desktop)
// ============================================
for (const [name, tool] of Object.entries(TOOLS)) {
  mcpServer.tool(
    name,
    tool.description,
    tool.schema,
    async (args: any) => {
      const result = await tool.handler(args);
      return {
        content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }]
      };
    }
  );
}

// ============================================
// DÉMARRAGE
// ============================================
app.listen(PORT, () => {
  console.log(`🚀 MCP Server Intelligent v4.1 démarré sur port ${PORT}`);
  console.log(`📊 ${TOOL_COUNT} outils disponibles`);
  console.log(`🔧 Endpoints:`);
  console.log(`   - GET  /health`);
  console.log(`   - GET  /api/tools`);
  console.log(`   - GET  /api/tool/:name     (Open WebUI MCP)`);
  console.log(`   - POST /api/tool/:name     (Open WebUI MCP)`);
  console.log(`   - POST /api/tools/execute  (Original)`);
});

// Mode stdio pour Claude Desktop
if (process.argv.includes('--stdio')) {
  const transport = new StdioServerTransport();
  mcpServer.connect(transport);
}
