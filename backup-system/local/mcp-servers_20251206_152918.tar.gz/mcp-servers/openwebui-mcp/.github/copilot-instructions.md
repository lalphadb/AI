# MCP Server Admin - Instructions pour Agents IA

## Vue d'ensemble du projet

Il s'agit d'un **serveur MCP (Model Context Protocol) intelligent** pour l'administration système Linux, intégré avec Open WebUI. Le serveur fournit plus de 25 outils pour la surveillance système, la gestion Docker, les opérations sur fichiers et des diagnostics intelligents avec mémoire persistante.

**Architecture :** Serveur MCP TypeScript → Conteneur Docker → Intégration Open WebUI via endpoints HTTP/REST

## Composants principaux

### 1. Serveur principal (`src/index.ts`)
- **Support dual-protocole :** MCP natif via stdio + API HTTP/REST (port 3000)
- **Endpoints Express** pour compatibilité Open WebUI (`/mcp`, `/api/*`, `/health`)
- **Pattern de gestionnaires d'outils :** Chaque outil a une méthode privée (ex: `runCommand()`, `diagnoseSystem()`)
- **Gestionnaires :** `setupToolHandlers()` (MCP stdio), `setupHttpRoutes()` (REST), `setupRequestHandlers()` (init)

### 2. Couche d'intelligence (`src/intelligence/`)
- **`memory.ts`** : Mémoire persistante basée sur SQLite à `/tmp/memory.db` - stocke actions, apprentissages, conversations
- **`agent.ts`** : Prise de décision autonome - analyse les problèmes, génère des actions, exécute des auto-diagnostics toutes les 5 min
- **`webgen.ts`** : Crée des services web (sites statiques, APIs, apps Next.js) avec Dockerisation automatique
- **`codegen.ts`** : Génère du code TypeScript/Python/Bash à partir de descriptions en langage naturel

### 3. Déploiement & Intégration
- **Docker** : Fonctionne sur le réseau `traefik-net` avec accès au système de fichiers hôte (`/:/host:ro`) et montage socket Docker
- **Mode privilégié** : Requis pour l'administration système (PID host, flag privileged, accès Docker)
- **Open WebUI** : S'intègre via le système Function (`openwebui-function-mcp.py`) en appelant les endpoints REST

## Workflows de développement

### Build & Déploiement
```bash
npm run build          # Compiler TypeScript vers dist/
npm start              # Lancer le serveur production
npm run dev            # Développement avec rechargement tsx
./deploy.sh            # Script de déploiement complet
./redeploy-mcp.sh      # Reconstruction et redémarrage Docker
```

### Tests
```bash
curl http://localhost:3000/health                    # Vérification santé
./test-mcp-integration.sh                            # Test d'intégration complet
curl -X POST http://localhost:3000/api/diagnose     # Tester endpoint REST
```

### Logs & Débogage
- Logs serveur : `mcp-server.log` à la racine du projet
- Logs conteneur : `docker logs mcp-server -f`
- Base de données mémoire : `/tmp/memory.db` (dans le conteneur)

## Patterns et conventions critiques

### Format de réponse des outils
**Tous les outils doivent retourner :**
```typescript
{
  content: [
    { type: "text", text: "chaîne de résultat formatée" }
  ]
}
```

### Pattern des endpoints HTTP
Chaque outil a un endpoint REST correspondant dans `setupHttpRoutes()` :
- Outil MCP : `diagnoseSystem(args)`
- REST : `POST /api/system/diagnose` → appelle `diagnoseSystem({})`
- Fonction Open WebUI : Wrapper Python appelant l'endpoint REST

### Accès au système de fichiers
- **Système de fichiers hôte :** Monté à `/host` (lecture seule)
- **Logs :** Accès via `/host/var/log/...`
- **Code généré :** Stocké dans `/home/lalpha/generated-code/`
- **Base de données mémoire :** `/tmp/memory.db` (écriture, scope conteneur)

### Utilisation du socket Docker
Le conteneur accède au Docker hôte via montage socket :
```dockerfile
-v /var/run/docker.sock:/var/run/docker.sock
```
Ceci permet les opérations Docker-in-Docker (lister conteneurs, créer services, etc.)

### Gestion des erreurs
Toujours envelopper les commandes externes dans try-catch :
```typescript
try {
  const { stdout, stderr } = await execAsync(command);
  return { content: [{ type: "text", text: stdout }] };
} catch (error: any) {
  return { content: [{ type: "text", text: `Erreur: ${error.message}` }] };
}
```

## Tâches courantes

### Ajouter un nouvel outil
1. Définir le schéma dans `handleListTools()` (gestionnaire HTTP) et `setupToolHandlers()` (gestionnaire MCP)
2. Créer une méthode privée : `private async monNouvelOutil(args: any) { ... }`
3. Ajouter un cas dans `handleCallTool()` (HTTP) et le gestionnaire CallToolRequestSchema (MCP)
4. Ajouter un endpoint REST dans `setupHttpRoutes()` si nécessaire
5. Mettre à jour la fonction Open WebUI (`openwebui-function-mcp.py`) si public

### Modifier les systèmes d'intelligence
- **Mémoire :** Étendre le schéma dans `memory.ts` → ajouter des tables via SQL dans `initializeDatabase()`
- **Agent :** Ajouter des patterns de problèmes dans `generateActions()` → nouvelle logique de détection dans `detectProblems()`
- **Génération de code :** Ajouter des templates dans `codegen.ts` → correspondance de patterns dans `generateCode()`

### Intégration réseau Docker
Les services créés par `WebServiceGenerator` rejoignent automatiquement `traefik-net` :
```typescript
--network traefik-net
```
Ceci permet l'intégration avec le reverse proxy Traefik et la découverte de services.

## Organisation des fichiers

```
src/
├── index.ts                 # Serveur principal, routes HTTP, gestionnaires d'outils
└── intelligence/
    ├── memory.ts            # Système de mémoire SQLite
    ├── agent.ts             # Prise de décision, auto-diagnostics
    ├── webgen.ts            # Générateur de services web
    └── codegen.ts           # Génération de code depuis descriptions

dist/                        # JavaScript compilé (gitignored)
logs/                        # Logs d'exécution
*.sh                         # Scripts de déploiement
*-GUIDE.md, *-FEATURES.md    # Documentation
openwebui-function-mcp.py    # Intégration Open WebUI
Dockerfile                   # Alpine + Node + Docker CLI
```

## Points d'intégration

### Pont de fonctions Open WebUI
Les fonctions Python dans `openwebui-function-mcp.py` appellent les endpoints REST :
```python
def read_file(self, path: str) -> str:
    response = requests.post(f"{MCP_SERVER_URL}/api/files/read", json={"path": path})
```

### Configuration MCP
Pour les clients MCP : `mcp-config.json` spécifie le mode stdio :
```json
{
  "command": "node",
  "args": ["/path/to/dist/index.js"]
}
```

### Système d'auto-diagnostic
Le monitoring en arrière-plan démarre dans le constructeur :
```typescript
this.startBackgroundMonitoring(); // Exécute agent.runAutoDiagnostic() toutes les 5 min
```

## Notes spécifiques au projet

- **Langue française :** Les messages utilisateur sont en français (ex : "✅ Serveur MCP Admin prêt")
- **Spécifique Linux :** Les commandes supposent un environnement Linux (systemctl, df, docker, /proc, /var/log)
- **Sécurité :** Le serveur s'exécute en mode privilégié - destiné uniquement aux environnements de confiance
- **Port 3000 :** Codé en dur à plusieurs endroits (serveur, config Open WebUI, vérifications de santé)

## Dépendances

**Principales :**
- `@modelcontextprotocol/sdk` : Implémentation du protocole MCP
- `express` : Serveur HTTP pour l'API REST
- `better-sqlite3` : Base de données pour mémoire persistante

**Système :**
- Docker CLI dans le conteneur
- Accès au système de fichiers hôte
- Services systemd (via l'hôte)