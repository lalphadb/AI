# 🎯 Guide Rapide - Nouveaux Outils MCP v2.0

## 1. 🧠 Mémoriser une information

**Outil:** `remember`

**Quand l'utiliser:**
- Sauvegarder des configurations importantes
- Mémoriser des IPs, ports, URLs
- Garder une trace de décisions techniques

**Exemple:**
```
remember
{
  "key": "api-production",
  "value": "https://api.monsite.com:8443",
  "context": "API principale en production"
}
```

## 2. 🔍 Rappeler une information

**Outil:** `recall`

**Quand l'utiliser:**
- Retrouver des informations sauvegardées
- Consulter l'historique des décisions
- Rechercher des configurations

**Exemple:**
```
recall
{
  "query": "api production"
}
```

## 3. 🌐 Créer un Service Web

**Outil:** `create_web_service`

**Types disponibles:**
- `static` : Site web vitrine
- `api` : API REST  
- `fullstack` : Application complète
- `proxy` : Reverse proxy

**Exemple - Site statique:**
```
create_web_service
{
  "name": "mon-portfolio",
  "type": "static",
  "port": 8080,
  "domain": "portfolio.com"
}
```

**Exemple - API:**
```
create_web_service
{
  "name": "api-users",
  "type": "api",
  "port": 3001
}
```

## 4. 💻 Générer du Code

**Outil:** `generate_code`

**Types de code:**
- `function` : Fonctions
- `class` : Classes complètes
- `script` : Scripts bash/python
- `component` : Composants React
- `config` : Fichiers de configuration

**Exemple - Fonction API:**
```
generate_code
{
  "description": "fonction pour récupérer des utilisateurs depuis une API",
  "language": "typescript",
  "type": "function",
  "save": true,
  "filename": "fetch-users.ts"
}
```

**Exemple - Script Python:**
```
generate_code
{
  "description": "script pour backup automatique de fichiers",
  "language": "python",
  "type": "script",
  "save": true,
  "filename": "backup.py"
}
```

**Exemple - Composant React:**
```
generate_code
{
  "description": "composant pour afficher une liste d'utilisateurs",
  "language": "typescript",
  "type": "component",
  "save": true,
  "filename": "UserList.tsx"
}
```

## 5. 🤖 Analyse Intelligente

**Outil:** `intelligent_analysis`

**Quand l'utiliser:**
- Problème complexe nécessitant une analyse
- Besoin de recommandations d'actions
- Recherche de solutions déjà apprises

**Exemple:**
```
intelligent_analysis
{
  "problem": "Mon application Node.js crash après 10 minutes",
  "context": "Logs montrent 'Out of memory'"
}
```

**Résultat:**
- Analyse détaillée du problème
- Actions recommandées (avec niveau de risque)
- Solutions déjà connues (si disponibles)
- Niveau de confiance de l'analyse

## 🎨 Scénarios d'Usage Complets

### Scénario 1: Créer un Portfolio

```bash
# 1. Créer le site
Appel: create_web_service
{
  "name": "portfolio-john",
  "type": "static",
  "port": 8080
}

# 2. Mémoriser
Appel: remember
{
  "key": "portfolio-john",
  "value": "Site portfolio sur port 8080",
  "context": "Créé le 19/01/2025"
}
```

### Scénario 2: API Complète

```bash
# 1. Créer l'API
Appel: create_web_service
{
  "name": "api-blog",
  "type": "api",
  "port": 3000
}

# 2. Générer le code des fonctions
Appel: generate_code
{
  "description": "fonction pour gérer les articles de blog avec CRUD",
  "language": "typescript",
  "type": "class",
  "save": true,
  "filename": "ArticleManager.ts"
}

# 3. Mémoriser
Appel: remember
{
  "key": "api-blog",
  "value": "API REST sur port 3000 avec ArticleManager",
  "context": "Gestion CRUD des articles"
}
```

### Scénario 3: Résolution de Problème

```bash
# 1. Analyser le problème
Appel: intelligent_analysis
{
  "problem": "Conteneur Docker redémarre en boucle",
  "context": "Service Nginx, erreur ECONNREFUSED"
}

# 2. Le système propose des actions
# 3. Appliquer la solution
Appel: run_command
{
  "command": "docker network inspect mon-network"
}

# 4. Mémoriser la solution
Appel: remember
{
  "key": "fix-nginx-restart",
  "value": "Vérifier que le backend est sur le même réseau Docker",
  "context": "Solution pour ECONNREFUSED"
}
```

## 💡 Conseils d'Utilisation

### Mémoire
- **Utilisez des clés descriptives** : `serveur-prod-nginx` plutôt que `srv1`
- **Ajoutez du contexte** : Ça aide pour les recherches futures
- **Pensez à mémoriser** : Configurations, IPs, décisions importantes

### Génération de Code
- **Soyez précis** dans la description
- **Mentionnez les technologies** : "avec Express.js", "utilisant React Hooks"
- **Sauvegardez le code** utile avec `save: true`

### Services Web
- **Choisissez le bon type** :
  - Site vitrine → `static`
  - API backend → `api`
  - App moderne → `fullstack`
  - Load balancer → `proxy`

### Analyse Intelligente
- **Donnez du contexte** : Plus il y en a, meilleure sera l'analyse
- **Consultez les solutions** apprises : Le système s'améliore avec le temps
- **Vérifiez le niveau de confiance** avant d'agir

## 🚀 Résultat Final

Avec ces outils, vous pouvez :

✅ **Créer** un site web en 30 secondes  
✅ **Générer** du code fonctionnel instantanément  
✅ **Mémoriser** toutes vos configurations importantes  
✅ **Résoudre** des problèmes complexes avec aide intelligente  
✅ **Apprendre** et améliorer le système au fil du temps  

Le serveur MCP devient votre **assistant DevOps personnel** ! 🎉
