# 🧠 Système d'Apprentissage Intelligent du MCP

## 📚 Vue d'ensemble

Le MCP possède **3 systèmes d'apprentissage** qui lui permettent de devenir plus intelligent avec le temps :

### 1. 🗄️ Mémoire Persistante (SQLite)

**Fichier**: `/tmp/memory.db`

#### Tables de données

##### `memories` - Historique complet

```sql
- id, timestamp, type, content, context, result, tags
- Stocke toutes les actions, commandes, décisions
```

##### `learnings` - Patterns appris

```sql
- pattern, solution, success_count, confidence
- Enregistre ce qui fonctionne et augmente la confiance
```

##### `conversations` - Historique des dialogues

```sql
- session_id, user_message, assistant_response, timestamp
- Garde le contexte des conversations
```

##### `system_state` - État du système

```sql
- key, value, updated_at
- Stocke les préférences et configurations
```

---

## 🎯 Comment le système apprend

### 1️⃣ Apprentissage par Pattern Matching

Quand vous exécutez une commande via le MCP :

```typescript
// L'outil est appelé
analyze_logs(service: "fail2ban")

// ✅ Si succès → le pattern est enregistré
memory.learn(
  pattern: "analyze fail2ban logs",
  solution: "tail -n 100 /var/log/fail2ban.log"
)

// 📊 Confiance initiale : 60%
// 📈 Chaque succès : +10% (max 100%)
```

**Prochaine fois que vous demandez la même chose** :

- Le MCP trouve la solution apprise
- Confiance = 70% (si 1 succès précédent)
- Exécution plus rapide et plus sûre

---

### 2️⃣ Apprentissage par Reconnaissance de Problèmes

Le MCP détecte automatiquement les problèmes récurrents :

```typescript
Problème détecté: "Disque plein (92% utilisé)"

Étape 1: Cherche dans memories les cas similaires
Étape 2: Trouve 3 cas passés avec "disque plein"
Étape 3: Récupère les solutions qui ont fonctionné
Étape 4: Propose les actions triées par taux de succès

Actions proposées (par ordre de confiance):
  1. Nettoyer Docker (85% succès, 12 fois)
  2. Supprimer logs anciens (90% succès, 8 fois)
  3. Vider /tmp (95% succès, 15 fois)
```

---

### 3️⃣ Auto-diagnostic et Auto-correction

Le MCP surveille le système **en arrière-plan** :

```typescript
Toutes les 5 minutes:
  ✓ Vérifie charge CPU
  ✓ Vérifie mémoire disponible
  ✓ Vérifie espace disque
  ✓ Vérifie services systemd
  ✓ Vérifie conteneurs Docker

Si problème détecté (risque = low):
  → Exécution automatique de la correction
  → Enregistrement du résultat
  → Apprentissage du pattern

Si problème détecté (risque = medium/high):
  → Proposition d'action à l'utilisateur
  → Attente d'approbation
```

---

## 🚀 Utilisation des outils d'apprentissage

### Outil `remember` - Mémoriser manuellement

Enregistre une information importante :

```json
{
  "name": "remember",
  "arguments": {
    "key": "backup_schedule",
    "value": "Tous les jours à 2h du matin",
    "context": "Configuration serveur principal"
  }
}
```

**Résultat** : Stocké dans `system_state` → disponible pour toujours

---

### Outil `recall` - Rappeler des infos

Retrouve une information mémorisée :

```json
{
  "name": "recall",
  "arguments": {
    "query": "backup"
  }
}
```

**Résultat** :

```
🔍 Trouvé dans la mémoire:
  • backup_schedule: "Tous les jours à 2h du matin"
  • dernière sauvegarde: "2025-11-14 02:00"
  • taille backup: "4.2 GB"
```

---

### Outil `intelligent_analysis` - Analyse intelligente

Analyse un problème avec l'historique :

```json
{
  "name": "intelligent_analysis",
  "arguments": {
    "problem": "Le serveur est lent depuis ce matin",
    "context": "Charge CPU à 85%"
  }
}
```

**Le MCP va** :

1. Chercher les fois où le serveur était lent
2. Identifier les causes communes (mémoire, disque, réseau)
3. Proposer les solutions qui ont fonctionné
4. Estimer la confiance pour chaque solution

---

## 📊 Statistiques d'apprentissage

### Consulter les stats via terminal

```bash
docker exec mcp-server node -e "
const db = require('better-sqlite3')('/tmp/memory.db');

console.log('📊 Statistiques MCP:');
console.log('Mémoires totales:', db.prepare('SELECT COUNT(*) as c FROM memories').get().c);
console.log('Patterns appris:', db.prepare('SELECT COUNT(*) as c FROM learnings').get().c);
console.log('Conversations:', db.prepare('SELECT COUNT(*) as c FROM conversations').get().c);

console.log('\n🎓 Top 5 patterns appris:');
db.prepare('SELECT pattern, success_count, confidence FROM learnings ORDER BY confidence DESC LIMIT 5')
  .all()
  .forEach(l => console.log(`  • ${l.pattern} (${(l.confidence*100).toFixed(0)}% confiance, ${l.success_count} succès)`));
"
```

---

## 🔄 Cycle d'apprentissage complet

### Exemple : Problème "Service fail2ban arrêté"

#### 1️⃣ **Première fois** (pas d'apprentissage)

```
Utilisateur: "Le service fail2ban ne fonctionne pas"

MCP:
  ✓ Analyse le problème
  ✓ Vérifie le statut du service
  ✓ Détecte: service inactif
  ✓ Propose: systemctl restart fail2ban
  ✓ Exécute (avec approbation)
  ✓ Enregistre: pattern="fail2ban arrêté" → solution="restart"
  
Confiance: 60% (nouveau pattern)
```

#### 2️⃣ **Deuxième fois** (apprentissage commence)

```
Utilisateur: "fail2ban est down encore"

MCP:
  ✓ Reconnaît le pattern similaire
  ✓ Trouve la solution apprise
  ✓ Confiance: 70% (1 succès précédent)
  ✓ Exécute automatiquement (confiance > 60%)
  ✓ Met à jour: success_count++, confidence += 10%
  
Confiance: 80%
```

#### 3️⃣ **Cinquième fois** (expert)

```
Utilisateur: "fail2ban problem"

MCP:
  ✓ Détection instantanée du pattern
  ✓ Confiance: 100% (4+ succès)
  ✓ Exécution automatique immédiate
  ✓ Ajoute: suggestion préventive (vérifier les logs)
  
Confiance: 100% (maximum)
```

---

## 🧪 Tester l'apprentissage

### Test 1 : Créer un apprentissage manuel

Dans Open WebUI, demandez :

```
Mémorise que le serveur de production est à l'IP 10.10.10.46
```

**Le MCP va utiliser** :

```json
{
  "name": "remember",
  "arguments": {
    "key": "serveur_production_ip",
    "value": "10.10.10.46"
  }
}
```

### Test 2 : Rappeler l'info

Ensuite demandez :

```
Quel est l'IP du serveur de production ?
```

**Le MCP va utiliser** :

```json
{
  "name": "recall",
  "arguments": {
    "query": "serveur production"
  }
}
```

**Résultat** : `10.10.10.46` (récupéré de la mémoire SQLite)

---

### Test 3 : Apprentissage par répétition

**Jour 1** :

```
Analyse les logs fail2ban et dis-moi ce qui a été bloqué
```

→ MCP exécute et mémorise le pattern

**Jour 2** :

```
Montre-moi les IPs bannies par fail2ban
```

→ MCP reconnaît le pattern similaire
→ Utilise la solution apprise (plus rapide)

**Jour 7** :

```
fail2ban blocks
```

→ MCP comprend immédiatement (pattern appris à 100%)
→ Réponse instantanée avec suggestion proactive

---

## 🎯 Conseils pour maximiser l'apprentissage

### ✅ Bonnes pratiques

1. **Soyez consistant** dans vos demandes
   - "Vérifie les logs fail2ban" → pattern reconnaissable
   - Évitez de reformuler complètement à chaque fois

2. **Utilisez `remember` pour les infos importantes**

   ```
   Mémorise que le backup est à 2h du matin
   Mémorise que le serveur principal s'appelle prod-1
   ```

3. **Laissez le MCP corriger les problèmes automatiquement**
   - Les actions `low risk` s'exécutent seules
   - Elles sont enregistrées et améliorent l'apprentissage

4. **Exploitez `intelligent_analysis` pour les problèmes complexes**

   ```
   Analyse pourquoi le serveur est lent depuis hier
   ```

   → Le MCP cherche dans l'historique et propose des solutions basées sur le passé

---

## 📈 Évolution de l'intelligence

### Semaine 1 : **Apprentissage de base**

- MCP enregistre toutes les commandes
- Patterns simples détectés
- Confiance moyenne : 60-70%

### Mois 1 : **Reconnaissance avancée**

- 100+ patterns appris
- Détection proactive de problèmes
- Confiance moyenne : 80-90%
- Auto-corrections fréquentes

### Mois 6 : **Expert du système**

- 500+ patterns maîtrisés
- Prédiction de problèmes avant qu'ils surviennent
- Suggestions contextuelles intelligentes
- Confiance moyenne : 95%+

---

## 🔍 Vérifier l'apprentissage en temps réel

### Via l'API MCP

```bash
# Voir les derniers apprentissages
curl -sS http://mcp-server:3000/api/system/info | jq '.memory_stats'

# Résultat exemple:
{
  "total_memories": 1247,
  "total_learnings": 89,
  "total_conversations": 156,
  "top_patterns": [
    "analyze fail2ban logs (95% conf, 23 succès)",
    "check docker status (90% conf, 18 succès)",
    "read syslog (88% conf, 15 succès)"
  ]
}
```

---

## 🚨 Réinitialiser l'apprentissage

Si vous voulez repartir de zéro :

```bash
# Supprimer la base de données
docker exec mcp-server rm /tmp/memory.db

# Redémarrer le conteneur
docker restart mcp-server

# Le MCP va recréer une base vide
```

⚠️ **Attention** : Vous perdrez tout l'historique d'apprentissage !

---

## 🎓 Résumé : Comment ça devient intelligent

1. **Enregistrement automatique** : Chaque action est sauvegardée
2. **Pattern matching** : Le MCP trouve les similitudes
3. **Renforcement** : Les succès augmentent la confiance
4. **Prédiction** : Après plusieurs répétitions, exécution automatique
5. **Suggestion proactive** : Le MCP propose des actions avant que vous demandiez

**Plus vous utilisez le MCP, plus il devient intelligent !** 🚀

---

## 📞 Questions fréquentes

### Q: Est-ce que le MCP peut faire des erreurs en apprenant ?

**R**: Oui, mais :

- Les actions à risque élevé demandent toujours confirmation
- Les échecs sont enregistrés et diminuent la confiance
- Après 2 échecs consécutifs, le pattern est mis en quarantaine

### Q: La mémoire ralentit-elle le MCP avec le temps ?

**R**: Non :

- Base SQLite optimisée avec indexes
- Nettoyage automatique des anciennes entrées (>6 mois)
- Limite de 10 000 entrées (les plus anciennes sont archivées)

### Q: Puis-je voir ce que le MCP a appris ?

**R**: Oui ! Utilisez :

```
Montre-moi ce que tu as appris récemment
```

→ Le MCP liste les patterns avec leur confiance

### Q: Comment forcer le MCP à oublier un mauvais pattern ?

**R**: Demandez :

```
Oublie le pattern "XXX"
```

→ Le MCP supprime l'entrée de la table `learnings`
