"""
title: MCP Server Admin Pro v4
author: Lalpha
version: 4.0
description: Administration système complète avec 31 outils - Fichiers, Docker, Système, Logs, Réseau, Sécurité
"""

from typing import Optional, Callable, Any, Dict
from pydantic import BaseModel, Field
import requests
import json

class Function:
    """
    Outils d'administration système avancés via le serveur MCP Intelligent v4.
    31 outils disponibles pour la gestion complète du serveur.
    """
    
    class Valves(BaseModel):
        MCP_SERVER_URL: str = Field(
            default="http://mcp-server:3000",
            description="URL du serveur MCP (interne Docker)"
        )
    
    def __init__(self):
        self.valves = self.Valves()

    def _call_tool(self, tool_name: str, args: Dict[str, Any] = None) -> str:
        """Méthode générique pour appeler n'importe quel outil MCP"""
        if args is None:
            args = {}
            
        try:
            response = requests.post(
                f"{self.valves.MCP_SERVER_URL}/api/tools/execute",
                json={"tool": tool_name, "arguments": args},
                timeout=120
            )
            
            if response.status_code != 200:
                return f"Erreur HTTP {response.status_code}: {response.text}"
                
            result = response.json()
            if result.get("success"):
                return json.dumps(result.get("result", {}), indent=2, ensure_ascii=False)
            else:
                return f"Erreur MCP: {result.get('error', 'Erreur inconnue')}"
        except Exception as e:
            return f"Erreur de connexion au serveur MCP: {str(e)}"

    # ============== FICHIERS (7 outils) ==============

    def read_file(self, path: str) -> str:
        """Lire le contenu d'un fichier."""
        return self._call_tool("read_file", {"path": path})

    def write_file(self, path: str, content: str) -> str:
        """Écrire du contenu dans un fichier."""
        return self._call_tool("write_file", {"path": path, "content": content})

    def list_directory(self, path: str = "/home/lalpha", recursive: bool = False) -> str:
        """Lister le contenu d'un répertoire."""
        return self._call_tool("list_directory", {"path": path, "recursive": recursive})

    def delete_file(self, path: str) -> str:
        """Supprimer un fichier ou répertoire."""
        return self._call_tool("delete_file", {"path": path})

    def copy_file(self, source: str, destination: str) -> str:
        """Copier un fichier."""
        return self._call_tool("copy_file", {"source": source, "destination": destination})

    def find_file(self, pattern: str, directory: str = "/home/lalpha") -> str:
        """Rechercher des fichiers par nom."""
        return self._call_tool("find_file", {"pattern": pattern, "directory": directory})

    def file_info(self, path: str) -> str:
        """Obtenir des informations détaillées sur un fichier."""
        return self._call_tool("file_info", {"path": path})

    # ============== DOCKER (6 outils) ==============

    def docker_list(self, all: bool = False) -> str:
        """Lister les conteneurs Docker."""
        return self._call_tool("docker_list", {"all": all})

    def docker_logs(self, container: str, lines: int = 50) -> str:
        """Afficher les logs d'un conteneur Docker."""
        return self._call_tool("docker_logs", {"container": container, "lines": lines})

    def docker_restart(self, container: str) -> str:
        """Redémarrer un conteneur Docker."""
        return self._call_tool("docker_restart", {"container": container})

    def docker_stop(self, container: str) -> str:
        """Arrêter un conteneur Docker."""
        return self._call_tool("docker_stop", {"container": container})

    def docker_start(self, container: str) -> str:
        """Démarrer un conteneur Docker."""
        return self._call_tool("docker_start", {"container": container})

    def docker_exec(self, container: str, command: str) -> str:
        """Exécuter une commande dans un conteneur Docker."""
        return self._call_tool("docker_exec", {"container": container, "command": command})

    # ============== SYSTÈME (6 outils) ==============

    def system_info(self) -> str:
        """Obtenir les informations complètes du système."""
        return self._call_tool("system_info", {})

    def disk_usage(self) -> str:
        """Afficher l'utilisation des disques."""
        return self._call_tool("disk_usage", {})

    def memory_info(self) -> str:
        """Afficher les informations mémoire détaillées."""
        return self._call_tool("memory_info", {})

    def cpu_info(self) -> str:
        """Afficher les informations CPU et la charge."""
        return self._call_tool("cpu_info", {})

    def process_list(self, limit: int = 20) -> str:
        """Lister les processus actifs triés par mémoire."""
        return self._call_tool("process_list", {"limit": limit})

    def run_command(self, command: str, timeout: int = 30000) -> str:
        """Exécuter une commande shell sur le serveur."""
        return self._call_tool("run_command", {"command": command, "timeout": timeout})

    # ============== LOGS (4 outils) ==============

    def analyze_logs(self, service: str, lines: int = 100) -> str:
        """Analyser les logs d'un service (fail2ban, nginx, syslog, auth, docker)."""
        return self._call_tool("analyze_logs", {"service": service, "lines": lines})

    def tail_log(self, path: str, lines: int = 50) -> str:
        """Afficher les dernières lignes d'un fichier log."""
        return self._call_tool("tail_log", {"path": path, "lines": lines})

    def search_logs(self, pattern: str, path: str = "/var/log/syslog") -> str:
        """Rechercher un pattern dans les logs."""
        return self._call_tool("search_logs", {"pattern": pattern, "path": path})

    def journalctl(self, unit: str = "", lines: int = 50) -> str:
        """Consulter les logs systemd (journalctl)."""
        return self._call_tool("journalctl", {"unit": unit, "lines": lines})

    # ============== RÉSEAU (4 outils) ==============

    def network_info(self) -> str:
        """Obtenir les informations réseau (interfaces, ports)."""
        return self._call_tool("network_info", {})

    def check_port(self, port: int) -> str:
        """Vérifier si un port est ouvert."""
        return self._call_tool("check_port", {"port": port})

    def ping_host(self, host: str, count: int = 3) -> str:
        """Ping un hôte."""
        return self._call_tool("ping_host", {"host": host, "count": count})

    def dns_lookup(self, domain: str) -> str:
        """Effectuer une résolution DNS."""
        return self._call_tool("dns_lookup", {"domain": domain})

    # ============== SÉCURITÉ (2 outils) ==============

    def fail2ban_status(self) -> str:
        """Obtenir le statut de Fail2Ban."""
        return self._call_tool("fail2ban_status", {})

    def firewall_status(self) -> str:
        """Obtenir le statut du firewall UFW."""
        return self._call_tool("firewall_status", {})

    # ============== SERVICES (2 outils) ==============

    def service_status(self, service: str) -> str:
        """Obtenir le statut d'un service systemd."""
        return self._call_tool("service_status", {"service": service})

    def service_restart(self, service: str) -> str:
        """Redémarrer un service systemd."""
        return self._call_tool("service_restart", {"service": service})
