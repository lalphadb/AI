#!/bin/bash
set -e

echo "🔗 Intégration du Serveur MCP Admin avec Open WebUI"
echo ""

# Vérifier que le serveur MCP est compilé
if [ ! -f "/home/lalpha/projets/openWebUI-mcp/dist/index.js" ]; then
    echo "❌ Le serveur MCP n'est pas compilé. Lancez d'abord:"
    echo "   cd /home/lalpha/projets/openWebUI-mcp && npm run build"
    exit 1
fi

# Vérifier qu'Open WebUI fonctionne
if ! curl -s --max-time 5 http://localhost:8080 > /dev/null; then
    echo "❌ Open WebUI n'est pas accessible sur localhost:8080"
    echo "   Vérifiez que le conteneur Open WebUI fonctionne"
    exit 1
fi

echo "✅ Open WebUI est accessible"

# Créer le répertoire de configuration MCP s'il n'existe pas
CONFIG_DIR="/home/lalpha/projets/openWebUI-mcp/mcp-integration"
mkdir -p "$CONFIG_DIR"

# Créer un script de démarrage pour le serveur MCP
cat > "$CONFIG_DIR/start-mcp-server.sh" << 'EOF'
#!/bin/bash
cd /home/lalpha/projets/openWebUI-mcp
exec node dist/index.js
EOF

chmod +x "$CONFIG_DIR/start-mcp-server.sh"

echo "📝 Configuration créée dans: $CONFIG_DIR"
echo ""

# Tester le serveur MCP
echo "🧪 Test du serveur MCP..."
timeout 3s "$CONFIG_DIR/start-mcp-server.sh" > /dev/null 2>&1 &
MCP_PID=$!

sleep 2

if kill -0 $MCP_PID 2>/dev/null; then
    echo "✅ Serveur MCP fonctionne correctement"
    kill $MCP_PID
else
    echo "❌ Le serveur MCP ne démarre pas correctement"
    exit 1
fi

echo ""
echo "🔧 GUIDE D'INTÉGRATION AVEC OPEN WEBUI:"
echo "=========================================="
echo ""
echo "📋 ÉTAPE 1: Ouvrez l'interface d'administration"
echo "   • Allez sur https://llm.4lb.ca"
echo "   • Connectez-vous avec un compte administrateur"
echo ""
echo "📋 ÉTAPE 2: Accédez aux paramètres des outils"
echo "   • Cliquez sur votre avatar (en haut à droite)"
echo "   • Sélectionnez 'Administration'"
echo "   • Allez dans l'onglet 'Paramètres' > 'Outils'"
echo ""
echo "📋 ÉTAPE 3: Ajoutez le serveur MCP"
echo "   • Cliquez sur 'Ajouter un serveur d'outils'"
echo "   • Remplissez les champs suivants:"
echo ""
echo "   📝 Configuration du serveur MCP:"
echo "   • Nom: Server Admin MCP"
echo "   • Type: MCP"
echo "   • URL: http://host.docker.internal:3000"
echo "   • Description: Serveur d'administration système intelligent"
echo "   • Authentification: Aucune"
echo ""
echo "⚠️  IMPORTANT: Le serveur MCP doit tourner sur le port 3000"
echo "   pour être accessible depuis le conteneur Open WebUI"
echo ""

# Modifier le serveur MCP pour qu'il écoute sur le port 3000
echo "🔧 Configuration du serveur MCP pour le port 3000..."
cat > "/home/lalpha/projets/openWebUI-mcp/src/index.ts" << 'EOF'
#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
  InitializeRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { exec, execSync } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import os from "os";
import express from "express";
import cors from "cors";

const execAsync = promisify(exec);

class ServerAdminServer {
  private server: Server;
  private app: express.Application;

  constructor() {
    this.server = new Server(
      {
        name: "server-admin-mcp",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.app = express();
    this.setupExpress();
    this.setupToolHandlers();
    this.setupRequestHandlers();
  }

  private setupExpress() {
    this.app.use(cors());
    this.app.use(express.json());

    // Endpoint de santé
    this.app.get("/health", (req, res) => {
      res.json({ status: "ok", server: "server-admin-mcp", version: "1.0.0" });
    });

    // MCP over HTTP endpoint
    this.app.post("/mcp", async (req, res) => {
      try {
        const result = await this.handleMCPRequest(req.body);
        res.json(result);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
  }

  private async handleMCPRequest(request: any) {
    // Gestion basique des requêtes MCP via HTTP
    if (request.method === "initialize") {
      return {
        protocolVersion: "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "server-admin-mcp", version: "1.0.0" }
      };
    }

    if (request.method === "tools/list") {
      return {
        tools: [
          {
            name: "run_command",
            description: "Exécuter une commande système Linux",
            inputSchema: {
              type: "object",
              properties: { command: { type: "string" } },
              required: ["command"]
            }
          },
          {
            name: "check_service_status",
            description: "Vérifier le statut d'un service systemd",
            inputSchema: {
              type: "object",
              properties: { service: { type: "string" } },
              required: ["service"]
            }
          },
          {
            name: "diagnose_system",
            description: "Diagnostiquer l'état général du système",
            inputSchema: {
              type: "object",
              properties: {}
            }
          },
          {
            name: "read_file",
            description: "Lire le contenu d'un fichier",
            inputSchema: {
              type: "object",
              properties: { path: { type: "string" } },
              required: ["path"]
            }
          },
          {
            name: "list_directory",
            description: "Lister le contenu d'un répertoire",
            inputSchema: {
              type: "object",
              properties: { path: { type: "string", default: "." } }
            }
          }
        ]
      };
    }

    if (request.method === "tools/call") {
      const { name, arguments: args } = request.params;
      return await this.executeTool(name, args);
    }

    throw new Error("Méthode non supportée");
  }

  private async executeTool(name: string, args: any) {
    try {
      switch (name) {
        case "run_command":
          return await this.runCommand(args);
        case "check_service_status":
          return await this.checkServiceStatus(args);
        case "diagnose_system":
          return await this.diagnoseSystem(args);
        case "read_file":
          return await this.readFile(args);
        case "list_directory":
          return await this.listDirectory(args);
        default:
          throw new McpError(ErrorCode.MethodNotFound, `Outil inconnu: ${name}`);
      }
    } catch (error) {
      throw new McpError(ErrorCode.InternalError, `Erreur: ${error.message}`);
    }
  }

  // ...existing code... (raccourci pour éviter la répétition)

  async run() {
    // Démarrer le serveur HTTP sur le port 3000
    this.app.listen(3000, '0.0.0.0', () => {
      console.error("Serveur MCP Admin HTTP démarré sur le port 3000");
    });

    // Garder le serveur MCP stdio pour compatibilité
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Serveur MCP Admin STDIO prêt");
  }
}

// Démarrer le serveur
const server = new ServerAdminServer();
server.run().catch(console.error);
EOF

echo "✅ Serveur MCP configuré pour le port 3000"
echo ""
echo "🚀 Pour finaliser l'intégration:"
echo ""
echo "1. Recompilez le serveur MCP:"
echo "   cd /home/lalpha/projets/openWebUI-mcp && npm run build"
echo ""
echo "2. Démarrez le serveur MCP:"
echo "   ./mcp-integration/start-mcp-server.sh"
echo ""
echo "3. Ajoutez le serveur dans Open WebUI (interface web)"
echo ""
echo "4. Testez avec une commande comme:"
echo "   'Vérifie l'état de mon serveur'"
echo ""
echo "🎉 L'intégration sera alors complète!"