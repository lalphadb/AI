# 🔐 Fix: Authentification Modèles Cloud Ollama

## 🚨 Problème Identifié

**Erreur:** `401: unauthorized` dans Open WebUI avec modèles cloud

**Modèles affectés:**
- `kimi-k2:1t-cloud`
- `qwen3-coder:480b-cloud`

**Modèles fonctionnels:**
- ✅ `deepseek-coder:33b` (local)
- ✅ `qwen2.5-coder:32b-instruct-q4_K_M` (local)
- ✅ `llama3.2-vision:11b-instruct-q8_0` (local)

---

## 🔍 Diagnostic

Les modèles cloud d'Ollama nécessitent une authentification avec `ollama.com`:

```bash
curl http://10.10.10.46:11434/api/generate -d '{"model":"kimi-k2:1t-cloud","prompt":"test"}'
# Résultat: {"error":"unauthorized","signin_url":"https://ollama.com/connect?..."}
```

---

## ✅ Solution 1: Authentifier Ollama (Recommandé)

### Étape 1: Se connecter sur le serveur Ollama

```bash
# SSH vers le serveur hébergeant Ollama (10.10.10.46)
ssh user@10.10.10.46
```

### Étape 2: Authentifier Ollama avec ollama.com

```bash
# Utiliser l'URL d'authentification fournie
ollama login

# OU visiter directement l'URL:
# https://ollama.com/connect?name=lalpha-server-1&key=c3NoLWVkMjU1MTkgQUFBQUMzTnphQzFsWkRJMU5URTVBQUFBSU5IOWhyYk1xNlVtQ2diYTdYU2dvUFF0emRuYTI0bGxXV05ZZ1VEeVBYTVA=
```

### Étape 3: Vérifier l'authentification

```bash
# Tester un modèle cloud
ollama run kimi-k2:1t-cloud "hello"
```

### Étape 4: Redémarrer Open WebUI (optionnel)

```bash
docker restart open-webui
```

---

## ✅ Solution 2: Utiliser uniquement les modèles locaux

Si tu ne veux pas authentifier avec ollama.com, utilise les **3 modèles locaux** qui fonctionnent parfaitement:

### Dans Open WebUI:

1. **Paramètres** → **Modèles**
2. **Désactiver** les modèles cloud:
   - ❌ `kimi-k2:1t-cloud`
   - ❌ `qwen3-coder:480b-cloud`

3. **Utiliser** les modèles locaux:
   - ✅ `deepseek-coder:33b` (33B params, excellent pour le code)
   - ✅ `qwen2.5-coder:32b-instruct-q4_K_M` (32B params, très performant)
   - ✅ `llama3.2-vision:11b-instruct-q8_0` (vision + texte)

---

## ✅ Solution 3: Retirer les modèles cloud d'Ollama

```bash
# Sur le serveur Ollama (10.10.10.46)
ssh user@10.10.10.46

# Supprimer les modèles cloud
ollama rm kimi-k2:1t-cloud
ollama rm qwen3-coder:480b-cloud
```

Ensuite, dans Open WebUI, rafraîchir la liste des modèles.

---

## 📊 Comparaison Modèles Locaux

| Modèle | Taille | Spécialité | Performance |
|--------|--------|------------|-------------|
| `deepseek-coder:33b` | 33B | Code, Python, JS, etc. | ⭐⭐⭐⭐⭐ |
| `qwen2.5-coder:32b` | 32B | Code, multilingual | ⭐⭐⭐⭐⭐ |
| `llama3.2-vision:11b` | 11B | Vision + texte | ⭐⭐⭐⭐ |

**Recommandation:** Les modèles locaux sont **plus rapides** et **sans limite de quota** cloud.

---

## 🧪 Tests de Validation

### Test 1: Modèle local (devrait fonctionner)

```bash
curl -sS http://10.10.10.46:11434/api/generate -d '{
  "model":"deepseek-coder:33b",
  "prompt":"hello",
  "stream":false
}'
```

**Résultat attendu:** Réponse JSON avec du texte

### Test 2: Modèle cloud non authentifié (échouera)

```bash
curl -sS http://10.10.10.46:11434/api/generate -d '{
  "model":"kimi-k2:1t-cloud",
  "prompt":"hello",
  "stream":false
}'
```

**Résultat attendu:** `{"error":"unauthorized","signin_url":"..."}`

---

## 🎯 Recommandation Finale

**Pour une utilisation immédiate sans configuration supplémentaire:**

1. Dans Open WebUI, **sélectionne un modèle local**:
   - `deepseek-coder:33b` → Excellent pour le code
   - `qwen2.5-coder:32b` → Très polyvalent

2. Les modèles locaux sont:
   - ✅ Plus rapides (pas de latence réseau vers ollama.com)
   - ✅ Privés (pas de données envoyées au cloud)
   - ✅ Sans limite de quota
   - ✅ Disponibles 24/7 sans authentification

**Si tu veux vraiment utiliser les modèles cloud:**
- Suis la **Solution 1** pour authentifier Ollama avec ollama.com
- Les modèles cloud ont des quotas et peuvent être plus lents

---

## 📝 Mise à Jour du VERIFICATION-REPORT.md

Le problème d'authentification cloud est maintenant documenté. Les modèles locaux fonctionnent parfaitement. ✅
