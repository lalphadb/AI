"""
title: MCP Server Admin v4
author: Lalpha
author_url: https://4lb.ca
version: 4.0.0
license: MIT
description: Administration système complète avec 31 outils via MCP Server - Fichiers, Docker, Système, Logs, Réseau, Sécurité
required_open_webui_version: 0.4.0
"""

import requests
import json
from typing import Callable, Any
from pydantic import BaseModel, Field


class Tools:
    """
    Outils d'administration système via MCP Server Intelligent v4.
    31 outils pour gérer fichiers, Docker, système, logs, réseau et sécurité.
    """

    class Valves(BaseModel):
        MCP_SERVER_URL: str = Field(
            default="http://mcp-server:3000",
            description="URL du serveur MCP"
        )

    def __init__(self):
        self.valves = self.Valves()

    def _call_mcp(self, tool: str, args: dict = None) -> str:
        """Appel générique au serveur MCP"""
        try:
            resp = requests.post(
                f"{self.valves.MCP_SERVER_URL}/api/tools/execute",
                json={"tool": tool, "arguments": args or {}},
                timeout=120
            )
            if resp.status_code != 200:
                return f"Erreur HTTP {resp.status_code}"
            data = resp.json()
            if data.get("success"):
                return json.dumps(data.get("result", {}), indent=2, ensure_ascii=False)
            return f"Erreur: {data.get('error', 'Inconnue')}"
        except Exception as e:
            return f"Erreur connexion: {str(e)}"

    # ===== FICHIERS =====

    def read_file(self, path: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Lire le contenu d'un fichier sur le serveur.
        :param path: Chemin complet du fichier à lire
        :return: Contenu du fichier
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": f"Lecture de {path}...", "done": False}})
        result = self._call_mcp("read_file", {"path": path})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Lecture terminée", "done": True}})
        return result

    def write_file(self, path: str, content: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Écrire du contenu dans un fichier.
        :param path: Chemin du fichier
        :param content: Contenu à écrire
        :return: Confirmation
        """
        return self._call_mcp("write_file", {"path": path, "content": content})

    def list_directory(self, path: str = "/home/lalpha", __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Lister le contenu d'un répertoire.
        :param path: Chemin du répertoire (défaut: /home/lalpha)
        :return: Liste des fichiers et dossiers
        """
        return self._call_mcp("list_directory", {"path": path})

    def delete_file(self, path: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Supprimer un fichier ou répertoire.
        :param path: Chemin à supprimer
        :return: Confirmation
        """
        return self._call_mcp("delete_file", {"path": path})

    def copy_file(self, source: str, destination: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Copier un fichier.
        :param source: Fichier source
        :param destination: Destination
        :return: Confirmation
        """
        return self._call_mcp("copy_file", {"source": source, "destination": destination})

    def find_file(self, pattern: str, directory: str = "/home/lalpha", __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Rechercher des fichiers par nom.
        :param pattern: Pattern de recherche
        :param directory: Répertoire de recherche
        :return: Liste des fichiers trouvés
        """
        return self._call_mcp("find_file", {"pattern": pattern, "directory": directory})

    def file_info(self, path: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir des informations détaillées sur un fichier.
        :param path: Chemin du fichier
        :return: Informations (taille, date, permissions)
        """
        return self._call_mcp("file_info", {"path": path})

    # ===== DOCKER =====

    def docker_list(self, all: bool = False, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Lister les conteneurs Docker.
        :param all: Inclure les conteneurs arrêtés
        :return: Liste des conteneurs
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Récupération des conteneurs...", "done": False}})
        result = self._call_mcp("docker_list", {"all": all})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Liste récupérée", "done": True}})
        return result

    def docker_logs(self, container: str, lines: int = 50, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Afficher les logs d'un conteneur Docker.
        :param container: Nom du conteneur
        :param lines: Nombre de lignes (défaut: 50)
        :return: Logs du conteneur
        """
        return self._call_mcp("docker_logs", {"container": container, "lines": lines})

    def docker_restart(self, container: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Redémarrer un conteneur Docker.
        :param container: Nom du conteneur
        :return: Confirmation
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": f"Redémarrage de {container}...", "done": False}})
        result = self._call_mcp("docker_restart", {"container": container})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Conteneur redémarré", "done": True}})
        return result

    def docker_stop(self, container: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Arrêter un conteneur Docker.
        :param container: Nom du conteneur
        :return: Confirmation
        """
        return self._call_mcp("docker_stop", {"container": container})

    def docker_start(self, container: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Démarrer un conteneur Docker.
        :param container: Nom du conteneur
        :return: Confirmation
        """
        return self._call_mcp("docker_start", {"container": container})

    def docker_exec(self, container: str, command: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Exécuter une commande dans un conteneur Docker.
        :param container: Nom du conteneur
        :param command: Commande à exécuter
        :return: Sortie de la commande
        """
        return self._call_mcp("docker_exec", {"container": container, "command": command})

    # ===== SYSTÈME =====

    def system_info(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir les informations complètes du système (CPU, RAM, OS, uptime).
        :return: Informations système
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Analyse du système...", "done": False}})
        result = self._call_mcp("system_info", {})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Analyse terminée", "done": True}})
        return result

    def disk_usage(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Afficher l'utilisation des disques.
        :return: Espace disque utilisé/disponible
        """
        return self._call_mcp("disk_usage", {})

    def memory_info(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Afficher les informations mémoire détaillées.
        :return: Utilisation RAM et swap
        """
        return self._call_mcp("memory_info", {})

    def cpu_info(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Afficher les informations CPU et la charge système.
        :return: Informations CPU et load average
        """
        return self._call_mcp("cpu_info", {})

    def process_list(self, limit: int = 20, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Lister les processus actifs triés par utilisation mémoire.
        :param limit: Nombre de processus à afficher (défaut: 20)
        :return: Liste des processus
        """
        return self._call_mcp("process_list", {"limit": limit})

    def run_command(self, command: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Exécuter une commande shell sur le serveur.
        :param command: Commande à exécuter
        :return: Sortie de la commande
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": f"Exécution: {command[:50]}...", "done": False}})
        result = self._call_mcp("run_command", {"command": command, "timeout": 30000})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Commande terminée", "done": True}})
        return result

    # ===== LOGS =====

    def analyze_logs(self, service: str, lines: int = 100, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Analyser les logs d'un service (fail2ban, nginx, syslog, auth, docker).
        :param service: Nom du service
        :param lines: Nombre de lignes (défaut: 100)
        :return: Contenu des logs
        """
        return self._call_mcp("analyze_logs", {"service": service, "lines": lines})

    def tail_log(self, path: str, lines: int = 50, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Afficher les dernières lignes d'un fichier log.
        :param path: Chemin du fichier log
        :param lines: Nombre de lignes (défaut: 50)
        :return: Dernières lignes du log
        """
        return self._call_mcp("tail_log", {"path": path, "lines": lines})

    def search_logs(self, pattern: str, path: str = "/var/log/syslog", __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Rechercher un pattern dans les logs.
        :param pattern: Pattern à rechercher
        :param path: Fichier log (défaut: /var/log/syslog)
        :return: Lignes correspondantes
        """
        return self._call_mcp("search_logs", {"pattern": pattern, "path": path})

    def journalctl(self, unit: str = "", lines: int = 50, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Consulter les logs systemd avec journalctl.
        :param unit: Unité systemd (optionnel)
        :param lines: Nombre de lignes (défaut: 50)
        :return: Logs systemd
        """
        return self._call_mcp("journalctl", {"unit": unit, "lines": lines})

    # ===== RÉSEAU =====

    def network_info(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir les informations réseau (interfaces, ports ouverts).
        :return: Configuration réseau
        """
        return self._call_mcp("network_info", {})

    def check_port(self, port: int, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Vérifier si un port est ouvert sur le serveur.
        :param port: Numéro de port
        :return: État du port
        """
        return self._call_mcp("check_port", {"port": port})

    def ping_host(self, host: str, count: int = 3, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Ping un hôte pour vérifier la connectivité.
        :param host: Hôte à pinger
        :param count: Nombre de pings (défaut: 3)
        :return: Résultat du ping
        """
        return self._call_mcp("ping_host", {"host": host, "count": count})

    def dns_lookup(self, domain: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Effectuer une résolution DNS.
        :param domain: Domaine à résoudre
        :return: Adresses IP
        """
        return self._call_mcp("dns_lookup", {"domain": domain})

    # ===== SÉCURITÉ =====

    def fail2ban_status(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir le statut de Fail2Ban (protection contre les attaques).
        :return: État de Fail2Ban et jails actives
        """
        return self._call_mcp("fail2ban_status", {})

    def firewall_status(self, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir le statut du firewall UFW.
        :return: Règles firewall actives
        """
        return self._call_mcp("firewall_status", {})

    # ===== SERVICES =====

    def service_status(self, service: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Obtenir le statut d'un service systemd.
        :param service: Nom du service
        :return: État du service
        """
        return self._call_mcp("service_status", {"service": service})

    def service_restart(self, service: str, __event_emitter__: Callable[[dict], Any] = None) -> str:
        """
        Redémarrer un service systemd.
        :param service: Nom du service
        :return: Confirmation
        """
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": f"Redémarrage de {service}...", "done": False}})
        result = self._call_mcp("service_restart", {"service": service})
        if __event_emitter__:
            __event_emitter__({"type": "status", "data": {"description": "Service redémarré", "done": True}})
        return result
