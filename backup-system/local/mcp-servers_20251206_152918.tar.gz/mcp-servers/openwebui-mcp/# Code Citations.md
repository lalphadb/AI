# Code Citations

## License: MIT
https://github.com/sudiptog81/learning-cpp/blob/da1f415e45d88af211efcdae6144465a406a3950/README.md

```
.0.0",
  "tasks": [
    {
      "label": "build",
      "type": "shell",
      "command": "npm",
      "args": ["run", "build"],
      "group": {
        "kind": "build",
        "isDefault": true
      },
      "presentation": {
        "echo": true,
        "reveal": "silent",
        "focus": false,
        "panel": "shared",
        "showReuseMessage": true,
        "clear": false
      }
```


## License: unknown
https://github.com/PythonDarkeningSchool/typescript/blob/e6fd7f1e6a0f282c3177c5ca7e7dd4f7c9df7dfd/readme.md

```
.0.0",
  "tasks": [
    {
      "label": "build",
      "type": "shell",
      "command": "npm",
      "args": ["run", "build"],
      "group": {
        "kind": "build",
        "isDefault": true
      },
      "presentation": {
        "echo": true,
        "reveal": "silent",
        "focus": false,
        "panel": "shared",
        "showReuseMessage": true,
        "clear": false
      }
```


## License: MIT
https://github.com/billhu0/billhu-hexo-blog/blob/2c4e3d94ab460261ace3e490ce20f88cc7f534bb/source/_posts/05_vscode_cpp.md

```
.0.0",
  "tasks": [
    {
      "label": "build",
      "type": "shell",
      "command": "npm",
      "args": ["run", "build"],
      "group": {
        "kind": "build",
        "isDefault": true
      },
      "presentation": {
        "echo": true,
        "reveal": "silent",
        "focus": false,
        "panel": "shared",
        "showReuseMessage": true,
        "clear": false
      }
```


## License: unknown
https://github.com/iujunhyung/monorepo/blob/9e080c69469cf43bc2e21c529a97383339404871/lit.code-workspace

```
.0.0",
  "tasks": [
    {
      "label": "build",
      "type": "shell",
      "command": "npm",
      "args": ["run", "build"],
      "group": {
        "kind": "build",
        "isDefault": true
      },
      "presentation": {
        "echo": true,
        "reveal": "silent",
        "focus": false,
        "panel": "shared",
        "showReuseMessage": true,
        "clear": false
      }
```

