#!/bin/bash

# Script de test de l'intégration MCP Server
echo "🧪 Test d'Intégration MCP Server"
echo "================================="
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Serveur MCP actif
echo "📋 Test 1: Vérification du processus MCP..."
if ps aux | grep -v grep | grep "node dist/index.js" > /dev/null; then
    echo -e "${GREEN}✅ Le serveur MCP est actif${NC}"
else
    echo -e "${RED}❌ Le serveur MCP n'est pas actif${NC}"
    echo "   Démarrez-le avec: npm start"
    exit 1
fi
echo ""

# Test 2: Health Check HTTP
echo "📋 Test 2: Health Check HTTP..."
HEALTH=$(curl -s http://localhost:3000/health)
if echo "$HEALTH" | grep -q "ok"; then
    echo -e "${GREEN}✅ Endpoint HTTP opérationnel${NC}"
    echo "   Réponse: $HEALTH"
else
    echo -e "${RED}❌ Le endpoint HTTP ne répond pas correctement${NC}"
    exit 1
fi
echo ""

# Test 3: MCP Initialize
echo "📋 Test 3: MCP Protocol - Initialize..."
INIT_RESULT=$(curl -s -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0.0"}}}')

if echo "$INIT_RESULT" | grep -q "protocolVersion"; then
    echo -e "${GREEN}✅ Initialisation MCP réussie${NC}"
    echo "   Protocol: $(echo $INIT_RESULT | grep -o '"protocolVersion":"[^"]*"' | cut -d'"' -f4)"
else
    echo -e "${RED}❌ Échec de l'initialisation MCP${NC}"
    exit 1
fi
echo ""

# Test 4: Liste des outils
echo "📋 Test 4: Récupération de la liste des outils..."
TOOLS_RESULT=$(curl -s -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}')

TOOL_COUNT=$(echo "$TOOLS_RESULT" | grep -o '"name":"[^"]*"' | wc -l)
if [ "$TOOL_COUNT" -gt 15 ]; then
    echo -e "${GREEN}✅ $TOOL_COUNT outils disponibles${NC}"
    echo "   Exemples: run_command, diagnose_system, check_docker_containers, read_file, etc."
else
    echo -e "${RED}❌ Nombre d'outils insuffisant: $TOOL_COUNT${NC}"
    exit 1
fi
echo ""

# Test 5: Exécution d'un outil simple
echo "📋 Test 5: Exécution d'un outil (system_info)..."
EXEC_RESULT=$(curl -s -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"system_info","arguments":{}}}')

if echo "$EXEC_RESULT" | grep -q "CPU\|RAM\|Disques"; then
    echo -e "${GREEN}✅ Exécution d'outil réussie${NC}"
    echo "   L'outil system_info a retourné des données système"
else
    echo -e "${RED}❌ Échec de l'exécution de l'outil${NC}"
    exit 1
fi
echo ""

# Test 6: Vérification Open WebUI
echo "📋 Test 6: Vérification Open WebUI..."
if curl -s -I http://localhost:8080 | grep -q "200 OK"; then
    echo -e "${GREEN}✅ Open WebUI est accessible${NC}"
    echo "   URL: http://localhost:8080"
else
    echo -e "${YELLOW}⚠️  Open WebUI n'est pas accessible sur localhost:8080${NC}"
    echo "   Vérifiez que le conteneur est actif"
fi
echo ""

# Résumé
echo "================================="
echo -e "${GREEN}🎉 Tous les tests sont passés !${NC}"
echo ""
echo "📝 Prochaines étapes pour Open WebUI:"
echo ""
echo "1. Accéder à Open WebUI: https://llm.4lb.ca"
echo "2. Aller dans Administration > Settings > Tools (ou External Tools)"
echo "3. Ajouter le serveur MCP avec cette configuration:"
echo ""
echo "   URL: http://10.10.10.46:3000/mcp"
echo "   (ou http://host.docker.internal:3000/mcp si dans Docker)"
echo ""
echo "4. Activer le serveur et sauvegarder"
echo ""
echo "5. Tester avec une question comme:"
echo "   'Fais un diagnostic de mon serveur'"
echo ""
echo "📚 Documentation complète: INTEGRATION-GUIDE.md"
echo ""
