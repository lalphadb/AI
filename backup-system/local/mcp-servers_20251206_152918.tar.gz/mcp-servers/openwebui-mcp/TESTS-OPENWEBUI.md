# 🧪 Tests et Exemples pour Open WebUI + MCP

## 🎯 Questions à poser dans Open WebUI pour tester le MCP

### 📊 Administration système

#### Test 1 : Lecture de logs

```
Lis les logs fail2ban et montre-moi les 10 dernières IPs bannies
```

**Outils attendus** : `read_file` ou `run_command`

---

#### Test 2 : État du système

```
Fais-moi un diagnostic complet du système
```

**Outils attendus** : `diagnose_system`, `system_info`

---

#### Test 3 : Conteneurs Docker

```
Liste tous les conteneurs Docker et leur statut
```

**Outils attendus** : `check_docker_containers`

---

#### Test 4 : Ressources système

```
Vérifie l'utilisation de la mémoire et du disque
```

**Outils attendus** : `check_memory_usage`, `check_disk_usage`

---

#### Test 5 : Services systemd

```
Vérifie si le service nginx est actif
```

**Outils attendus** : `check_service_status`

---

### 🧠 Tests d'apprentissage

#### Test 6 : Mémorisation

```
Mémorise que le serveur de production est à 10.10.10.46
```

**Outils attendus** : `remember`

Puis ensuite :

```
Quel est l'IP du serveur de production ?
```

**Outils attendus** : `recall`

---

#### Test 7 : Analyse intelligente

```
Analyse pourquoi le serveur pourrait être lent et propose des solutions
```

**Outils attendus** : `intelligent_analysis`, `smart_diagnose`

---

### 📁 Tests de gestion de fichiers

#### Test 8 : Lister un répertoire

```
Liste le contenu de /var/log
```

**Outils attendus** : `list_directory`

---

#### Test 9 : Recherche de fichiers

```
Cherche tous les fichiers .log dans /var/log
```

**Outils attendus** : `search_files`

---

#### Test 10 : Lecture de fichier système

```
Lis le fichier /etc/hostname
```

**Outils attendus** : `read_file`

---

### 🔧 Tests de commandes avancées

#### Test 11 : Exécution de commande

```
Exécute la commande "uptime" et montre-moi le résultat
```

**Outils attendus** : `run_command`

---

#### Test 12 : Vérification réseau

```
Montre-moi les connexions réseau actives sur le port 443
```

**Outils attendus** : `check_network_connections`

---

#### Test 13 : Monitoring en temps réel

```
Surveille les ressources système pendant 30 secondes
```

**Outils attendus** : `monitor_resources`

---

### 🚀 Tests de génération de code

#### Test 14 : Générer du code

```
Génère un script bash qui sauvegarde /var/log dans /backup
```

**Outils attendus** : `generate_code`

---

#### Test 15 : Créer un service web

```
Crée un service web API REST sur le port 8080
```

**Outils attendus** : `create_web_service`

---

## 📋 Checklist de vérification

Avant de tester, vérifiez :

### ✅ Configuration Open WebUI

```bash
# Vérifier que Open WebUI peut atteindre le MCP
docker exec open-webui curl -s http://mcp-server:3000/api/tools | jq '.tools | length'
```

**Résultat attendu** : `25` (nombre d'outils)

---

### ✅ OpenAPI accessible

```bash
docker exec open-webui curl -s http://mcp-server:3000/openapi.json | jq '.info.title'
```

**Résultat attendu** : `"Server Admin MCP - Intelligent System Administration"`

---

### ✅ MCP en cours d'exécution

```bash
docker ps | grep mcp-server
```

**Résultat attendu** : conteneur `mcp-server` avec status `Up`

---

## 🎨 Scénarios complexes

### Scénario 1 : Investigation fail2ban complète

```
1. Analyse les logs fail2ban
2. Identifie les IPs bannies aujourd'hui
3. Compte combien il y en a
4. Dis-moi de quels pays elles viennent (si possible)
```

---

### Scénario 2 : Audit Docker

```
1. Liste tous les conteneurs
2. Identifie ceux qui sont arrêtés
3. Vérifie l'utilisation des ressources
4. Propose un nettoyage si nécessaire
```

---

### Scénario 3 : Diagnostic complet

```
Fais un diagnostic complet du serveur :
- État des services
- Espace disque
- Mémoire disponible
- Conteneurs Docker
- Logs d'erreurs récents
```

---

## 🐛 Résolution de problèmes

### Problème : Le modèle ne voit pas les outils

**Vérification** :

```bash
docker exec open-webui curl -s http://mcp-server:3000/openapi.json
```

**Solution** :

1. Dans Open WebUI → Settings → Connections → External Tools
2. Vérifier l'URL : `http://mcp-server:3000`
3. Cliquer sur "Rafraîchir" ou "Test Connection"

---

### Problème : Erreur "MCP error -32601"

**Cause** : L'outil n'existe pas ou mauvais nom

**Vérification** :

```bash
docker exec open-webui curl -s http://mcp-server:3000/api/tools | jq '.tools[].name'
```

**Solution** : Utilisez les noms d'outils exacts listés

---

### Problème : Réponse lente ou timeout

**Cause** : Commande trop longue ou fichier trop gros

**Solution** : Utilisez des limites :

```
Lis les 50 premières lignes de /var/log/syslog
```

---

## 📊 Résultats attendus par outil

### `read_file`

```json
{
  "success": true,
  "data": "Contenu du fichier /path/to/file:\n\n..."
}
```

### `run_command`

```json
{
  "success": true,
  "data": "Commande exécutée: ...\n\nSortie standard:\n..."
}
```

### `check_docker_containers`

```json
{
  "success": true,
  "data": "NAMES              STATUS           PORTS\npostgres          Up 2 hours       5432/tcp\n..."
}
```

### `analyze_logs`

```json
{
  "success": true,
  "data": "Analyse des logs fail2ban:\n\n📊 9 erreurs détectées...\n⚠️ 2 avertissements..."
}
```

---

## 🎓 Astuces pour optimiser les tests

### 1. Soyez spécifique

❌ "Regarde les logs"
✅ "Lis les 50 dernières lignes de /var/log/fail2ban.log"

### 2. Utilisez les chemins complets

❌ "Lis fail2ban.log"
✅ "Lis /var/log/fail2ban.log" ou "/host/var/log/fail2ban.log"

### 3. Limitez les résultats

❌ "Liste tous les fichiers du système"
✅ "Liste les 20 plus gros fichiers dans /var/log"

### 4. Testez progressivement

1. D'abord les outils simples (`read_file`, `list_directory`)
2. Puis les outils complexes (`smart_diagnose`, `intelligent_analysis`)
3. Enfin les scénarios multi-étapes

---

## 📈 Mesurer l'apprentissage

Après quelques jours d'utilisation, demandez :

```
Montre-moi ce que tu as appris sur ce serveur
```

Le MCP devrait répondre avec :

- Nombre de commandes exécutées
- Patterns reconnus
- Solutions apprises
- Taux de succès

---

## 🔥 Commandes de test rapides (via terminal)

```bash
# Test 1: Lecture de fichier
docker exec open-webui curl -sS -X POST http://mcp-server:3000/api/files/read \
  -H "Content-Type: application/json" \
  -d '{"path":"/host/var/log/fail2ban.log"}' | jq -r '.data' | head -20

# Test 2: Liste des outils
docker exec open-webui curl -sS http://mcp-server:3000/api/tools | jq '.tools[].name'

# Test 3: Info système
docker exec open-webui curl -sS http://mcp-server:3000/api/system/info | jq .

# Test 4: Conteneurs Docker
docker exec open-webui curl -sS http://mcp-server:3000/api/docker/containers | jq -r '.data'

# Test 5: Exécuter une commande
docker exec open-webui curl -sS -X POST http://mcp-server:3000/api/command/execute \
  -H "Content-Type: application/json" \
  -d '{"command":"uptime"}' | jq -r '.data'
```

---

## ✅ Tests de validation finale

Avant de déployer en production, testez ces 5 scénarios critiques :

### 1. ✅ Lecture de logs système

```
Analyse les logs système et identifie les erreurs récentes
```

### 2. ✅ Gestion Docker

```
Liste les conteneurs Docker et redémarre ceux qui sont arrêtés
```

### 3. ✅ Monitoring

```
Surveille le système pendant 60 secondes et alerte-moi si quelque chose est anormal
```

### 4. ✅ Apprentissage

```
Mémorise que le backup quotidien est à 2h du matin
```

Puis :

```
À quelle heure est le backup ?
```

### 5. ✅ Correction automatique

```
Diagnostique le système et corrige automatiquement les problèmes mineurs
```

---

## 🎉 Félicitations

Si tous les tests passent, votre MCP intelligent est **100% opérationnel** ! 🚀

Le système va maintenant :

- ✅ Apprendre de chaque interaction
- ✅ Devenir plus rapide avec le temps
- ✅ Proposer des solutions proactives
- ✅ Auto-corriger les problèmes simples

**Plus vous l'utilisez, plus il devient intelligent !** 🧠
