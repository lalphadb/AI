# ✅ Guide d'Intégration Open WebUI - MCP Server

## État actuel ✨

**Le serveur MCP fonctionne parfaitement !**

- ✅ Serveur MCP actif sur le port **3000**
- ✅ HTTP endpoint opérationnel
- ✅ 20+ outils disponibles
- ✅ Open WebUI accessible sur le port **8080**
- ✅ Tests de diagnostic réussis

## Configuration dans Open WebUI

### Méthode 1: Configuration via Interface Web (Recommandé)

1. **Accéder à Open WebUI**
   ```
   https://llm.4lb.ca
   ```

2. **Ouvrir les Paramètres**
   - Cliquez sur votre avatar (en haut à droite)
   - Sélectionnez **"Administration"** ou **"Settings"**

3. **Configurer le serveur MCP**
   - Allez dans **"External Tools"** ou **"MCP Servers"** ou **"Tools"**
   - Cliquez sur **"Add Tool Server"** ou **"Add MCP Server"**

4. **Entrer la configuration suivante:**

   ```json
   {
     "name": "Server Admin MCP",
     "url": "http://10.10.10.46:3000/mcp",
     "description": "Administration système intelligente",
     "enabled": true,
     "timeout": 30000
   }
   ```

   **OU si Open WebUI est dans Docker:**

   ```json
   {
     "name": "Server Admin MCP",
     "url": "http://host.docker.internal:3000/mcp",
     "description": "Administration système intelligente",
     "enabled": true,
     "timeout": 30000
   }
   ```

5. **Sauvegarder et Activer**

### Méthode 2: Configuration via Variable d'Environnement

Si Open WebUI supporte les variables d'environnement pour MCP:

```bash
export MCP_SERVERS='[
  {
    "name": "server-admin",
    "url": "http://10.10.10.46:3000/mcp",
    "enabled": true
  }
]'
```

Puis redémarrer Open WebUI:
```bash
docker restart open-webui
```

## Vérification de l'Intégration

### Test 1: Vérifier la connexion

Dans Open WebUI, envoyez ce message:
```
Liste les outils MCP disponibles
```

Vous devriez voir 20+ outils disponibles.

### Test 2: Exécuter un diagnostic

```
Fais un diagnostic complet de mon serveur
```

### Test 3: Vérifier un service

```
Vérifie le statut du service docker
```

## Outils Disponibles (20+)

### 🔧 Administration Système
- `run_command` - Exécuter des commandes Linux
- `check_service_status` - Statut des services systemd
- `restart_service` - Redémarrer des services
- `system_info` - Informations système complètes

### 📊 Monitoring
- `diagnose_system` - Diagnostic général
- `smart_diagnose` - Diagnostic intelligent par composant
- `monitor_resources` - Surveillance en temps réel
- `check_disk_usage` - Utilisation disque
- `check_memory_usage` - Utilisation mémoire
- `check_network_connections` - Connexions réseau
- `check_docker_containers` - État des conteneurs Docker

### 📁 Fichiers
- `read_file` - Lire des fichiers
- `write_file` - Écrire dans des fichiers
- `list_directory` - Lister répertoires
- `create_directory` - Créer répertoires
- `delete_file` - Supprimer fichiers/dossiers
- `search_files` - Rechercher par nom ou contenu
- `backup_file` - Sauvegarder des fichiers

### 🔍 Diagnostic Avancé
- `analyze_logs` - Analyser les logs système
- `auto_fix` - Correction automatique
- `monitor_resources` - Surveillance continue

## Exemples d'Utilisation

### Diagnostic Système
```
Vérifie l'état de mon serveur et identifie les problèmes
```

### Gestion Docker
```
Liste tous les conteneurs Docker et leur statut
```

### Analyse de Logs
```
Analyse les logs du service ollama et trouve les erreurs
```

### Recherche de Fichiers
```
Cherche tous les fichiers .conf dans /etc
```

### Monitoring
```
Surveille l'utilisation CPU et mémoire pendant 60 secondes
```

## Dépannage

### Le serveur MCP ne répond pas

1. Vérifier que le serveur tourne:
   ```bash
   ps aux | grep "node dist/index.js"
   ```

2. Tester le endpoint:
   ```bash
   curl http://localhost:3000/health
   ```

3. Redémarrer si nécessaire:
   ```bash
   cd /home/lalpha/projets/openWebUI-mcp
   pkill -f "node dist/index.js"
   npm start
   ```

### Open WebUI ne voit pas le serveur MCP

1. Vérifier que l'URL est correcte (`http://10.10.10.46:3000/mcp`)
2. Si Open WebUI est dans Docker, utiliser `http://host.docker.internal:3000/mcp`
3. Vérifier les logs Open WebUI pour les erreurs de connexion
4. Tester manuellement avec curl:
   ```bash
   curl -X POST http://10.10.10.46:3000/mcp \
     -H "Content-Type: application/json" \
     -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'
   ```

### Permissions insuffisantes

Certaines commandes nécessitent sudo. Configurez sudoers pour l'utilisateur:
```bash
sudo visudo
# Ajouter:
lalpha ALL=(ALL) NOPASSWD: /bin/systemctl, /usr/bin/docker
```

## Logs et Monitoring

### Logs du serveur MCP
```bash
tail -f /home/lalpha/projets/openWebUI-mcp/mcp-server.log
```

### Redémarrer le serveur MCP
```bash
cd /home/lalpha/projets/openWebUI-mcp
./start-mcp-server.sh
```

### Arrêter le serveur MCP
```bash
pkill -f "node dist/index.js"
```

## URLs et Endpoints

- **MCP Server HTTP**: `http://10.10.10.46:3000/mcp`
- **MCP Health Check**: `http://10.10.10.46:3000/health`
- **Open WebUI**: `https://llm.4lb.ca` (ou `http://localhost:8080`)

## Configuration Automatique au Démarrage

Pour démarrer automatiquement le serveur MCP au boot:

```bash
# Créer un service systemd
sudo tee /etc/systemd/system/mcp-server.service << EOF
[Unit]
Description=MCP Server Admin
After=network.target

[Service]
Type=simple
User=lalpha
WorkingDirectory=/home/lalpha/projets/openWebUI-mcp
ExecStart=/usr/bin/node /home/lalpha/projets/openWebUI-mcp/dist/index.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Activer et démarrer
sudo systemctl daemon-reload
sudo systemctl enable mcp-server
sudo systemctl start mcp-server
```

## Support et Contribution

Pour tout problème ou suggestion:
- Vérifier les logs: `tail -f mcp-server.log`
- Tester manuellement les endpoints
- Consulter la documentation MCP: https://modelcontextprotocol.io/

---

**✅ Le serveur MCP est opérationnel et prêt à être utilisé avec Open WebUI !**
