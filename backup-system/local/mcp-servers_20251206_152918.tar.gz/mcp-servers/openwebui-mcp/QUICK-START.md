# 🎯 Guide Rapide - MCP Intelligent avec Open WebUI

## ✅ État actuel du système

### 🟢 Services opérationnels

- **MCP Server** : `http://mcp-server:3000` (conteneur Docker)
- **Open WebUI** : `https://llm.4lb.ca` (configuré avec MCP)
- **Ollama** : `http://10.10.10.46:11434` (modèles locaux)
- **ChromaDB** : Vector database pour embeddings
- **Mémoire SQLite** : `/tmp/memory.db` (apprentissage persistant)

### 🔧 Outils disponibles : **25 outils**

---

## 🚀 Utilisation dans Open WebUI

### 1️⃣ Ouvrir une conversation

Allez sur : <https://llm.4lb.ca>

### 2️⃣ Sélectionner le modèle

Choisissez : **deepseek-coder:33b** (ou autre modèle configuré)

### 3️⃣ Poser une question

Le modèle utilisera **automatiquement** les outils MCP nécessaires.

---

## 💡 Exemples de questions efficaces

### 📊 Administration

```
Fais un diagnostic complet du système
Liste les conteneurs Docker et leur statut
Vérifie l'utilisation du disque et de la mémoire
Montre-moi les services systemd qui ont échoué
```

### 📁 Logs et Fichiers

```
Analyse les logs fail2ban et montre les IPs bannies aujourd'hui
Lis les 50 dernières lignes de /var/log/syslog
Cherche tous les fichiers .log dans /var/log
Liste le contenu de /etc/nginx
```

### 🐳 Docker

```
Montre-moi tous les conteneurs (y compris arrêtés)
Redémarre les conteneurs qui sont down
Vérifie la santé des conteneurs
Nettoie les images Docker inutilisées
```

### 🧠 Apprentissage

```
Mémorise que le serveur de backup est à 10.10.10.50
Quel est l'IP du serveur de production ?
Montre-moi ce que tu as appris récemment
Analyse pourquoi le serveur est lent et propose des solutions
```

### 🔧 Commandes

```
Exécute "uptime" et montre le résultat
Vérifie les connexions réseau sur le port 443
Surveille les ressources pendant 60 secondes
Redémarre le service nginx
```

---

## 🧠 Comment fonctionne l'apprentissage

### Cycle d'apprentissage

1. **Vous posez une question** → Le modèle choisit un outil MCP
2. **L'outil s'exécute** → Le résultat est enregistré dans SQLite
3. **Pattern détecté** → Si succès, confiance +10%
4. **Prochaine fois** → Reconnaissance automatique + exécution plus rapide

### Progression

- **Semaine 1** : Apprentissage des commandes de base
- **Mois 1** : Reconnaissance avancée, 100+ patterns
- **Mois 6** : Expert, 500+ patterns, prédiction proactive

### Mémoire persistante

Tout est stocké dans `/tmp/memory.db` :

- Historique des commandes
- Patterns appris avec leur taux de succès
- Conversations
- État du système

---

## 📚 Documentation complète

- **LEARNING-SYSTEM.md** : Détails sur l'apprentissage intelligent
- **TESTS-OPENWEBUI.md** : Tests et scénarios d'utilisation
- **INTEGRATION-GUIDE.md** : Guide d'intégration technique
- **INTELLIGENT-FEATURES.md** : Fonctionnalités intelligentes

---

## 🔍 Vérifier que tout fonctionne

### Test rapide dans Open WebUI

```
Lis le fichier /var/log/fail2ban.log et montre-moi les 10 dernières IPs bannies
```

**Résultat attendu** : Le modèle utilise l'outil `read_file` ou `run_command` et affiche les IPs.

---

### Test via terminal (si besoin)

```bash
# Vérifier que MCP répond
docker exec open-webui curl -s http://mcp-server:3000/api/tools | jq '.tools | length'
# Résultat attendu: 25

# Tester la lecture d'un fichier
docker exec open-webui curl -sS -X POST http://mcp-server:3000/api/files/read \
  -H "Content-Type: application/json" \
  -d '{"path":"/host/var/log/fail2ban.log"}' | jq -r '.data' | head -20

# Voir les logs du MCP
docker logs mcp-server --tail 20
```

---

## 🛠️ Maintenance

### Redémarrer le MCP

```bash
docker restart mcp-server
```

### Voir les stats d'apprentissage

Dans Open WebUI, demandez :

```
Montre-moi tes statistiques d'apprentissage
```

### Réinitialiser la mémoire (si nécessaire)

```bash
docker exec mcp-server rm /tmp/memory.db
docker restart mcp-server
```

⚠️ Cela efface tout l'historique d'apprentissage !

---

## 🐛 Résolution de problèmes

### Problème : "Le modèle ne voit pas les outils"

**Solution** :

1. Open WebUI → Settings → Connections → External Tools
2. Vérifier URL : `http://mcp-server:3000`
3. Cliquer "Refresh" ou "Test Connection"

---

### Problème : "Erreur lors de l'exécution"

**Causes possibles** :

- Fichier inexistant → Utilisez `/host/var/log/...` pour les logs système
- Permission refusée → Le MCP tourne en mode privilégié, mais certains fichiers peuvent être protégés
- Commande non trouvée → Certaines commandes (comme `journalctl`) ne sont pas disponibles dans Alpine

**Solution** : Reformulez avec des commandes Unix de base :

```
Utilise "tail -n 50 /host/var/log/syslog" au lieu de journalctl
```

---

### Problème : "Réponse trop lente"

**Solution** : Limitez les résultats :

```
Lis les 50 premières lignes (au lieu de tout le fichier)
Liste les 20 plus gros fichiers (au lieu de tous)
```

---

## 🎯 Bonnes pratiques

### ✅ À faire

- Soyez spécifique dans vos questions
- Utilisez des chemins absolus (`/var/log/...`)
- Limitez les résultats (50 lignes, 20 fichiers, etc.)
- Laissez le MCP apprendre (utilisez `remember` pour les infos importantes)

### ❌ À éviter

- Questions trop vagues ("regarde les logs")
- Demandes massives ("liste tout le système de fichiers")
- Chemins relatifs sans contexte
- Réinitialiser la mémoire trop souvent (perte d'apprentissage)

---

## 📈 Fonctionnalités avancées

### Auto-diagnostic périodique

Le MCP surveille automatiquement :

- Charge CPU
- Mémoire disponible
- Espace disque
- Services systemd
- Conteneurs Docker

Les problèmes à **faible risque** sont corrigés automatiquement.

### Suggestions proactives

Après plusieurs utilisations, le MCP propose des actions avant que vous demandiez :

```
"J'ai remarqué que vous vérifiez fail2ban tous les jours à 10h.
Voulez-vous que je crée un rapport automatique ?"
```

### Génération de code

```
Génère un script bash qui sauvegarde /var/log dans /backup tous les jours
```

Le MCP crée le script et peut même le déployer si vous confirmez.

---

## 🎉 Résumé

Votre MCP est maintenant **100% opérationnel** avec :

✅ **25 outils** disponibles  
✅ **Apprentissage automatique** via SQLite  
✅ **Auto-diagnostic** et correction  
✅ **Intégration complète** avec Open WebUI  
✅ **Surveillance proactive** du système  

**Plus vous l'utilisez, plus il devient intelligent !** 🚀

---

## 📞 Commandes utiles

```bash
# Statut du MCP
docker ps | grep mcp-server

# Logs en temps réel
docker logs -f mcp-server

# Redémarrer
docker restart mcp-server

# Rebuild (après modification du code)
cd /home/lalpha/projets/openWebUI-mcp
npm run build
docker build -t mcp-server:latest .
docker restart mcp-server

# Statistiques d'apprentissage
docker exec open-webui curl -s http://mcp-server:3000/api/system/info | jq .
```

---

## 🔗 Liens rapides

- **Open WebUI** : <https://llm.4lb.ca>
- **MCP API** : <http://mcp-server:3000/api/tools> (depuis containers)
- **OpenAPI Spec** : <http://mcp-server:3000/openapi.json>
- **Health Check** : <http://localhost:3000/health>

---

**Documentation complète disponible dans `/home/lalpha/projets/openWebUI-mcp/`** 📚
