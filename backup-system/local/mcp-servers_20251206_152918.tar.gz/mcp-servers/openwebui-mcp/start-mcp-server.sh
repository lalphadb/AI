#!/bin/bash
set -e

echo "🚀 Démarrage du Serveur MCP Admin pour Open WebUI"
echo ""

# Vérifier que le serveur est compilé
if [ ! -f "dist/index.js" ]; then
    echo "❌ Serveur non compilé. Lancez: npm run build"
    exit 1
fi

# Tuer les instances existantes
pkill -f "node dist/index.js" 2>/dev/null || true
sleep 1

# Démarrer le serveur en arrière-plan
echo "🔧 Démarrage du serveur MCP sur le port 3000..."
nohup node dist/index.js > mcp-server.log 2>&1 &
SERVER_PID=$!

# Attendre que le serveur démarre
sleep 3

# Vérifier que le serveur fonctionne
if curl -s http://localhost:3000/health > /dev/null; then
    echo "✅ Serveur MCP Admin opérationnel!"
    echo "   • Port HTTP: 3000"
    echo "   • PID: $SERVER_PID"
    echo "   • Logs: mcp-server.log"
    echo ""
    echo "🌐 Pour l'intégrer avec Open WebUI:"
    echo "   1. Ouvrez https://llm.4lb.ca"
    echo "   2. Allez dans Administration > Paramètres > Outils"
    echo "   3. Cliquez 'Ajouter un serveur d'outils'"
    echo "   4. Configurez:"
    echo "      - Nom: Server Admin MCP"
    echo "      - Type: MCP"
    echo "      - URL: http://host.docker.internal:3000"
    echo "      - Description: Administration système intelligente"
    echo ""
    echo "🧪 Testez avec: 'Vérifie l'état de mon serveur'"
    echo ""
    echo "🛑 Pour arrêter: kill $SERVER_PID"
else
    echo "❌ Échec du démarrage du serveur"
    echo "📋 Logs:"
    cat mcp-server.log
    exit 1
fi