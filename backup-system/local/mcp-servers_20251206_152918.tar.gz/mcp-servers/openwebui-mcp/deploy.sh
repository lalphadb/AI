#!/bin/bash
set -e

echo "🚀 Déploiement du Serveur MCP Admin..."

# Vérifier si Node.js est installé
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé. Veuillez l'installer d'abord."
    exit 1
fi

# Vérifier si npm est installé
if ! command -v npm &> /dev/null; then
    echo "❌ npm n'est pas installé. Veuillez l'installer d'abord."
    exit 1
fi

# Installer les dépendances si nécessaire
if [ ! -d "node_modules" ]; then
    echo "📦 Installation des dépendances..."
    npm install
fi

# Compiler le projet
echo "🔨 Compilation du projet..."
npm run build

# Créer le répertoire de logs s'il n'existe pas
mkdir -p logs

echo ""
echo "✅ Serveur MCP Admin prêt!"
echo ""
echo "🔧 Pour démarrer le serveur:"
echo "   npm start"
echo ""
echo "📋 Ou en mode développement:"
echo "   npm run dev"
echo ""
echo "🔗 Pour l'intégrer avec Open WebUI:"
echo "   Configurez Open WebUI pour utiliser ce serveur MCP"
echo "   Commande: node $(pwd)/dist/index.js"