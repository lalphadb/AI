/**
 * Système d'Auto-Correction Intelligent v3.0
 * - Vérifie avant d'agir
 * - Corrige automatiquement les erreurs
 * - Apprend des erreurs passées
 * - Propose des alternatives
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';

const execAsync = promisify(exec);

export interface CorrectionResult {
  original: string;
  corrected: string;
  corrections: string[];
  confidence: number;
  alternatives: string[];
}

export interface ValidationResult {
  valid: boolean;
  exists: boolean;
  accessible: boolean;
  type: 'file' | 'directory' | 'unknown';
  suggestions: string[];
  error?: string;
}

export class AutoCorrector {
  private commonPaths: Map<string, string[]> = new Map();
  private errorPatterns: Map<string, string> = new Map();
  
  constructor() {
    this.initializePatterns();
  }

  private initializePatterns() {
    // Chemins communs pour suggestions
    this.commonPaths.set('config', [
      '/etc', '/home/lalpha/.config', '/opt', '/var/lib'
    ]);
    this.commonPaths.set('logs', [
      '/var/log', '/home/lalpha/logs', '/tmp'
    ]);
    this.commonPaths.set('docker', [
      '/var/run/docker.sock', '/etc/docker', '/var/lib/docker'
    ]);
    this.commonPaths.set('web', [
      '/var/www', '/home/lalpha/projets', '/srv'
    ]);
    
    // Corrections d'erreurs courantes
    this.errorPatterns.set('permission denied', 'sudo');
    this.errorPatterns.set('command not found', 'which');
    this.errorPatterns.set('no such file', 'find');
    this.errorPatterns.set('connection refused', 'systemctl status');
  }

  /**
   * Valide un chemin AVANT d'essayer d'y accéder
   */
  async validatePath(targetPath: string): Promise<ValidationResult> {
    const result: ValidationResult = {
      valid: false,
      exists: false,
      accessible: false,
      type: 'unknown',
      suggestions: []
    };

    try {
      // Normaliser le chemin
      const normalizedPath = path.resolve(targetPath);
      
      // Vérifier si existe
      const stats = await fs.stat(normalizedPath);
      result.exists = true;
      result.type = stats.isDirectory() ? 'directory' : 'file';
      
      // Vérifier si accessible en lecture
      await fs.access(normalizedPath, fs.constants.R_OK);
      result.accessible = true;
      result.valid = true;
      
    } catch (error: any) {
      result.error = error.message;
      
      // Générer des suggestions
      result.suggestions = await this.findSimilarPaths(targetPath);
      
      // Si c'est un problème de permission
      if (error.code === 'EACCES') {
        result.exists = true;
        result.suggestions.unshift(`Essayez avec sudo: sudo cat ${targetPath}`);
      }
      
      // Si le fichier n'existe pas, chercher des alternatives
      if (error.code === 'ENOENT') {
        const dirname = path.dirname(targetPath);
        const basename = path.basename(targetPath);
        
        // Chercher des fichiers similaires dans le répertoire parent
        try {
          const files = await fs.readdir(dirname);
          const similar = files.filter(f => 
            f.toLowerCase().includes(basename.toLowerCase().substring(0, 3)) ||
            this.levenshteinDistance(f, basename) < 3
          );
          
          result.suggestions.push(...similar.map(f => path.join(dirname, f)));
        } catch { /* ignore */ }
      }
    }
    
    return result;
  }

  /**
   * Trouve des chemins similaires sur le système
   */
  async findSimilarPaths(targetPath: string): Promise<string[]> {
    const suggestions: string[] = [];
    const basename = path.basename(targetPath);
    const dirname = path.dirname(targetPath);
    
    try {
      // Chercher avec find
      const { stdout } = await execAsync(
        `find /home/lalpha /var /etc /opt -maxdepth 4 -name "*${basename}*" 2>/dev/null | head -5`,
        { timeout: 5000 }
      );
      
      suggestions.push(...stdout.trim().split('\n').filter(Boolean));
    } catch { /* timeout ou erreur - ignorer */ }
    
    // Ajouter des suggestions basées sur les patterns connus
    for (const [category, paths] of this.commonPaths) {
      if (targetPath.toLowerCase().includes(category)) {
        suggestions.push(...paths.map(p => `${p}/${basename}`));
      }
    }
    
    return [...new Set(suggestions)].slice(0, 5);
  }

  /**
   * Corrige automatiquement une commande
   */
  async correctCommand(command: string): Promise<CorrectionResult> {
    const result: CorrectionResult = {
      original: command,
      corrected: command,
      corrections: [],
      confidence: 1.0,
      alternatives: []
    };

    // 1. Corriger les typos courants
    const typoCorrections: [RegExp, string][] = [
      [/\bgrpe\b/g, 'grep'],
      [/\bsystemclt\b/g, 'systemctl'],
      [/\bdoker\b/g, 'docker'],
      [/\bsudo\s+sudo\b/g, 'sudo'],
      [/\bcd\s+&&\s+cd\b/g, 'cd'],
      [/\bls\s+-la\s+-la\b/g, 'ls -la'],
    ];

    for (const [pattern, replacement] of typoCorrections) {
      if (pattern.test(result.corrected)) {
        result.corrected = result.corrected.replace(pattern, replacement);
        result.corrections.push(`Typo corrigé: ${pattern} → ${replacement}`);
      }
    }

    // 2. Vérifier les chemins dans la commande
    const pathPattern = /(?:^|\s)(\/[\w\/.+-]+)/g;
    let match;
    
    while ((match = pathPattern.exec(command)) !== null) {
      const pathInCommand = match[1];
      const validation = await this.validatePath(pathInCommand);
      
      if (!validation.exists && validation.suggestions.length > 0) {
        result.alternatives.push(
          `Chemin "${pathInCommand}" non trouvé. Alternatives: ${validation.suggestions.join(', ')}`
        );
        result.confidence *= 0.7;
      }
    }

    // 3. Vérifier si les commandes existent
    const firstWord = command.trim().split(/\s+/)[0];
    if (firstWord && !['cd', 'echo', 'export', 'alias'].includes(firstWord)) {
      try {
        await execAsync(`which ${firstWord}`, { timeout: 2000 });
      } catch {
        result.alternatives.push(`Commande "${firstWord}" non trouvée. Vérifiez l'installation.`);
        result.confidence *= 0.5;
        
        // Suggérer des commandes similaires
        const similar = await this.findSimilarCommands(firstWord);
        if (similar.length > 0) {
          result.alternatives.push(`Commandes similaires: ${similar.join(', ')}`);
        }
      }
    }

    return result;
  }

  /**
   * Trouve des commandes similaires
   */
  async findSimilarCommands(cmd: string): Promise<string[]> {
    try {
      const { stdout } = await execAsync(
        `compgen -c | grep -i "${cmd.substring(0, 3)}" | head -5 2>/dev/null || echo ""`,
        { timeout: 2000, shell: '/bin/bash' }
      );
      return stdout.trim().split('\n').filter(Boolean);
    } catch {
      return [];
    }
  }

  /**
   * Corrige automatiquement un nom de service Docker
   */
  async correctDockerService(serviceName: string): Promise<CorrectionResult> {
    const result: CorrectionResult = {
      original: serviceName,
      corrected: serviceName,
      corrections: [],
      confidence: 1.0,
      alternatives: []
    };

    try {
      // Lister les conteneurs
      const { stdout } = await execAsync('docker ps -a --format "{{.Names}}"');
      const containers = stdout.trim().split('\n').filter(Boolean);
      
      // Chercher une correspondance exacte
      if (containers.includes(serviceName)) {
        return result;
      }
      
      // Chercher des correspondances partielles
      const matches = containers.filter(c => 
        c.toLowerCase().includes(serviceName.toLowerCase()) ||
        serviceName.toLowerCase().includes(c.toLowerCase()) ||
        this.levenshteinDistance(c.toLowerCase(), serviceName.toLowerCase()) < 3
      );
      
      if (matches.length > 0) {
        result.corrected = matches[0];
        result.corrections.push(`Service corrigé: ${serviceName} → ${matches[0]}`);
        result.alternatives = matches.slice(1);
        result.confidence = 0.9;
      } else {
        result.alternatives = containers.slice(0, 5);
        result.confidence = 0.3;
        result.corrections.push(`Service "${serviceName}" non trouvé`);
      }
    } catch (error) {
      result.corrections.push(`Erreur Docker: ${error}`);
      result.confidence = 0;
    }

    return result;
  }

  /**
   * Auto-répare une erreur et réessaie
   */
  async autoRepairAndRetry<T>(
    operation: () => Promise<T>,
    errorHandler: (error: Error) => Promise<(() => Promise<T>) | null>,
    maxRetries: number = 3
  ): Promise<T> {
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error: any) {
        lastError = error;
        console.error(`Tentative ${attempt + 1}/${maxRetries} échouée:`, error.message);
        
        // Essayer de réparer
        const repairedOperation = await errorHandler(error);
        if (repairedOperation) {
          try {
            return await repairedOperation();
          } catch (repairError) {
            console.error('Réparation échouée:', repairError);
          }
        }
      }
    }
    
    throw lastError || new Error('Toutes les tentatives ont échoué');
  }

  /**
   * Distance de Levenshtein pour comparer les chaînes
   */
  private levenshteinDistance(a: string, b: string): number {
    const matrix: number[][] = [];
    
    for (let i = 0; i <= b.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= a.length; j++) {
      matrix[0][j] = j;
    }
    
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    
    return matrix[b.length][a.length];
  }
}
