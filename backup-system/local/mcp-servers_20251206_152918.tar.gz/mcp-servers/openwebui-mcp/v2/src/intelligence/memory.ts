/**
 * Système de Mémoire Intelligent v3.0
 * - Apprend des erreurs et succès
 * - Mémorise le contexte
 * - Stocke les solutions validées
 */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

export interface MemoryEntry {
  type: string;
  content: string;
  context?: string;
  result?: string;
  success?: boolean;
  tags?: string[];
}

export interface LearnedSolution {
  pattern: string;
  solution: string;
  confidence: number;
  successCount: number;
}

export class IntelligentMemory {
  private db: Database.Database;

  constructor(dbPath: string = '/tmp/mcp-memory.db') {
    // Créer le répertoire si nécessaire
    const dir = path.dirname(dbPath);
    
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      this.db = new Database(dbPath);
      console.error(`✅ Base mémoire ouverte: ${dbPath}`);
    } catch (error: any) {
      console.error(`⚠️ Fallback mémoire RAM: ${error.message}`);
      this.db = new Database(':memory:');
    }
    
    this.initializeDatabase();
  }

  private initializeDatabase() {
    this.db.exec(`
      -- Actions et leurs résultats
      CREATE TABLE IF NOT EXISTS actions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        type TEXT NOT NULL,
        command TEXT NOT NULL,
        context TEXT,
        result TEXT,
        success INTEGER DEFAULT 1,
        error_message TEXT,
        correction_applied TEXT
      );

      -- Solutions apprises par l'expérience
      CREATE TABLE IF NOT EXISTS solutions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        error_pattern TEXT NOT NULL UNIQUE,
        solution TEXT NOT NULL,
        success_count INTEGER DEFAULT 1,
        fail_count INTEGER DEFAULT 0,
        confidence REAL DEFAULT 0.6,
        last_used DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Chemins validés (existent réellement)
      CREATE TABLE IF NOT EXISTS valid_paths (
        path TEXT PRIMARY KEY,
        type TEXT,
        last_verified DATETIME DEFAULT CURRENT_TIMESTAMP,
        access_count INTEGER DEFAULT 1
      );

      -- Services Docker connus
      CREATE TABLE IF NOT EXISTS docker_services (
        name TEXT PRIMARY KEY,
        image TEXT,
        status TEXT,
        last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Statistiques d'utilisation des outils
      CREATE TABLE IF NOT EXISTS tool_stats (
        tool_name TEXT PRIMARY KEY,
        call_count INTEGER DEFAULT 0,
        success_count INTEGER DEFAULT 0,
        avg_duration_ms REAL DEFAULT 0,
        last_used DATETIME
      );

      CREATE INDEX IF NOT EXISTS idx_actions_type ON actions(type);
      CREATE INDEX IF NOT EXISTS idx_actions_success ON actions(success);
      CREATE INDEX IF NOT EXISTS idx_solutions_pattern ON solutions(error_pattern);
    `);
  }

  /**
   * Enregistre une action et son résultat
   */
  recordAction(action: {
    type: string;
    command: string;
    context?: string;
    result?: string;
    success: boolean;
    error?: string;
    correction?: string;
  }): number {
    const stmt = this.db.prepare(`
      INSERT INTO actions (type, command, context, result, success, error_message, correction_applied)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = stmt.run(
      action.type,
      action.command,
      action.context || null,
      action.result || null,
      action.success ? 1 : 0,
      action.error || null,
      action.correction || null
    );
    
    return Number(info.lastInsertRowid);
  }

  /**
   * Apprend une solution pour un pattern d'erreur
   */
  learnSolution(errorPattern: string, solution: string, success: boolean = true) {
    const existing = this.db.prepare(
      'SELECT * FROM solutions WHERE error_pattern = ?'
    ).get(errorPattern) as LearnedSolution | undefined;

    if (existing) {
      if (success) {
        this.db.prepare(`
          UPDATE solutions 
          SET success_count = success_count + 1,
              confidence = MIN(0.99, confidence + 0.05),
              last_used = CURRENT_TIMESTAMP
          WHERE error_pattern = ?
        `).run(errorPattern);
      } else {
        this.db.prepare(`
          UPDATE solutions 
          SET fail_count = fail_count + 1,
              confidence = MAX(0.1, confidence - 0.1),
              last_used = CURRENT_TIMESTAMP
          WHERE error_pattern = ?
        `).run(errorPattern);
      }
    } else {
      this.db.prepare(`
        INSERT INTO solutions (error_pattern, solution, confidence)
        VALUES (?, ?, 0.6)
      `).run(errorPattern, solution);
    }
  }

  /**
   * Cherche une solution apprise pour une erreur
   */
  findSolution(errorMessage: string): LearnedSolution | null {
    // Chercher une correspondance exacte
    let solution = this.db.prepare(`
      SELECT * FROM solutions 
      WHERE error_pattern = ? AND confidence > 0.4
      ORDER BY confidence DESC, success_count DESC
      LIMIT 1
    `).get(errorMessage) as LearnedSolution | undefined;

    if (solution) return solution;

    // Chercher une correspondance partielle
    solution = this.db.prepare(`
      SELECT * FROM solutions 
      WHERE ? LIKE '%' || error_pattern || '%' AND confidence > 0.4
      ORDER BY confidence DESC, success_count DESC
      LIMIT 1
    `).get(errorMessage) as LearnedSolution | undefined;

    return solution || null;
  }

  /**
   * Enregistre un chemin validé
   */
  recordValidPath(pathStr: string, type: 'file' | 'directory') {
    this.db.prepare(`
      INSERT OR REPLACE INTO valid_paths (path, type, last_verified, access_count)
      VALUES (?, ?, CURRENT_TIMESTAMP, 
        COALESCE((SELECT access_count + 1 FROM valid_paths WHERE path = ?), 1))
    `).run(pathStr, type, pathStr);
  }

  /**
   * Vérifie si un chemin était valide récemment
   */
  isPathKnownValid(pathStr: string): boolean {
    const result = this.db.prepare(`
      SELECT * FROM valid_paths 
      WHERE path = ? 
      AND datetime(last_verified) > datetime('now', '-1 hour')
    `).get(pathStr);
    
    return !!result;
  }

  /**
   * Met à jour les services Docker connus
   */
  updateDockerServices(services: Array<{ name: string; image: string; status: string }>) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO docker_services (name, image, status, last_seen)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    `);
    
    for (const svc of services) {
      stmt.run(svc.name, svc.image, svc.status);
    }
  }

  /**
   * Récupère les services Docker connus
   */
  getKnownDockerServices(): Array<{ name: string; image: string; status: string }> {
    return this.db.prepare(`
      SELECT name, image, status FROM docker_services
      ORDER BY last_seen DESC
    `).all() as Array<{ name: string; image: string; status: string }>;
  }

  /**
   * Enregistre l'utilisation d'un outil
   */
  recordToolUsage(toolName: string, durationMs: number, success: boolean) {
    this.db.prepare(`
      INSERT INTO tool_stats (tool_name, call_count, success_count, avg_duration_ms, last_used)
      VALUES (?, 1, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(tool_name) DO UPDATE SET
        call_count = call_count + 1,
        success_count = success_count + ?,
        avg_duration_ms = (avg_duration_ms * call_count + ?) / (call_count + 1),
        last_used = CURRENT_TIMESTAMP
    `).run(toolName, success ? 1 : 0, durationMs, success ? 1 : 0, durationMs);
  }

  /**
   * Récupère les actions similaires passées
   */
  findSimilarActions(command: string, limit: number = 5): any[] {
    return this.db.prepare(`
      SELECT * FROM actions
      WHERE command LIKE ? OR command LIKE ?
      ORDER BY timestamp DESC
      LIMIT ?
    `).all(`%${command}%`, `%${command.split(' ')[0]}%`, limit);
  }

  /**
   * Statistiques globales
   */
  getStats() {
    return {
      totalActions: this.db.prepare('SELECT COUNT(*) as c FROM actions').get(),
      successRate: this.db.prepare(`
        SELECT ROUND(100.0 * SUM(success) / COUNT(*), 2) as rate 
        FROM actions WHERE timestamp > datetime('now', '-7 days')
      `).get(),
      learnedSolutions: this.db.prepare('SELECT COUNT(*) as c FROM solutions').get(),
      validPaths: this.db.prepare('SELECT COUNT(*) as c FROM valid_paths').get(),
      topTools: this.db.prepare(`
        SELECT tool_name, call_count, success_count 
        FROM tool_stats ORDER BY call_count DESC LIMIT 5
      `).all()
    };
  }

  close() {
    this.db.close();
  }
}
