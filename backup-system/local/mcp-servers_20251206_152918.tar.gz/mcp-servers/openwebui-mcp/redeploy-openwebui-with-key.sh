#!/bin/bash
set -e

echo "🔄 Redéploiement d'Open WebUI avec la clé API Ollama..."

# Configuration
OLLAMA_API_KEY="6e1719ab31be41caa0f66f51681a072e.xl_VS6J785TUmjjyjmOgLB5s"
OLLAMA_BASE_URL="http://10.10.10.46:11434"

# Arrêter et supprimer le conteneur actuel
echo "🛑 Arrêt du conteneur Open WebUI..."
docker stop open-webui || true
docker rm open-webui || true

# Recréer avec la clé API et labels Traefik
echo "🚀 Démarrage d'Open WebUI avec la clé API..."
docker run -d \
  --name open-webui \
  --network traefik-net \
  --restart unless-stopped \
  -v open-webui:/app/backend/data \
  -e ENABLE_OLLAMA_API=true \
  -e OLLAMA_BASE_URL="$OLLAMA_BASE_URL" \
  -e OLLAMA_API_KEY="$OLLAMA_API_KEY" \
  -e USE_OLLAMA_DOCKER=false \
  -e WEBUI_SECRET_KEY=lalpha-secret-2024 \
  -l "traefik.enable=true" \
  -l "traefik.http.routers.openwebui.rule=Host(\`llm.4lb.ca\`)" \
  -l "traefik.http.routers.openwebui.entrypoints=websecure" \
  -l "traefik.http.routers.openwebui.tls.certresolver=letsencrypt" \
  -l "traefik.http.services.openwebui.loadbalancer.server.port=8080" \
  ghcr.io/open-webui/open-webui:main

echo ""
echo "✅ Open WebUI redémarré avec succès!"
echo ""
echo "🔑 Configuration appliquée:"
echo "   - Ollama Base URL: $OLLAMA_BASE_URL"
echo "   - API Key configurée: ${OLLAMA_API_KEY:0:20}..."
echo ""
echo "⏳ Attente du démarrage (10 secondes)..."
sleep 10

# Vérifier le statut
echo ""
echo "📊 Statut du conteneur:"
docker ps --filter "name=open-webui" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "✅ Les modèles cloud (kimi-k2, qwen3-coder) devraient maintenant fonctionner!"
echo "🌐 Accède à Open WebUI et teste un modèle cloud"
