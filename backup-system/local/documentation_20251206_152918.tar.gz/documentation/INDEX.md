# 📚 INDEX DOCUMENTATION

> **Chemin** : `/home/lalpha/documentation/`
> **Dernière mise à jour** : 6 décembre 2025

---

## 🏗️ Architecture

| Fichier | Description |
|---------|-------------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Vue complète de l'infrastructure IA |
| [CONTEXTE-SERVEUR.md](CONTEXTE-SERVEUR.md) | Prompt à copier pour les IA |
| [PROCEDURES-IA-SECURISEES.md](PROCEDURES-IA-SECURISEES.md) | Règles pour agents IA |

---

## 🤖 Agents IA

| Projet | URL | Description |
|--------|-----|-------------|
| **AI Orchestrator v2.0** | https://ai.4lb.ca | Agent autonome (26 outils, sélection auto, vision) |
| **Open WebUI** | https://llm.4lb.ca | Chat LLM rapide |
| **Code Server** | https://code.4lb.ca | VS Code + Cline + Continue |
| **MCP Servers** | - | 33 outils pour Claude Desktop |

---

## 📖 Guides Techniques

### IA & LLM
| Fichier | Description |
|---------|-------------|
| [AI-ORCHESTRATOR.md](guides/AI-ORCHESTRATOR.md) | 🆕 Guide Agent IA autonome v2.0 |
| [AGENT-4LB-GUIDE.md](guides/AGENT-4LB-GUIDE.md) | Guide Agent 4LB (legacy) |
| [INSTALLATION_LLM_GUIDE.md](guides/INSTALLATION_LLM_GUIDE.md) | Installation Ollama/CUDA |
| [INSTALLATION-CONTINUE-DEV.md](guides/INSTALLATION-CONTINUE-DEV.md) | Continue.dev (VS Code) |
| [SELF-IMPROVEMENT-BACKUP.md](guides/SELF-IMPROVEMENT-BACKUP.md) | 🆕 Auto-amélioration & Backups |

### Infrastructure
| Fichier | Description |
|---------|-------------|
| [SERVEUR_COMPLET.md](guides/SERVEUR_COMPLET.md) | Documentation serveur |
| [CODE-SERVER-GUIDE.md](guides/CODE-SERVER-GUIDE.md) | Guide code-server |
| [MCP-SERVER-UDM-PRO.md](guides/MCP-SERVER-UDM-PRO.md) | Serveurs MCP et UDM-Pro |
| [README-SECURITE.md](guides/README-SECURITE.md) | Guide sécurité |

---

## 📝 Comptes-rendus

| Fichier | Date | Description |
|---------|------|-------------|
| [SESSION-2025-12-05-AGENT-4LB.md](comptes-rendus/SESSION-2025-12-05-AGENT-4LB.md) | 05 déc | Validation Agent 4LB |
| [SESSION-2025-12-02-CONTINUE-DEV.md](comptes-rendus/SESSION-2025-12-02-CONTINUE-DEV.md) | 02 déc | Migration Continue.dev |
| [SESSION-2025-12-02-MIGRATION-ORICO.md](comptes-rendus/SESSION-2025-12-02-MIGRATION-ORICO.md) | 02 déc | Migration Ollama ORICO |
| [ANALYSE-INFRASTRUCTURE-2025-11-30.md](comptes-rendus/ANALYSE-INFRASTRUCTURE-2025-11-30.md) | 30 nov | Analyse infrastructure |
| [SESSION-2025-11-29-RESEAU.md](comptes-rendus/SESSION-2025-11-29-RESEAU.md) | 29 nov | Sécurisation réseau |

---

## 📦 Archives

| Fichier | Description |
|---------|-------------|
| [RAPPORT-ANALYSE-TRAEFIK.md](archives/RAPPORT-ANALYSE-TRAEFIK.md) | Analyse Traefik (résolu) |
| [RAPPORT-FINAL-FIXES-3DEC2025.md](archives/RAPPORT-FINAL-FIXES-3DEC2025.md) | Corrections 3 déc |

---

## 🌐 Architecture Réseau

```
Internet → Cloudflare CDN → UDM-Pro (192.168.1.1)
    │
    ├── VLAN 1  - Admin     (192.168.1.0/26)
    ├── VLAN 2  - Home      (10.10.10.0/25)   ← lalpha-server-1 (10.10.10.46)
    ├── VLAN 50 - Deeper    (172.16.50.0/28)
    ├── VLAN 60 - IoT       (172.16.60.60/27)
    └── VLAN 70 - Work      (172.16.70.0/29)
```

---

## 💾 Stockage

```
lalpha-server-1
├── nvme1n1 (Kingston 1.8 TB)  → Système (/) - 16% utilisé
└── nvme0n1 (ORICO 954 GB)     → Ollama (/mnt/ollama-models) - 9% utilisé
```

---

## 📌 Services Principaux

| Service | URL | Status |
|---------|-----|--------|
| AI Orchestrator | https://ai.4lb.ca | ✅ v2.0 |
| Open WebUI | https://llm.4lb.ca | ✅ |
| Code Server | https://code.4lb.ca | ✅ |
| Grafana | https://grafana.4lb.ca | ✅ |
| Prometheus | https://prometheus.4lb.ca | ✅ |
| Ollama | localhost:11434 | ✅ 9 modèles |

---

## 🔗 Liens Rapides

- **Projets** : `/home/lalpha/projets/`
- **AI Orchestrator** : `/home/lalpha/projets/ai-tools/ai-orchestrator/`
- **MCP Servers** : `/home/lalpha/projets/ai-tools/mcp-servers/`
- **Infrastructure** : `/home/lalpha/projets/infrastructure/4lb-docker-stack/`
- **Scripts** : `/home/lalpha/scripts/`

---

*Index mis à jour le 6 décembre 2025*
