# 🔌 MCP Servers - Architecture Complète

> **Date** : 1er décembre 2025  
> **Chemin MCP** : `/home/lalpha/projets/ai-tools/mcp-servers/`  
> **SDK Version** : 1.23.0

---

## 📍 Architecture MCP

```
┌─────────────────────────────────────────────────────────────────┐
│                       Claude Desktop                             │
│            ~/.config/Claude/claude_desktop_config.json           │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────┬───────┴───────┬─────────────┐
        ▼             ▼               ▼             ▼
┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ ubuntu-mcp  │ │ udm-pro-mcp │ │ filesystem  │ │ chromadb    │
│   v2.0.0    │ │   v2.0.0    │ │   v2.0.0    │ │   v2.0.0    │
│ (12 outils) │ │ (8 outils)  │ │ (4 outils)  │ │ (9 outils)  │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
      │               │               │               │
      ▼               ▼               ▼               ▼
 Ubuntu Server     UDM-Pro       Filesystem       ChromaDB
 (10.10.10.46)   (10.10.10.1)     (local)      (localhost:8000)
                    SSH
```

---

## 🔧 Configuration Claude Desktop

**Fichier** : `/home/lalpha/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "ubuntu-server": {
      "command": "node",
      "args": [
        "/home/lalpha/projets/ai-tools/mcp-servers/ubuntu-mcp/dist/index.js"
      ],
      "env": {
        "HOME": "/home/lalpha",
        "USER": "lalpha",
        "SHELL": "/bin/bash",
        "PERSIST_SESSION": "true"
      }
    },
    "filesystem": {
      "command": "node",
      "args": [
        "/home/lalpha/projets/ai-tools/mcp-servers/filesystem-mcp/dist/index.js"
      ],
      "env": {
        "HOME": "/home/lalpha",
        "USER": "lalpha"
      }
    },
    "udm-pro": {
      "command": "node",
      "args": [
        "/home/lalpha/projets/ai-tools/mcp-servers/udm-pro-mcp/dist/index.js"
      ]
    },
    "chromadb": {
      "command": "node",
      "args": [
        "/home/lalpha/projets/ai-tools/mcp-servers/chromadb-mcp/dist/index.js"
      ],
      "env": {
        "CHROMA_HOST": "localhost",
        "CHROMA_PORT": "8000"
      }
    }
  }
}
```

---

## 📁 Chemins des Serveurs MCP

| Serveur | Chemin | SDK |
|---------|--------|-----|
| ubuntu-server | `/home/lalpha/projets/ai-tools/mcp-servers/ubuntu-mcp/` | 1.23.0 |
| udm-pro | `/home/lalpha/projets/ai-tools/mcp-servers/udm-pro-mcp/` | 1.23.0 |
| filesystem | `/home/lalpha/projets/ai-tools/mcp-servers/filesystem-mcp/` | 1.23.0 |
| chromadb | `/home/lalpha/projets/ai-tools/mcp-servers/chromadb-mcp/` | 1.23.0 |

---

## 🛠️ Outils MCP Disponibles

### ubuntu-server (Serveur local)

| Outil | Description |
|-------|-------------|
| `system_info` | Infos système (CPU, RAM, disque, OS, network) |
| `list_processes` | Processus en cours avec CPU/mémoire |
| `execute_command` | Exécuter une commande bash |
| `service_status` | Statut d'un service systemd |
| `service_control` | Contrôler un service (start/stop/restart) |
| `disk_usage` | Analyse disque par répertoire |
| `network_info` | Informations réseau |
| `log_analyzer` | Analyser les logs système |
| `docker_status` | Statut des conteneurs Docker |
| `file_search` | Rechercher des fichiers |
| `security_check` | Vérification sécurité |
| `backup_manager` | Gestion des sauvegardes |

### udm-pro (UDM-Pro via SSH)

| Outil | Description |
|-------|-------------|
| `udm_connection_test` | Tester la connexion SSH |
| `udm_exec` | Exécuter une commande |
| `udm_status` | Statut complet du UDM |
| `udm_network_info` | Infos réseau (VLANs, clients) |
| `udm_device_list` | Appareils UniFi gérés |
| `udm_logs` | Logs système |
| `udm_backup_config` | Sauvegarder la config |
| `udm_firewall_rules` | Règles firewall |

### filesystem (Analyse fichiers)

| Outil | Description |
|-------|-------------|
| `analyze_directory` | Fichiers inutilisés |
| `find_duplicates` | Fichiers dupliqués |
| `check_dependencies` | Dépendances non utilisées |
| `disk_usage` | Utilisation disque |

### chromadb (Base vectorielle)

| Outil | Description |
|-------|-------------|
| `chroma_list_collections` | Lister les collections |
| `chroma_create_collection` | Créer une collection |
| `chroma_delete_collection` | Supprimer une collection |
| `chroma_add_documents` | Ajouter des documents |
| `chroma_query` | Recherche sémantique |
| `chroma_get_documents` | Récupérer documents par ID |
| `chroma_delete_documents` | Supprimer documents |
| `store_memory` | Stocker un souvenir |
| `recall_memory` | Rappeler des souvenirs |

---

## 🔐 Connexion SSH au UDM-Pro

### Paramètres

| Paramètre | Valeur |
|-----------|--------|
| **Hôte** | 10.10.10.1 |
| **Port** | 22 |
| **Utilisateur** | root |
| **Authentification** | Clé SSH RSA |

### Clé SSH

| Fichier | Chemin |
|---------|--------|
| **Clé privée** | `/home/lalpha/.ssh/id_rsa_udm` |
| **Clé publique** | `/home/lalpha/.ssh/id_rsa_udm.pub` |

### Test manuel

```bash
ssh -i ~/.ssh/id_rsa_udm root@10.10.10.1
```

---

## 📊 Requêtes MongoDB UDM-Pro

### Accès à la base

```bash
mongo --quiet --port 27117 ace --eval '<QUERY>'
```

### Requêtes utiles

```javascript
// Lister les réseaux
db.networkconf.find({}, {name: 1, vlan: 1, ip_subnet: 1}).forEach(printjson)

// Lister les clients
db.user.find({}, {name: 1, mac: 1, ip: 1}).forEach(printjson)

// Règles firewall actives
db.firewall_policy.find({enabled: true}, {name: 1, action: 1}).forEach(printjson)

// Configuration WireGuard
db.networkconf.find({purpose: "remote-user-vpn"}).forEach(printjson)
```

---

## 🚀 Démarrage Rapide

### 1. Vérifier Claude Desktop

Les MCP servers sont lancés automatiquement par Claude Desktop.

### 2. Tester les connexions

Dans Claude, demander :
- "Teste la connexion au UDM-Pro"
- "Montre les infos système du serveur"
- "Liste les collections ChromaDB"

### 3. Tests manuels

```bash
# Test SSH UDM-Pro
ssh -i ~/.ssh/id_rsa_udm root@10.10.10.1 "echo OK"

# Test ChromaDB
curl http://localhost:8000/api/v2/heartbeat

# Test MCP ubuntu-server
timeout 5 node /home/lalpha/projets/ai-tools/mcp-servers/ubuntu-mcp/dist/index.js
```

---

## 🔧 Dépannage

### Connexion UDM-Pro échoue

```bash
# Tester SSH
ssh -i ~/.ssh/id_rsa_udm -o ConnectTimeout=5 root@10.10.10.1 "echo OK"

# Vérifier permissions clé
chmod 600 ~/.ssh/id_rsa_udm
```

### MCP Server ne démarre pas

```bash
# Recompiler
cd /home/lalpha/projets/ai-tools/mcp-servers/<server>
npm run build

# Tester
node dist/index.js
```

### Recompiler tous les MCP

```bash
for server in ubuntu-mcp udm-pro-mcp filesystem-mcp chromadb-mcp; do
  echo "Building $server..."
  cd /home/lalpha/projets/ai-tools/mcp-servers/$server
  npm run build
done
```

---

## 📁 Structure des Fichiers

```
/home/lalpha/projets/ai-tools/mcp-servers/
├── ubuntu-mcp/
│   ├── src/index.ts
│   ├── dist/index.js
│   └── package.json
├── udm-pro-mcp/
│   ├── src/index.ts
│   ├── dist/index.js
│   └── package.json
├── filesystem-mcp/
│   ├── src/index.ts
│   ├── dist/index.js
│   └── package.json
├── chromadb-mcp/
│   ├── src/index.ts
│   ├── dist/index.js
│   └── package.json
└── openwebui-mcp/        # MCP Server Docker v3.0
    └── v2/
        ├── src/
        │   ├── index.ts
        │   └── intelligence/
        ├── dist/
        └── Dockerfile
```

---

*Documentation mise à jour le 1er décembre 2025*
