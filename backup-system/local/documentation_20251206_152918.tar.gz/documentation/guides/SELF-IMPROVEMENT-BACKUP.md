# 🧠💾 Modules Self-Improvement & Backup

> **Date** : 6 décembre 2025
> **Statut** : ✅ Opérationnels

---

## 🧠 Self-Improvement Analyzer

### Description
Module d'auto-amélioration qui analyse les métriques système et génère des recommandations via LLM local.

### Emplacement
```
/home/lalpha/projets/ai-tools/self-improvement/
├── analyzer.py      # Script principal
├── setup.sh         # Installation
├── README.md        # Documentation
└── reports/         # Rapports JSON
```

### Utilisation
```bash
# Analyse complète
python3 analyzer.py

# Analyse rapide (sans Loki)
python3 analyzer.py --quick
```

### Automatisation
- **Cron** : Tous les jours à 6h00
- **Logs** : `cron.log`

### Métriques collectées
- CPU, RAM, Disque (système + Ollama)
- GPU (utilisation + mémoire)
- Conteneurs Docker
- Logs d'erreurs (Loki)

### Sortie
- Score de santé (0-100)
- Status (healthy/warning/critical)
- Liste des problèmes avec recommandations
- Optimisations suggérées

---

## 💾 Backup System

### Description
Système de sauvegarde automatique pour l'infrastructure critique.

### Emplacement
```
/home/lalpha/projets/ai-tools/backup-system/
├── backup.py        # Script principal
├── README.md        # Documentation
└── local/           # Backups locaux
```

### Éléments sauvegardés
| Élément | Type | Contenu |
|---------|------|---------|
| docker-compose | Directory | Stack Docker |
| ai-orchestrator | Directory | Agent IA v2.0 |
| mcp-servers | Directory | 33 outils MCP |
| documentation | Directory | Docs |
| scripts | Directory | Scripts |
| postgres | Database | PostgreSQL |

### Utilisation
```bash
# Backup local
python3 backup.py

# Avec nettoyage (>7 jours)
python3 backup.py --cleanup

# Avec upload S3
python3 backup.py --upload
```

### Automatisation
- **Cron** : Tous les jours à 3h00
- **Logs** : `cron.log`

### Configuration S3 (optionnel)
```bash
export S3_ENDPOINT="https://xxx.r2.cloudflarestorage.com"
export S3_ACCESS_KEY="..."
export S3_SECRET_KEY="..."
export S3_BUCKET="lalpha-backups"
```

---

## ⏰ Crons Actifs

| Heure | Module | Description |
|-------|--------|-------------|
| 3h00 | Backup | Sauvegarde quotidienne |
| 6h00 | Self-Improvement | Analyse système |

---

## 📊 Workflow Quotidien

```
03:00  💾 Backup System
        → Sauvegarde configs, code, DB
        → Nettoyage anciens backups
        → (Optionnel) Upload S3

06:00  🧠 Self-Improvement
        → Collecte métriques Prometheus
        → Analyse conteneurs Docker
        → Génération recommandations LLM
        → Rapport JSON
```

---

*Documentation créée le 6 décembre 2025*
