# 🏗️ Architecture Infrastructure IA - lalpha-server-1

> **Dernière mise à jour** : 6 décembre 2025
> **Serveur** : Ubuntu 25.10 (Oracular)
> **Domaine** : 4lb.ca

---

## 📊 Vue d'ensemble

```
                              Internet
                                  │
                                  ▼
                    ┌─────────────────────────┐
                    │   Cloudflare CDN/WAF    │
                    └─────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Traefik v3.0 (Reverse Proxy)                  │
│                    Ports: 80, 443, 8080                          │
│                    SSL: Let's Encrypt                            │
└──────────────────────────────────────────────────────────────────┘
          │              │              │              │
          ▼              ▼              ▼              ▼
    ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
    │   AI     │  │  Open    │  │  Code    │  │ Grafana  │
    │Orchestr. │  │  WebUI   │  │ Server   │  │          │
    │ai.4lb.ca │  │llm.4lb.ca│  │code.4lb  │  │grafana.  │
    └──────────┘  └──────────┘  └──────────┘  └──────────┘
          │              │
          ▼              ▼
    ┌──────────────────────────────────────┐
    │           Ollama (LLM)               │
    │           Port: 11434                │
    │      GPU: RTX 5070 Ti (16GB)         │
    │      9 modèles (~78 GB)              │
    └──────────────────────────────────────┘
```

---

## 🖥️ Spécifications Serveur

| Composant | Spécification |
|-----------|---------------|
| **CPU** | AMD Ryzen 9 7900X (12 cores, 24 threads) @ 5.74 GHz |
| **GPU** | NVIDIA GeForce RTX 5070 Ti - 16 GB VRAM |
| **RAM** | 64 GB DDR5 |
| **Stockage Système** | NVMe Kingston 1.8 TB (nvme1n1) - 16% utilisé |
| **Stockage Ollama** | NVMe ORICO 954 GB (nvme0n1) - 9% utilisé |
| **OS** | Ubuntu 25.10 (Oracular) |
| **Kernel** | 6.17.0-7-generic |
| **IP Locale** | 10.10.10.46 (VLAN 2 - Home) |

---

## 🐳 Services Docker Actifs

### Stack Principale (4lb-docker-stack)

| Conteneur | Image | Ports | Rôle |
|-----------|-------|-------|------|
| **traefik** | traefik:v3.0 | 80, 443, 8080 | Reverse proxy, SSL |
| **code-server** | custom | 8443 | VS Code + Cline + Continue |
| **grafana** | grafana/grafana | 3001 | Dashboards |
| **prometheus** | prom/prometheus | 9090 | Métriques |
| **postgres** | postgres:16-alpine | 5432 | Base données |
| **redis** | redis:7-alpine | 6379 | Cache |
| **loki** | grafana/loki | 3100 | Logs centralisés |
| **promtail** | grafana/promtail | - | Collecteur logs |
| **cadvisor** | cadvisor | - | Métriques conteneurs |
| **node-exporter** | prom/node-exporter | - | Métriques système |
| **nvidia-exporter** | nvidia/dcgm-exporter | - | Métriques GPU |

### Stack IA

| Conteneur | Image | Rôle |
|-----------|-------|------|
| **ai-orchestrator-backend** | custom | Agent IA autonome (FastAPI) |
| **ai-orchestrator-frontend** | nginx:alpine | Interface web ai.4lb.ca |
| **open-webui** | open-webui:main | Chat LLM llm.4lb.ca |

---

## 🌐 URLs et Accès

### URLs Publiques (HTTPS)

| Service | URL | Description |
|---------|-----|-------------|
| **Agent IA** | https://ai.4lb.ca | 🆕 Orchestrateur autonome v2.0 |
| **Open WebUI** | https://llm.4lb.ca | Chat IA rapide |
| **Code Server** | https://code.4lb.ca | VS Code web |
| **Grafana** | https://grafana.4lb.ca | Dashboards |
| **Prometheus** | https://prometheus.4lb.ca | Métriques |
| **JSR** | https://jsr.4lb.ca | Site client |

### URLs Locales

| Service | URL | Port |
|---------|-----|------|
| Ollama | http://localhost:11434 | 11434 |
| Prometheus | http://localhost:9090 | 9090 |
| Grafana | http://localhost:3001 | 3001 |

---

## 🤖 Stack LLM

### Ollama

**Port** : 11434  
**GPU** : RTX 5070 Ti (16 GB VRAM)  
**Stockage** : `/mnt/ollama-models` (disque ORICO avec dissipateur)

#### Modèles Installés

| Modèle | Taille | Usage |
|--------|--------|-------|
| qwen2.5-coder:32b | 18 GB | Code (principal) |
| deepseek-coder:33b | 17 GB | Code (alternatif) |
| qwen3-vl:32b | 19 GB | Vision multimodale |
| llama3.2-vision:11b | 11 GB | Vision + texte |
| gpt-oss-safeguard | 12 GB | Sécurité |
| nomic-embed-text | 274 MB | Embeddings RAG |

**Total** : ~78 GB / 870 GB disponibles

### AI Orchestrator v2.0 (ai.4lb.ca)

**26 outils intégrés** :
- Système : execute_command, system_info, disk_usage, service_status/control
- Fichiers : read_file, write_file, list_directory, search_files
- Docker : docker_status, docker_logs, docker_restart
- Réseau (UDM-Pro) : udm_status, udm_network_info, udm_clients
- LLM : ollama_list, ollama_run
- Mémoire : memory_store, memory_recall

**Fonctionnalités** :
- ✅ Sélection automatique de modèle (AUTO)
- ✅ Upload fichiers et images
- ✅ Analyse d'images avec vision
- ✅ Historique des conversations (SQLite)
- ✅ Boucle ReAct autonome
- ✅ WebSocket temps réel

---

## 🔌 Serveurs MCP (Model Context Protocol)

### Architecture MCP

```
┌─────────────────────────────────────────────────────────────┐
│              Claude Desktop + Continue.dev                   │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────┬───────┴───────┬─────────────┐
        ▼             ▼               ▼             ▼
┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ ubuntu-mcp  │ │ udm-pro-mcp │ │ filesystem  │ │  chromadb   │
│ (12 outils) │ │ (8 outils)  │ │ (4 outils)  │ │ (9 outils)  │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
```

**Total : 33 outils MCP** disponibles pour Claude Desktop et Continue.dev

---

## 📊 Monitoring

### Stack Complète

| Service | Port | Rôle |
|---------|------|------|
| Prometheus | 9090 | Collecte métriques |
| Grafana | 3001 | Visualisation |
| Loki | 3100 | Agrégation logs |
| Promtail | - | Collecteur logs |
| cAdvisor | - | Métriques Docker |
| Node Exporter | 9100 | Métriques système |
| NVIDIA Exporter | - | Métriques GPU |

---

## 💾 Bases de Données

| Instance | Port | Usage |
|----------|------|-------|
| PostgreSQL | 5432 | Applications |
| Redis | 6379 | Cache |
| SQLite | - | AI Orchestrator (conversations) |

---

## 📁 Structure des Dossiers

```
/home/lalpha/
├── projets/
│   ├── ai-tools/
│   │   ├── ai-orchestrator/      # 🆕 Agent IA autonome v2.0
│   │   └── mcp-servers/          # Serveurs MCP (33 outils)
│   ├── clients/
│   │   └── jsr/                  # Projet client
│   └── infrastructure/
│       ├── 4lb-docker-stack/     # Stack Docker principale
│       └── ai-infrastructure/    # Open WebUI
├── scripts/
│   ├── docker/                   # Scripts déploiement
│   └── backup/                   # Scripts backup
└── documentation/                # Cette documentation
```

---

## 🚀 Commandes Utiles

### Docker
```bash
docker ps -a                              # État conteneurs
docker logs -f <container>                # Logs
~/scripts/docker/deploy_4lb_stack.sh      # Déploiement sécurisé
~/scripts/docker/check_4lb_stack.sh       # Vérification
```

### Ollama
```bash
ollama list                               # Modèles
ollama run qwen2.5-coder:32b              # Lancer modèle
curl http://localhost:11434/api/tags      # API
```

### AI Orchestrator
```bash
curl https://ai.4lb.ca/health             # Statut
curl https://ai.4lb.ca/tools              # Liste outils
```

---

*Documentation mise à jour le 6 décembre 2025*
