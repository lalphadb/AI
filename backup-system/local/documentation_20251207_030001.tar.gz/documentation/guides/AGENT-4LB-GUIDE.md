# 🧠 Guide Agent 4LB - Agent IA Autonome

> **Date** : 5 décembre 2025  
> **Statut** : ✅ 100% Fonctionnel  
> **Emplacement** : `/home/lalpha/projets/ai-tools/agent-4lb/`

---

## 🎯 Concept

L'Agent 4LB est un **agent IA autonome** qui utilise le pattern ReAct :

```
Tu parles → Il réfléchit → Il agit → Il observe → Il répète → Il répond
```

**C'est comme parler avec Claude, mais il peut exécuter des commandes sur ton serveur.**

---

## 🚀 Démarrage Rapide

### CLI Interactif
```bash
cd /home/lalpha/projets/ai-tools/agent-4lb
./agent.sh

# Exemples de commandes :
[TASK] > Liste les conteneurs Docker actifs
[TASK] > Vérifie l'espace disque
[TASK] > Montre les logs de Traefik des 5 dernières minutes
```

### API REST
```bash
./start-api.sh
# API disponible sur http://localhost:8889
# Documentation Swagger : http://localhost:8889/docs
```

---

## ⚙️ Configuration

### Fichier : `core/config.py`

| Variable | Valeur | Description |
|----------|--------|-------------|
| `OLLAMA_HOST` | http://localhost:11434 | Serveur Ollama |
| `OLLAMA_MODEL` | qwen2.5-coder:32b-instruct-q4_K_M | Modèle LLM |
| `OLLAMA_TEMPERATURE` | 0.1 | Créativité (bas = précis) |
| `AGENT_MAX_ITERATIONS` | 15 | Limite de boucles |
| `API_PORT` | 8889 | Port de l'API |

### Variables d'environnement

```bash
# Utiliser Claude au lieu d'Ollama
export DEFAULT_LLM=claude
export ANTHROPIC_API_KEY=sk-ant-...

# Changer le modèle Ollama
export OLLAMA_MODEL=deepseek-coder:33b
```

---

## 🔧 15 Outils Disponibles

### Système
| Outil | Usage |
|-------|-------|
| `execute_command` | Exécuter une commande bash |
| `read_file` | Lire un fichier |
| `write_file` | Écrire dans un fichier |
| `list_directory` | Lister un dossier |
| `search_files` | Chercher des fichiers |
| `system_info` | Infos CPU, RAM, GPU |

### Docker
| Outil | Usage |
|-------|-------|
| `docker_ps` | Lister les conteneurs |
| `docker_logs` | Voir les logs |
| `docker_restart` | Redémarrer un conteneur |

### Git
| Outil | Usage |
|-------|-------|
| `git_status` | Statut du repo |
| `git_commit` | Commiter des changements |

### Autres
| Outil | Usage |
|-------|-------|
| `service_status` | Statut systemd |
| `check_url` | Tester une URL |
| `ollama_list` | Lister les modèles |
| `ollama_run` | Exécuter un prompt |

---

## 💡 Exemples d'Utilisation

### Tâches simples
```
Liste les conteneurs Docker actifs
Vérifie l'espace disque
Montre les infos système
```

### Tâches moyennes
```
Vérifie les logs de Traefik et identifie les erreurs
Crée un script qui sauvegarde PostgreSQL
Analyse l'utilisation mémoire des conteneurs
```

### Tâches complexes
```
Analyse les performances du serveur, identifie les goulots d'étranglement et propose des optimisations
Crée un système de monitoring qui vérifie tous les conteneurs et envoie des alertes
```

---

## 📡 API Endpoints

### Exécuter une tâche
```bash
curl -X POST http://localhost:8889/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Liste les conteneurs Docker"}'
```

### Mode conversation
```bash
curl -X POST http://localhost:8889/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Bonjour!", "session_id": "test123"}'
```

### Statut
```bash
curl http://localhost:8889/status
```

### Historique
```bash
curl http://localhost:8889/history
```

---

## 🧠 Comment ça marche

### Boucle ReAct

```
1. USER: "Liste les conteneurs Docker"

2. AGENT THINK: "Je dois utiliser docker_ps pour lister les conteneurs"

3. AGENT ACT: docker_ps({})

4. OBSERVE: "NAMES: traefik, open-webui, grafana..."

5. AGENT THINK: "J'ai la liste, je peux répondre"

6. FINAL: "Voici les conteneurs actifs: traefik, open-webui..."
```

### Format JSON interne

```json
{
  "thought": "Je réfléchis à ce qu'il faut faire",
  "action": "docker_ps",
  "action_input": {"all_containers": false}
}
```

---

## 💾 Mémoire Persistante

L'agent stocke dans SQLite (`memory/agent_memory.db`) :

| Table | Contenu |
|-------|---------|
| `conversations` | Historique des échanges par session |
| `tasks` | Tâches exécutées avec résultats |
| `knowledge` | Connaissances apprises |
| `errors` | Erreurs pour auto-amélioration |

---

## 🔍 Dépannage

### Erreur 404 Ollama
```bash
# Vérifier les modèles disponibles
curl http://localhost:11434/api/tags

# Le modèle doit être exactement celui dans config.py
```

### Agent trop lent
```bash
# Utiliser un modèle plus petit
export OLLAMA_MODEL=qwen2.5-coder:7b
```

### Agent boucle sans fin
```bash
# Réduire le nombre d'itérations
export AGENT_MAX_ITERATIONS=5
```

---

## 🆚 Agent 4LB vs Orchestrateur 4LB

| | Agent 4LB | Orchestrateur 4LB |
|--|-----------|-------------------|
| **Usage** | Interactif, à la demande | Automatisé, planifié |
| **Mode** | Tu parles, il exécute | Cron jobs, scripts |
| **Port** | 8889 | 8888 |
| **Emplacement** | `agent-4lb/` | `orchestrator-4lb/` |

**Tu peux utiliser les deux !**
- Agent pour les tâches ponctuelles
- Orchestrateur pour l'automatisation

---

## 📚 Fichiers Clés

```
agent-4lb/
├── core/
│   ├── config.py      # ⚙️ Configuration
│   └── agent.py       # 🧠 Logique agent
├── tools/
│   └── system_tools.py # 🔧 15 outils
├── memory/
│   └── persistent.py  # 💾 SQLite
├── api/
│   └── server.py      # 📡 FastAPI
├── cli.py             # 💻 Interface CLI
├── agent.sh           # 🚀 Lancer CLI
└── start-api.sh       # 🚀 Lancer API
```

---

*Guide créé le 5 décembre 2025*
