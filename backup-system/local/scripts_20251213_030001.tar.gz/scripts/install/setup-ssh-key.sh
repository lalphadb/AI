#!/bin/bash
# Configuration d'une clé SSH sécurisée

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          Configuration Clé SSH                            ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Vérifier si une clé existe déjà
if [ -f "$HOME/.ssh/id_ed25519" ] || [ -f "$HOME/.ssh/id_rsa" ]; then
    echo -e "${GREEN}✓ Une clé SSH existe déjà${NC}"
    echo ""
    echo "Clés trouvées:"
    ls -lh ~/.ssh/id_* 2>/dev/null | grep -v ".pub"
    echo ""
    
    read -p "Voulez-vous créer une nouvelle clé ? [o/N] " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Oo]$ ]]; then
        echo "Utilisation de la clé existante."
        exit 0
    fi
fi

# Créer le dossier .ssh si nécessaire
mkdir -p ~/.ssh
chmod 700 ~/.ssh

echo ""
echo -e "${YELLOW}Génération d'une clé SSH Ed25519 (recommandé)${NC}"
echo ""
read -p "Entrez votre email pour identifier la clé: " email

if [ -z "$email" ]; then
    email="$USER@$(hostname)"
fi

# Générer la clé
ssh-keygen -t ed25519 -C "$email" -f ~/.ssh/id_ed25519

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Clé SSH générée avec succès !${NC}"
    echo ""
    echo -e "${YELLOW}Votre clé publique:${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    cat ~/.ssh/id_ed25519.pub
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    # Ajouter à authorized_keys
    cat ~/.ssh/id_ed25519.pub >> ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
    
    echo -e "${GREEN}✓ Clé ajoutée à ~/.ssh/authorized_keys${NC}"
    echo ""
    
    # Instructions
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}PROCHAINES ÉTAPES:${NC}"
    echo ""
    echo "1. Copiez la clé publique ci-dessus"
    echo ""
    echo "2. Sur votre machine cliente, créez le fichier:"
    echo "   ${CYAN}~/.ssh/id_ed25519${NC} (clé privée)"
    echo "   ${CYAN}~/.ssh/id_ed25519.pub${NC} (clé publique)"
    echo ""
    echo "3. OU utilisez cette commande depuis votre machine:"
    echo "   ${CYAN}ssh-copy-id -i ~/.ssh/id_ed25519.pub $USER@10.10.10.46${NC}"
    echo ""
    echo "4. Testez la connexion:"
    echo "   ${CYAN}ssh -i ~/.ssh/id_ed25519 $USER@10.10.10.46${NC}"
    echo ""
    echo "5. Une fois le test réussi, désactivez l'auth par mot de passe:"
    echo "   ${CYAN}sudo nano /etc/ssh/sshd_config.d/99-hardening.conf${NC}"
    echo "   Décommentez: ${RED}PasswordAuthentication no${NC}"
    echo "   ${CYAN}sudo systemctl restart sshd${NC}"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
else
    echo -e "${RED}✗ Erreur lors de la génération de la clé${NC}"
    exit 1
fi
