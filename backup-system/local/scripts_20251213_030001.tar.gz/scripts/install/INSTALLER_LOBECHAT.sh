#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║           INSTALLER LOBECHAT (Meilleur qu'OpenWebUI)         ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

cd /home/lalpha/projets/traefik-config

# Arrêter Open WebUI
docker-compose down

# Créer nouveau docker-compose avec LobeChat
cat > docker-compose.yml << 'EOFCOMPOSE'
version: '3.8'

services:
  traefik:
    image: traefik:v3.1
    container_name: traefik
    restart: unless-stopped
    security_opt:
      - no-new-privileges:true
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - ./traefik.yml:/etc/traefik/traefik.yml:ro
      - ./dynamic.yml:/etc/traefik/dynamic.yml:ro
      - ./acme.json:/acme.json
    networks:
      - traefik-net
      - 4lbca_frontend
      - 4lbca_backend
      - 4lbca_llm
      - 4lbca_monitoring

  lobechat:
    image: lobehub/lobe-chat:latest
    container_name: lobechat
    restart: unless-stopped
    ports:
      - "3210:3210"
    environment:
      - OLLAMA_PROXY_URL=http://10.10.10.46:11434
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.lobechat.rule=Host(\`llm.4lb.ca\`)"
      - "traefik.http.routers.lobechat.entrypoints=websecure"
      - "traefik.http.routers.lobechat.tls.certresolver=letsencrypt"
      - "traefik.http.services.lobechat.loadbalancer.server.port=3210"
    networks:
      - traefik-net

networks:
  traefik-net:
    external: true
  4lbca_frontend:
    external: true
  4lbca_backend:
    external: true
  4lbca_llm:
    external: true
  4lbca_monitoring:
    external: true
EOFCOMPOSE

docker-compose up -d

echo ""
echo "✅ LobeChat installé!"
echo "   URL: https://llm.4lb.ca"
echo ""
echo "Configuration:"
echo "   1. Ouvrir https://llm.4lb.ca"
echo "   2. Aller dans Settings"
echo "   3. Ollama est déjà configuré automatiquement!"
echo "   4. Vos 2 modèles apparaîtront directement!"
