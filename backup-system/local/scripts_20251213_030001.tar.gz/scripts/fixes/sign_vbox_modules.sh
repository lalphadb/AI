#!/bin/bash

echo "=== Signature des modules VirtualBox pour Secure Boot ==="
echo ""

# Vérifier si on est root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Ce script doit être exécuté avec sudo"
    exit 1
fi

# Créer le répertoire pour les clés
echo "1. Création du répertoire pour les clés..."
mkdir -p /var/lib/shim-signed/mok
cd /var/lib/shim-signed/mok

# Générer une paire de clés si elle n'existe pas déjà
if [ ! -f MOK.priv ]; then
    echo "2. Génération de la paire de clés (cela peut prendre quelques secondes)..."
    openssl req -new -x509 -newkey rsa:2048 -keyout MOK.priv -outform DER -out MOK.der -nodes -days 36500 -subj "/CN=VirtualBox Module Signing Key/"
    chmod 600 MOK.priv
    echo "✅ Clés générées"
else
    echo "2. Clés existantes trouvées"
fi

# Trouver les modules VirtualBox
echo "3. Recherche des modules VirtualBox..."
KERNEL_VERSION=$(uname -r)
echo "   Kernel version: $KERNEL_VERSION"

# Signer les modules
echo "4. Signature des modules..."
for module in vboxdrv vboxnetflt vboxnetadp vboxpci; do
    MODULE_PATH=$(modinfo -n $module 2>/dev/null)
    if [ -n "$MODULE_PATH" ] && [ -f "$MODULE_PATH" ]; then
        echo "   📝 Signature de $module ($MODULE_PATH)..."
        /usr/src/linux-headers-$KERNEL_VERSION/scripts/sign-file sha256 \
            /var/lib/shim-signed/mok/MOK.priv \
            /var/lib/shim-signed/mok/MOK.der \
            "$MODULE_PATH"
        if [ $? -eq 0 ]; then
            echo "   ✅ $module signé avec succès"
        else
            echo "   ❌ Erreur lors de la signature de $module"
        fi
    else
        echo "   ⚠️  Module $module non trouvé"
    fi
done

echo ""
echo "5. Import de la clé dans MOK (Machine Owner Key)..."
echo "   Vous allez devoir créer un mot de passe temporaire (8-16 caractères)"
mokutil --import /var/lib/shim-signed/mok/MOK.der

echo ""
echo "============================================"
echo "✅ SIGNATURE TERMINÉE"
echo ""
echo "PROCHAINES ÉTAPES IMPORTANTES :"
echo "1. Redémarrez votre serveur : sudo reboot"
echo "2. Au redémarrage, un écran bleu 'MOK Management' apparaîtra"
echo "3. Sélectionnez 'Enroll MOK'"
echo "4. Sélectionnez 'Continue'"
echo "5. Sélectionnez 'Yes'"
echo "6. Entrez le mot de passe que vous venez de créer"
echo "7. Sélectionnez 'Reboot'"
echo ""
echo "Après le redémarrage, les modules VirtualBox se chargeront automatiquement."
echo "============================================"
