#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║     RECRÉER OPEN WEBUI AVEC TRAEFIK + OLLAMA                 ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}[1/4]${NC} Arrêt d'Open WebUI..."
docker stop open-webui 2>/dev/null
echo -e "${GREEN}✓ Arrêté${NC}"
echo ""

echo -e "${YELLOW}[2/4]${NC} Suppression du conteneur..."
docker rm open-webui 2>/dev/null
echo -e "${GREEN}✓ Supprimé${NC}"
echo ""

echo -e "${YELLOW}[3/4]${NC} Création avec Traefik + Ollama..."
docker run -d \
  --name open-webui \
  --network traefik-net \
  -e ENABLE_OLLAMA_API=true \
  -e OLLAMA_BASE_URL=http://10.10.10.46:11434 \
  -v traefik-config_open-webui:/app/backend/data \
  --label "traefik.enable=true" \
  --label "traefik.http.routers.open-webui.rule=Host(\`llama.lalpha.ca\`)" \
  --label "traefik.http.routers.open-webui.entrypoints=websecure" \
  --label "traefik.http.routers.open-webui.tls.certresolver=myresolver" \
  --label "traefik.http.services.open-webui.loadbalancer.server.port=8080" \
  --restart unless-stopped \
  ghcr.io/open-webui/open-webui:main

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Conteneur créé avec Traefik${NC}"
else
    echo -e "${RED}✗ Erreur${NC}"
    exit 1
fi
echo ""

echo -e "${YELLOW}[4/4]${NC} Attente du démarrage..."
sleep 15
echo -e "${GREEN}✓ Prêt${NC}"
echo ""

echo "╔═══════════════════════════════════════════════════════════════╗"
echo -e "║  ${GREEN}✓ SUCCÈS! Open WebUI accessible via Traefik${NC}            ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""
echo "🌐 Accès: https://llama.lalpha.ca"
echo ""
echo "✅ Ollama activé: http://10.10.10.46:11434"
echo "✅ 2 modèles disponibles"
