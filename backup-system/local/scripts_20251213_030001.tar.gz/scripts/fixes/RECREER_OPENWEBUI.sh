#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║        RECRÉER OPEN WEBUI AVEC OLLAMA ACTIVÉ                 ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}⚠️  Cette opération va:${NC}"
echo "  1. Arrêter Open WebUI"
echo "  2. Supprimer le conteneur (PAS les données!)"
echo "  3. Le recréer avec Ollama activé"
echo ""
read -p "Continuer? (oui/non): " CONFIRM

if [ "$CONFIRM" != "oui" ]; then
    echo "Opération annulée"
    exit 0
fi

echo ""
echo -e "${YELLOW}[1/4]${NC} Arrêt d'Open WebUI..."
docker stop open-webui
echo -e "${GREEN}✓ Arrêté${NC}"
echo ""

echo -e "${YELLOW}[2/4]${NC} Suppression du conteneur..."
docker rm open-webui
echo -e "${GREEN}✓ Supprimé${NC}"
echo ""

echo -e "${YELLOW}[3/4]${NC} Création du nouveau conteneur avec Ollama activé..."
docker run -d \
  --name open-webui \
  --network traefik-net \
  -e ENABLE_OLLAMA_API=true \
  -e OLLAMA_BASE_URL=http://10.10.10.46:11434 \
  -v traefik-config_open-webui:/app/backend/data \
  --restart unless-stopped \
  ghcr.io/open-webui/open-webui:main

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Conteneur créé${NC}"
else
    echo -e "${RED}✗ Erreur lors de la création${NC}"
    exit 1
fi
echo ""

echo -e "${YELLOW}[4/4]${NC} Attente du démarrage (10 secondes)..."
sleep 10
echo -e "${GREEN}✓ Démarrage terminé${NC}"
echo ""

echo "╔═══════════════════════════════════════════════════════════════╗"
echo -e "║  ${GREEN}✓ SUCCÈS! Open WebUI reconfiguré${NC}                        ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""
echo "📋 Prochaines étapes:"
echo "  1. Ouvrir Open WebUI dans le navigateur"
echo "  2. Se reconnecter (vos données sont sauvegardées)"
echo "  3. Les modèles devraient apparaître automatiquement!"
echo ""
echo "  Vos 2 modèles disponibles:"
echo "  • qwen2.5-coder:32b-instruct-q4_K_M"
echo "  • llama3.2-vision:11b-instruct-q8_0"
