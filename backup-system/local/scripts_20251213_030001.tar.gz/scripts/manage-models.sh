#!/bin/bash
# Script de gestion des modèles AI Orchestrator
# Usage: ./manage-models.sh [commande]

BACKEND="/home/lalpha/projets/ai-tools/ai-orchestrator/backend/main.py"
FRONTEND="/home/lalpha/projets/ai-tools/ai-orchestrator/frontend/index.html"
STACK_DIR="/home/lalpha/projets/infrastructure/unified-stack"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

show_help() {
    echo -e "${CYAN}=== Gestion des modèles AI Orchestrator ===${NC}"
    echo ""
    echo "Commandes Ollama:"
    echo -e "  ${GREEN}list${NC}              - Lister les modèles installés"
    echo -e "  ${GREEN}pull <model>${NC}      - Télécharger/mettre à jour un modèle"
    echo -e "  ${GREEN}rm <model>${NC}        - Supprimer un modèle"
    echo -e "  ${GREEN}update-all${NC}        - Mettre à jour tous les modèles locaux"
    echo ""
    echo "Configuration Orchestrator:"
    echo -e "  ${GREEN}show-config${NC}       - Afficher la config actuelle"
    echo -e "  ${GREEN}edit-backend${NC}      - Ouvrir main.py dans nano"
    echo -e "  ${GREEN}edit-frontend${NC}     - Ouvrir index.html dans nano"
    echo -e "  ${GREEN}rebuild${NC}           - Rebuild et redémarrer le backend"
    echo ""
    echo "Exemples:"
    echo "  ./manage-models.sh pull llama3.3:70b"
    echo "  ./manage-models.sh rm gpt-oss-safeguard:latest"
    echo "  ./manage-models.sh update-all"
}

list_models() {
    echo -e "${CYAN}=== Modèles Ollama installés ===${NC}"
    ollama list
    echo ""
    echo -e "${CYAN}=== Modèles dans l'Orchestrator ===${NC}"
    grep -A2 '"model":' $BACKEND | grep -v "keywords\|None" | head -20
}

pull_model() {
    echo -e "${YELLOW}Téléchargement de $1...${NC}"
    ollama pull "$1"
}

remove_model() {
    echo -e "${RED}Suppression de $1...${NC}"
    ollama rm "$1"
    echo -e "${YELLOW}N'oublie pas de retirer ce modèle de main.py et index.html !${NC}"
}

update_all() {
    echo -e "${CYAN}=== Mise à jour de tous les modèles locaux ===${NC}"
    models=(
        "qwen2.5-coder:32b-instruct-q4_K_M"
        "deepseek-coder:33b"
        "llama3.2-vision:11b-instruct-q8_0"
        "qwen3-vl:32b"
        "gpt-oss-safeguard:latest"
        "nomic-embed-text:latest"
    )
    for model in "${models[@]}"; do
        echo -e "${YELLOW}Updating $model...${NC}"
        ollama pull "$model"
    done
    echo -e "${GREEN}✅ Mise à jour terminée${NC}"
}

rebuild_backend() {
    echo -e "${CYAN}=== Rebuild du backend ===${NC}"
    cd $STACK_DIR
    docker compose build --no-cache ai-orchestrator-backend
    docker compose up -d ai-orchestrator-backend
    sleep 5
    echo -e "${GREEN}✅ Backend redémarré${NC}"
    curl -s https://ai.4lb.ca/api/models | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(f'Modèles disponibles: {len(d.get(\"models\",[]))}')
"
}

show_config() {
    echo -e "${CYAN}=== Configuration Backend (MODELS) ===${NC}"
    sed -n '35,95p' $BACKEND
}

case "$1" in
    list)
        list_models
        ;;
    pull)
        pull_model "$2"
        ;;
    rm|remove)
        remove_model "$2"
        ;;
    update-all)
        update_all
        ;;
    rebuild)
        rebuild_backend
        ;;
    show-config)
        show_config
        ;;
    edit-backend)
        nano $BACKEND
        ;;
    edit-frontend)
        nano $FRONTEND
        ;;
    *)
        show_help
        ;;
esac
