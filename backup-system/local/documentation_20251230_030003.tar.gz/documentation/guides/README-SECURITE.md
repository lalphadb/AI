# 🔒 GUIDE DE SÉCURISATION - Serveur Ubuntu (lalpha-server-1)

> **Dernière mise à jour** : 1er décembre 2025

---

## 📋 Résumé Système

| Élément | Valeur |
|---------|--------|
| **OS** | Ubuntu 25.10 (Oracular) |
| **CPU** | AMD Ryzen 9 7900X (12 cores) |
| **RAM** | 64 GB |
| **IP** | 10.10.10.46 (VLAN 2 - Home) |

---

## 🔐 État Sécurité Actuel

### Services Actifs

| Service | Statut | Notes |
|---------|--------|-------|
| Docker | ✅ Actif | ~12 conteneurs |
| Traefik | ✅ Actif | Reverse proxy SSL |
| Fail2Ban | ✅ Actif | Protection brute-force |
| UFW | ⚠️ Vérifier | Firewall |

### Ports Exposés

| Port | Service | Risque |
|------|---------|--------|
| 22 | SSH | 🟡 Restreindre au LAN |
| 80, 443 | HTTP/S (Traefik) | ✅ OK |
| 25, 465, 587, 993 | Mail | 🟡 Si utilisé |
| 3000+ | Services internes | 🟡 Vérifier exposition |

---

## 🚀 Scripts de Sécurité

Les scripts sont dans `/home/lalpha/scripts/security/` :

| Script | Description |
|--------|-------------|
| `configure-ufw.sh` | Configuration firewall UFW |
| `security-check.sh` | Rapport sécurité complet |
| `secure-docker.sh` | Sécurisation Docker |
| `docker-audit-guide.sh` | Guide audit Docker |

### Utilisation

```bash
# Vérification sécurité
bash /home/lalpha/scripts/security/security-check.sh

# Configuration UFW
sudo bash /home/lalpha/scripts/security/configure-ufw.sh

# Sécurisation Docker
sudo bash /home/lalpha/scripts/security/secure-docker.sh
```

---

## 🛡️ Configuration UFW Recommandée

```bash
# Politique par défaut
sudo ufw default deny incoming
sudo ufw default allow outgoing

# SSH (LAN uniquement)
sudo ufw allow from 10.10.10.0/25 to any port 22

# HTTP/HTTPS (Traefik)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Activer
sudo ufw enable

# Vérifier
sudo ufw status verbose
```

### Règles Additionnelles (si nécessaire)

```bash
# Mail (si serveur mail actif)
sudo ufw allow 25/tcp
sudo ufw allow 465/tcp
sudo ufw allow 587/tcp
sudo ufw allow 993/tcp

# Bloquer explicitement
sudo ufw deny 3389/tcp  # RDP
```

---

## 🔧 Hardening SSH

### Configuration recommandée

Créer `/etc/ssh/sshd_config.d/99-hardening.conf` :

```bash
# Désactiver login root
PermitRootLogin prohibit-password

# Authentification par clé uniquement (après config clé!)
# PasswordAuthentication no

# Limiter les tentatives
MaxAuthTries 3

# Timeout
ClientAliveInterval 300
ClientAliveCountMax 2

# Désactiver protocoles inutiles
X11Forwarding no
AllowAgentForwarding no
```

Appliquer :
```bash
sudo systemctl restart sshd
```

---

## 🐳 Sécurisation Docker

### Vérifications

```bash
# Conteneurs en root
docker ps --format '{{.Names}}: {{.Image}}' | while read c; do
  echo "$c - User: $(docker inspect --format '{{.Config.User}}' ${c%%:*})"
done

# Volumes sensibles
docker inspect --format '{{range .Mounts}}{{.Source}} -> {{.Destination}}{{println}}{{end}}' $(docker ps -q)

# Réseau
docker network ls
```

### Bonnes pratiques

1. **Ne pas exposer Docker socket** sans nécessité
2. **Utiliser des utilisateurs non-root** dans les conteneurs
3. **Limiter les capabilities** : `--cap-drop=ALL --cap-add=...`
4. **Réseaux isolés** par projet

---

## 📊 Fail2Ban

### Vérifier statut

```bash
sudo fail2ban-client status
sudo fail2ban-client status sshd
```

### Configuration

Fichier : `/etc/fail2ban/jail.local`

```ini
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
findtime = 600
```

### Commandes utiles

```bash
# IPs bannies
sudo fail2ban-client status sshd

# Débannir une IP
sudo fail2ban-client set sshd unbanip <IP>

# Logs
sudo tail -f /var/log/fail2ban.log
```

---

## 🔍 Vérifications Rapides

```bash
# Firewall
sudo ufw status verbose

# Fail2Ban
sudo fail2ban-client status

# Ports ouverts
sudo ss -tlnp

# Connexions actives
sudo ss -tnp

# Dernières connexions SSH
last -10

# Tentatives échouées
sudo grep "Failed password" /var/log/auth.log | tail -20
```

---

## 📝 Checklist Sécurité

- [ ] UFW activé avec règles restrictives
- [ ] SSH limité au réseau local
- [ ] Fail2Ban actif sur SSH
- [ ] Pas de port 3389 (RDP) exposé
- [ ] Mises à jour automatiques activées
- [ ] Clés SSH configurées (pas de mot de passe)
- [ ] Docker socket non exposé publiquement
- [ ] Conteneurs avec utilisateurs non-root
- [ ] Logs centralisés et surveillés

---

## 🆘 En Cas de Problème

### Bloqué hors du serveur

1. Accès physique ou console
2. `sudo ufw disable`
3. Corriger la configuration
4. `sudo ufw enable`

### Service ne fonctionne plus

```bash
# Vérifier UFW
sudo ufw status numbered

# Logs
sudo journalctl -u <service> -f

# Test port
nc -zv localhost <port>
```

---

## 🔗 Références

- [ARCHITECTURE.md](../ARCHITECTURE.md) - Vue infrastructure
- [Guide UniFi](../Guide-Securisation-UniFi-Forteresse.docx) - Sécurité réseau

---

*Documentation mise à jour le 1er décembre 2025*
