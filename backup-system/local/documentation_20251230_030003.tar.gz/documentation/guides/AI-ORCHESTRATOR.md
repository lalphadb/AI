# 🤖 Agent IA Orchestrateur v3.0

> **URL** : https://ai.4lb.ca
> **Version** : 3.0.0
> **Date** : 14 décembre 2025

---

## 🎯 Nouveautés v3.0 - Auto-Apprentissage

### 🧠 Apprentissage Automatique
| Fonction | Description |
|----------|-------------|
| **Auto-extraction de faits** | Détecte automatiquement "Je suis...", "Je travaille sur...", etc. |
| **Contexte automatique** | Charge les mémoires pertinentes pour chaque question |
| **Résumé de conversation** | Sauvegarde un résumé à la fin de chaque conversation |
| **Extraction problème/solution** | Mémorise les problèmes résolus pour référence future |

### Patterns Détectés Automatiquement

| Pattern | Catégorie | Exemple |
|---------|-----------|---------|
| "Je suis..." | user_fact | "Je suis développeur" |
| "Je travaille sur..." | project | "Je travaille sur le monitoring" |
| "Je préfère..." | preference | "Je préfère les réponses courtes" |
| "Mon serveur a..." | tech_fact | "Mon serveur a 64GB de RAM" |
| "J'utilise X pour Y" | tech_fact | "J'utilise Docker pour mes services" |

---

## 📊 Architecture v3.0

```
┌─────────────────────────────────────────────────────────────────┐
│                    Message Utilisateur                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   AUTO-APPRENTISSAGE                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │ Extract Facts   │  │ Load Context    │  │ Detect Patterns │ │
│  │ (auto_learn.py) │  │ (ChromaDB)      │  │ (regex)         │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              [CONTEXTE MÉMOIRE] ... [/CONTEXTE]                 │
│                    Message enrichi                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BOUCLE ReAct                                │
│                    (LLM + 34 outils)                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      RÉPONSE FINALE                              │
└─────────────────────────────────────────────────────────────────┘
                              │
            ┌─────────────────┴─────────────────┐
            ▼                                   ▼
┌─────────────────────┐              ┌─────────────────────┐
│  Faits appris       │              │  Résumé conversation │
│  → ChromaDB         │              │  → ChromaDB          │
└─────────────────────┘              └─────────────────────┘
```

---

## 🔧 Outils Mémoire (4)

| Outil | Description |
|-------|-------------|
| `memory_store` | Mémoriser manuellement une information |
| `memory_recall` | Recherche sémantique dans la mémoire |
| `memory_stats` | **NOUVEAU** Statistiques de la mémoire |

### Exemple memory_stats
```
📊 Statistiques mémoire:
   Total: 12 souvenirs
   Par type: {'base': 5, 'auto_learned': 5, 'conversation_summary': 2}
   Par catégorie: {'user_fact': 2, 'project': 3}
```

---

## 📝 Comment "Entraîner" l'Agent

### Méthode 1: Automatique (recommandé)
Parle naturellement, l'agent apprend tout seul:
```
"Je suis Lalpha et je travaille sur un homelab IA"
→ Auto-extrait: [user_fact] Lalpha, [project] homelab IA

"Je préfère les réponses concises sans bullet points"
→ Auto-extrait: [preference] réponses concises sans bullet points

"Mon serveur tourne sur Ubuntu 25.10 avec 64GB de RAM"
→ Auto-extrait: [tech_fact] Ubuntu 25.10, 64GB RAM
```

### Méthode 2: Explicite
```
"Mémorise que je suis allergique aux emojis"
"Retiens que mon projet prioritaire est Grafana"
"Note que je préfère le format markdown"
```

### Méthode 3: Correction
```
"Non, j'ai 64GB pas 32GB. Corrige ta mémoire."
```

---

## 🎮 Modèles Disponibles (9)

### Modèles Locaux
| Mode | Modèle | Usage |
|------|--------|-------|
| 💻 **Qwen Coder** | qwen2.5-coder:32b | Code, scripts, debug |
| 🧠 **DeepSeek** | deepseek-coder:33b | Algorithmes complexes |
| 👁️ **Llama Vision** | llama3.2-vision:11b | Analyse d'images |
| 🎨 **Qwen Vision** | qwen3-vl:32b | Vision multimodale |

### Modèles Cloud
| Mode | Modèle | Usage |
|------|--------|-------|
| ☁️ **Qwen3 Coder 480B** | qwen3-coder:480b-cloud | Code avancé (défaut) |
| ☁️ **Kimi K2 1T** | kimi-k2:1t-cloud | Modèle Moonshot AI |
| ☁️ **Gemini 3 Pro** | gemini-3-pro-preview | Google Gemini |

---

## 🔧 Tous les Outils (34)

### Système (6)
execute_command, system_info, disk_usage, service_status, service_control, network_scan

### Fichiers (7)
read_file, write_file, list_directory, search_files, create_script, analyze_file, analyze_image

### Docker (3)
docker_status, docker_logs, docker_restart

### Git (6)
git_status, git_diff, git_log, git_commit, git_branch, git_pull

### UDM-Pro (3)
udm_status, udm_network_info, udm_clients

### LLM (2)
ollama_list, ollama_run

### Mémoire (3) 🆕
memory_store, memory_recall, **memory_stats**

### Planification (2)
create_plan, validate_step

### Utilitaires (2)
web_request, final_answer

---

## ⚙️ Fichiers du Projet

| Fichier | Description |
|---------|-------------|
| `backend/main.py` | Backend FastAPI (~1500 lignes) |
| `backend/auto_learn.py` | **NOUVEAU** Module auto-apprentissage |
| `backend/requirements.txt` | Dépendances Python |
| `frontend/index.html` | Interface web |

---

## 📝 Changelog

### v3.0.0 (14 décembre 2025) 🆕
- ✅ **Auto-apprentissage** : Extraction automatique des faits
- ✅ **Contexte automatique** : Mémoires pertinentes chargées
- ✅ **Résumé conversation** : Sauvegarde à la déconnexion
- ✅ **Extraction problème/solution** : Solutions mémorisées
- ✅ **memory_stats** : Nouvel outil de statistiques
- ✅ 34 outils (vs 33 en v2.5)

### v2.5.0 (14 décembre 2025)
- ✅ Mémoire sémantique ChromaDB
- ✅ Recherche par similarité

### v2.4.0 (11 décembre 2025)
- ✅ Résolution WebSocket
- ✅ Progressive urgency messaging

---

*Documentation mise à jour le 14 décembre 2025*
