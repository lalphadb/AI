# 🔒 Procédures Sécurisées pour Agents IA

> **Audience** : Claude Code, Continue, Cline, et tous les agents IA
> **Date** : 7 décembre 2025
> **Statut** : OBLIGATOIRE

---

## ⚠️ RÈGLES D'OR

### **1. TOUJOURS utiliser Unified Stack**
```bash
cd /home/lalpha/projets/infrastructure/unified-stack
./stack.sh <commande>
```

### **2. NE JAMAIS exécuter directement :**
```bash
❌ docker compose up (hors unified-stack)
❌ docker compose down (hors unified-stack)
❌ Modifications directes de docker-compose.yml sans backup
❌ docker restart <container> (utiliser ./stack.sh restart)
```

---

## 📋 Procédures Standard

### **Démarrer/Arrêter la Stack**

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

# Démarrer tout
./stack.sh up

# Arrêter tout
./stack.sh down

# Redémarrer un service
./stack.sh restart grafana
```

### **Vérifier l'État**

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

# État des conteneurs
./stack.sh status

# Tester les URLs
./stack.sh test

# Logs d'un service
./stack.sh logs traefik
```

### **Mettre à Jour un Service**

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

# Rebuild + restart
./stack.sh update jsr-dev
```

---

## ✅ Ce que tu PEUX faire

### **Lecture / Analyse**
```bash
✅ cat, less, grep sur les fichiers de config
✅ docker ps, docker logs pour diagnostics
✅ docker stats pour métriques
✅ ./stack.sh status, ./stack.sh test
✅ Analyser les logs et identifier les problèmes
```

### **Exécution Autorisée**
```bash
✅ ./stack.sh up
✅ ./stack.sh down
✅ ./stack.sh restart <service>
✅ ./stack.sh update <service>
✅ ./stack.sh logs <service>
✅ ./stack.sh test
```

### **Modifications**
```bash
✅ Proposer des modifications au docker-compose.yml
✅ Créer des scripts dans ~/scripts/
✅ Documenter les changements
```

---

## 🚫 Ce que tu ne dois JAMAIS faire

### **Commandes Dangereuses**
```bash
❌ docker compose down --volumes (supprime les données !)
❌ docker system prune -a (supprime toutes les images !)
❌ rm -rf sur des dossiers système
❌ Modifications de /etc/ sans validation
❌ docker compose up depuis un autre dossier que unified-stack
```

### **Sans Validation**
```bash
❌ Modifier docker-compose.yml sans backup
❌ Supprimer des volumes
❌ Changer les ports exposés
```

---

## 📁 Emplacements Importants

| Dossier | Description |
|---------|-------------|
| `/home/lalpha/projets/infrastructure/unified-stack/` | **STACK PRINCIPALE** |
| `/home/lalpha/projets/ai-tools/` | Projets IA |
| `/home/lalpha/projets/clients/` | Projets clients |
| `/home/lalpha/documentation/` | Documentation |
| `/home/lalpha/scripts/` | Scripts utilitaires |

---

## 🔧 Exemple : Ajouter un Service

1. **Backup le fichier actuel**
```bash
cp docker-compose.yml docker-compose.yml.backup
```

2. **Proposer la modification** à l'utilisateur

3. **L'utilisateur valide et applique**
```bash
./stack.sh up
./stack.sh test
```

---

## 📊 Checklist Avant Action

- [ ] Suis-je dans `/home/lalpha/projets/infrastructure/unified-stack/` ?
- [ ] Est-ce que j'utilise `./stack.sh` au lieu de `docker compose` direct ?
- [ ] Est-ce que j'ai fait un backup avant modification ?
- [ ] L'utilisateur a-t-il validé les changements ?

---

*Mis à jour le 7 décembre 2025*
