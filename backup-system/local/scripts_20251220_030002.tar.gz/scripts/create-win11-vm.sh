#!/bin/bash

# Configuration
VM_NAME="Windows11-CronusZen"
VM_RAM=8192        # 8 GB (ajustez selon besoin)
VM_VRAM=128        # 128 MB VRAM
VM_CPUS=4          # 4 cœurs CPU
VM_DISK_SIZE=80000 # 80 GB
ISO_PATH="$HOME/VMs/ISOs/Windows11.iso"
VM_DIR="$HOME/VMs"

# Créer le dossier VM
mkdir -p "$VM_DIR"

# Créer la VM
VBoxManage createvm --name "$VM_NAME" --ostype Windows11_64 --register --basefolder "$VM_DIR"

# Configuration matérielle
VBoxManage modifyvm "$VM_NAME" \
    --memory $VM_RAM \
    --vram $VM_VRAM \
    --cpus $VM_CPUS \
    --clipboard bidirectional \
    --draganddrop bidirectional \
    --boot1 dvd \
    --boot2 disk \
    --boot3 none \
    --boot4 none \
    --firmware efi \
    --rtcuseutc on \
    --graphicscontroller vmsvga \
    --audio-driver pulse \
    --audiocontroller hda \
    --audio-enabled on

# Activer USB 3.0 (IMPORTANT pour Cronus Zen)
VBoxManage modifyvm "$VM_NAME" --usb on --usbehci on --usbxhci on

# Créer le disque virtuel
VBoxManage createhd --filename "$VM_DIR/$VM_NAME/$VM_NAME.vdi" --size $VM_DISK_SIZE --variant Standard

# Ajouter contrôleur SATA
VBoxManage storagectl "$VM_NAME" --name "SATA" --add sata --controller IntelAhci --portcount 2

# Attacher le disque
VBoxManage storageattach "$VM_NAME" --storagectl "SATA" --port 0 --device 0 --type hdd --medium "$VM_DIR/$VM_NAME/$VM_NAME.vdi"

# Attacher l'ISO Windows 11
VBoxManage storageattach "$VM_NAME" --storagectl "SATA" --port 1 --device 0 --type dvddrive --medium "$ISO_PATH"

# Configuration réseau (NAT par défaut)
VBoxManage modifyvm "$VM_NAME" --nic1 nat

# Activer PAE/NX (requis pour Windows 11)
VBoxManage modifyvm "$VM_NAME" --pae on

# Bypass TPM requirement Windows 11 (IMPORTANT!)
VBoxManage modifyvm "$VM_NAME" --tpm-type 2.0
VBoxManage modifyvm "$VM_NAME" --secure-boot on

echo "✅ VM $VM_NAME créée avec succès!"
echo "📁 Emplacement: $VM_DIR/$VM_NAME"
echo ""
echo "🚀 Pour démarrer : VBoxManage startvm '$VM_NAME' --type gui"
echo "   Ou utilisez l'interface graphique VirtualBox"
