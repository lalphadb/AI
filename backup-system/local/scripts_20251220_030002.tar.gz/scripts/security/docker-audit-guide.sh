#!/bin/bash
# Guide complet pour l'audit Docker Security

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Ce script doit être exécuté en tant que root${NC}"
    echo "Utilisez: sudo bash $0"
    exit 1
fi

echo -e "${BLUE}"
cat << "LOGO"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║              🐳 AUDIT SÉCURITÉ DOCKER                    ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
LOGO
echo -e "${NC}"

# 1. Installer Docker Bench Security si nécessaire
if [ ! -d "/opt/docker-bench-security" ]; then
    echo -e "${YELLOW}[1/4] Installation de Docker Bench Security...${NC}"
    git clone https://github.com/docker/docker-bench-security.git /opt/docker-bench-security
    chmod +x /opt/docker-bench-security/docker-bench-security.sh
    echo -e "${GREEN}✓ Installé${NC}"
else
    echo -e "${GREEN}✓ Docker Bench Security déjà installé${NC}"
    cd /opt/docker-bench-security
    git pull origin master 2>/dev/null
fi

echo ""
echo -e "${YELLOW}[2/4] Pré-audit - État actuel de Docker...${NC}"
echo ""

# Vérifier Docker daemon
echo "• Version Docker:"
docker version --format '  {{.Server.Version}}'

echo ""
echo "• Conteneurs actifs:"
docker ps --format "  {{.Names}} - {{.Status}}" | head -10

echo ""
echo "• Configuration daemon.json:"
if [ -f /etc/docker/daemon.json ]; then
    echo -e "  ${GREEN}✓ Présent${NC}"
    cat /etc/docker/daemon.json | python3 -m json.tool 2>/dev/null || cat /etc/docker/daemon.json
else
    echo -e "  ${YELLOW}⚠ Non configuré${NC}"
fi

echo ""
echo -e "${YELLOW}[3/4] Lancement de l'audit complet...${NC}"
echo ""
echo "Cela peut prendre 2-3 minutes..."
echo ""

# Créer un répertoire pour les rapports
mkdir -p /var/log/docker-security
REPORT_FILE="/var/log/docker-security/audit-$(date +%Y%m%d-%H%M%S).log"

# Lancer l'audit
cd /opt/docker-bench-security
./docker-bench-security.sh | tee "$REPORT_FILE"

echo ""
echo -e "${YELLOW}[4/4] Analyse des résultats...${NC}"
echo ""

# Compter les warnings et erreurs
WARN_COUNT=$(grep -c "\[WARN\]" "$REPORT_FILE" 2>/dev/null || echo "0")
PASS_COUNT=$(grep -c "\[PASS\]" "$REPORT_FILE" 2>/dev/null || echo "0")
INFO_COUNT=$(grep -c "\[INFO\]" "$REPORT_FILE" 2>/dev/null || echo "0")
NOTE_COUNT=$(grep -c "\[NOTE\]" "$REPORT_FILE" 2>/dev/null || echo "0")

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                    RÉSUMÉ DE L'AUDIT                      ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
echo -e "${GREEN}✓ PASS: $PASS_COUNT${NC}"
echo -e "${YELLOW}⚠ WARN: $WARN_COUNT${NC}"
echo -e "${CYAN}ℹ INFO: $INFO_COUNT${NC}"
echo -e "${BLUE}📝 NOTE: $NOTE_COUNT${NC}"
echo ""

if [ "$WARN_COUNT" -gt 10 ]; then
    echo -e "${RED}⚠️  ATTENTION: $WARN_COUNT avertissements détectés !${NC}"
elif [ "$WARN_COUNT" -gt 0 ]; then
    echo -e "${YELLOW}⚠  $WARN_COUNT avertissements à examiner${NC}"
else
    echo -e "${GREEN}✓ Aucun avertissement majeur${NC}"
fi

echo ""
echo -e "${YELLOW}Rapport complet sauvegardé:${NC}"
echo "  $REPORT_FILE"
echo ""

# Recommandations prioritaires
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║              RECOMMANDATIONS PRIORITAIRES                 ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

echo -e "${YELLOW}1. Configuration daemon.json${NC}"
echo "   Vérifiez: /etc/docker/daemon.json"
echo "   Recommandations:"
echo '   • "icc": false (Inter-Container Communication)'
echo '   • "live-restore": true'
echo '   • "userland-proxy": false'
echo '   • Limites de logs configurées'
echo ""

echo -e "${YELLOW}2. Conteneurs en cours${NC}"
echo "   Commandes utiles:"
echo "   • Vérifier les privilèges: ${CYAN}docker inspect <container> | grep -i priv${NC}"
echo "   • Vérifier root: ${CYAN}docker exec <container> whoami${NC}"
echo "   • Limites ressources: ${CYAN}docker stats --no-stream${NC}"
echo ""

echo -e "${YELLOW}3. Images Docker${NC}"
echo "   • Scanner les vulnérabilités: ${CYAN}docker scan <image>${NC}"
echo "   • Nettoyer les images: ${CYAN}docker image prune -a${NC}"
echo ""

echo -e "${YELLOW}4. Réseau Docker${NC}"
echo "   • Lister les réseaux: ${CYAN}docker network ls${NC}"
echo "   • Inspecter: ${CYAN}docker network inspect <network>${NC}"
echo ""

# Actions recommandées
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                  ACTIONS À EFFECTUER                      ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Vérifier daemon.json
if [ ! -f /etc/docker/daemon.json ]; then
    echo -e "${RED}❌ Créer /etc/docker/daemon.json${NC}"
    echo "   sudo ~/secure-docker.sh"
fi

# Vérifier les conteneurs root
ROOT_CONTAINERS=$(docker ps -q | xargs -I {} docker exec {} whoami 2>/dev/null | grep -c "root" 2>/dev/null || echo "0")
if [ "$ROOT_CONTAINERS" -gt 0 ]; then
    echo -e "${YELLOW}⚠️  $ROOT_CONTAINERS conteneurs tournent en root${NC}"
    echo "   Envisagez d'utiliser des users non-root dans vos Dockerfiles"
fi

# Vérifier les conteneurs privilégiés
PRIV_CONTAINERS=$(docker ps -q | xargs -I {} docker inspect {} | grep -c '"Privileged": true' 2>/dev/null || echo "0")
if [ "$PRIV_CONTAINERS" -gt 0 ]; then
    echo -e "${RED}❌ $PRIV_CONTAINERS conteneurs privilégiés détectés${NC}"
    echo "   Évitez --privileged sauf si absolument nécessaire"
fi

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                COMMANDES UTILES                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "• Relancer l'audit:"
echo "  ${CYAN}sudo bash ~/docker-audit-guide.sh${NC}"
echo ""
echo "• Voir le dernier rapport:"
echo "  ${CYAN}cat $REPORT_FILE${NC}"
echo ""
echo "• Tous les rapports:"
echo "  ${CYAN}ls -lh /var/log/docker-security/${NC}"
echo ""
echo "• Nettoyer Docker:"
echo "  ${CYAN}docker system prune -a --volumes${NC}"
echo ""
echo "• Inspecter un conteneur:"
echo "  ${CYAN}docker inspect <container_name>${NC}"
echo ""

echo -e "${GREEN}Audit terminé !${NC}"
echo ""
