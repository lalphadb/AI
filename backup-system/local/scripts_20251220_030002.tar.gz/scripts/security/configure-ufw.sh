#!/bin/bash
# Configuration rapide UFW pour serveur web/mail
# ATTENTION: Assurez-vous d'avoir accès au serveur avant d'activer UFW !

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}═══════════════════════════════════════${NC}"
echo -e "${YELLOW}  Configuration UFW - Serveur Principal${NC}"
echo -e "${YELLOW}═══════════════════════════════════════${NC}"
echo ""

# Vérifier si on est root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Ce script doit être exécuté en tant que root${NC}"
    echo "Utilisez: sudo bash $0"
    exit 1
fi

echo -e "${YELLOW}[1/7] Réinitialisation UFW...${NC}"
ufw --force reset

echo -e "${YELLOW}[2/7] Configuration des politiques par défaut...${NC}"
ufw default deny incoming
ufw default allow outgoing

echo -e "${YELLOW}[3/7] Autorisation Loopback...${NC}"
ufw allow in on lo
ufw allow out on lo

echo -e "${YELLOW}[4/7] Autorisation réseau local (VLAN 2)...${NC}"
# Tout autoriser depuis le réseau local
ufw allow from 10.10.10.0/25 comment 'LAN VLAN2 Full Access'
ufw allow from 192.168.1.0/26 comment 'Management VLAN1'

echo -e "${YELLOW}[5/7] Configuration SSH (avec rate limiting)...${NC}"
# SSH uniquement depuis le réseau local
ufw allow from 10.10.10.0/25 to any port 22 proto tcp comment 'SSH from LAN'
ufw allow from 192.168.1.0/26 to any port 22 proto tcp comment 'SSH from Management'
# Rate limiting pour SSH
ufw limit 22/tcp comment 'SSH Rate Limit'

echo -e "${YELLOW}[6/7] Ouverture des services web et mail...${NC}"
# HTTP/HTTPS (via Traefik)
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'

# Services Mail (exposés publiquement)
ufw allow 25/tcp comment 'SMTP'
ufw allow 465/tcp comment 'SMTPS'
ufw allow 587/tcp comment 'Mail Submission'
ufw allow 993/tcp comment 'IMAPS'

# BLOQUER RDP explicitement
ufw deny 3389/tcp comment 'RDP BLOCKED'

# Services de monitoring (BLOQUER depuis Internet)
ufw deny from any to any port 3000 comment 'Grafana - Internal Only'
ufw deny from any to any port 9090 comment 'Prometheus - Internal Only'

echo -e "${YELLOW}[7/7] Logging UFW...${NC}"
ufw logging medium

echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  Configuration UFW terminée !${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Règles configurées:${NC}"
ufw show added
echo ""

read -p "Activer UFW maintenant ? (o/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Oo]$ ]]; then
    echo -e "${YELLOW}Activation de UFW...${NC}"
    ufw --force enable
    echo ""
    echo -e "${GREEN}✓ UFW activé et configuré !${NC}"
    echo ""
    ufw status verbose
else
    echo -e "${YELLOW}UFW non activé. Pour l'activer plus tard:${NC}"
    echo "  sudo ufw enable"
fi

echo ""
echo -e "${YELLOW}Pour vérifier l'état:${NC} sudo ufw status verbose"
echo -e "${YELLOW}Pour voir les logs:${NC} sudo tail -f /var/log/ufw.log"
echo ""
