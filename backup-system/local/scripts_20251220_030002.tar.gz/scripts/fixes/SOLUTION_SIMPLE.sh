#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║          SOLUTION SIMPLE - UTILISER DOCKER-COMPOSE           ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

echo "🎯 Votre Open WebUI existe déjà dans docker-compose!"
echo "   URL: https://llm.4lb.ca"
echo ""

echo "Options:"
echo "  1. Accéder à https://llm.4lb.ca (peut-être que ça marche déjà!)"
echo "  2. Modifier le docker-compose pour activer Ollama"
echo ""

read -p "Voulez-vous modifier le docker-compose? (oui/non): " MODIFY

if [ "$MODIFY" != "oui" ]; then
    echo "Essayez d'accéder à https://llm.4lb.ca"
    exit 0
fi

# Arrêter le conteneur standalone
docker stop open-webui 2>/dev/null
docker rm open-webui 2>/dev/null

# Modifier le docker-compose
cd /home/lalpha/projets/traefik-config

# Backup
cp docker-compose.yml docker-compose.yml.backup-$(date +%Y%m%d-%H%M%S)

# Modifier pour activer Ollama
sed -i 's/ENABLE_OLLAMA_API=false/ENABLE_OLLAMA_API=true/' docker-compose.yml

# Ajouter l'URL Ollama après ENABLE_OLLAMA_API
sed -i '/ENABLE_OLLAMA_API=true/a\      - OLLAMA_BASE_URL=http://host.docker.internal:11434' docker-compose.yml

echo "✅ docker-compose.yml modifié"
echo ""
echo "Relançons Open WebUI via docker-compose..."

docker-compose up -d open-webui

echo ""
echo "✅ Open WebUI démarré!"
echo "   Attendez 15 secondes puis accédez à:"
echo "   https://llm.4lb.ca"
echo ""
echo "   Allez dans Settings → API Ollama"
echo "   URL: http://host.docker.internal:11434"

