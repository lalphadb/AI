# 🚀 Guide de Démarrage Rapide - 4lb.ca

## ⚡ Installation en 5 Minutes

### 1. Prérequis Vérifiés ✅

```bash
✓ Ubuntu 24.04 LTS
✓ Docker 28.5.0
✓ Docker Compose v2
✓ NVIDIA RTX 5070 Ti avec drivers 580.65
✓ 64 GB RAM
✓ 2 TB NVMe SSD
```

### 2. Configuration (.env)

```bash
cd /home/lalpha/4lb.ca
cp .env.example .env
nano .env
```

**Modifier obligatoirement :**
```bash
ANTHROPIC_API_KEY=sk-ant-api03-VOTRE_CLE_ICI
DB_PASSWORD=VotreMotDePasseUltraSecurise123!
GRAFANA_PASSWORD=AutreMotDePasseSecurise456!
ACME_EMAIL=admin@4lb.ca

# Générer APP_KEY:
APP_KEY=base64:$(openssl rand -base64 32)
```

### 3. Lancer l'Installation

```bash
./scripts/deploy/install.sh
```

⏱️ **Temps : ~10 minutes**

### 4. Configurer DNS Cloudflare

| Type | Nom | Valeur | Proxy |
|------|-----|--------|-------|
| A | @ | 1.1.4.12 | ✓ |
| A | www | 1.1.4.12 | ✓ |
| A | ai | 1.1.4.12 | ✓ |
| A | grafana | 1.1.4.12 | ✓ |
| A | prometheus | 1.1.4.12 | ✓ |

### 5. Accéder aux Services

```bash
# Application
https://4lb.ca

# Grafana (monitoring)
https://grafana.4lb.ca
Login: admin / ${GRAFANA_PASSWORD}

# Prometheus (métriques)
https://prometheus.4lb.ca

# API LLM
https://ai.4lb.ca
```

## 🎯 Commandes Essentielles

```bash
# Voir tous les services
docker-compose ps

# Logs en temps réel
docker-compose logs -f

# Redémarrer
docker-compose restart

# Arrêter
docker-compose down

# Démarrer
docker-compose up -d

# Backup manuel
./scripts/backup/backup.sh

# Voir métriques GPU
nvidia-smi
```

## 🤖 Tester l'API LLM

```bash
# Test simple
curl -X POST https://ai.4lb.ca/api/tasks \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${MCP_API_KEY}" \
  -d '{"prompt": "Dis bonjour!", "model": "llama3.1:8b"}'

# Résultat:
{
  "success": true,
  "taskId": "xxx-yyy-zzz",
  "status": "queued",
  "estimatedWaitTime": 5
}

# Vérifier le résultat
curl https://ai.4lb.ca/api/tasks/xxx-yyy-zzz \
  -H "X-API-Key: ${MCP_API_KEY}"
```

## ✅ Checklist Post-Installation

- [ ] Tous les services sont UP (vert dans `docker-compose ps`)
- [ ] Grafana accessible et loggé
- [ ] Prometheus scrape des métriques (voir Targets)
- [ ] Ollama répond (curl http://localhost:11434/api/tags)
- [ ] MCP Server répond (test API ci-dessus)
- [ ] DNS configuré dans Cloudflare
- [ ] Certificats SSL générés (attendre 2-5 min)
- [ ] Backup automatique configuré (crontab)

## 🐛 Problèmes Courants

**Service ne démarre pas :**
```bash
docker-compose logs nom_du_service
docker-compose restart nom_du_service
```

**GPU non détecté :**
```bash
nvidia-smi  # Doit afficher RTX 5070 Ti
docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi
```

**Port déjà utilisé :**
```bash
sudo netstat -tulpn | grep :443
# Arrêter le service conflictuel ou changer le port
```

## 📞 Aide

**Documentation complète :** `README.md`
**Logs :** `/home/lalpha/4lb.ca/logs/`
**Configurations :** `/home/lalpha/4lb.ca/configs/`

---

🎉 **Votre infrastructure est prête !**
