// ═══════════════════════════════════════════════════════════════
// MCP Server - Model Control Plane
// Orchestration intelligente des workers LLM
// ═══════════════════════════════════════════════════════════════

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const Redis = require('ioredis');
const Queue = require('bull');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const promClient = require('prom-client');
const winston = require('winston');

// ────────────────────────────────────────────────────────────────
// CONFIGURATION
// ────────────────────────────────────────────────────────────────
const CONFIG = {
  port: process.env.PORT || 8080,
  ollamaHost: process.env.OLLAMA_HOST || 'http://ollama:11434',
  redisHost: process.env.REDIS_HOST || 'redis',
  redisPort: parseInt(process.env.REDIS_PORT) || 6379,
  apiKey: process.env.API_KEY || 'dev-key-change-me',
  maxWorkers: parseInt(process.env.MAX_WORKERS) || 5,
  workerTimeout: parseInt(process.env.WORKER_TIMEOUT) || 300000,
  maxTokens: parseInt(process.env.MAX_TOKENS) || 4096,
};

// ────────────────────────────────────────────────────────────────
// LOGGER
// ────────────────────────────────────────────────────────────────
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

// ────────────────────────────────────────────────────────────────
// REDIS & QUEUES
// ────────────────────────────────────────────────────────────────
const redis = new Redis({
  host: CONFIG.redisHost,
  port: CONFIG.redisPort,
  retryStrategy: (times) => Math.min(times * 50, 2000),
});

const taskQueue = new Queue('llm-tasks', {
  redis: { host: CONFIG.redisHost, port: CONFIG.redisPort },
  settings: {
    lockDuration: CONFIG.workerTimeout,
    maxStalledCount: 3,
  }
});

// ────────────────────────────────────────────────────────────────
// MÉTRIQUES PROMETHEUS
// ────────────────────────────────────────────────────────────────
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register });

const requestCounter = new promClient.Counter({
  name: 'mcp_requests_total',
  help: 'Total number of requests',
  labelNames: ['method', 'route', 'status'],
  registers: [register]
});

const requestDuration = new promClient.Histogram({
  name: 'mcp_request_duration_seconds',
  help: 'Request duration in seconds',
  labelNames: ['method', 'route'],
  registers: [register]
});

const activeWorkers = new promClient.Gauge({
  name: 'mcp_active_workers',
  help: 'Number of active workers',
  registers: [register]
});

const queueLength = new promClient.Gauge({
  name: 'mcp_queue_length',
  help: 'Current queue length',
  registers: [register]
});

// ────────────────────────────────────────────────────────────────
// EXPRESS APP
// ────────────────────────────────────────────────────────────────
const app = express();

// Middlewares de sécurité
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key']
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_PER_MINUTE) || 100,
  message: 'Too many requests, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// ────────────────────────────────────────────────────────────────
// AUTHENTIFICATION MIDDLEWARE
// ────────────────────────────────────────────────────────────────
function authenticateAPI(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key;
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key required' });
  }
  
  if (apiKey !== CONFIG.apiKey) {
    return res.status(403).json({ error: 'Invalid API key' });
  }
  
  next();
}

// ────────────────────────────────────────────────────────────────
// GESTION WORKERS LLM
// ────────────────────────────────────────────────────────────────
class WorkerManager {
  constructor() {
    this.workers = new Map();
    this.maxConcurrent = CONFIG.maxWorkers;
  }

  async executeTask(task) {
    const workerId = `worker-${uuidv4()}`;
    const startTime = Date.now();

    try {
      logger.info(`Worker ${workerId} started task ${task.id}`);
      activeWorkers.inc();

      // Appel à Ollama
      const response = await axios.post(`${CONFIG.ollamaHost}/api/generate`, {
        model: task.model || 'llama3.1:8b',
        prompt: task.prompt,
        stream: false,
        options: {
          num_predict: task.maxTokens || CONFIG.maxTokens,
          temperature: task.temperature || 0.7,
          top_p: task.topP || 0.9,
        }
      }, {
        timeout: CONFIG.workerTimeout,
        headers: { 'Content-Type': 'application/json' }
      });

      const duration = Date.now() - startTime;
      logger.info(`Worker ${workerId} completed task ${task.id} in ${duration}ms`);

      activeWorkers.dec();

      return {
        success: true,
        workerId,
        response: response.data.response,
        model: response.data.model,
        duration,
        stats: {
          totalTokens: response.data.total_duration / 1e9,
          evalCount: response.data.eval_count,
        }
      };

    } catch (error) {
      activeWorkers.dec();
      logger.error(`Worker ${workerId} failed:`, error.message);
      
      throw {
        success: false,
        workerId,
        error: error.message,
        duration: Date.now() - startTime
      };
    }
  }
}

const workerManager = new WorkerManager();

// ────────────────────────────────────────────────────────────────
// QUEUE PROCESSING
// ────────────────────────────────────────────────────────────────
taskQueue.process(CONFIG.maxWorkers, async (job) => {
  try {
    const result = await workerManager.executeTask(job.data);
    await redis.set(`result:${job.data.id}`, JSON.stringify(result), 'EX', 3600);
    return result;
  } catch (error) {
    await redis.set(`result:${job.data.id}`, JSON.stringify(error), 'EX', 3600);
    throw error;
  }
});

// ────────────────────────────────────────────────────────────────
// ROUTES API
// ────────────────────────────────────────────────────────────────

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    redis: redis.status === 'ready',
    ollama: true, // TODO: check Ollama health
  });
});

// Métriques Prometheus
app.get('/metrics', (req, res) => {
  res.set('Content-Type', register.contentType);
  register.metrics().then(data => res.send(data));
});

// Soumettre une tâche
app.post('/api/tasks', authenticateAPI, async (req, res) => {
  try {
    const taskId = uuidv4();
    const task = {
      id: taskId,
      prompt: req.body.prompt,
      model: req.body.model || 'llama3.1:8b',
      maxTokens: req.body.maxTokens || CONFIG.maxTokens,
      temperature: req.body.temperature || 0.7,
      topP: req.body.topP || 0.9,
      priority: req.body.priority || 5,
      createdAt: Date.now(),
    };

    // Ajouter à la queue
    const job = await taskQueue.add(task, {
      priority: task.priority,
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 2000
      }
    });

    // Mettre à jour métrique
    const queueCount = await taskQueue.count();
    queueLength.set(queueCount);

    logger.info(`Task ${taskId} queued with priority ${task.priority}`);

    res.status(202).json({
      success: true,
      taskId,
      jobId: job.id,
      status: 'queued',
      estimatedWaitTime: Math.ceil(queueCount / CONFIG.maxWorkers) * 30, // secondes
    });

  } catch (error) {
    logger.error('Failed to queue task:', error);
    res.status(500).json({ error: 'Failed to queue task', details: error.message });
  }
});

// Vérifier statut d'une tâche
app.get('/api/tasks/:taskId', authenticateAPI, async (req, res) => {
  try {
    const { taskId } = req.params;
    
    // Chercher le résultat dans Redis
    const result = await redis.get(`result:${taskId}`);
    
    if (result) {
      const data = JSON.parse(result);
      return res.json({
        taskId,
        status: data.success ? 'completed' : 'failed',
        ...data
      });
    }

    // Chercher dans la queue
    const jobs = await taskQueue.getJobs(['active', 'waiting', 'delayed']);
    const job = jobs.find(j => j.data.id === taskId);

    if (job) {
      const state = await job.getState();
      return res.json({
        taskId,
        status: state,
        position: jobs.findIndex(j => j.id === job.id) + 1,
        createdAt: job.data.createdAt,
      });
    }

    res.status(404).json({ error: 'Task not found' });

  } catch (error) {
    logger.error('Failed to get task status:', error);
    res.status(500).json({ error: 'Failed to get task status' });
  }
});

// Lister les modèles disponibles
app.get('/api/models', authenticateAPI, async (req, res) => {
  try {
    const response = await axios.get(`${CONFIG.ollamaHost}/api/tags`);
    res.json({
      models: response.data.models || [],
      count: response.data.models?.length || 0,
    });
  } catch (error) {
    logger.error('Failed to list models:', error);
    res.status(500).json({ error: 'Failed to list models' });
  }
});

// Stats dashboard
app.get('/api/stats', authenticateAPI, async (req, res) => {
  try {
    const [waiting, active, completed, failed] = await Promise.all([
      taskQueue.getWaitingCount(),
      taskQueue.getActiveCount(),
      taskQueue.getCompletedCount(),
      taskQueue.getFailedCount(),
    ]);

    res.json({
      queue: {
        waiting,
        active,
        completed,
        failed,
        total: waiting + active + completed + failed,
      },
      workers: {
        max: CONFIG.maxWorkers,
        active: activeWorkers.get().values[0]?.value || 0,
      },
      uptime: process.uptime(),
      memory: process.memoryUsage(),
    });
  } catch (error) {
    logger.error('Failed to get stats:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error', details: err.message });
});

// ────────────────────────────────────────────────────────────────
// DÉMARRAGE
// ────────────────────────────────────────────────────────────────
app.listen(CONFIG.port, '0.0.0.0', () => {
  logger.info(`MCP Server running on port ${CONFIG.port}`);
  logger.info(`Ollama host: ${CONFIG.ollamaHost}`);
  logger.info(`Max workers: ${CONFIG.maxWorkers}`);
  logger.info(`Redis: ${CONFIG.redisHost}:${CONFIG.redisPort}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully...');
  await taskQueue.close();
  await redis.quit();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully...');
  await taskQueue.close();
  await redis.quit();
  process.exit(0);
});
