# 🚀 Configuration du démarrage automatique de 4LB.CA

## État actuel
- ✅ Docker est installé et actif
- ✅ Traefik fonctionne sur les ports 80/443
- ✅ Services de monitoring (Grafana, Prometheus) actifs
- ✅ Base de données (PostgreSQL, Redis) actives
- ❌ Laravel et workers en erreur (problème de logs supervisor)
- ❌ Service systemd 4lbca-docker inactif

## Scripts de gestion créés

### 1. `/scripts/quick-check.sh`
Vérification rapide de l'état de tous les services
```bash
./scripts/quick-check.sh
```

### 2. `/scripts/startup-check.sh`
Vérification complète au démarrage avec tests d'accès
```bash
./scripts/startup-check.sh
```

### 3. `/scripts/fix-startup.sh`
Configuration du démarrage automatique (à exécuter avec sudo)
```bash
sudo ./scripts/fix-startup.sh
```

### 4. `/scripts/fix-laravel.sh`
Correction des problèmes de Laravel
```bash
./scripts/fix-laravel.sh
```

## Pour configurer le démarrage automatique

### Option 1 : Solution rapide (temporaire)
```bash
# Arrêter nginx et démarrer tous les services
sudo systemctl stop nginx
sudo systemctl disable nginx
cd /home/lalpha/4lb.ca
docker-compose down
docker-compose up -d
```

### Option 2 : Solution permanente (recommandée)
```bash
# 1. Corriger le Dockerfile de Laravel
cd /home/lalpha/4lb.ca
cp docker/laravel/Dockerfile.fixed docker/laravel/Dockerfile

# 2. Reconstruire l'image
docker-compose build laravel laravel-worker

# 3. Configurer le service systemd
sudo cp /home/lalpha/4lbca-docker-fixed.service /etc/systemd/system/4lbca-docker.service
sudo systemctl daemon-reload
sudo systemctl enable 4lbca-docker.service

# 4. Désactiver nginx
sudo systemctl disable nginx

# 5. Redémarrer le service
sudo systemctl restart 4lbca-docker.service
```

## Vérification après redémarrage

Au prochain démarrage du PC, exécutez :
```bash
cd /home/lalpha/4lb.ca
./scripts/quick-check.sh
```

## URLs d'accès

Une fois tout configuré :
- Site principal : https://4lb.ca
- Interface AI : https://ai.4lb.ca (port 8081 actuellement)
- Grafana : https://grafana.4lb.ca (port 3000)
- Prometheus : https://prometheus.4lb.ca (port 9090)
- Traefik Dashboard : https://traefik.4lb.ca

## En cas de problème

1. Vérifier les logs :
```bash
docker-compose logs -f laravel
journalctl -u 4lbca-docker -f
```

2. Redémarrer manuellement :
```bash
cd /home/lalpha/4lb.ca
docker-compose down
docker-compose up -d
```

3. Si nginx reprend le port 80 :
```bash
sudo systemctl stop nginx
sudo systemctl mask nginx
```

## Monitoring continu

Pour surveiller en permanence :
```bash
./scripts/monitor.sh &
tail -f logs/monitor.log
```
