#!/bin/bash

# Script de vérification de santé pour 4lb.ca
# Retourne 0 si tout va bien, 1 sinon

ERRORS=0

# Vérifier les services critiques
for service in traefik laravel postgres redis; do
    if ! docker ps | grep -q "$service"; then
        echo "ERREUR: Service $service non trouvé"
        ERRORS=$((ERRORS + 1))
    fi
done

# Vérifier les URLs principales
if ! curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "http://localhost:80" | grep -q "200\|301\|302\|404"; then
    echo "ERREUR: Site principal non accessible"
    ERRORS=$((ERRORS + 1))
fi

if [ $ERRORS -eq 0 ]; then
    echo "✅ Tous les services sont opérationnels"
    exit 0
else
    echo "❌ $ERRORS erreur(s) détectée(s)"
    exit 1
fi
