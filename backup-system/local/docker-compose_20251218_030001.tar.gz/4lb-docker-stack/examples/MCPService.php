<?php
/**
 * Service MCP pour Laravel
 * Intégration avec le MCP Server pour requêtes LLM
 * 
 * Installation:
 * 1. Copier ce fichier dans app/Services/MCPService.php
 * 2. Configurer dans .env:
 *    MCP_API_URL=http://mcp-server:8080
 *    MCP_API_KEY=votre-clé-api
 * 
 * Utilisation:
 *    $mcp = app(MCPService::class);
 *    $response = $mcp->query("Bonjour, comment ça va?");
 */

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Exception;

class MCPService
{
    /**
     * URL de l'API MCP
     */
    protected string $apiUrl;

    /**
     * Clé API
     */
    protected string $apiKey;

    /**
     * Timeout par défaut (secondes)
     */
    protected int $defaultTimeout = 300;

    /**
     * Constructeur
     */
    public function __construct()
    {
        $this->apiUrl = rtrim(config('services.mcp.url', 'http://mcp-server:8080'), '/');
        $this->apiKey = config('services.mcp.key', env('MCP_API_KEY'));

        if (empty($this->apiKey)) {
            throw new Exception('MCP_API_KEY not configured');
        }
    }

    /**
     * Soumettre une tâche au MCP Server
     *
     * @param string $prompt Le prompt
     * @param string $model Modèle à utiliser
     * @param array $options Options additionnelles
     * @return array Réponse contenant taskId, status, etc.
     */
    public function submitTask(
        string $prompt,
        string $model = 'llama3.1:8b',
        array $options = []
    ): array {
        $payload = array_merge([
            'prompt' => $prompt,
            'model' => $model,
        ], $options);

        $response = Http::withHeaders([
            'X-API-Key' => $this->apiKey,
        ])->timeout(30)->post("{$this->apiUrl}/api/tasks", $payload);

        if (!$response->successful()) {
            Log::error('MCP task submission failed', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);
            throw new Exception("MCP API error: " . $response->status());
        }

        return $response->json();
    }

    /**
     * Récupérer le statut d'une tâche
     *
     * @param string $taskId ID de la tâche
     * @return array Statut de la tâche
     */
    public function getTaskStatus(string $taskId): array
    {
        $response = Http::withHeaders([
            'X-API-Key' => $this->apiKey,
        ])->timeout(10)->get("{$this->apiUrl}/api/tasks/{$taskId}");

        if (!$response->successful()) {
            throw new Exception("Failed to get task status: " . $response->status());
        }

        return $response->json();
    }

    /**
     * Attendre le résultat d'une tâche
     *
     * @param string $taskId ID de la tâche
     * @param int $timeout Timeout en secondes
     * @param int $pollInterval Intervalle de polling en secondes
     * @return array|null Résultat ou null si timeout
     */
    public function waitForResult(
        string $taskId,
        int $timeout = 300,
        int $pollInterval = 2
    ): ?array {
        $startTime = time();

        while (time() - $startTime < $timeout) {
            $status = $this->getTaskStatus($taskId);

            if ($status['status'] === 'completed') {
                return $status['result'] ?? null;
            }

            if ($status['status'] === 'failed') {
                throw new Exception("Task failed: " . ($status['error'] ?? 'Unknown error'));
            }

            sleep($pollInterval);
        }

        throw new Exception("Task timeout after {$timeout}s");
    }

    /**
     * Méthode simplifiée : soumettre et attendre le résultat
     *
     * @param string $prompt Le prompt
     * @param string $model Modèle à utiliser
     * @param array $options Options additionnelles
     * @param int $timeout Timeout en secondes
     * @return string Réponse du LLM
     */
    public function query(
        string $prompt,
        string $model = 'llama3.1:8b',
        array $options = [],
        int $timeout = 300
    ): string {
        // Soumettre la tâche
        $task = $this->submitTask($prompt, $model, $options);
        $taskId = $task['taskId'];

        Log::info('MCP task submitted', ['taskId' => $taskId]);

        // Attendre le résultat
        $result = $this->waitForResult($taskId, $timeout);

        return $result['response'] ?? '';
    }

    /**
     * Requête avec cache (pour éviter les requêtes répétées)
     *
     * @param string $prompt Le prompt
     * @param string $model Modèle à utiliser
     * @param int $cacheTtl TTL du cache en secondes (défaut: 1h)
     * @return string Réponse du LLM
     */
    public function queryCached(
        string $prompt,
        string $model = 'llama3.1:8b',
        int $cacheTtl = 3600
    ): string {
        $cacheKey = 'mcp:' . md5($prompt . $model);

        return Cache::remember($cacheKey, $cacheTtl, function () use ($prompt, $model) {
            return $this->query($prompt, $model);
        });
    }

    /**
     * Récupérer les statistiques du MCP Server
     *
     * @return array Statistiques
     */
    public function getStats(): array
    {
        $response = Http::withHeaders([
            'X-API-Key' => $this->apiKey,
        ])->timeout(10)->get("{$this->apiUrl}/api/stats");

        if (!$response->successful()) {
            throw new Exception("Failed to get stats: " . $response->status());
        }

        return $response->json();
    }

    /**
     * Lister les modèles disponibles
     *
     * @return array Liste des modèles
     */
    public function listModels(): array
    {
        $response = Http::withHeaders([
            'X-API-Key' => $this->apiKey,
        ])->timeout(10)->get("{$this->apiUrl}/api/models");

        if (!$response->successful()) {
            throw new Exception("Failed to list models: " . $response->status());
        }

        return $response->json()['models'] ?? [];
    }

    /**
     * Vérifier la santé du MCP Server
     *
     * @return bool True si healthy
     */
    public function health(): bool
    {
        try {
            $response = Http::timeout(5)->get("{$this->apiUrl}/health");
            return $response->successful();
        } catch (Exception $e) {
            return false;
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Controller Example - app/Http/Controllers/AIController.php
// ════════════════════════════════════════════════════════════════

namespace App\Http\Controllers;

use App\Services\MCPService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class AIController extends Controller
{
    protected MCPService $mcp;

    public function __construct(MCPService $mcp)
    {
        $this->mcp = $mcp;
    }

    /**
     * Endpoint pour requêtes LLM simples
     *
     * POST /api/ai/query
     * Body: { "prompt": "Your question here", "model": "llama3.1:8b" }
     */
    public function query(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'prompt' => 'required|string|max:10000',
            'model' => 'sometimes|string',
            'temperature' => 'sometimes|numeric|min:0|max:2',
            'maxTokens' => 'sometimes|integer|min:1|max:8192',
        ]);

        try {
            $response = $this->mcp->query(
                $validated['prompt'],
                $validated['model'] ?? 'llama3.1:8b',
                array_filter([
                    'temperature' => $validated['temperature'] ?? null,
                    'maxTokens' => $validated['maxTokens'] ?? null,
                ])
            );

            return response()->json([
                'success' => true,
                'response' => $response,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Soumettre une tâche asynchrone
     *
     * POST /api/ai/submit
     */
    public function submit(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'prompt' => 'required|string|max:10000',
            'model' => 'sometimes|string',
            'priority' => 'sometimes|integer|min:1|max:10',
        ]);

        try {
            $task = $this->mcp->submitTask(
                $validated['prompt'],
                $validated['model'] ?? 'llama3.1:8b',
                ['priority' => $validated['priority'] ?? 5]
            );

            return response()->json([
                'success' => true,
                'taskId' => $task['taskId'],
                'status' => $task['status'],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Vérifier le statut d'une tâche
     *
     * GET /api/ai/status/{taskId}
     */
    public function status(string $taskId): JsonResponse
    {
        try {
            $status = $this->mcp->getTaskStatus($taskId);

            return response()->json([
                'success' => true,
                'task' => $status,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Statistiques MCP
     *
     * GET /api/ai/stats
     */
    public function stats(): JsonResponse
    {
        try {
            $stats = $this->mcp->getStats();

            return response()->json([
                'success' => true,
                'stats' => $stats,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Routes Example - routes/api.php
// ════════════════════════════════════════════════════════════════

/*
use App\Http\Controllers\AIController;

Route::prefix('ai')->group(function () {
    Route::post('/query', [AIController::class, 'query']);
    Route::post('/submit', [AIController::class, 'submit']);
    Route::get('/status/{taskId}', [AIController::class, 'status']);
    Route::get('/stats', [AIController::class, 'stats']);
});
*/

// ════════════════════════════════════════════════════════════════
// Config Example - config/services.php
// ════════════════════════════════════════════════════════════════

/*
return [
    // ...

    'mcp' => [
        'url' => env('MCP_API_URL', 'http://mcp-server:8080'),
        'key' => env('MCP_API_KEY'),
    ],
];
*/

// ════════════════════════════════════════════════════════════════
// Usage Examples
// ════════════════════════════════════════════════════════════════

/*
// Exemple 1: Requête simple
$mcp = app(MCPService::class);
$response = $mcp->query("Qu'est-ce que Laravel?");
echo $response;

// Exemple 2: Avec cache
$response = $mcp->queryCached("Explique Docker", 'llama3.1:8b', 7200);

// Exemple 3: Tâche asynchrone
$task = $mcp->submitTask("Écris un long article...", 'llama3.1:8b');
$taskId = $task['taskId'];

// Plus tard...
$result = $mcp->waitForResult($taskId);
echo $result['response'];

// Exemple 4: Dans un contrôleur
class BlogController extends Controller
{
    public function generateContent(Request $request, MCPService $mcp)
    {
        $title = $request->input('title');
        $prompt = "Écris un article de blog sur: {$title}";
        
        $content = $mcp->query($prompt, 'llama3.1:8b', [
            'temperature' => 0.8,
            'maxTokens' => 2000
        ]);
        
        return view('blog.show', compact('content'));
    }
}

// Exemple 5: Job Laravel
class GenerateArticleJob implements ShouldQueue
{
    protected string $topic;

    public function handle(MCPService $mcp)
    {
        $article = $mcp->query("Écris sur: {$this->topic}");
        
        // Sauvegarder en DB
        Article::create([
            'title' => $this->topic,
            'content' => $article,
        ]);
    }
}
*/
