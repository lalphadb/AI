#!/bin/bash
# Script de sauvegarde automatique quotidienne
# Crontab: 0 2 * * * /home/lalpha/scripts/auto-commit-ai-tools.sh >> /home/lalpha/scripts/auto-commit.log 2>&1

cd /home/lalpha/projets/ai-tools

# Configurer SSH
export GIT_SSH_COMMAND="ssh -i /home/lalpha/.ssh/github_ed25519 -o IdentitiesOnly=yes"

# Vérifier s'il y a des changements
if [[ -n $(git status --porcelain) ]]; then
    DATE=$(date '+%Y-%m-%d %H:%M')
    git add .
    git commit -m "💾 Auto-save: $DATE"
    git push origin main
    echo "[$DATE] ✅ Changes committed and pushed"
else
    echo "[$(date '+%Y-%m-%d %H:%M')] No changes to commit"
fi
