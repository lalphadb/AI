#!/bin/bash
# Script de mise à jour des serveurs MCP
# Auteur: Claude via MCP | Date: 2025-11-30

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

MCP_BASE="/home/lalpha/projets/ai-tools/mcp-servers"
NEW_SDK_VERSION="^1.23.0"

echo -e "${BLUE}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Mise à jour des Serveurs MCP               ║${NC}"
echo -e "${BLUE}║   SDK cible: ${NEW_SDK_VERSION}                       ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════╝${NC}"

update_mcp_server() {
    local server_name=$1
    local server_path="${MCP_BASE}/${server_name}"
    
    if [ ! -d "$server_path" ]; then
        echo -e "${RED}❌ Non trouvé: $server_name${NC}"
        return 1
    fi
    
    echo -e "${YELLOW}📦 Mise à jour: ${server_name}${NC}"
    cd "$server_path"
    
    local current=$(grep -o '"@modelcontextprotocol/sdk": "[^"]*"' package.json 2>/dev/null | cut -d'"' -f4)
    echo -e "   Actuel: ${RED}${current}${NC}"
    
    sed -i "s|\"@modelcontextprotocol/sdk\": \"[^\"]*\"|\"@modelcontextprotocol/sdk\": \"$NEW_SDK_VERSION\"|g" package.json
    npm install --prefer-offline 2>/dev/null || npm install
    
    [ -f "tsconfig.json" ] && npm run build 2>/dev/null || true
    
    local new=$(npm list @modelcontextprotocol/sdk --depth=0 2>/dev/null | grep sdk | awk -F@ '{print $NF}')
    echo -e "   Nouveau: ${GREEN}${new}${NC}"
}

# Backup
BACKUP="${MCP_BASE}/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
for s in ubuntu-mcp filesystem-mcp udm-pro-mcp chromadb-mcp; do
    [ -d "${MCP_BASE}/${s}" ] && cp "${MCP_BASE}/${s}/package.json" "${BACKUP}/${s}.json" 2>/dev/null
done
echo -e "${GREEN}✅ Backup: ${BACKUP}${NC}"

# Updates
for server in ubuntu-mcp filesystem-mcp udm-pro-mcp chromadb-mcp; do
    update_mcp_server "$server"
done

echo -e "${BLUE}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   ✅ Mise à jour terminée!                   ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════╝${NC}"
echo -e "${YELLOW}⚠️ Redémarrer Claude Desktop pour appliquer${NC}"
