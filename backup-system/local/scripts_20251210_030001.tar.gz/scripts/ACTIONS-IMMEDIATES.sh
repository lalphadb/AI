#!/bin/bash
# Actions immédiates de sécurisation
# Ce script vous guide étape par étape

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

clear
echo -e "${BLUE}"
cat << "LOGO"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║     🔒  SÉCURISATION SERVEUR UBUNTU - GUIDE INTERACTIF   ║
║                                                           ║
║     Serveur: lalpha-server-1 (10.10.10.46)              ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
LOGO
echo -e "${NC}"

echo ""
echo -e "${YELLOW}Ce script va vous guider pour sécuriser votre serveur.${NC}"
echo -e "${YELLOW}Vous pourrez choisir les actions à effectuer.${NC}"
echo ""
read -p "Appuyez sur ENTRÉE pour continuer..."

# Fonction pour demander confirmation
ask_continue() {
    echo ""
    read -p "$(echo -e ${CYAN}Voulez-vous effectuer cette action ? [o/N] ${NC})" -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Oo]$ ]]; then
        return 0
    else
        echo -e "${YELLOW}➜ Action ignorée${NC}"
        return 1
    fi
}

# Fonction de séparateur
separator() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# ============================================
# ACTION 1: Vérifier l'état actuel
# ============================================
separator
echo -e "${YELLOW}[ACTION 1/6] 📊 VÉRIFICATION DE L'ÉTAT ACTUEL${NC}"
echo ""
echo "Cette action va générer un rapport de sécurité complet."
echo "Cela prend environ 10 secondes."

if ask_continue; then
    ~/security-check.sh
    echo ""
    echo -e "${GREEN}✓ Rapport généré${NC}"
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# ACTION 2: Activer UFW (CRITIQUE)
# ============================================
separator
echo -e "${RED}[ACTION 2/6] 🔥 ACTIVER LE FIREWALL UFW (CRITIQUE)${NC}"
echo ""
echo -e "${RED}⚠️  ATTENTION: Ceci est l'action la plus critique !${NC}"
echo ""
echo "Le firewall UFW va:"
echo "  ✓ Bloquer tout le trafic entrant par défaut"
echo "  ✓ Autoriser SSH uniquement depuis le réseau local"
echo "  ✓ Autoriser HTTP/HTTPS (Traefik)"
echo "  ✓ Autoriser les services mail"
echo "  ✓ BLOQUER le port RDP (3389)"
echo "  ✓ BLOQUER Grafana/Prometheus depuis Internet"
echo ""
echo -e "${YELLOW}IMPORTANT: Assurez-vous d'avoir un accès physique ou console${NC}"
echo -e "${YELLOW}au serveur en cas de problème !${NC}"
echo ""

if ask_continue; then
    sudo ~/configure-ufw.sh
    
    echo ""
    echo -e "${GREEN}✓ UFW configuré${NC}"
    echo ""
    echo "Vérification de l'accès SSH..."
    
    # Test SSH
    if systemctl is-active --quiet ssh; then
        echo -e "${GREEN}✓ SSH toujours actif${NC}"
    else
        echo -e "${RED}✗ PROBLÈME: SSH n'est plus actif !${NC}"
    fi
    
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# ACTION 3: Corriger RKHunter
# ============================================
separator
echo -e "${YELLOW}[ACTION 3/6] 🔍 CORRIGER RKHUNTER${NC}"
echo ""
echo "RKHunter (Rootkit Hunter) détecte les rootkits et malwares."
echo "Cette action va corriger sa configuration."

if ask_continue; then
    if [ -f "/tmp/fix-rkhunter.sh" ]; then
        sudo /tmp/fix-rkhunter.sh
        echo ""
        echo -e "${GREEN}✓ RKHunter corrigé${NC}"
    else
        echo -e "${YELLOW}Script non trouvé, création...${NC}"
        cat > /tmp/fix-rkhunter.sh << 'RKHEOF'
#!/bin/bash
sudo cp /etc/rkhunter.conf /etc/rkhunter.conf.backup
sudo sed -i 's|^WEB_CMD=.*|WEB_CMD="/usr/bin/curl"|' /etc/rkhunter.conf
sudo sed -i 's|^ALLOW_SSH_ROOT_USER=.*|ALLOW_SSH_ROOT_USER=prohibit-password|' /etc/rkhunter.conf
sudo rkhunter --propupd
RKHEOF
        chmod +x /tmp/fix-rkhunter.sh
        sudo /tmp/fix-rkhunter.sh
        echo -e "${GREEN}✓ RKHunter corrigé${NC}"
    fi
    
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# ACTION 4: Sécuriser Docker
# ============================================
separator
echo -e "${YELLOW}[ACTION 4/6] 🐳 SÉCURISER DOCKER${NC}"
echo ""
echo "Cette action va:"
echo "  ✓ Limiter la taille des logs Docker"
echo "  ✓ Configurer des politiques de sécurité"
echo "  ✓ Nettoyer les conteneurs/images inutilisés"
echo "  ✓ Installer Docker Bench Security"
echo ""
echo -e "${RED}ATTENTION: Les conteneurs Docker vont redémarrer !${NC}"

if ask_continue; then
    sudo ~/secure-docker.sh
    echo ""
    echo -e "${GREEN}✓ Docker sécurisé${NC}"
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# ACTION 5: Configurer SSH Hardening
# ============================================
separator
echo -e "${YELLOW}[ACTION 5/6] 🔐 HARDENING SSH${NC}"
echo ""
echo "Cette action va créer une configuration SSH renforcée."
echo ""
echo -e "${RED}⚠️  N'ACTIVEZ PAS 'PasswordAuthentication no'${NC}"
echo -e "${RED}    tant que vous n'avez pas configuré une clé SSH !${NC}"
echo ""
echo "Configuration proposée:"
echo "  • PermitRootLogin prohibit-password"
echo "  • MaxAuthTries 3"
echo "  • ClientAliveInterval 300"
echo ""

if ask_continue; then
    echo "Création de la configuration..."
    
    sudo tee /etc/ssh/sshd_config.d/99-hardening.conf > /dev/null << 'SSHEOF'
# SSH Hardening Configuration
PermitRootLogin prohibit-password
MaxAuthTries 3
MaxSessions 2
ClientAliveInterval 300
ClientAliveCountMax 2
Protocol 2

# Algorithmes forts
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com
KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org

# Désactiver les tunnels
AllowTcpForwarding no
AllowStreamLocalForwarding no
GatewayPorts no
PermitTunnel no

# Limiter les utilisateurs
AllowUsers lalpha

# NOTE: PasswordAuthentication est encore à 'yes'
# Configurez une clé SSH avant de le désactiver !
SSHEOF

    # Tester la configuration
    if sudo sshd -t; then
        echo -e "${GREEN}✓ Configuration SSH valide${NC}"
        echo ""
        echo "Pour appliquer, exécutez:"
        echo "  sudo systemctl restart sshd"
        echo ""
        echo -e "${YELLOW}Voulez-vous redémarrer SSH maintenant ?${NC}"
        read -p "[o/N] " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Oo]$ ]]; then
            sudo systemctl restart sshd
            echo -e "${GREEN}✓ SSH redémarré${NC}"
        fi
    else
        echo -e "${RED}✗ Erreur dans la configuration SSH${NC}"
        echo "Configuration non appliquée pour sécurité"
    fi
    
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# ACTION 6: Configurer les mises à jour auto
# ============================================
separator
echo -e "${YELLOW}[ACTION 6/6] 🔄 MISES À JOUR AUTOMATIQUES${NC}"
echo ""
echo "Cette action va configurer les mises à jour de sécurité automatiques."

if ask_continue; then
    if [ -f "/etc/apt/apt.conf.d/50unattended-upgrades" ]; then
        echo -e "${GREEN}✓ Les mises à jour automatiques sont déjà configurées${NC}"
    else
        echo "Installation de unattended-upgrades..."
        sudo apt install -y unattended-upgrades apt-listchanges
        
        sudo tee /etc/apt/apt.conf.d/20auto-upgrades > /dev/null << 'UPGRADEEOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";
UPGRADEEOF
        
        echo -e "${GREEN}✓ Mises à jour automatiques configurées${NC}"
    fi
    
    echo ""
    read -p "Appuyez sur ENTRÉE pour continuer..."
fi

# ============================================
# RÉSUMÉ FINAL
# ============================================
separator
echo -e "${BLUE}"
cat << "SUMMARY"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║              ✅  SÉCURISATION TERMINÉE !                  ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
SUMMARY
echo -e "${NC}"

echo ""
echo -e "${GREEN}Actions effectuées avec succès !${NC}"
echo ""
echo -e "${YELLOW}PROCHAINES ÉTAPES:${NC}"
echo ""
echo "1. Vérifiez l'état de la sécurité:"
echo "   ${CYAN}~/security-check.sh${NC}"
echo ""
echo "2. Vérifiez les logs UFW:"
echo "   ${CYAN}sudo tail -f /var/log/ufw.log${NC}"
echo ""
echo "3. Vérifiez Fail2Ban:"
echo "   ${CYAN}sudo fail2ban-client status${NC}"
echo ""
echo "4. Testez l'accès aux services:"
echo "   ${CYAN}curl -I https://4lb.ca${NC}"
echo ""
echo "5. Consultez le guide complet:"
echo "   ${CYAN}cat ~/README-SECURITE.md${NC}"
echo ""
echo -e "${YELLOW}IMPORTANT:${NC}"
echo "• Configurez une clé SSH avant de désactiver l'auth par mot de passe"
echo "• Configurez des alertes email (Fail2Ban, Logwatch)"
echo "• Effectuez un audit Docker: cd /opt/docker-bench-security && sudo ./docker-bench-security.sh"
echo ""

separator

echo -e "${GREEN}Script terminé !${NC}"
echo ""
