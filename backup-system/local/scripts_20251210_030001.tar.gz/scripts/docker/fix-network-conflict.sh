#!/usr/bin/env bash
set -euo pipefail

echo "═══════════════════════════════════════════════════"
echo "🔧 Nettoyage Réseaux Docker Conflictuels"
echo "═══════════════════════════════════════════════════"
echo ""

STACK_DIR="/home/lalpha/projets/infrastructure/4lb-docker-stack"

echo "📂 [1/5] Passage dans le dossier de la stack..."
cd "$STACK_DIR"

echo "🛑 [2/5] Arrêt complet de tous les conteneurs..."
docker compose down

echo "🗑️  [3/5] Suppression des anciens réseaux 4lbca_*..."
for network in 4lbca_backend 4lbca_frontend 4lbca_llm 4lbca_monitoring; do
    if docker network inspect "$network" >/dev/null 2>&1; then
        echo "   Suppression de $network..."
        docker network rm "$network" 2>/dev/null || echo "   ⚠️  $network est peut-être encore utilisé, ignoré"
    else
        echo "   ✓ $network déjà supprimé"
    fi
done

echo "🧹 [4/5] Nettoyage des ressources inutilisées..."
docker network prune -f

echo "🚀 [5/5] Redémarrage de la stack avec les nouveaux réseaux..."
docker compose up -d --force-recreate --remove-orphans

echo ""
echo "═══════════════════════════════════════════════════"
echo "✅ Nettoyage terminé"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📊 Réseaux Docker actuels :"
docker network ls

echo ""
echo "👉 Lancez maintenant : ~/scripts/docker/check_4lb_stack.sh"
