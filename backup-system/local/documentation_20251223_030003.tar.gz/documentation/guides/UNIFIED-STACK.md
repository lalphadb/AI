# 🎯 Guide Unified Stack

> **Emplacement** : `/home/lalpha/projets/infrastructure/unified-stack/`
> **Date** : 7 décembre 2025
> **Version** : 1.0

---

## 📋 Principe

**UN docker-compose.yml → UN réseau → TOUS les services**

Avant la migration, l'infrastructure avait :
- 20+ fichiers docker-compose.yml dispersés
- 8 réseaux Docker différents
- Problèmes de routing constants ("toucher X casse Y")

Maintenant :
- 1 seul docker-compose.yml
- 1 seul réseau (unified-net)
- Tous les services se voient
- Gestion simplifiée via stack.sh

---

## 🚀 Commandes

```bash
cd /home/lalpha/projets/infrastructure/unified-stack

# Démarrer
./stack.sh up              # Tout démarrer
./stack.sh up ai           # Démarrer profil AI seulement
./stack.sh up monitoring   # Démarrer profil monitoring seulement

# Arrêter
./stack.sh down            # Tout arrêter

# Gérer
./stack.sh status          # État des conteneurs
./stack.sh restart grafana # Redémarrer un service
./stack.sh logs traefik    # Voir les logs
./stack.sh logs -f traefik # Logs en temps réel

# Mettre à jour
./stack.sh update jsr-dev  # Pull + rebuild + restart

# Tester
./stack.sh test            # Tester toutes les URLs
```

---

## 📦 Services

### Core (toujours actifs)
- **traefik** : Reverse proxy + SSL
- **postgres** : Base de données
- **redis** : Cache

### Profil AI
- **open-webui** : Chat LLM (llm.4lb.ca)
- **ai-orchestrator-backend** : API Agent IA
- **ai-orchestrator-frontend** : Interface Agent (ai.4lb.ca)
- **chromadb** : Base vectorielle

### Profil Web
- **jsr-dev** : Site JSR dev (jsr.4lb.ca)
- **jsr-solutions** : Site JSR prod (jsr-solutions.ca)

### Profil Monitoring
- **prometheus** : Métriques
- **grafana** : Dashboards
- **node-exporter** : Métriques système
- **cadvisor** : Métriques Docker

### Profil Tools
- **code-server** : IDE VS Code (code.4lb.ca)

---

## 📁 Structure

```
unified-stack/
├── docker-compose.yml    # Source unique de vérité
├── .env                  # Variables d'environnement
├── stack.sh              # Script de gestion
├── migrate.sh            # Script migration (historique)
└── configs/
    ├── prometheus/
    │   └── prometheus.yml
    └── traefik/
        └── dynamic/      # Configs Traefik dynamiques
```

---

## 🔧 Configuration

### Variables d'environnement (.env)

```bash
POSTGRES_PASSWORD=lalpha2024secure
GRAFANA_PASSWORD=admin2024
CODE_SERVER_PASSWORD=code2024
WEBUI_SECRET_KEY=webui2024secret
TZ=America/Toronto
```

### Prometheus

Config : `configs/prometheus/prometheus.yml`

Targets actuels :
- prometheus (localhost:9090)
- node-exporter (node-exporter:9100)
- cadvisor (cadvisor:8080)
- traefik (traefik:8080)
- ollama (10.10.10.46:11434)

### Traefik

- SSL automatique via Let's Encrypt
- Routing basé sur les labels Docker
- Dashboard : https://traefik.4lb.ca

---

## ➕ Ajouter un Service

1. **Éditer docker-compose.yml**

```yaml
  mon-service:
    image: mon-image:latest
    container_name: mon-service
    restart: unless-stopped
    profiles: ["web", "all"]  # Choisir le profil
    networks:
      - main
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.mon-service.rule=Host(`mon.4lb.ca`)"
      - "traefik.http.routers.mon-service.entrypoints=websecure"
      - "traefik.http.routers.mon-service.tls.certresolver=letsencrypt"
      - "traefik.http.services.mon-service.loadbalancer.server.port=8080"
```

2. **Démarrer**

```bash
./stack.sh up
```

3. **Vérifier**

```bash
./stack.sh test
```

---

## 🔄 Mettre à Jour un Service

```bash
# Rebuild + restart
./stack.sh update jsr-dev

# Ou manuellement
docker compose build jsr-dev
docker compose up -d jsr-dev
```

---

## 🐛 Dépannage

### Service ne répond pas

```bash
# Vérifier l'état
./stack.sh status

# Voir les logs
./stack.sh logs mon-service

# Redémarrer
./stack.sh restart mon-service
```

### Problème de réseau

```bash
# Vérifier que le service est sur unified-net
docker inspect mon-service | grep -A5 Networks
```

### Certificat SSL

```bash
# Voir les logs Traefik
./stack.sh logs traefik | grep -i acme
```

---

## 📊 Monitoring

### Prometheus Targets

```bash
curl -s https://prometheus.4lb.ca/api/v1/targets | python3 -c "
import sys,json
data=json.load(sys.stdin)
for t in data.get('data',{}).get('activeTargets',[]):
    status = '✅' if t['health'] == 'up' else '❌'
    print(f\"{status} {t['labels'].get('job','?')}: {t['health']}\")
"
```

### Grafana

- URL : https://grafana.4lb.ca
- User : admin
- Password : voir .env (GRAFANA_PASSWORD)

---

## 🔒 Sécurité

- Tous les services sont sur un réseau isolé
- Seuls les ports 80/443 sont exposés publiquement
- SSL automatique via Let's Encrypt
- Pas d'accès direct aux bases de données depuis l'extérieur

---

*Guide créé le 7 décembre 2025*
