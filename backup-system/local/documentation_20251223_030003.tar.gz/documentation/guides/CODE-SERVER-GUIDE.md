# 🖥️ Guide Code-Server - Agent IA Autonome

> **Date** : 3 décembre 2025
> **Version** : Phase 1 (Interface VS Code)
> **Accès** : https://code.4lb.ca

---

## 🎯 Objectif

Code-server te donne accès à un **agent IA autonome** (comme Claude Code) accessible de partout :
- **Ordinateur** (navigateur)
- **Téléphone** (navigateur)
- **Tablette** (navigateur)

---

## 📱 Accès

### URL
```
https://code.4lb.ca
```

### Mot de passe
```
MWYrmdHc+1T/AN8KJVOcSdv3fPiZpiCS9D5Q49kVBck=
```

**Note** : Sauvegarde ce mot de passe dans ton gestionnaire de mots de passe !

---

## 🤖 Agents IA Disponibles

### **1. Cline** (Recommandé - Chef d'orchestre)

**Rôle** : Agent autonome qui exécute des missions complètes

**Utilisation** :
1. Clique sur l'icône **Cline** dans la barre latérale
2. Donne-lui une mission :
   - "Crée un système de monitoring Docker complet"
   - "Analyse les logs et trouve le problème"
   - "Mets à jour tous les MCP servers"
   - "Répare le conteneur qui crash"
3. Cline planifie les étapes
4. Cline exécute automatiquement
5. Cline te demande confirmation si actions critiques

**Exemples de missions** :
```
"Crée un script de backup automatique pour PostgreSQL"
"Analyse les performances du serveur et propose des optimisations"
"Crée un dashboard de monitoring avec Grafana"
"Configure un système d'alertes pour les erreurs Docker"
```

**Modèles disponibles** :
- Qwen 2.5 Coder 32B (local, gratuit, rapide)
- Claude Sonnet 4 (API, payant, très intelligent)

---

### **2. Continue** (Assistant quotidien)

**Rôle** : Assistant de codage et autocomplétion IA

**Utilisation** :

#### Autocomplétion
- Tape du code
- Appuie sur **Tab** pour accepter la suggestion IA
- Continue génère du code intelligent en temps réel

#### Chat
- Sélectionne du code
- Clic droit → "Continue: Ask"
- Pose une question sur le code

#### Commandes rapides
- `/test` : Génère des tests pour le code sélectionné
- `/check` : Analyse bugs et performance
- `/explain` : Explique le code sélectionné

**Modèles disponibles** :
- Qwen 2.5 Coder 32B (autocomplétion)
- DeepSeek Coder 33B (code alternatif)
- Llama 3.2 Vision 11B (analyse d'images)
- Claude Sonnet 4 (raisonnement avancé)

---

## 🔧 Outils MCP (33 outils disponibles)

Les agents (Cline & Continue) ont accès à **33 outils MCP** :

### **ubuntu-mcp** (12 outils)
- `execute_command` : Exécuter des commandes système
- `docker_status` : État des conteneurs Docker
- `system_info` : Infos CPU, RAM, disque
- `list_services` : Services systemd
- `check_ports` : Ports ouverts
- Et 7 autres...

### **udm-pro-mcp** (8 outils)
- `udm_status` : État UDM-Pro
- `udm_network_info` : Infos réseau UniFi
- `udm_firewall_rules` : Règles firewall
- `udm_devices` : Appareils connectés
- Et 4 autres...

### **filesystem-mcp** (4 outils)
- `analyze_directory` : Analyse de dossiers
- `find_duplicates` : Fichiers dupliqués
- `disk_usage` : Utilisation disque
- `file_search` : Recherche avancée

### **chromadb-mcp** (9 outils)
- `chroma_query` : Recherche vectorielle
- `store_memory` : Stocker des données
- `recall_memory` : Rappeler des données
- Et 6 autres...

---

## 📂 Structure des Dossiers

Tes dossiers sont montés dans code-server :

```
/home/coder/workspace/
├── projets/
│   ├── ai-tools/
│   ├── clients/
│   └── infrastructure/
├── scripts/
│   ├── security/
│   ├── docker/
│   └── fixes/
└── documentation/
    ├── guides/
    ├── comptes-rendus/
    └── archives/
```

**Tu peux modifier n'importe quel fichier et les changements seront sauvegardés sur le serveur !**

---

## 🎨 Personnalisation

### Thème
- **Actuel** : GitHub Dark
- **Changer** : Settings (Ctrl+,) → "Color Theme"

### Raccourcis Utiles
- `Ctrl+P` : Ouvrir un fichier rapidement
- `Ctrl+Shift+P` : Palette de commandes
- `Ctrl+`` : Terminal intégré
- `Ctrl+B` : Basculer la barre latérale
- `Tab` : Accepter l'autocomplétion IA

---

## 🚀 Cas d'Usage

### **1. Créer un nouveau projet**

**Avec Cline :**
```
"Crée un projet Express.js avec authentification JWT,
PostgreSQL, et Docker Compose prêt à déployer"
```

Cline va :
- Créer la structure de dossiers
- Générer le code
- Configurer Docker
- Créer les tests
- Te montrer comment le lancer

---

### **2. Corriger un bug**

**Avec Cline :**
```
"Le conteneur open-webui crash au démarrage.
Analyse les logs et répare le problème"
```

Cline va :
- Lire les logs Docker
- Identifier le problème
- Proposer une solution
- Appliquer le fix
- Redémarrer le conteneur

---

### **3. Monitoring automatique**

**Avec Cline :**
```
"Crée un script qui surveille les conteneurs Docker,
l'espace disque ORICO, et envoie des alertes si problème"
```

Cline va :
- Créer le script de monitoring
- Configurer les seuils d'alerte
- Ajouter un cron job
- Tester le script
- Documenter l'utilisation

---

### **4. Développement rapide**

**Avec Continue :**
1. Ouvre un fichier Python
2. Tape : `def calculate_disk_usage(`
3. **Tab** → Continue génère la fonction complète
4. Sélectionne la fonction → Clic droit → "/test"
5. Continue génère les tests automatiquement

---

## 🔐 Sécurité

### Accès
- ✅ **HTTPS** : Certificat Let's Encrypt automatique
- ✅ **Mot de passe** : Authentification requise
- ✅ **Traefik** : Reverse proxy sécurisé

### Permissions
- ✅ Accès Docker socket (peut gérer les conteneurs)
- ✅ Accès SSH (peut se connecter à UDM-Pro)
- ✅ Accès filesystem (peut modifier tes fichiers)

**⚠️ Protège bien ton mot de passe !**

---

## 🐛 Troubleshooting

### **Problème** : Code-server ne répond pas

**Solution** :
```bash
docker logs code-server
docker restart code-server
```

---

### **Problème** : Extensions ne fonctionnent pas

**Solution** :
1. Ouvre le terminal dans code-server (Ctrl+`)
2. Exécute :
```bash
/home/coder/init-extensions.sh
```

---

### **Problème** : MCP servers inaccessibles

**Solution** :
1. Vérifie la config MCP : `~/.continue/mcp.json`
2. Vérifie les logs :
```bash
docker logs code-server | grep -i mcp
```

---

## 📊 Performances

### Ressources Allouées
- **CPU** : 2-4 cores
- **RAM** : 4-8 GB
- **Stockage** : Volume Docker persistant

### Modèles Ollama
- Utilise `qwen2.5-coder:32b` pour rapidité (gratuit, local)
- Utilise `claude-sonnet-4` pour intelligence maximale (API payante)

---

## 🎯 Phase 2 : Interface Personnalisée

**Statut** : Planifiée (4-6h de développement)

### Améliorations prévues :
- ✨ Interface web minimaliste (style ChatGPT)
- 📱 Optimisée pour mobile
- 🎨 UI 100% personnalisée
- 🚀 VS Code caché en arrière-plan
- ⚡ Performance améliorée

**Architecture Phase 2 :**
```
┌────────────────────────────────┐
│   Interface Chat Simple        │
│   (React - Style ChatGPT)      │
│   https://ai.4lb.ca            │
└────────────────────────────────┘
              │
              ▼
┌────────────────────────────────┐
│   Code-Server (caché)          │
│   + Cline + Continue           │
│   + 33 MCP tools               │
└────────────────────────────────┘
```

---

## 📚 Ressources

### Documentation
- Guide MCP : `/home/lalpha/documentation/guides/MCP-SERVER-UDM-PRO.md`
- Guide Continue : `/home/lalpha/documentation/guides/INSTALLATION-CONTINUE-DEV.md`
- Architecture : `/home/lalpha/documentation/ARCHITECTURE.md`

### Liens Utiles
- Continue.dev : https://continue.dev/docs
- Cline : https://github.com/saoudrizwan/claude-dev
- MCP Protocol : https://modelcontextprotocol.io

---

## ✅ Checklist

- [x] Code-server installé
- [x] Traefik configuré (https://code.4lb.ca)
- [x] Extensions installées (Cline + Continue)
- [x] MCP servers configurés (33 outils)
- [x] Thème moderne appliqué
- [x] Accès mobile fonctionnel
- [ ] Tester Cline avec une mission
- [ ] Tester Continue avec autocomplétion
- [ ] Ajouter clé API Claude (optionnel)
- [ ] Phase 2 : Interface personnalisée

---

**Créé le** : 3 décembre 2025
**Par** : Claude Code
**Version** : 1.0 - Phase 1

