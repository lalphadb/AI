# MCP Server 4LB v2.0 - Documentation Gemini

## Connexion
- **URL SSE**: `http://10.10.10.46:8888/sse`
- **Port**: 8888
- **Transport**: SSE (Server-Sent Events)

## Outils Disponibles (20)

### 🖥️ Système (Lecture)
| Outil | Description | Exemple |
|-------|-------------|---------|
| `get_gpu_status()` | État GPU RTX 5070 Ti | Utilisation, VRAM, température |
| `get_system_status()` | État système complet | CPU, RAM, Disk, Load |
| `get_docker_status(all_containers=False)` | Liste containers | Docker ps |
| `ollama_list()` | Modèles LLM installés | qwen2.5-coder, etc. |
| `ollama_status()` | État service Ollama | Port 11434 |

### 📁 Fichiers
| Outil | Description | Paramètres |
|-------|-------------|------------|
| `read_file(path, lines=0)` | Lire fichier | lines=0 pour tout |
| `write_file(path, content, backup=True)` | Écrire/créer | Backup auto |
| `patch_file(path, old_text, new_text)` | Search/replace | Backup auto |
| `append_file(path, content)` | Ajouter à la fin | - |
| `list_directory(path, recursive=False)` | Lister dossier | - |
| `backup_file(path)` | Créer backup | timestamp.backup |

### 🐳 Docker
| Outil | Description | Paramètres |
|-------|-------------|------------|
| `docker_logs(container, lines=50)` | Voir logs | - |
| `docker_restart(container)` | Redémarrer | - |
| `docker_rebuild(service)` | Rebuild via stack.sh | - |
| `clean_docker_logs(container)` | Vider logs | truncate |

### 📊 Git
| Outil | Description | Paramètres |
|-------|-------------|------------|
| `git_status(repo_path)` | Statut git | - |
| `git_diff(repo_path, file_path="")` | Voir diff | - |
| `git_commit(repo_path, message, add_all=True)` | Créer commit | git add -A + commit |

### 🐍 Code
| Outil | Description | Paramètres |
|-------|-------------|------------|
| `python_check_syntax(path)` | Vérifier syntaxe | py_compile |
| `run_command(command, cwd)` | Exécuter shell | timeout 60s |

## Sécurité

### Chemins Autorisés
- `/home/lalpha/projets`
- `/home/lalpha/scripts`
- `/home/lalpha/documentation`
- `/tmp`

### Chemins Interdits
- `.env` (variables d'environnement)
- `id_rsa`, `id_ed25519` (clés SSH)
- `.ssh/`
- `secrets`
- `.git/objects`

### Extensions Interdites (écriture)
- `.key`, `.pem`, `.p12`

### Commandes Interdites
- `rm -rf /`
- `mkfs`
- `dd if=`
- `> /dev/`
- `chmod 777 /`
- Fork bomb

## Service Systemd

```bash
# Installation
sudo cp /tmp/mcp-4lb.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mcp-4lb

# Gestion
sudo systemctl status mcp-4lb
sudo systemctl restart mcp-4lb
journalctl -u mcp-4lb -f
```

## Structure Fichiers
```
/home/lalpha/projets/ai-tools/mcp-servers/custom-admin-mcp/
├── server.py           # Serveur MCP v2.0
├── venv/               # Environnement Python
└── requirements.txt    # Dépendances (fastmcp)
```

## Logs
- Console: `/tmp/mcp-server.log`
- Systemd: `journalctl -u mcp-4lb`

---
*Mis à jour: $(date)*
