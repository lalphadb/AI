#!/usr/bin/env python3
# ═══════════════════════════════════════════════════════════════
# AI Optimizer - Agent d'Auto-Amélioration
# Analyse système et suggestions d'optimisations via Claude
# ═══════════════════════════════════════════════════════════════

import os
import sys
import time
import json
import logging
import schedule
from datetime import datetime, timedelta
from typing import Dict, List, Any

import requests
from anthropic import Anthropic
from prometheus_api_client import PrometheusConnect
import docker

# ────────────────────────────────────────────────────────────────
# CONFIGURATION
# ────────────────────────────────────────────────────────────────
CONFIG = {
    'anthropic_api_key': os.getenv('ANTHROPIC_API_KEY'),
    'anthropic_model': os.getenv('ANTHROPIC_MODEL', 'claude-sonnet-4-20250514'),
    'ollama_host': os.getenv('OLLAMA_HOST', 'http://ollama:11434'),
    'prometheus_url': os.getenv('PROMETHEUS_URL', 'http://prometheus:9090'),
    'loki_url': os.getenv('LOKI_URL', 'http://loki:3100'),
    'check_interval': int(os.getenv('CHECK_INTERVAL', '21600')),  # 6h
    'auto_apply': os.getenv('AUTO_APPLY', 'false').lower() == 'true',
    'max_suggestions': int(os.getenv('MAX_SUGGESTIONS', '5')),
}

# ────────────────────────────────────────────────────────────────
# LOGGING
# ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/logs/optimizer.log')
    ]
)
logger = logging.getLogger('AI-Optimizer')

# ────────────────────────────────────────────────────────────────
# CLIENTS
# ────────────────────────────────────────────────────────────────
try:
    anthropic_client = Anthropic(api_key=CONFIG['anthropic_api_key'])
    prometheus = PrometheusConnect(url=CONFIG['prometheus_url'], disable_ssl=True)
    docker_client = docker.from_env()
    logger.info("✓ Clients initialisés avec succès")
except Exception as e:
    logger.error(f"✗ Erreur initialisation clients: {e}")
    sys.exit(1)

# ────────────────────────────────────────────────────────────────
# COLLECTE MÉTRIQUES SYSTÈME
# ────────────────────────────────────────────────────────────────
class MetricsCollector:
    """Collecte les métriques système depuis Prometheus"""
    
    def __init__(self):
        self.prom = prometheus
    
    def get_cpu_usage(self, hours=1) -> float:
        """CPU usage moyen"""
        try:
            query = f'avg(rate(node_cpu_seconds_total{{mode!="idle"}}[{hours}h]))'
            result = self.prom.custom_query(query)
            return float(result[0]['value'][1]) * 100 if result else 0
        except Exception as e:
            logger.error(f"Erreur CPU metrics: {e}")
            return 0
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Mémoire utilisée"""
        try:
            total_query = 'node_memory_MemTotal_bytes'
            available_query = 'node_memory_MemAvailable_bytes'
            
            total = self.prom.custom_query(total_query)
            available = self.prom.custom_query(available_query)
            
            total_bytes = float(total[0]['value'][1]) if total else 0
            available_bytes = float(available[0]['value'][1]) if available else 0
            used_bytes = total_bytes - available_bytes
            
            return {
                'total_gb': total_bytes / (1024**3),
                'used_gb': used_bytes / (1024**3),
                'available_gb': available_bytes / (1024**3),
                'usage_percent': (used_bytes / total_bytes * 100) if total_bytes > 0 else 0
            }
        except Exception as e:
            logger.error(f"Erreur Memory metrics: {e}")
            return {}
    
    def get_gpu_metrics(self) -> Dict[str, Any]:
        """Métriques GPU NVIDIA"""
        try:
            temp_query = 'DCGM_FI_DEV_GPU_TEMP'
            util_query = 'DCGM_FI_DEV_GPU_UTIL'
            mem_query = 'DCGM_FI_DEV_FB_USED'
            
            temp = self.prom.custom_query(temp_query)
            util = self.prom.custom_query(util_query)
            mem = self.prom.custom_query(mem_query)
            
            return {
                'temperature_c': float(temp[0]['value'][1]) if temp else 0,
                'utilization_percent': float(util[0]['value'][1]) if util else 0,
                'memory_used_mb': float(mem[0]['value'][1]) if mem else 0,
            }
        except Exception as e:
            logger.warning(f"GPU metrics non disponibles: {e}")
            return {}
    
    def get_container_stats(self) -> List[Dict]:
        """Stats containers Docker"""
        try:
            containers = docker_client.containers.list()
            stats = []
            
            for container in containers:
                try:
                    stat = container.stats(stream=False)
                    cpu_delta = stat['cpu_stats']['cpu_usage']['total_usage'] - \
                                stat['precpu_stats']['cpu_usage']['total_usage']
                    system_delta = stat['cpu_stats']['system_cpu_usage'] - \
                                   stat['precpu_stats']['system_cpu_usage']
                    
                    cpu_percent = (cpu_delta / system_delta) * 100.0 if system_delta > 0 else 0
                    mem_usage = stat['memory_stats']['usage'] / (1024**2)  # MB
                    mem_limit = stat['memory_stats']['limit'] / (1024**2)  # MB
                    
                    stats.append({
                        'name': container.name,
                        'status': container.status,
                        'cpu_percent': round(cpu_percent, 2),
                        'memory_mb': round(mem_usage, 2),
                        'memory_limit_mb': round(mem_limit, 2),
                        'memory_percent': round((mem_usage / mem_limit * 100) if mem_limit > 0 else 0, 2)
                    })
                except Exception as e:
                    logger.debug(f"Skip container {container.name}: {e}")
            
            return stats
        except Exception as e:
            logger.error(f"Erreur container stats: {e}")
            return []
    
    def get_queue_metrics(self) -> Dict[str, int]:
        """Métriques de la queue LLM"""
        try:
            waiting = self.prom.custom_query('mcp_queue_length')
            active = self.prom.custom_query('mcp_active_workers')
            
            return {
                'queue_length': int(float(waiting[0]['value'][1])) if waiting else 0,
                'active_workers': int(float(active[0]['value'][1])) if active else 0,
            }
        except Exception as e:
            logger.warning(f"Queue metrics non disponibles: {e}")
            return {}

# ────────────────────────────────────────────────────────────────
# ANALYSE IA
# ────────────────────────────────────────────────────────────────
class AIAnalyzer:
    """Analyse les métriques avec Claude et suggère des optimisations"""
    
    def __init__(self):
        self.client = anthropic_client
        self.model = CONFIG['anthropic_model']
    
    def analyze_system(self, metrics: Dict) -> List[Dict]:
        """Analyse complète du système"""
        
        prompt = self._build_analysis_prompt(metrics)
        
        try:
            logger.info("🤖 Demande d'analyse à Claude...")
            
            message = self.client.messages.create(
                model=self.model,
                max_tokens=4096,
                temperature=0.3,
                messages=[{
                    "role": "user",
                    "content": prompt
                }]
            )
            
            response_text = message.content[0].text
            logger.info("✓ Analyse reçue de Claude")
            
            # Parser les suggestions (format JSON attendu)
            suggestions = self._parse_suggestions(response_text)
            
            # Sauvegarder l'analyse
            self._save_analysis(metrics, suggestions)
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Erreur analyse Claude: {e}")
            return []
    
    def _build_analysis_prompt(self, metrics: Dict) -> str:
        """Construit le prompt d'analyse"""
        
        metrics_json = json.dumps(metrics, indent=2)
        
        return f"""Tu es un expert en optimisation d'infrastructures cloud et IA. 

Analyse ces métriques système d'une infrastructure LLM (4lb.ca) et suggère jusqu'à {CONFIG['max_suggestions']} optimisations concrètes et actionnables.

MÉTRIQUES ACTUELLES:
{metrics_json}

INSTRUCTIONS:
1. Identifie les goulots d'étranglement et problèmes de performance
2. Suggère des optimisations spécifiques et mesurables
3. Priorise par impact (high, medium, low)
4. Fournis des commandes/configs exactes quand possible
5. Estime le gain de performance attendu

FORMAT DE RÉPONSE (JSON strict):
{{
  "analysis_summary": "Résumé en 2-3 phrases de l'état global",
  "critical_issues": ["Liste des problèmes critiques"],
  "suggestions": [
    {{
      "priority": "high|medium|low",
      "category": "cpu|memory|gpu|network|configuration|scaling",
      "title": "Titre court de l'optimisation",
      "description": "Description détaillée",
      "implementation": "Commande ou config exacte à appliquer",
      "expected_impact": "Impact estimé en %",
      "risk_level": "low|medium|high",
      "estimated_time": "Temps d'application en minutes"
    }}
  ]
}}

Réponds UNIQUEMENT avec le JSON valide, sans texte additionnel."""

    def _parse_suggestions(self, response: str) -> List[Dict]:
        """Parse la réponse de Claude"""
        try:
            # Extraire JSON de la réponse
            response = response.strip()
            if response.startswith('```json'):
                response = response.split('```json')[1].split('```')[0]
            elif response.startswith('```'):
                response = response.split('```')[1].split('```')[0]
            
            data = json.loads(response.strip())
            
            if 'suggestions' in data:
                return data['suggestions'][:CONFIG['max_suggestions']]
            
            return []
            
        except json.JSONDecodeError as e:
            logger.error(f"Erreur parsing JSON: {e}")
            logger.debug(f"Response: {response[:500]}")
            return []
    
    def _save_analysis(self, metrics: Dict, suggestions: List[Dict]):
        """Sauvegarde l'analyse"""
        timestamp = datetime.now().isoformat()
        filename = f"/logs/analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        analysis = {
            'timestamp': timestamp,
            'metrics': metrics,
            'suggestions': suggestions
        }
        
        try:
            with open(filename, 'w') as f:
                json.dump(analysis, f, indent=2)
            logger.info(f"✓ Analyse sauvegardée: {filename}")
        except Exception as e:
            logger.error(f"Erreur sauvegarde analyse: {e}")

# ────────────────────────────────────────────────────────────────
# APPLICATION DES OPTIMISATIONS
# ────────────────────────────────────────────────────────────────
class OptimizerEngine:
    """Applique les optimisations suggérées"""
    
    def apply_suggestions(self, suggestions: List[Dict]):
        """Applique les suggestions (si AUTO_APPLY=true)"""
        
        if not CONFIG['auto_apply']:
            logger.info("⚠️  AUTO_APPLY désactivé - suggestions enregistrées uniquement")
            self._notify_suggestions(suggestions)
            return
        
        applied = []
        failed = []
        
        for suggestion in suggestions:
            if suggestion.get('risk_level') == 'high':
                logger.warning(f"⚠️  Skip suggestion à risque élevé: {suggestion['title']}")
                continue
            
            try:
                logger.info(f"🔧 Application: {suggestion['title']}")
                
                # Ici implémenter la logique d'application selon la catégorie
                success = self._apply_optimization(suggestion)
                
                if success:
                    applied.append(suggestion)
                    logger.info(f"✓ Appliqué: {suggestion['title']}")
                else:
                    failed.append(suggestion)
                    logger.error(f"✗ Échec: {suggestion['title']}")
                    
            except Exception as e:
                logger.error(f"Erreur application {suggestion['title']}: {e}")
                failed.append(suggestion)
        
        logger.info(f"Résumé: {len(applied)} appliqués, {len(failed)} échoués")
    
    def _apply_optimization(self, suggestion: Dict) -> bool:
        """Applique une optimisation spécifique"""
        category = suggestion.get('category')
        implementation = suggestion.get('implementation', '')
        
        # TODO: Implémenter selon catégorie
        # - scaling: docker-compose scale
        # - configuration: modifier configs
        # - etc.
        
        logger.debug(f"Category: {category}, Implementation: {implementation}")
        return False  # Par défaut, ne rien appliquer automatiquement
    
    def _notify_suggestions(self, suggestions: List[Dict]):
        """Notifie les suggestions (email, Slack, etc.)"""
        logger.info(f"📧 {len(suggestions)} suggestions disponibles")
        for i, s in enumerate(suggestions, 1):
            logger.info(f"  {i}. [{s['priority']}] {s['title']}")

# ────────────────────────────────────────────────────────────────
# ORCHESTRATION PRINCIPALE
# ────────────────────────────────────────────────────────────────
def run_optimization_cycle():
    """Cycle complet d'optimisation"""
    logger.info("=" * 60)
    logger.info("🚀 DÉMARRAGE CYCLE D'OPTIMISATION")
    logger.info("=" * 60)
    
    try:
        # 1. Collecte des métriques
        logger.info("📊 Collecte des métriques...")
        collector = MetricsCollector()
        
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'cpu': {
                'usage_percent_1h': collector.get_cpu_usage(hours=1),
                'usage_percent_24h': collector.get_cpu_usage(hours=24),
            },
            'memory': collector.get_memory_usage(),
            'gpu': collector.get_gpu_metrics(),
            'containers': collector.get_container_stats(),
            'llm_queue': collector.get_queue_metrics(),
        }
        
        logger.info(f"✓ Métriques collectées:")
        logger.info(f"  - CPU: {metrics['cpu']['usage_percent_1h']:.1f}%")
        logger.info(f"  - Memory: {metrics['memory'].get('usage_percent', 0):.1f}%")
        logger.info(f"  - Containers: {len(metrics['containers'])}")
        
        # 2. Analyse IA
        logger.info("🤖 Analyse par IA...")
        analyzer = AIAnalyzer()
        suggestions = analyzer.analyze_system(metrics)
        
        logger.info(f"✓ {len(suggestions)} suggestions générées")
        
        # 3. Application (si activé)
        if suggestions:
            optimizer = OptimizerEngine()
            optimizer.apply_suggestions(suggestions)
        
        logger.info("✓ Cycle terminé avec succès")
        
    except Exception as e:
        logger.error(f"✗ Erreur dans le cycle: {e}", exc_info=True)
    
    logger.info("=" * 60)

# ────────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────────
def main():
    logger.info("🌟 AI Optimizer démarré")
    logger.info(f"  Model: {CONFIG['anthropic_model']}")
    logger.info(f"  Interval: {CONFIG['check_interval']}s ({CONFIG['check_interval']/3600}h)")
    logger.info(f"  Auto-apply: {CONFIG['auto_apply']}")
    
    # Exécution initiale
    run_optimization_cycle()
    
    # Planification récurrente
    schedule.every(CONFIG['check_interval']).seconds.do(run_optimization_cycle)
    
    logger.info(f"⏰ Prochaine analyse dans {CONFIG['check_interval']/3600}h")
    
    # Boucle principale
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check toutes les minutes

if __name__ == '__main__':
    main()
