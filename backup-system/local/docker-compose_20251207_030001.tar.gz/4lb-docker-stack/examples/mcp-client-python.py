#!/usr/bin/env python3
"""
Exemple d'utilisation de l'API MCP - Python
Démontre comment utiliser le MCP Server pour des requêtes LLM
"""

import os
import time
import json
import requests
from typing import Dict, Any, Optional

# Configuration
MCP_API_URL = os.getenv("MCP_API_URL", "http://localhost:8080")
MCP_API_KEY = os.getenv("MCP_API_KEY", "your-api-key-here")

class MCPClient:
    """Client Python pour l'API MCP"""
    
    def __init__(self, api_url: str = MCP_API_URL, api_key: str = MCP_API_KEY):
        self.api_url = api_url.rstrip('/')
        self.api_key = api_key
        self.headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key
        }
    
    def submit_task(self, prompt: str, model: str = "llama3.1:8b", 
                   priority: int = 5, **kwargs) -> Dict[str, Any]:
        """
        Soumettre une tâche au MCP Server
        
        Args:
            prompt: Le prompt à envoyer au LLM
            model: Modèle à utiliser (défaut: llama3.1:8b)
            priority: Priorité de 1 (haute) à 10 (basse)
            **kwargs: Paramètres additionnels (temperature, maxTokens, etc.)
        
        Returns:
            Dict contenant taskId, status, etc.
        """
        payload = {
            "prompt": prompt,
            "model": model,
            "priority": priority,
            **kwargs
        }
        
        response = requests.post(
            f"{self.api_url}/api/tasks",
            headers=self.headers,
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        Récupérer le statut d'une tâche
        
        Args:
            task_id: ID de la tâche
        
        Returns:
            Dict contenant le statut et éventuellement le résultat
        """
        response = requests.get(
            f"{self.api_url}/api/tasks/{task_id}",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()
    
    def wait_for_result(self, task_id: str, timeout: int = 300, 
                       poll_interval: int = 2) -> Optional[Dict[str, Any]]:
        """
        Attendre le résultat d'une tâche
        
        Args:
            task_id: ID de la tâche
            timeout: Timeout en secondes (défaut: 5 min)
            poll_interval: Intervalle de polling en secondes
        
        Returns:
            Résultat de la tâche ou None si timeout
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            status = self.get_task_status(task_id)
            
            if status.get("status") == "completed":
                return status.get("result")
            elif status.get("status") == "failed":
                raise Exception(f"Task failed: {status.get('error')}")
            
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Task {task_id} timed out after {timeout}s")
    
    def query(self, prompt: str, model: str = "llama3.1:8b", 
             timeout: int = 300, **kwargs) -> str:
        """
        Méthode simplifiée : soumettre et attendre le résultat
        
        Args:
            prompt: Le prompt
            model: Modèle à utiliser
            timeout: Timeout en secondes
            **kwargs: Paramètres additionnels
        
        Returns:
            Réponse du LLM (texte)
        """
        # Soumettre
        task = self.submit_task(prompt, model, **kwargs)
        task_id = task["taskId"]
        
        # Attendre résultat
        result = self.wait_for_result(task_id, timeout)
        
        return result.get("response", "")
    
    def get_stats(self) -> Dict[str, Any]:
        """Récupérer les statistiques du MCP Server"""
        response = requests.get(
            f"{self.api_url}/api/stats",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()
    
    def list_models(self) -> list:
        """Lister les modèles disponibles"""
        response = requests.get(
            f"{self.api_url}/api/models",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json().get("models", [])


# ════════════════════════════════════════════════════════════════
# Exemples d'utilisation
# ════════════════════════════════════════════════════════════════

def example_simple_query():
    """Exemple 1: Requête simple"""
    print("═" * 60)
    print("EXEMPLE 1: Requête Simple")
    print("═" * 60)
    
    client = MCPClient()
    
    # Question simple
    response = client.query(
        prompt="Explique ce qu'est Docker en 3 phrases.",
        model="llama3.1:8b"
    )
    
    print(f"\nRéponse:\n{response}\n")


def example_async_task():
    """Exemple 2: Tâche asynchrone avec polling"""
    print("═" * 60)
    print("EXEMPLE 2: Tâche Asynchrone")
    print("═" * 60)
    
    client = MCPClient()
    
    # Soumettre la tâche
    task = client.submit_task(
        prompt="Écris un poème sur l'intelligence artificielle.",
        model="llama3.1:8b",
        priority=3,
        temperature=0.9,
        maxTokens=500
    )
    
    print(f"\nTâche soumise: {task['taskId']}")
    print(f"Statut: {task['status']}")
    print(f"Position dans la queue: ~{task.get('estimatedWaitTime', 'N/A')}s\n")
    
    # Attendre le résultat
    print("Attente du résultat...")
    result = client.wait_for_result(task["taskId"])
    
    print(f"\nRéponse:\n{result['response']}\n")
    print(f"Stats: {result.get('stats', {})}\n")


def example_multiple_tasks():
    """Exemple 3: Plusieurs tâches en parallèle"""
    print("═" * 60)
    print("EXEMPLE 3: Tâches Multiples Parallèles")
    print("═" * 60)
    
    client = MCPClient()
    
    # Soumettre plusieurs tâches
    prompts = [
        "Résume l'actualité tech en 2 phrases.",
        "Donne 3 conseils pour apprendre Python.",
        "Explique le machine learning simplement."
    ]
    
    task_ids = []
    for prompt in prompts:
        task = client.submit_task(prompt)
        task_ids.append(task["taskId"])
        print(f"✓ Tâche soumise: {task['taskId'][:8]}...")
    
    print(f"\n{len(task_ids)} tâches soumises. Attente des résultats...\n")
    
    # Récupérer les résultats
    for i, task_id in enumerate(task_ids, 1):
        result = client.wait_for_result(task_id)
        print(f"\n[{i}] {prompts[i-1]}")
        print(f"→ {result['response'][:100]}...\n")


def example_with_models():
    """Exemple 4: Utiliser différents modèles"""
    print("═" * 60)
    print("EXEMPLE 4: Différents Modèles")
    print("═" * 60)
    
    client = MCPClient()
    
    # Lister modèles disponibles
    models = client.list_models()
    print("\nModèles disponibles:")
    for model in models:
        print(f"  • {model.get('name')} - {model.get('size', 'N/A')}")
    
    # Tester avec différents modèles
    prompt = "Qu'est-ce que Kubernetes?"
    
    for model_name in ["llama3.1:8b", "mistral:7b"]:
        print(f"\n--- Test avec {model_name} ---")
        try:
            response = client.query(prompt, model=model_name, timeout=60)
            print(f"{response[:150]}...\n")
        except Exception as e:
            print(f"Erreur: {e}\n")


def example_stats():
    """Exemple 5: Statistiques du serveur"""
    print("═" * 60)
    print("EXEMPLE 5: Statistiques MCP Server")
    print("═" * 60)
    
    client = MCPClient()
    
    stats = client.get_stats()
    
    print("\n📊 Statistiques:")
    print(f"  Queue:")
    print(f"    • En attente: {stats['queue']['waiting']}")
    print(f"    • En cours: {stats['queue']['active']}")
    print(f"    • Complétées: {stats['queue']['completed']}")
    print(f"    • Échouées: {stats['queue']['failed']}")
    
    print(f"\n  Workers:")
    print(f"    • Max workers: {stats['workers']['max']}")
    print(f"    • Actifs: {stats['workers']['active']}")
    
    print(f"\n  Système:")
    print(f"    • Uptime: {stats['uptime']:.0f}s")
    print(f"    • Mémoire: {stats['memory']}\n")


def example_error_handling():
    """Exemple 6: Gestion d'erreurs"""
    print("═" * 60)
    print("EXEMPLE 6: Gestion d'Erreurs")
    print("═" * 60)
    
    client = MCPClient()
    
    try:
        # Tenter avec un modèle inexistant
        response = client.query(
            prompt="Test",
            model="model-inexistant:123"
        )
    except requests.HTTPError as e:
        print(f"\n✓ Erreur HTTP capturée: {e}")
    except Exception as e:
        print(f"\n✓ Erreur capturée: {e}")
    
    try:
        # Timeout très court
        response = client.query(
            prompt="Écris une longue histoire...",
            timeout=1
        )
    except TimeoutError as e:
        print(f"✓ Timeout capturé: {e}\n")


# ════════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════════

def main():
    print("\n" + "=" * 60)
    print("EXEMPLES D'UTILISATION API MCP - Python")
    print("=" * 60 + "\n")
    
    # Vérifier configuration
    if MCP_API_KEY == "your-api-key-here":
        print("⚠️  ATTENTION: Configurez MCP_API_KEY dans .env")
        print("   export MCP_API_KEY='votre-clé-ici'\n")
        return
    
    # Exécuter exemples
    try:
        example_simple_query()
        example_async_task()
        example_multiple_tasks()
        example_with_models()
        example_stats()
        example_error_handling()
        
        print("\n" + "=" * 60)
        print("✅ Tous les exemples terminés !")
        print("=" * 60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Erreur: {e}\n")
        raise


if __name__ == "__main__":
    main()
