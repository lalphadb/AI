#!/bin/bash

echo "========================================"
echo "   Correction permanente de Laravel    "
echo "========================================"
echo ""

cd /home/lalpha/4lb.ca

# 1. Arrêter tous les conteneurs problématiques
echo "1. Arrêt des conteneurs Laravel..."
docker stop laravel 4lbca-laravel-worker-1 4lbca-laravel-worker-2 4lbca-laravel-worker-3 ai-optimizer 2>/dev/null
docker rm laravel 4lbca-laravel-worker-1 4lbca-laravel-worker-2 4lbca-laravel-worker-3 ai-optimizer 2>/dev/null

# 2. Modifier le docker-compose.yml pour ajouter une commande d'override
echo "2. Modification du docker-compose.yml..."
cat > docker-compose-override.yml << 'OVERRIDE'
version: '3.8'

services:
  laravel:
    command: sh -c "mkdir -p /var/log/supervisor && touch /var/log/supervisor/supervisord.log && supervisord -c /etc/supervisor/conf.d/supervisord.conf"
    
  laravel-worker:
    command: sh -c "mkdir -p /var/log/supervisor && touch /var/log/supervisor/supervisord.log && supervisord -c /etc/supervisor/conf.d/supervisord.conf"
    
  ai-optimizer:
    command: sh -c "mkdir -p /var/log && python -u optimizer.py"
OVERRIDE

# 3. Recréer les conteneurs avec la nouvelle configuration
echo "3. Recréation des conteneurs..."
docker-compose -f docker-compose.yml -f docker-compose-override.yml up -d laravel laravel-worker ai-optimizer

echo "4. Attente de démarrage (20 secondes)..."
sleep 20

# 5. Vérification
echo ""
echo "5. Vérification de l'état des services:"
echo "----------------------------------------"

# Fonction pour afficher le statut avec couleurs
check_service() {
    local service=$1
    local status=$(docker ps --filter "name=$service" --format "{{.Status}}" | head -1)
    
    if [[ "$status" == *"Up"* ]]; then
        echo -e "✅ $service: $status"
    elif [[ "$status" == *"Restarting"* ]]; then
        echo -e "⚠️  $service: $status"
    else
        echo -e "❌ $service: Non trouvé ou arrêté"
    fi
}

check_service "laravel"
check_service "4lbca-laravel-worker-1"
check_service "4lbca-laravel-worker-2"
check_service "4lbca-laravel-worker-3"
check_service "ai-optimizer"

echo ""
echo "✅ Correction appliquée!"
echo ""
echo "Si les services sont toujours en redémarrage, exécutez:"
echo "  docker-compose logs laravel --tail 50"
echo ""
