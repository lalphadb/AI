#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Script de Vérification Système - 4lb.ca
# Vérifie la santé complète de l'infrastructure
# ═══════════════════════════════════════════════════════════════

set -e

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Variables
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="/home/lalpha/4lb.ca"

# ────────────────────────────────────────────────────────────────
# Fonctions
# ────────────────────────────────────────────────────────────────

print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

check_ok() {
    echo -e "${GREEN}✓${NC} $1"
}

check_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

check_error() {
    echo -e "${RED}✗${NC} $1"
}

check_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# ────────────────────────────────────────────────────────────────
# Vérifications Système
# ────────────────────────────────────────────────────────────────

check_system() {
    print_header "🖥️  VÉRIFICATION SYSTÈME"
    
    # OS
    local os_version=$(lsb_release -d | cut -f2)
    check_ok "OS: $os_version"
    
    # Kernel
    local kernel=$(uname -r)
    check_ok "Kernel: $kernel"
    
    # CPU
    local cpu_model=$(lscpu | grep "Model name" | cut -d':' -f2 | xargs)
    local cpu_cores=$(nproc)
    check_ok "CPU: $cpu_model ($cpu_cores cores)"
    
    # RAM
    local ram_total=$(free -h | awk '/^Mem:/{print $2}')
    local ram_used=$(free -h | awk '/^Mem:/{print $3}')
    local ram_percent=$(free | awk '/^Mem:/{printf "%.0f", $3/$2 * 100}')
    
    if [ "$ram_percent" -gt 90 ]; then
        check_warning "RAM: $ram_used / $ram_total (${ram_percent}% utilisé - ÉLEVÉ)"
    else
        check_ok "RAM: $ram_used / $ram_total (${ram_percent}% utilisé)"
    fi
    
    # Disque
    local disk_info=$(df -h / | awk 'NR==2 {print $3 " / " $2 " (" $5 " utilisé)"}')
    local disk_percent=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    
    if [ "$disk_percent" -gt 80 ]; then
        check_warning "Disque: $disk_info - ATTENTION"
    else
        check_ok "Disque: $disk_info"
    fi
    
    # GPU
    if command -v nvidia-smi &> /dev/null; then
        local gpu_name=$(nvidia-smi --query-gpu=name --format=csv,noheader)
        local gpu_temp=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader)
        local gpu_util=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader | sed 's/ %//')
        local gpu_mem=$(nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader)
        
        check_ok "GPU: $gpu_name"
        
        if [ "$gpu_temp" -gt 85 ]; then
            check_warning "  └─ Température: ${gpu_temp}°C (ÉLEVÉ)"
        else
            check_ok "  └─ Température: ${gpu_temp}°C"
        fi
        
        check_info "  └─ Utilisation: ${gpu_util}%"
        check_info "  └─ Mémoire: $gpu_mem"
    else
        check_warning "GPU: Aucun GPU NVIDIA détecté"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications Docker
# ────────────────────────────────────────────────────────────────

check_docker() {
    print_header "🐳 VÉRIFICATION DOCKER"
    
    # Docker installé
    if ! command -v docker &> /dev/null; then
        check_error "Docker n'est pas installé"
        return 1
    fi
    
    local docker_version=$(docker --version | cut -d' ' -f3 | sed 's/,//')
    check_ok "Docker: $docker_version"
    
    # Docker Compose
    if docker compose version &> /dev/null; then
        local compose_version=$(docker compose version | cut -d' ' -f4)
        check_ok "Docker Compose: $compose_version"
    else
        check_error "Docker Compose non installé"
        return 1
    fi
    
    # Docker running
    if ! docker info &> /dev/null; then
        check_error "Docker daemon n'est pas en cours d'exécution"
        return 1
    fi
    check_ok "Docker daemon: actif"
    
    # NVIDIA Docker
    if command -v nvidia-smi &> /dev/null; then
        if docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi &> /dev/null; then
            check_ok "NVIDIA Docker runtime: configuré"
        else
            check_warning "NVIDIA Docker runtime: non configuré"
        fi
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications Services
# ────────────────────────────────────────────────────────────────

check_services() {
    print_header "🚀 VÉRIFICATION SERVICES"
    
    cd "$PROJECT_ROOT"
    
    if [ ! -f docker-compose.yml ]; then
        check_error "docker-compose.yml non trouvé"
        return 1
    fi
    
    # Liste des services
    local services=$(docker-compose ps --services 2>/dev/null || echo "")
    
    if [ -z "$services" ]; then
        check_warning "Aucun service en cours d'exécution"
        return 0
    fi
    
    # Vérifier chaque service
    while IFS= read -r service; do
        local status=$(docker-compose ps "$service" 2>/dev/null | grep "$service" | awk '{print $4}')
        
        if echo "$status" | grep -q "Up"; then
            check_ok "$service: UP"
        else
            check_error "$service: DOWN"
        fi
    done <<< "$services"
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications Réseau
# ────────────────────────────────────────────────────────────────

check_network() {
    print_header "🌐 VÉRIFICATION RÉSEAU"
    
    # Ports critiques
    local ports=(80 443 5432 6379 11434)
    
    for port in "${ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            check_ok "Port $port: en écoute"
        else
            check_warning "Port $port: non utilisé"
        fi
    done
    
    # Test connectivité internet
    if ping -c 1 8.8.8.8 &> /dev/null; then
        check_ok "Connectivité internet: OK"
    else
        check_error "Connectivité internet: ÉCHEC"
    fi
    
    # DNS
    if dig +short 4lb.ca @8.8.8.8 &> /dev/null; then
        local dns_ip=$(dig +short 4lb.ca @8.8.8.8 | head -1)
        check_ok "DNS 4lb.ca: $dns_ip"
    else
        check_warning "DNS 4lb.ca: non résolvable"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications API/Endpoints
# ────────────────────────────────────────────────────────────────

check_endpoints() {
    print_header "🔗 VÉRIFICATION ENDPOINTS"
    
    # Ollama
    if curl -sf http://localhost:11434/api/tags &> /dev/null; then
        check_ok "Ollama API: accessible"
    else
        check_warning "Ollama API: non accessible"
    fi
    
    # PostgreSQL
    if docker-compose exec -T postgres pg_isready -U laravel &> /dev/null 2>&1; then
        check_ok "PostgreSQL: accessible"
    else
        check_warning "PostgreSQL: non accessible"
    fi
    
    # Redis
    if docker-compose exec -T redis redis-cli ping &> /dev/null 2>&1; then
        check_ok "Redis: accessible"
    else
        check_warning "Redis: non accessible"
    fi
    
    # Prometheus
    if curl -sf http://localhost:9090/-/healthy &> /dev/null; then
        check_ok "Prometheus: accessible"
    else
        check_warning "Prometheus: non accessible"
    fi
    
    # Grafana
    if curl -sf http://localhost:3000/api/health &> /dev/null; then
        check_ok "Grafana: accessible"
    else
        check_warning "Grafana: non accessible"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications Métriques
# ────────────────────────────────────────────────────────────────

check_metrics() {
    print_header "📊 MÉTRIQUES EN TEMPS RÉEL"
    
    # Containers stats
    echo -e "${BLUE}Top 5 containers par CPU:${NC}"
    docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}" | head -6
    
    echo
    
    # GPU stats si disponible
    if command -v nvidia-smi &> /dev/null; then
        echo -e "${BLUE}GPU Stats:${NC}"
        nvidia-smi --query-gpu=utilization.gpu,utilization.memory,memory.used,memory.total,temperature.gpu --format=csv,noheader,nounits | \
        awk -F',' '{printf "  GPU: %s%% | VRAM: %s%% (%s/%s MB) | Temp: %s°C\n", $1, $2, $3, $4, $5}'
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérifications Logs
# ────────────────────────────────────────────────────────────────

check_logs() {
    print_header "📋 VÉRIFICATION LOGS"
    
    # Chercher erreurs récentes
    if [ -d "$PROJECT_ROOT/logs" ]; then
        local error_count=$(find "$PROJECT_ROOT/logs" -type f -name "*.log" -mtime -1 -exec grep -i "error\|critical\|fatal" {} \; 2>/dev/null | wc -l)
        
        if [ "$error_count" -gt 10 ]; then
            check_warning "Erreurs trouvées: $error_count dans les dernières 24h"
        elif [ "$error_count" -gt 0 ]; then
            check_info "Erreurs trouvées: $error_count dans les dernières 24h"
        else
            check_ok "Aucune erreur dans les dernières 24h"
        fi
    fi
    
    # Docker logs avec erreurs
    if docker-compose ps -q &> /dev/null; then
        local services_with_errors=$(docker-compose logs --tail=100 2>&1 | grep -i "error\|exception" | cut -d'|' -f1 | sort -u | wc -l)
        
        if [ "$services_with_errors" -gt 0 ]; then
            check_warning "$services_with_errors services avec erreurs récentes"
        else
            check_ok "Aucune erreur récente dans les containers"
        fi
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Résumé Final
# ────────────────────────────────────────────────────────────────

print_summary() {
    print_header "📝 RÉSUMÉ"
    
    echo -e "${GREEN}✓ Vérifications complètes${NC}"
    echo
    echo "Commandes utiles:"
    echo "  • Voir services:    docker-compose ps"
    echo "  • Voir logs:        docker-compose logs -f"
    echo "  • Redémarrer:       docker-compose restart"
    echo "  • Stats en direct:  docker stats"
    echo "  • GPU en direct:    watch -n 1 nvidia-smi"
    echo
    echo "Dashboards:"
    echo "  • Grafana:         http://localhost:3000"
    echo "  • Prometheus:      http://localhost:9090"
    echo
}

# ────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────

main() {
    clear
    
    echo -e "${BLUE}"
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║         VÉRIFICATION INFRASTRUCTURE 4LB.CA           ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo
    
    check_system
    check_docker
    check_network
    check_services
    check_endpoints
    check_metrics
    check_logs
    print_summary
    
    echo -e "${GREEN}✅ Vérification terminée !${NC}"
    echo
}

main "$@"
