# 📋 Changelog Récent

## 14 décembre 2025

### AI Orchestrator v3.0 - Auto-Apprentissage
- ✅ **Auto-extraction de faits** : Détecte automatiquement "Je suis...", "Je travaille sur...", etc.
- ✅ **Contexte automatique** : Charge les mémoires pertinentes pour chaque question
- ✅ **Résumé de conversation** : Sauvegarde à la déconnexion WebSocket
- ✅ **Extraction problème/solution** : Mémorise les solutions pour référence future
- ✅ **Nouvel outil** : `memory_stats()` pour voir les statistiques mémoire
- ✅ **34 outils** (vs 33 en v2.5)

### Correction Bug Télémétrie ChromaDB
- **Problème** : `Failed to send telemetry event ClientStartEvent: capture() takes 1 positional argument but 3 were given`
- **Cause** : Incompatibilité posthog 7.0.1 / chromadb-client 1.0.0
- **Solution** : Patch posthog.capture + désactivation télémétrie dans docker-compose

### Fichiers Modifiés
- `backend/main.py` - Intégration auto-learn, patch posthog
- `backend/auto_learn.py` - **NOUVEAU** module complet
- `backend/Dockerfile` - Ajout COPY auto_learn.py
- `docker-compose.yml` - Environment ChromaDB télémétrie désactivée

---

## 14 décembre 2025 (matin)

### AI Orchestrator v2.5 - Mémoire Sémantique
- ✅ Intégration ChromaDB pour mémoire sémantique
- ✅ Recherche par similarité avec scores
- ✅ 33 outils (ajout memory_store, memory_recall)
- ✅ Embeddings via all-MiniLM-L6-v2 ONNX

---

## 11 décembre 2025

### AI Orchestrator v2.4
- ✅ Résolution WebSocket connectivity issues
- ✅ Progressive urgency messaging
- ✅ Augmentation limite itérations à 12

---

*Mis à jour le 14 décembre 2025*
