# 🔒 Procédures Sécurisées pour Agents IA

> **Audience** : Claude, Continue, Cline, et tous les agents IA
> **Date** : 6 décembre 2025
> **Statut** : OBLIGATOIRE

---

## ⚠️ RÈGLES D'OR

### **1. NE JAMAIS exécuter directement :**
```bash
❌ docker compose up/down/restart
❌ docker restart traefik
❌ Modifications directes de docker-compose.yml
❌ Modifications directes de configs Traefik
```

### **2. TOUJOURS utiliser les scripts standardisés :**
```bash
✅ ~/scripts/docker/deploy_4lb_stack.sh
✅ ~/scripts/docker/check_4lb_stack.sh
```

---

## 📋 Procédures Standard

### **Déploiement de la Stack**

```bash
~/scripts/docker/deploy_4lb_stack.sh
```

**Ce que le script fait :**
1. Arrêt propre de la stack
2. Nettoyage des ressources obsolètes
3. Pull des nouvelles images
4. Recréation des conteneurs
5. Vérification du statut

---

### **Vérification de la Stack**

```bash
~/scripts/docker/check_4lb_stack.sh
```

**Ce que le script fait :**
1. Liste tous les conteneurs Docker
2. Vérifie que Traefik tourne
3. Affiche les logs Traefik
4. Teste les services HTTPS
5. Vérifie l'espace disque

---

### **Modifications de Configuration**

**Procédure OBLIGATOIRE :**

1. **Analyser** la configuration actuelle
2. **Créer un patch** dans `patches/`
3. **Proposer** le patch à l'utilisateur
4. **Attendre validation**
5. **L'utilisateur applique** (pas l'IA !)

```bash
cd /home/lalpha/projets/infrastructure/4lb-docker-stack
git apply patches/ma-modification.patch
git commit -m "Description"
~/scripts/docker/deploy_4lb_stack.sh
```

---

## 🚫 Ce que tu ne dois JAMAIS faire

### **Modifications Directes**
```bash
❌ Edit docker-compose.yml directement
❌ Edit configs/traefik/* directement
❌ Lancer des commandes docker compose manuellement
❌ Appliquer des patches sans validation utilisateur
```

### **Commandes Dangereuses**
```bash
❌ docker compose down --volumes (supprime les données !)
❌ docker system prune -a (supprime toutes les images !)
❌ rm -rf sur des dossiers système
```

---

## ✅ Ce que tu PEUX faire

### **Lecture / Analyse**
```bash
✅ cat, less, grep sur les fichiers de config
✅ docker ps, docker logs pour diagnostics
✅ df, du pour vérifier l'espace disque
✅ Analyser les logs et identifier les problèmes
```

### **Propositions**
```bash
✅ Créer des patches/diffs
✅ Expliquer les changements nécessaires
✅ Proposer des solutions
✅ Créer des scripts dans ~/scripts/
```

### **Exécution Autorisée**
```bash
✅ ~/scripts/docker/deploy_4lb_stack.sh
✅ ~/scripts/docker/check_4lb_stack.sh
✅ Scripts de backup (~/scripts/backup/)
```

---

## 📝 Diagnostics Autorisés

### **Conteneurs**
```bash
✅ docker ps -a
✅ docker logs <container> --tail=N
✅ docker inspect <container>
✅ docker stats
```

### **Réseau**
```bash
✅ docker network ls
✅ docker network inspect traefik-net
✅ curl -I https://domain.4lb.ca
```

### **Système**
```bash
✅ htop (lecture)
✅ systemctl status ollama
✅ nvidia-smi
✅ df -h
```

---

## 🎯 AI Orchestrator (ai.4lb.ca)

L'AI Orchestrator v2.0 est l'agent autonome principal. Il possède :
- 26 outils intégrés
- Accès Docker socket
- SSH vers UDM-Pro
- Lecture/écriture fichiers

**Pour modifier l'orchestrateur :**
```bash
cd /home/lalpha/projets/ai-tools/ai-orchestrator
# Modifier backend/main.py ou frontend/index.html
docker compose up -d --build
```

---

## ✅ Checklist Avant Action

- [ ] Est-ce que je modifie docker-compose.yml ou Traefik ?
  - Si OUI → Créer un patch, proposer à l'utilisateur
- [ ] Est-ce que j'exécute une commande docker compose ?
  - Si OUI → Utiliser deploy_4lb_stack.sh
- [ ] Est-ce une vérification ?
  - Si OUI → Utiliser check_4lb_stack.sh
- [ ] Est-ce que je redémarre un service ?
  - Si OUI → Utiliser deploy_4lb_stack.sh

---

## 🎓 Principe Fondamental

**Tu es un agent IA puissant, mais :**
- L'utilisateur est le **décisionnaire final**
- La **stabilité > rapidité**
- **Proposer > Appliquer directement**

**En cas de doute :**
1. Demande confirmation
2. Propose un plan d'action
3. Attends validation
4. Exécute selon les procédures

---

**Version** : 2.0
**Date** : 6 décembre 2025
**Statut** : OBLIGATOIRE pour tous les agents IA
