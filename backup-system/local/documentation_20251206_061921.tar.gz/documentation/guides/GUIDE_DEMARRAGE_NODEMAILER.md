# 🚀 GUIDE DÉMARRAGE - Backend Nodemailer (JSR)

> **Projet** : `/home/lalpha/projets/clients/jsr/`  
> **Dernière mise à jour** : 1er décembre 2025

---

## ✅ Ce qui est en place

### Backend Email (Nodemailer)

- ✅ Serveur Node.js + Express
- ✅ Envoi d'emails via Gmail SMTP
- ✅ Emails HTML professionnels
- ✅ API REST `/api/contact`
- ✅ Dockerisé et déployé

### Frontend

- ✅ Utilise le backend email
- ✅ Configuration production

---

## 🔴 Configuration Gmail (si nouveau déploiement)

### Étape 1 : Créer un mot de passe d'application Gmail

1. Aller sur : https://myaccount.google.com/security
2. **Validation en 2 étapes** → Activer si pas fait
3. **Mots de passe des applications** → Créer
4. Nom : "JSR Backend"
5. **Copier le mot de passe** (16 caractères : `xxxx xxxx xxxx xxxx`)

### Étape 2 : Configurer le fichier .env

```bash
cd /home/lalpha/projets/clients/jsr/JSR
cp .env.example .env
nano .env
```

Variables requises :
```env
GMAIL_USER=votre-email@gmail.com
GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx
CONTACT_EMAIL=email-destination@domain.com
```

---

## 📁 Structure du Projet

```
/home/lalpha/projets/clients/jsr/
├── JSR/                    # Version principale
│   ├── src/
│   │   └── lib/
│   │       └── backend-email.ts
│   ├── .env
│   └── package.json
└── JSR-solutions/          # Version alternative
    └── src/
        └── lib/
            └── backend-email.ts
```

---

## 🚀 Démarrage

### Développement

```bash
cd /home/lalpha/projets/clients/jsr/JSR
npm install
npm run dev
```

### Production (Docker)

```bash
# Vérifier le conteneur
docker ps | grep jsr

# Logs
docker logs -f jsr-dev

# Redémarrer
docker restart jsr-dev
```

---

## 🧪 Tests

### Test API Contact

```bash
curl -X POST http://localhost:8082/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test",
    "email": "test@example.com",
    "message": "Message de test"
  }'
```

### Test Health Check

```bash
curl http://localhost:8082/health
```

---

## 🌐 URLs

| Environnement | URL |
|---------------|-----|
| **Production** | https://jsr.4lb.ca |
| **Local** | http://localhost:8082 |

---

## 🔗 Références

- [README_BACKEND_NODEMAILER.md](README_BACKEND_NODEMAILER.md) - Détails implémentation
- [ARCHITECTURE.md](../ARCHITECTURE.md) - Vue infrastructure

---

*Documentation mise à jour le 1er décembre 2025*
