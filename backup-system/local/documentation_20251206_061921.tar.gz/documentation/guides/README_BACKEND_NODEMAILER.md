# ✅ BACKEND NODEMAILER - Implémentation JSR

> **Projet** : `/home/lalpha/projets/clients/jsr/`  
> **Dernière mise à jour** : 1er décembre 2025

---

## 📊 Résumé

### Backend créé

| Composant | Statut |
|-----------|--------|
| Serveur Node.js + Express + Nodemailer | ✅ |
| Emails HTML professionnels | ✅ |
| API REST `/api/contact` | ✅ |
| Health check `/health` | ✅ |
| Dockerisé | ✅ |

### Frontend mis à jour

| Composant | Statut |
|-----------|--------|
| `src/lib/backend-email.ts` | ✅ |
| Configuration production | ✅ |

---

## 📁 Fichiers Clés

### Backend Email

```
/home/lalpha/projets/clients/jsr/JSR/src/lib/backend-email.ts
```

### Fonctionnalités

- Envoi email via Gmail SMTP
- Template HTML stylisé
- Validation des champs
- Gestion erreurs

---

## 🔧 Configuration

### Variables d'environnement

Fichier `.env` dans le projet :

```env
# Gmail SMTP
GMAIL_USER=votre-email@gmail.com
GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx

# Destinataire
CONTACT_EMAIL=contact@jsr.ca
```

### Obtenir le mot de passe d'application

1. https://myaccount.google.com/security
2. Activer la validation en 2 étapes
3. Créer un mot de passe d'application
4. Copier les 16 caractères

---

## 🐳 Docker

### Conteneurs

```bash
# Lister
docker ps | grep jsr

# Logs
docker logs -f jsr-dev

# Redémarrer
docker restart jsr-dev
```

### Réseau

Le frontend et backend partagent le réseau Docker `traefik-net`.

---

## 📡 API Endpoints

### POST /api/contact

**Corps de la requête :**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "message": "Message de contact..."
}
```

**Réponse succès :**
```json
{
  "success": true,
  "message": "Email envoyé avec succès"
}
```

### GET /health

**Réponse :**
```json
{
  "status": "ok",
  "timestamp": "2025-12-01T..."
}
```

---

## 🧪 Tests

```bash
# Test envoi email
curl -X POST https://jsr.4lb.ca/api/contact \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","email":"test@test.com","message":"Test"}'

# Test health
curl https://jsr.4lb.ca/health
```

---

## 🔍 Dépannage

### Email non envoyé

1. Vérifier les credentials Gmail dans `.env`
2. Vérifier que le mot de passe d'application est valide
3. Consulter les logs : `docker logs jsr-dev`

### Erreur CORS

Vérifier la configuration CORS dans le backend Express.

### Conteneur down

```bash
docker restart jsr-dev
docker logs -f jsr-dev
```

---

## 🔗 Références

- [GUIDE_DEMARRAGE_NODEMAILER.md](GUIDE_DEMARRAGE_NODEMAILER.md) - Guide démarrage
- [ARCHITECTURE.md](../ARCHITECTURE.md) - Vue infrastructure

---

*Documentation mise à jour le 1er décembre 2025*
