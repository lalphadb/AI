# 🎨 Phase 2 : Interface Personnalisée pour Agent IA

> **Statut** : 📋 Planifiée
> **Durée estimée** : 4-6 heures
> **Date** : À déterminer

---

## 🎯 Objectif

Créer une **interface web minimaliste** (style ChatGPT/Claude) qui communique avec code-server en arrière-plan.

**Résultat** : Agent IA autonome avec interface moderne, sans voir VS Code.

---

## 📊 Architecture

```
┌─────────────────────────────────────────────────┐
│         Interface Web Personnalisée             │
│         (React/Vue + Tailwind CSS)              │
│         https://ai.4lb.ca                       │
├─────────────────────────────────────────────────┤
│  • Chat minimaliste (style ChatGPT)            │
│  • Historique conversations                     │
│  • Boutons simples et intuitifs                 │
│  • 100% responsive (mobile first)               │
│  • Thème sombre moderne                         │
└─────────────────────────────────────────────────┘
                      │
                      ▼ WebSocket/API
┌─────────────────────────────────────────────────┐
│         Backend Proxy API                       │
│         (Node.js/Express)                       │
│         Port 3000                               │
├─────────────────────────────────────────────────┤
│  • Gère les sessions utilisateur               │
│  • Communique avec code-server                  │
│  • Authentification                             │
│  • Rate limiting                                │
└─────────────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────┐
│         Code-Server (Caché)                     │
│         https://code.4lb.ca (backend only)      │
├─────────────────────────────────────────────────┤
│  • Cline (agent autonome)                       │
│  • Continue (assistant code)                    │
│  • 33 MCP tools                                 │
│  • Ollama (qwen, deepseek, llama)               │
│  • Claude API (optionnel)                       │
└─────────────────────────────────────────────────┘
```

---

## ✨ Fonctionnalités Interface

### **1. Chat Minimaliste**

```
┌─────────────────────────────────────────┐
│  🤖 Agent IA - 4lb.ca                   │
├─────────────────────────────────────────┤
│                                         │
│  👤 Toi                                 │
│  Crée un script de monitoring Docker   │
│                                         │
│  🤖 Agent                               │
│  Je vais créer un script de monitoring │
│  complet avec alertes. Voici les       │
│  étapes :                               │
│  1. Vérifier l'état des conteneurs     │
│  2. Surveiller l'espace disque ORICO   │
│  3. Configurer les alertes              │
│  [Exécution en cours...]               │
│                                         │
│  🤖 Agent                               │
│  ✅ Script créé avec succès !          │
│  📄 /home/lalpha/scripts/docker-       │
│     monitor.sh                          │
│  [Voir le code] [Tester] [Modifier]    │
│                                         │
├─────────────────────────────────────────┤
│  💬 Pose une question ou donne une     │
│     mission...                          │
└─────────────────────────────────────────┘
```

### **2. Sélection de Modèle**

```
┌─────────────────────────────────┐
│  Modèle : Qwen 2.5 Coder 32B ▼ │
├─────────────────────────────────┤
│  ⚡ Qwen 2.5 Coder 32B (rapide) │
│  🧠 Claude Sonnet 4 (intelligent)│
│  💻 DeepSeek Coder 33B          │
│  👁️ Llama 3.2 Vision 11B        │
└─────────────────────────────────┘
```

### **3. Historique Conversations**

```
┌─────────────────────────────────┐
│  📂 Conversations récentes       │
├─────────────────────────────────┤
│  🕐 Il y a 5 min                │
│     Script monitoring Docker     │
│                                  │
│  🕐 Il y a 2h                   │
│     Correction bug PostgreSQL    │
│                                  │
│  🕐 Hier                        │
│     Migration Ollama ORICO       │
└─────────────────────────────────┘
```

### **4. Actions Rapides**

```
┌─────────────────────────────────┐
│  🚀 Actions Rapides              │
├─────────────────────────────────┤
│  📊 État du serveur              │
│  🐳 Docker status                │
│  💾 Espace disque ORICO          │
│  🔧 Logs système                 │
│  📈 Métriques Prometheus         │
└─────────────────────────────────┘
```

---

## 🛠️ Stack Technique

### **Frontend**
- **Framework** : React 18 + TypeScript
- **Styling** : Tailwind CSS
- **UI Components** : shadcn/ui (components modernes)
- **État** : Zustand (léger et simple)
- **WebSocket** : Socket.io-client
- **Markdown** : react-markdown (affichage réponses)
- **Syntax Highlighting** : Prism.js

### **Backend**
- **Runtime** : Node.js 20
- **Framework** : Express.js
- **WebSocket** : Socket.io
- **Authentification** : JWT
- **Rate Limiting** : express-rate-limit
- **Communication code-server** : Axios + WebSocket

### **Infrastructure**
- **Conteneurisation** : Docker + Docker Compose
- **Reverse Proxy** : Traefik
- **SSL/TLS** : Let's Encrypt automatique
- **Base données** : Redis (sessions + cache)
- **Logs** : Winston → Loki

---

## 📝 Étapes de Développement

### **Phase 2.1 : Backend API** (1-2h)

1. **Créer le serveur Express**
   - Routes API (`/api/chat`, `/api/models`, `/api/sessions`)
   - Middleware authentification
   - WebSocket pour streaming

2. **Intégration code-server**
   - Communiquer avec l'API code-server
   - Proxy des requêtes vers Cline/Continue
   - Gestion des sessions utilisateur

3. **Base de données**
   - Redis pour sessions
   - Stockage historique conversations
   - Cache des réponses

### **Phase 2.2 : Frontend** (2-3h)

1. **Créer l'interface React**
   - Composant Chat principal
   - Zone de saisie + bouton envoyer
   - Affichage messages (markdown)

2. **Fonctionnalités avancées**
   - Streaming des réponses (WebSocket)
   - Sélection de modèle
   - Historique conversations
   - Actions rapides

3. **Responsive Design**
   - Mobile first
   - Optimisé pour téléphone/tablette
   - Thème sombre élégant

### **Phase 2.3 : Dockerisation** (30min)

1. **Créer Dockerfile frontend**
   - Build React optimisé
   - Nginx pour servir

2. **Créer Dockerfile backend**
   - Node.js runtime
   - Dépendances minimales

3. **Docker Compose**
   - Service frontend
   - Service backend
   - Redis
   - Traefik labels

### **Phase 2.4 : Tests & Déploiement** (30min-1h)

1. **Tests**
   - Test conversation simple
   - Test streaming
   - Test sur mobile
   - Test authentification

2. **Déploiement**
   - Build et push images
   - Démarrer les services
   - Configurer Traefik (https://ai.4lb.ca)
   - Vérifier certificats SSL

---

## 📦 Structure du Projet

```
/home/lalpha/projets/ai-tools/ai-interface/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Chat.tsx
│   │   │   ├── MessageList.tsx
│   │   │   ├── InputBox.tsx
│   │   │   ├── ModelSelector.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   └── QuickActions.tsx
│   │   ├── hooks/
│   │   │   ├── useChat.ts
│   │   │   ├── useWebSocket.ts
│   │   │   └── useAuth.ts
│   │   ├── stores/
│   │   │   └── chatStore.ts
│   │   ├── utils/
│   │   │   └── api.ts
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── public/
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── Dockerfile
│
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   │   ├── chat.ts
│   │   │   ├── models.ts
│   │   │   └── auth.ts
│   │   ├── services/
│   │   │   ├── codeServerClient.ts
│   │   │   ├── redisClient.ts
│   │   │   └── sessionManager.ts
│   │   ├── middleware/
│   │   │   ├── auth.ts
│   │   │   └── rateLimit.ts
│   │   ├── types/
│   │   │   └── index.ts
│   │   └── index.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── Dockerfile
│
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## 🔐 Sécurité

### **Authentification**
- JWT tokens (refresh + access)
- Expiration automatique
- Rate limiting par IP

### **Communication**
- WebSocket sécurisé (WSS)
- CORS configuré
- HTTPS uniquement (Traefik)

### **Isolation**
- Frontend et backend séparés
- code-server non exposé publiquement
- Redis pour sessions seulement

---

## 🎨 Design

### **Palette de Couleurs**
```css
--bg-primary: #0a0a0a
--bg-secondary: #1a1a1a
--bg-tertiary: #2a2a2a
--text-primary: #ffffff
--text-secondary: #a0a0a0
--accent: #3b82f6
--success: #10b981
--error: #ef4444
```

### **Typographie**
- **Titres** : Inter (system-ui)
- **Corps** : Inter
- **Code** : JetBrains Mono

### **Inspiration**
- ChatGPT (simplicité)
- Claude.ai (élégance)
- Linear.app (minimalisme)

---

## 📊 Métriques de Succès

### **Performance**
- ⚡ Temps de réponse < 2s
- 📱 Score Lighthouse > 90
- 🚀 Streaming fluide (WebSocket)

### **UX**
- ✅ Interface intuitive (0 documentation)
- 📱 Parfaitement responsive
- 🎨 Thème élégant et moderne

### **Technique**
- 🐳 Docker build < 5 min
- 💾 Image < 200 MB (frontend)
- 🔧 Déploiement < 2 min

---

## 🚀 Commandes de Développement

### **Frontend**
```bash
cd frontend
npm install
npm run dev      # Dev server (port 5173)
npm run build    # Build production
npm run preview  # Preview build
```

### **Backend**
```bash
cd backend
npm install
npm run dev      # Dev server (port 3000)
npm run build    # Compile TypeScript
npm start        # Production
```

### **Docker**
```bash
# Build images
docker compose build

# Démarrer les services
docker compose up -d

# Logs
docker compose logs -f ai-frontend
docker compose logs -f ai-backend

# Arrêter
docker compose down
```

---

## ✅ Checklist Phase 2

### **Backend**
- [ ] Créer serveur Express
- [ ] Routes API (/chat, /models, /auth)
- [ ] WebSocket pour streaming
- [ ] Intégration code-server
- [ ] Redis pour sessions
- [ ] Rate limiting
- [ ] Authentification JWT
- [ ] Tests API

### **Frontend**
- [ ] Initialiser React + Vite
- [ ] Composant Chat
- [ ] Zone de saisie
- [ ] Affichage messages (markdown)
- [ ] Streaming temps réel
- [ ] Sélection modèle
- [ ] Historique conversations
- [ ] Actions rapides
- [ ] Thème sombre
- [ ] Responsive mobile

### **Infrastructure**
- [ ] Dockerfile frontend
- [ ] Dockerfile backend
- [ ] Docker Compose
- [ ] Traefik labels
- [ ] SSL Let's Encrypt
- [ ] Redis service

### **Tests**
- [ ] Test conversation
- [ ] Test streaming
- [ ] Test sur mobile
- [ ] Test authentification
- [ ] Test performance

### **Déploiement**
- [ ] Build images
- [ ] Démarrer services
- [ ] Configurer DNS (ai.4lb.ca)
- [ ] Vérifier HTTPS
- [ ] Documentation

---

## 💰 Coûts

### **Développement**
- **Temps** : 4-6 heures
- **Complexité** : Moyenne

### **Infrastructure**
- **Ressources** : Aucun coût supplémentaire
  - CPU : +1 core
  - RAM : +1 GB
  - Stockage : +500 MB

### **API**
- **Ollama** : Gratuit (local)
- **Claude API** : Payant si utilisé ($3-15/million tokens)

---

## 📚 Ressources

### **Frontend**
- React : https://react.dev
- Tailwind CSS : https://tailwindcss.com
- shadcn/ui : https://ui.shadcn.com
- Socket.io : https://socket.io

### **Backend**
- Express : https://expressjs.com
- Socket.io : https://socket.io
- Redis : https://redis.io

### **Design**
- Figma (wireframes) : https://figma.com
- Coolors (palette) : https://coolors.co

---

## 🎯 Prochaine Action

**Quand tu seras prêt pour Phase 2, dis-moi et je :**
1. Crée toute la structure du projet
2. Développe le backend API
3. Développe l'interface React
4. Configure Docker + Traefik
5. Déploie sur https://ai.4lb.ca
6. Te donne un guide d'utilisation complet

**Temps estimé : 4-6 heures de développement**

---

**Planifié le** : 3 décembre 2025
**Par** : Claude Code
**Version** : 1.0

