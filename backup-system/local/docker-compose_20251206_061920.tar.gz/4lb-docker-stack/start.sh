#!/bin/bash

echo "Démarrage de l'infrastructure 4lb.ca..."

# Se placer dans le bon répertoire
cd /home/lalpha/4lb.ca

# Utiliser docker-compose avec override
docker-compose -f docker-compose.yml -f docker-compose-override.yml up -d

# Attendre que tout démarre
sleep 20

# Vérifier l'état
./scripts/quick-check.sh

echo ""
echo "Pour voir les logs : docker-compose logs -f"
echo "Pour arrêter : docker-compose down"
