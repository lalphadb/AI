# 🚀 Infrastructure IA Auto-Améliorante - 4lb.ca

## 📋 Vue d'Ensemble

Infrastructure complète et auto-optimisante combinant :
- **Services LLM** : Ollama avec GPU NVIDIA RTX 5070 Ti
- **Application Web** : Laravel 11 + PHP 8.3 + Nginx
- **Serveur Email** : Postfix/Dovecot avec anti-spam
- **Auto-Amélioration** : Agent IA analysant et optimisant le système
- **Monitoring** : Prometheus + Grafana + Loki
- **Sécurité** : Traefik + SSL + Cloudflare WAF

## 🏗️ Architecture

```
Internet → Cloudflare CDN/WAF
    ↓
[Traefik :443] SSL Termination
    ↓
    ├── [Laravel] → Application Web
    ├── [MCP] → Model Control Plane
    ├── [Mail] → Serveur Email
    └── [Monitoring] → Grafana/Prometheus
         ↓
    [Backend Services]
    ├── PostgreSQL 16
    ├── Redis 7
    ├── Ollama (GPU)
    └── AI Optimizer
```

## 🎯 Configuration Matérielle

**Détectée automatiquement :**
- CPU : AMD Ryzen 9 7900X (12C/24T)
- GPU : NVIDIA RTX 5070 Ti 16GB
- RAM : 64 GB
- Storage : 2 TB NVMe SSD
- OS : Ubuntu 24.04 LTS

## ⚡ Installation Rapide

### Prérequis

```bash
# Docker et Docker Compose déjà installés ✓
# NVIDIA Drivers installés ✓
# Git installé ✓
```

### Étape 1 : Configuration

```bash
cd /home/lalpha/4lb.ca

# Copier et éditer le fichier d'environnement
cp .env.example .env
nano .env

# IMPORTANT: Configurer les variables suivantes:
# - ANTHROPIC_API_KEY=sk-ant-api03-...
# - DB_PASSWORD=votre_mot_de_passe_fort
# - GRAFANA_PASSWORD=votre_mot_de_passe_grafana
# - APP_KEY (générer avec: openssl rand -base64 32)
# - ACME_EMAIL=admin@4lb.ca
```

### Étape 2 : Déploiement Automatique

```bash
# Lancer le script d'installation
./scripts/deploy/install.sh
```

Le script va :
1. ✅ Vérifier les prérequis
2. ✅ Créer la structure de répertoires
3. ✅ Builder les images Docker
4. ✅ Démarrer tous les services
5. ✅ Vérifier la santé des services
6. ✅ Afficher les URLs d'accès

**Durée estimée : 10-15 minutes**

### Étape 3 : Configuration DNS

Dans Cloudflare, configurer les enregistrements DNS :

```
Type  Nom              Valeur          Proxy
A     4lb.ca          1.1.4.12         ✓
A     www             1.1.4.12         ✓
A     ai              1.1.4.12         ✓
A     grafana         1.1.4.12         ✓
A     prometheus      1.1.4.12         ✓
A     traefik         1.1.4.12         ✓
MX    4lb.ca          mail.4lb.ca      10
TXT   4lb.ca          SPF/DKIM/DMARC   -
```

## 📊 Services Disponibles

| Service | URL | Port | Description |
|---------|-----|------|-------------|
| **Application** | https://4lb.ca | 443 | Laravel app |
| **Grafana** | https://grafana.4lb.ca | 443 | Dashboards |
| **Prometheus** | https://prometheus.4lb.ca | 443 | Métriques |
| **Traefik** | https://traefik.4lb.ca | 443 | Proxy dashboard |
| **MCP API** | https://ai.4lb.ca | 443 | LLM API |
| **Ollama** | http://localhost:11434 | 11434 | LLM direct |
| **PostgreSQL** | localhost:5432 | 5432 | Base de données |
| **Redis** | localhost:6379 | 6379 | Cache |
| **Mail SMTP** | mail.4lb.ca | 25,465,587 | Email envoi |
| **Mail IMAP** | mail.4lb.ca | 993 | Email lecture |

## 🔧 Gestion Quotidienne

### Voir le Statut

```bash
cd /home/lalpha/4lb.ca

# Statut de tous les services
docker-compose ps

# Logs en temps réel
docker-compose logs -f

# Logs d'un service spécifique
docker-compose logs -f laravel
docker-compose logs -f ollama
docker-compose logs -f ai-optimizer
```

### Redémarrer un Service

```bash
# Redémarrer Laravel
docker-compose restart laravel

# Redémarrer tous les services
docker-compose restart

# Arrêter tous les services
docker-compose down

# Démarrer tous les services
docker-compose up -d
```

### Scaling Workers LLM

```bash
# Augmenter les workers Laravel
docker-compose up -d --scale laravel-worker=5

# Vérifier
docker-compose ps laravel-worker
```

## 🤖 Auto-Amélioration IA

L'agent IA analyse automatiquement le système **toutes les 6 heures** et :

1. 📊 Collecte métriques (CPU, RAM, GPU, queues, etc.)
2. 🤖 Analyse avec Claude Sonnet 4
3. 💡 Génère suggestions d'optimisation
4. ✅ Les applique (si `AUTO_APPLY=true`) ou notifie

### Consulter les Analyses

```bash
# Logs de l'optimizer
docker-compose logs -f ai-optimizer

# Analyses sauvegardées
ls -lh /home/lalpha/4lb.ca/logs/analysis_*.json

# Dernière analyse
cat /home/lalpha/4lb.ca/logs/analysis_$(ls -t /home/lalpha/4lb.ca/logs/analysis_*.json | head -1)
```

### Forcer une Analyse

```bash
# Redémarrer l'optimizer pour analyse immédiate
docker-compose restart ai-optimizer
```

## 💾 Backups Automatiques

### Configuration Backup

Les backups se font automatiquement via cron :

```bash
# Ajouter au crontab
crontab -e

# Backup quotidien à 2h du matin
0 2 * * * /home/lalpha/4lb.ca/scripts/backup/backup.sh >> /home/lalpha/4lb.ca/logs/backup.log 2>&1
```

### Backup Manuel

```bash
# Exécuter backup maintenant
./scripts/backup/backup.sh
```

### Restauration

```bash
# Restaurer PostgreSQL
gunzip < backups/daily/postgres_YYYYMMDD_HHMMSS.sql.gz | \
  docker-compose exec -T postgres psql -U laravel laravel

# Restaurer un volume
docker run --rm \
  -v ollama_models:/data \
  -v $(pwd)/backups/daily:/backup \
  alpine \
  tar xzf /backup/ollama_models_YYYYMMDD_HHMMSS.tar.gz -C /data
```

## 📈 Monitoring & Dashboards

### Grafana

URL : https://grafana.4lb.ca
Credentials : admin / ${GRAFANA_PASSWORD}

**Dashboards préconfigurés :**
- Vue d'ensemble infrastructure
- Métriques GPU NVIDIA
- Queue LLM & Workers
- Performances Laravel
- Métriques containers

### Prometheus

URL : https://prometheus.4lb.ca

**Métriques disponibles :**
- `node_*` : Système (CPU, RAM, Disk, Network)
- `DCGM_*` : GPU NVIDIA
- `mcp_*` : Queue LLM, Workers
- `container_*` : Containers Docker

### Loki (Logs)

Accessible via Grafana → Explore → Loki

**Requêtes utiles :**
```logql
# Logs Laravel
{job="laravel"}

# Erreurs seulement
{job="laravel"} |= "error" or "ERROR"

# Logs MCP Server
{job="mcp"}

# Logs AI Optimizer
{job="optimizer"}
```

## 🔐 Sécurité

### Firewall UFW

```bash
# Configurer le firewall
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw allow 25/tcp   # SMTP
sudo ufw allow 465/tcp  # SMTPS
sudo ufw allow 587/tcp  # Submission
sudo ufw allow 993/tcp  # IMAPS
sudo ufw enable

# Vérifier
sudo ufw status
```

### SSL/TLS

Les certificats SSL sont automatiquement générés par **Traefik** via **Let's Encrypt**.

Vérifier les certificats :
```bash
# Voir les certificats stockés
docker-compose exec traefik ls -lh /certs/

# Tester SSL
curl -vI https://4lb.ca
```

### Secrets

**NE JAMAIS** commiter le fichier `.env` dans Git !

Créer `.gitignore` :
```bash
echo ".env" >> .gitignore
echo "logs/" >> .gitignore
echo "backups/" >> .gitignore
echo "data/" >> .gitignore
```

## 🐛 Dépannage

### Service ne démarre pas

```bash
# Voir les logs détaillés
docker-compose logs --tail=100 nom_du_service

# Redémarrer en mode verbose
docker-compose up nom_du_service
```

### GPU non détecté

```bash
# Vérifier NVIDIA driver
nvidia-smi

# Vérifier NVIDIA Docker runtime
docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi

# Reconstruire Ollama
docker-compose build --no-cache ollama
docker-compose up -d ollama
```

### PostgreSQL erreurs de connexion

```bash
# Vérifier que PostgreSQL est prêt
docker-compose exec postgres pg_isready -U laravel

# Voir les logs
docker-compose logs postgres

# Restart
docker-compose restart postgres
```

### MCP Server ne répond pas

```bash
# Vérifier Ollama est accessible
curl http://localhost:11434/api/tags

# Vérifier Redis
docker-compose exec redis redis-cli ping

# Restart MCP
docker-compose restart mcp-server
```

## 📚 Documentation Supplémentaire

### Créer une Application Laravel

```bash
# Se connecter au container
docker-compose exec laravel bash

# Créer nouveau projet Laravel
composer create-project laravel/laravel .

# Ou cloner projet existant
git clone https://github.com/votre/projet.git .
composer install
php artisan key:generate
php artisan migrate
```

### Utiliser l'API MCP

```bash
# Test simple
curl -X POST https://ai.4lb.ca/api/tasks \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${MCP_API_KEY}" \
  -d '{
    "prompt": "Bonjour, comment ça va?",
    "model": "llama3.1:8b"
  }'

# Vérifier statut
curl https://ai.4lb.ca/api/tasks/TASK_ID \
  -H "X-API-Key: ${MCP_API_KEY}"
```

### Modèles LLM Disponibles

```bash
# Lister modèles
docker-compose exec ollama ollama list

# Télécharger nouveau modèle
docker-compose exec ollama ollama pull mistral:latest

# Tester un modèle
docker-compose exec ollama ollama run llama3.1:8b "Écris un poème"
```

## 🚀 Optimisations Avancées

### Augmenter les Performances

**PHP OPcache :**
Déjà optimisé dans `docker/laravel/php.ini`

**Redis :**
```bash
# Augmenter maxmemory
docker-compose exec redis redis-cli CONFIG SET maxmemory 8gb
```

**PostgreSQL :**
Éditer `configs/postgres/postgresql.conf` pour tuning avancé

### Monitoring GPU Temps Réel

```bash
# Dans un terminal
watch -n 1 nvidia-smi

# Ou via Grafana dashboard GPU
```

## 📞 Support

### Logs

Tous les logs sont dans `/home/lalpha/4lb.ca/logs/`

### Rapporter un Problème

1. Collecter logs : `docker-compose logs > debug.log`
2. Collecter statut : `docker-compose ps > status.txt`
3. Copier fichier .env (sans secrets)
4. Créer un ticket avec ces informations

## 🎉 Conclusion

Votre infrastructure **4lb.ca** est maintenant opérationnelle !

**Prochaines étapes recommandées :**
1. ✅ Configurer DNS Cloudflare
2. ✅ Créer votre application Laravel
3. ✅ Configurer serveur email (DKIM, SPF, DMARC)
4. ✅ Personnaliser dashboards Grafana
5. ✅ Tester auto-amélioration IA
6. ✅ Configurer backups S3
7. ✅ Monitorer performances

---

**Fait avec ❤️ pour 4lb.ca**
Infrastructure auto-améliorante propulsée par Claude Sonnet 4
