#!/bin/bash

echo "================================================"
echo "  Configuration finale du démarrage automatique"
echo "================================================"
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. Mise à jour du service systemd
echo "1. Mise à jour du service systemd..."
cat > /tmp/4lbca-docker.service << 'SERVICE'
[Unit]
Description=4lb.ca Docker Compose Application Stack
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/lalpha/4lb.ca
Environment="COMPOSE_FILE=docker-compose.yml:docker-compose-override.yml"

# Nettoyer avant le démarrage
ExecStartPre=/usr/bin/docker compose down --remove-orphans

# Démarrer avec le fichier override
ExecStart=/usr/bin/docker compose -f docker-compose.yml -f docker-compose-override.yml up -d

# Vérifier que les services critiques sont lancés
ExecStartPost=/bin/bash -c 'sleep 15 && docker ps | grep -q "laravel" && docker ps | grep -q "traefik"'

# Arrêt propre
ExecStop=/usr/bin/docker compose down

TimeoutStartSec=600
User=lalpha
Group=lalpha

[Install]
WantedBy=multi-user.target
SERVICE

echo -e "${GREEN}✓${NC} Service systemd créé dans /tmp/4lbca-docker.service"
echo "   Pour l'installer : sudo cp /tmp/4lbca-docker.service /etc/systemd/system/"
echo ""

# 2. Créer un script de healthcheck
echo "2. Création du script de healthcheck..."
cat > /home/lalpha/4lb.ca/scripts/healthcheck.sh << 'HEALTH'
#!/bin/bash

# Script de vérification de santé pour 4lb.ca
# Retourne 0 si tout va bien, 1 sinon

ERRORS=0

# Vérifier les services critiques
for service in traefik laravel postgres redis; do
    if ! docker ps | grep -q "$service"; then
        echo "ERREUR: Service $service non trouvé"
        ERRORS=$((ERRORS + 1))
    fi
done

# Vérifier les URLs principales
if ! curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "http://localhost:80" | grep -q "200\|301\|302\|404"; then
    echo "ERREUR: Site principal non accessible"
    ERRORS=$((ERRORS + 1))
fi

if [ $ERRORS -eq 0 ]; then
    echo "✅ Tous les services sont opérationnels"
    exit 0
else
    echo "❌ $ERRORS erreur(s) détectée(s)"
    exit 1
fi
HEALTH
chmod +x /home/lalpha/4lb.ca/scripts/healthcheck.sh

echo -e "${GREEN}✓${NC} Script de healthcheck créé"
echo ""

# 3. Créer un crontab pour le monitoring
echo "3. Configuration du monitoring automatique..."
CRON_LINE="*/5 * * * * /home/lalpha/4lb.ca/scripts/healthcheck.sh || (cd /home/lalpha/4lb.ca && docker-compose restart)"
(crontab -l 2>/dev/null | grep -v "healthcheck.sh"; echo "$CRON_LINE") | crontab -

echo -e "${GREEN}✓${NC} Cron de monitoring configuré (toutes les 5 minutes)"
echo ""

# 4. Créer le script de démarrage final
echo "4. Création du script de démarrage principal..."
cat > /home/lalpha/4lb.ca/start.sh << 'START'
#!/bin/bash

echo "Démarrage de l'infrastructure 4lb.ca..."

# Se placer dans le bon répertoire
cd /home/lalpha/4lb.ca

# Utiliser docker-compose avec override
docker-compose -f docker-compose.yml -f docker-compose-override.yml up -d

# Attendre que tout démarre
sleep 20

# Vérifier l'état
./scripts/quick-check.sh

echo ""
echo "Pour voir les logs : docker-compose logs -f"
echo "Pour arrêter : docker-compose down"
START
chmod +x /home/lalpha/4lb.ca/start.sh

echo -e "${GREEN}✓${NC} Script de démarrage principal créé"
echo ""

# 5. Instructions finales
echo "================================================"
echo "         📋 INSTRUCTIONS FINALES"
echo "================================================"
echo ""
echo -e "${YELLOW}Pour terminer la configuration, exécutez :${NC}"
echo ""
echo "  1. sudo cp /tmp/4lbca-docker.service /etc/systemd/system/"
echo "  2. sudo systemctl daemon-reload"
echo "  3. sudo systemctl enable 4lbca-docker.service"
echo "  4. sudo systemctl disable nginx"
echo "  5. sudo systemctl mask nginx"
echo ""
echo -e "${YELLOW}Pour démarrer manuellement :${NC}"
echo "  cd /home/lalpha/4lb.ca && ./start.sh"
echo ""
echo -e "${YELLOW}Pour vérifier l'état :${NC}"
echo "  ./scripts/quick-check.sh"
echo ""
echo "================================================"
