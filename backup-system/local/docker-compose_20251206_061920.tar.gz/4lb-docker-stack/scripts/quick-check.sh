#!/bin/bash

echo "=== Vérification rapide 4LB.CA ==="
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. État des services système
echo "1. Services système:"
echo "--------------------"
echo -n "Docker: "
systemctl is-active docker >/dev/null 2>&1 && echo -e "${GREEN}✓ Actif${NC}" || echo -e "${RED}✗ Inactif${NC}"

echo -n "Nginx: "
systemctl is-active nginx >/dev/null 2>&1 && echo -e "${YELLOW}⚠ Actif (conflit potentiel)${NC}" || echo -e "${GREEN}✓ Inactif${NC}"

echo -n "4lbca-docker: "
systemctl is-active 4lbca-docker >/dev/null 2>&1 && echo -e "${GREEN}✓ Actif${NC}" || echo -e "${RED}✗ Inactif${NC}"

# 2. Ports utilisés
echo ""
echo "2. Ports critiques:"
echo "-------------------"
for port in 80 443 3000 8081 9090; do
    echo -n "Port $port: "
    if ss -tlnp 2>/dev/null | grep -q ":$port "; then
        service=$(ss -tlnp 2>/dev/null | grep ":$port " | awk '{print $NF}' | cut -d'"' -f2 | head -1)
        if [ -z "$service" ]; then
            service=$(docker ps --format "table {{.Names}}\t{{.Ports}}" | grep ":$port" | awk '{print $1}' | head -1)
        fi
        echo -e "${GREEN}Utilisé${NC} (par: ${service:-inconnu})"
    else
        echo -e "${RED}Libre${NC}"
    fi
done

# 3. Conteneurs Docker
echo ""
echo "3. Conteneurs Docker 4lb.ca:"
echo "-----------------------------"
running=$(docker ps --filter "label=com.docker.compose.project=4lbca" --format "{{.Names}}" | wc -l)
total=$(docker ps -a --filter "label=com.docker.compose.project=4lbca" --format "{{.Names}}" | wc -l)
echo "Actifs: $running / $total"

# Liste des conteneurs avec leur état
docker ps -a --filter "label=com.docker.compose.project=4lbca" --format "table {{.Names}}\t{{.Status}}" | while IFS=$'\t' read -r name status; do
    if [[ "$name" == "NAMES"* ]]; then
        continue
    fi
    if [[ "$status" == *"Up"* ]]; then
        echo -e "  ${GREEN}✓${NC} $name: $status"
    elif [[ "$status" == *"Restarting"* ]]; then
        echo -e "  ${YELLOW}⟳${NC} $name: $status"
    else
        echo -e "  ${RED}✗${NC} $name: $status"
    fi
done

# 4. URLs accessibles
echo ""
echo "4. Services web accessibles:"
echo "----------------------------"
urls=("http://localhost:80:Site principal" "http://localhost:8081:MCP Server" "http://localhost:3000:Grafana" "http://localhost:9090:Prometheus")

for url_info in "${urls[@]}"; do
    IFS=':' read -r proto host port name <<< "$url_info"
    url="$proto:$host:$port"
    echo -n "$name: "
    if curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 "$url" | grep -q "200\|301\|302\|401\|403"; then
        echo -e "${GREEN}✓ Accessible${NC}"
    else
        echo -e "${RED}✗ Non accessible${NC}"
    fi
done

echo ""
echo "==================================="
