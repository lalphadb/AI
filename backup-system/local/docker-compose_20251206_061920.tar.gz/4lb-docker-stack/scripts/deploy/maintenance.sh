#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Script de Maintenance - Infrastructure 4lb.ca
# Nettoyage, optimisation, et maintenance automatique
# ═══════════════════════════════════════════════════════════════

set -e

PROJECT_ROOT="/home/lalpha/4lb.ca"
cd "$PROJECT_ROOT"

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

LOG_FILE="$PROJECT_ROOT/logs/maintenance_$(date +%Y%m%d_%H%M%S).log"

# ────────────────────────────────────────────────────────────────
# Fonctions de logging
# ────────────────────────────────────────────────────────────────

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

# ────────────────────────────────────────────────────────────────
# Nettoyage Docker
# ────────────────────────────────────────────────────────────────

cleanup_docker() {
    log "═══════════════════════════════════════════════════════"
    log "🧹 NETTOYAGE DOCKER"
    log "═══════════════════════════════════════════════════════"
    
    # Containers arrêtés
    log_info "Suppression des containers arrêtés..."
    local stopped=$(docker ps -aq -f status=exited | wc -l)
    if [ "$stopped" -gt 0 ]; then
        docker container prune -f
        log "✓ $stopped containers arrêtés supprimés"
    else
        log "✓ Aucun container arrêté à supprimer"
    fi
    
    # Images non utilisées
    log_info "Suppression des images non utilisées..."
    docker image prune -a -f --filter "until=720h" # 30 jours
    
    # Volumes non utilisés
    log_info "Suppression des volumes non utilisés..."
    docker volume prune -f
    
    # Build cache
    log_info "Nettoyage du build cache..."
    docker builder prune -f --filter "until=168h" # 7 jours
    
    # Networks non utilisés
    log_info "Suppression des networks non utilisés..."
    docker network prune -f
    
    # Résumé espace libéré
    log "✓ Nettoyage Docker terminé"
    echo
}

# ────────────────────────────────────────────────────────────────
# Nettoyage Logs
# ────────────────────────────────────────────────────────────────

cleanup_logs() {
    log "═══════════════════════════════════════════════════════"
    log "📋 NETTOYAGE LOGS"
    log "═══════════════════════════════════════════════════════"
    
    # Logs Docker
    log_info "Rotation logs Docker..."
    truncate -s 0 /var/lib/docker/containers/*/*-json.log 2>/dev/null || true
    
    # Logs applicatifs > 30 jours
    log_info "Suppression logs > 30 jours..."
    find "$PROJECT_ROOT/logs" -type f -name "*.log" -mtime +30 -delete 2>/dev/null || true
    
    # Compression logs > 7 jours
    log_info "Compression logs > 7 jours..."
    find "$PROJECT_ROOT/logs" -type f -name "*.log" -mtime +7 ! -name "*.gz" -exec gzip {} \; 2>/dev/null || true
    
    log "✓ Nettoyage logs terminé"
    echo
}

# ────────────────────────────────────────────────────────────────
# Optimisation Base de Données
# ────────────────────────────────────────────────────────────────

optimize_database() {
    log "═══════════════════════════════════════════════════════"
    log "🗄️  OPTIMISATION BASE DE DONNÉES"
    log "═══════════════════════════════════════════════════════"
    
    # VACUUM PostgreSQL
    log_info "VACUUM PostgreSQL..."
    docker-compose exec -T postgres psql -U ${DB_USERNAME:-laravel} ${DB_DATABASE:-laravel} -c "VACUUM ANALYZE;" || log_warning "VACUUM échoué"
    
    # Statistiques
    log_info "Mise à jour des statistiques..."
    docker-compose exec -T postgres psql -U ${DB_USERNAME:-laravel} ${DB_DATABASE:-laravel} -c "ANALYZE;" || log_warning "ANALYZE échoué"
    
    # Taille DB
    local db_size=$(docker-compose exec -T postgres psql -U ${DB_USERNAME:-laravel} ${DB_DATABASE:-laravel} -t -c "SELECT pg_size_pretty(pg_database_size('${DB_DATABASE:-laravel}'));" | xargs)
    log "✓ Taille DB: $db_size"
    echo
}

# ────────────────────────────────────────────────────────────────
# Optimisation Redis
# ────────────────────────────────────────────────────────────────

optimize_redis() {
    log "═══════════════════════════════════════════════════════"
    log "⚡ OPTIMISATION REDIS"
    log "═══════════════════════════════════════════════════════"
    
    # Défragmentation
    log_info "Défragmentation mémoire Redis..."
    docker-compose exec -T redis redis-cli MEMORY PURGE || log_warning "Purge échoué"
    
    # Stats
    local keys=$(docker-compose exec -T redis redis-cli DBSIZE | awk '{print $2}')
    local memory=$(docker-compose exec -T redis redis-cli INFO memory | grep used_memory_human | cut -d: -f2 | tr -d '\r')
    
    log "✓ Clés: $keys"
    log "✓ Mémoire: $memory"
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérification Santé Services
# ────────────────────────────────────────────────────────────────

health_check() {
    log "═══════════════════════════════════════════════════════"
    log "🏥 VÉRIFICATION SANTÉ SERVICES"
    log "═══════════════════════════════════════════════════════"
    
    # Services critiques
    local critical_services=("postgres" "redis" "ollama" "traefik")
    
    for service in "${critical_services[@]}"; do
        if docker-compose ps "$service" | grep -q "Up"; then
            log "✓ $service: UP"
        else
            log_error "$service: DOWN - REDÉMARRAGE..."
            docker-compose restart "$service"
        fi
    done
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Mise à jour Images
# ────────────────────────────────────────────────────────────────

update_images() {
    log "═══════════════════════════════════════════════════════"
    log "🔄 MISE À JOUR IMAGES DOCKER"
    log "═══════════════════════════════════════════════════════"
    
    log_info "Pull des dernières images..."
    docker-compose pull
    
    log "✓ Images mises à jour"
    log_warning "⚠️  Redémarrer les services pour appliquer: docker-compose up -d"
    echo
}

# ────────────────────────────────────────────────────────────────
# Statistiques Système
# ────────────────────────────────────────────────────────────────

show_stats() {
    log "═══════════════════════════════════════════════════════"
    log "📊 STATISTIQUES SYSTÈME"
    log "═══════════════════════════════════════════════════════"
    
    # Disque
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}')
    log "Disque: $disk_usage utilisé"
    
    # RAM
    local ram_usage=$(free | awk '/^Mem:/{printf "%.0f%%", $3/$2 * 100}')
    log "RAM: $ram_usage utilisé"
    
    # CPU Load
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | xargs)
    log "CPU Load: $cpu_load"
    
    # Containers
    local containers=$(docker ps -q | wc -l)
    log "Containers actifs: $containers"
    
    # GPU
    if command -v nvidia-smi &> /dev/null; then
        local gpu_util=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader)
        local gpu_temp=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader)
        log "GPU: ${gpu_util} utilisation, ${gpu_temp}°C"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Backup Rapide
# ────────────────────────────────────────────────────────────────

quick_backup() {
    log "═══════════════════════════════════════════════════════"
    log "💾 BACKUP RAPIDE"
    log "═══════════════════════════════════════════════════════"
    
    # Lancer script backup
    if [ -f "$PROJECT_ROOT/scripts/backup/backup.sh" ]; then
        bash "$PROJECT_ROOT/scripts/backup/backup.sh"
    else
        log_warning "Script backup non trouvé"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Vérification Sécurité
# ────────────────────────────────────────────────────────────────

security_check() {
    log "═══════════════════════════════════════════════════════"
    log "🔒 VÉRIFICATION SÉCURITÉ"
    log "═══════════════════════════════════════════════════════"
    
    # Permissions .env
    if [ -f .env ]; then
        local env_perms=$(stat -c "%a" .env)
        if [ "$env_perms" != "600" ]; then
            log_warning ".env permissions: $env_perms (devrait être 600)"
            chmod 600 .env
            log "✓ Permissions .env corrigées"
        else
            log "✓ Permissions .env: OK"
        fi
    fi
    
    # Images vulnérables (si trivy installé)
    if command -v trivy &> /dev/null; then
        log_info "Scan vulnérabilités images..."
        trivy image --severity HIGH,CRITICAL $(docker-compose config | grep "image:" | awk '{print $2}' | sort -u) 2>/dev/null || log_warning "Trivy scan échoué"
    fi
    
    # UFW status
    if command -v ufw &> /dev/null; then
        local ufw_status=$(sudo ufw status | grep "Status:" | awk '{print $2}')
        log "Firewall UFW: $ufw_status"
    fi
    
    echo
}

# ────────────────────────────────────────────────────────────────
# Menu interactif
# ────────────────────────────────────────────────────────────────

show_menu() {
    echo
    echo "Options de maintenance:"
    echo "  1. docker          - Nettoyage Docker"
    echo "  2. logs            - Nettoyage logs"
    echo "  3. db              - Optimisation PostgreSQL"
    echo "  4. redis           - Optimisation Redis"
    echo "  5. health          - Vérification santé"
    echo "  6. update          - Mise à jour images"
    echo "  7. stats           - Statistiques système"
    echo "  8. backup          - Backup rapide"
    echo "  9. security        - Vérification sécurité"
    echo "  all                - Toutes les opérations"
    echo
}

# ────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────

main() {
    echo -e "${BLUE}"
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║         MAINTENANCE INFRASTRUCTURE 4LB.CA           ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    local action="${1:-all}"
    
    mkdir -p logs
    
    log "DÉBUT MAINTENANCE: $action"
    echo
    
    case "$action" in
        docker)
            cleanup_docker
            ;;
        logs)
            cleanup_logs
            ;;
        db|database)
            optimize_database
            ;;
        redis|cache)
            optimize_redis
            ;;
        health)
            health_check
            ;;
        update)
            update_images
            ;;
        stats)
            show_stats
            ;;
        backup)
            quick_backup
            ;;
        security)
            security_check
            ;;
        all)
            cleanup_docker
            cleanup_logs
            optimize_database
            optimize_redis
            health_check
            show_stats
            security_check
            ;;
        help|--help|-h)
            show_menu
            exit 0
            ;;
        *)
            log_error "Action inconnue: $action"
            show_menu
            exit 1
            ;;
    esac
    
    log "═══════════════════════════════════════════════════════"
    log "✅ MAINTENANCE TERMINÉE"
    log "═══════════════════════════════════════════════════════"
    log "Log complet: $LOG_FILE"
    echo
}

main "$@"
