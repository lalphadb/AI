#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Tests d'Intégration - Infrastructure 4lb.ca
# Valide tous les composants de l'infrastructure
# ═══════════════════════════════════════════════════════════════

set -e

PROJECT_ROOT="/home/lalpha/4lb.ca"
cd "$PROJECT_ROOT"

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Compteurs
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# ────────────────────────────────────────────────────────────────
# Fonctions
# ────────────────────────────────────────────────────────────────

run_test() {
    local test_name="$1"
    local test_command="$2"
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    
    echo -n "Testing $test_name... "
    
    if eval "$test_command" &>/dev/null; then
        echo -e "${GREEN}✓ PASS${NC}"
        PASSED_TESTS=$((PASSED_TESTS + 1))
        return 0
    else
        echo -e "${RED}✗ FAIL${NC}"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        return 1
    fi
}

print_section() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}\n"
}

# ────────────────────────────────────────────────────────────────
# Tests Infrastructure
# ────────────────────────────────────────────────────────────────

test_infrastructure() {
    print_section "🔧 TESTS INFRASTRUCTURE"
    
    run_test "Docker installed" "command -v docker"
    run_test "Docker Compose installed" "docker compose version"
    run_test "Docker daemon running" "docker info"
    run_test "Sufficient disk space (>50GB)" "[ \$(df -BG / | awk 'NR==2 {print \$4}' | sed 's/G//') -gt 50 ]"
    run_test "Sufficient RAM (>16GB)" "[ \$(free -g | awk '/^Mem:/{print \$2}') -gt 15 ]"
}

# ────────────────────────────────────────────────────────────────
# Tests GPU
# ────────────────────────────────────────────────────────────────

test_gpu() {
    print_section "🎮 TESTS GPU"
    
    run_test "NVIDIA driver installed" "command -v nvidia-smi"
    run_test "GPU detected" "nvidia-smi --query-gpu=name --format=csv,noheader"
    run_test "NVIDIA Docker runtime" "docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi"
}

# ────────────────────────────────────────────────────────────────
# Tests Services Docker
# ────────────────────────────────────────────────────────────────

test_docker_services() {
    print_section "🐳 TESTS SERVICES DOCKER"
    
    # Charger .env si existe
    if [ -f .env ]; then
        source .env
    fi
    
    # Services critiques
    local critical_services=(
        "traefik"
        "postgres"
        "redis"
        "ollama"
        "mcp-server"
        "prometheus"
        "grafana"
    )
    
    for service in "${critical_services[@]}"; do
        run_test "Service $service UP" "docker-compose ps $service | grep -q 'Up'"
    done
}

# ────────────────────────────────────────────────────────────────
# Tests Réseau & Connectivité
# ────────────────────────────────────────────────────────────────

test_network() {
    print_section "🌐 TESTS RÉSEAU"
    
    run_test "Internet connectivity" "ping -c 1 8.8.8.8"
    run_test "DNS resolution" "dig +short google.com @8.8.8.8"
    run_test "Port 80 listening" "netstat -tuln | grep -q ':80 '"
    run_test "Port 443 listening" "netstat -tuln | grep -q ':443 '"
}

# ────────────────────────────────────────────────────────────────
# Tests Endpoints API
# ────────────────────────────────────────────────────────────────

test_endpoints() {
    print_section "🔗 TESTS ENDPOINTS API"
    
    # Attendre que les services soient prêts
    sleep 2
    
    run_test "Ollama API" "curl -sf http://localhost:11434/api/tags"
    run_test "Prometheus API" "curl -sf http://localhost:9090/-/healthy"
    run_test "Grafana API" "curl -sf http://localhost:3000/api/health"
    
    # PostgreSQL
    run_test "PostgreSQL connection" "docker-compose exec -T postgres pg_isready -U \${DB_USERNAME:-laravel}"
    
    # Redis
    run_test "Redis connection" "docker-compose exec -T redis redis-cli ping | grep -q PONG"
}

# ────────────────────────────────────────────────────────────────
# Tests MCP Server
# ────────────────────────────────────────────────────────────────

test_mcp_server() {
    print_section "🤖 TESTS MCP SERVER"
    
    if [ -z "${MCP_API_KEY:-}" ]; then
        echo -e "${YELLOW}⚠ MCP_API_KEY non configuré, tests MCP skippés${NC}"
        return
    fi
    
    # Health check
    run_test "MCP health endpoint" "curl -sf http://localhost:8080/health"
    
    # Stats endpoint
    run_test "MCP stats endpoint" "curl -sf -H 'X-API-Key: ${MCP_API_KEY}' http://localhost:8080/api/stats"
    
    # Models endpoint
    run_test "MCP models endpoint" "curl -sf -H 'X-API-Key: ${MCP_API_KEY}' http://localhost:8080/api/models"
}

# ────────────────────────────────────────────────────────────────
# Tests Prometheus Metrics
# ────────────────────────────────────────────────────────────────

test_prometheus_metrics() {
    print_section "📊 TESTS MÉTRIQUES PROMETHEUS"
    
    run_test "Prometheus scraping targets" "curl -sf http://localhost:9090/api/v1/targets | jq -e '.data.activeTargets | length > 0'"
    run_test "Node exporter metrics" "curl -sf http://localhost:9090/api/v1/query?query=up | jq -e '.data.result | length > 0'"
    run_test "Container metrics" "curl -sf http://localhost:9090/api/v1/query?query=container_memory_usage_bytes | jq -e '.data.result | length > 0'"
    
    # GPU metrics si disponible
    if command -v nvidia-smi &> /dev/null; then
        run_test "GPU metrics" "curl -sf http://localhost:9090/api/v1/query?query=DCGM_FI_DEV_GPU_TEMP"
    fi
}

# ────────────────────────────────────────────────────────────────
# Tests Sécurité
# ────────────────────────────────────────────────────────────────

test_security() {
    print_section "🔒 TESTS SÉCURITÉ"
    
    run_test ".env file exists" "[ -f .env ]"
    run_test ".env permissions secure" "[ \$(stat -c '%a' .env) = '600' ]"
    run_test "docker-compose.yml exists" "[ -f docker-compose.yml ]"
    run_test "No .env in git" "! git ls-files --error-unmatch .env 2>/dev/null"
}

# ────────────────────────────────────────────────────────────────
# Tests Performance
# ────────────────────────────────────────────────────────────────

test_performance() {
    print_section "⚡ TESTS PERFORMANCE"
    
    # CPU Load
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    run_test "CPU load acceptable (<10)" "[ \$(echo \"$cpu_load < 10\" | bc) -eq 1 ]"
    
    # Memory usage
    local mem_percent=$(free | awk '/^Mem:/{printf "%.0f", $3/$2 * 100}')
    run_test "Memory usage acceptable (<90%)" "[ $mem_percent -lt 90 ]"
    
    # Disk usage
    local disk_percent=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    run_test "Disk usage acceptable (<80%)" "[ $disk_percent -lt 80 ]"
}

# ────────────────────────────────────────────────────────────────
# Tests Logs
# ────────────────────────────────────────────────────────────────

test_logs() {
    print_section "📋 TESTS LOGS"
    
    run_test "Logs directory exists" "[ -d logs ]"
    run_test "Logs writable" "[ -w logs ]"
    run_test "No critical errors in last hour" "! find logs -name '*.log' -mmin -60 -exec grep -i 'CRITICAL\\|FATAL' {} \\; 2>/dev/null | grep -q ."
}

# ────────────────────────────────────────────────────────────────
# Tests Backups
# ────────────────────────────────────────────────────────────────

test_backups() {
    print_section "💾 TESTS BACKUPS"
    
    run_test "Backup directory exists" "[ -d backups ]"
    run_test "Backup script exists" "[ -f scripts/backup/backup.sh ]"
    run_test "Backup script executable" "[ -x scripts/backup/backup.sh ]"
}

# ────────────────────────────────────────────────────────────────
# Résumé Final
# ────────────────────────────────────────────────────────────────

print_summary() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}RÉSUMÉ DES TESTS${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}\n"
    
    echo "Total tests: $TOTAL_TESTS"
    echo -e "${GREEN}Passed: $PASSED_TESTS${NC}"
    
    if [ $FAILED_TESTS -gt 0 ]; then
        echo -e "${RED}Failed: $FAILED_TESTS${NC}"
        echo -e "\n${RED}❌ TESTS ÉCHOUÉS - Veuillez corriger les erreurs${NC}\n"
        exit 1
    else
        echo -e "${RED}Failed: $FAILED_TESTS${NC}"
        echo -e "\n${GREEN}✅ TOUS LES TESTS RÉUSSIS !${NC}\n"
        exit 0
    fi
}

# ────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────

main() {
    clear
    
    echo -e "${BLUE}"
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║        TESTS INTÉGRATION - INFRASTRUCTURE 4LB.CA     ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
    
    # Exécuter tous les tests
    test_infrastructure
    test_gpu
    test_docker_services
    test_network
    test_endpoints
    test_mcp_server
    test_prometheus_metrics
    test_security
    test_performance
    test_logs
    test_backups
    
    # Afficher résumé
    print_summary
}

main "$@"
