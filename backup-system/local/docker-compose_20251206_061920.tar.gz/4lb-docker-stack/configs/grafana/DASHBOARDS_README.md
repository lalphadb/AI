# 📊 Dashboards Grafana Personnalisés - 4lb.ca

## 🎯 Dashboards Disponibles

### 1. **Vue d'ensemble Infrastructure** (`overview.json`)
**URL :** https://grafana.4lb.ca/d/overview

**Panneaux :**
- ✅ État des Services (Laravel, MCP, Ollama, PostgreSQL, Redis, etc.)
- 📊 Utilisation CPU Système
- 🧠 Utilisation Mémoire
- 🎮 Utilisation GPU
- 📋 Files d'attente MCP
- 🌐 Trafic Réseau
- 💾 Utilisation Disque

**Refresh :** 30 secondes

---

### 2. **GPU NVIDIA RTX 5070 Ti** (`gpu-nvidia.json`)
**URL :** https://grafana.4lb.ca/d/gpu-nvidia

**Panneaux :**
- 🎮 Utilisation GPU temps réel
- 🧠 Utilisation Mémoire GPU
- 🌡️ Température GPU
- ⚡ Fréquence GPU (SM Clock, Memory Clock)
- 💾 Utilisation VRAM
- 🔌 Puissance GPU (consommation)
- 📋 Informations GPU (nom, énergie)

**Refresh :** 10 secondes

---

### 3. **Services LLM - MCP & Ollama** (`llm-services.json`)
**URL :** https://grafana.4lb.ca/d/llm-services

**Panneaux :**
- ✅ État Services LLM
- 📋 Files d'attente MCP (taille, waiting, active)
- 👷 Workers MCP (actifs, disponibles, total)
- ⏱️ Temps de réponse MCP (95th, 50th percentile)
- 💻 Utilisation Ressources Ollama (CPU, RAM)
- 📊 Requêtes par Modèle
- ❌ Erreurs MCP
- 🎫 Tokens Générés

**Refresh :** 15 secondes

---

### 4. **Métriques Système Détaillées** (`system-metrics.json`)
**URL :** https://grafana.4lb.ca/d/system-metrics

**Panneaux :**
- ⚙️ Utilisation CPU par Cœur
- 📈 Charge Système (1min, 5min, 15min)
- 🧠 Utilisation Mémoire Détaillée (Used, Buffers, Cached)
- 🔄 Swap Utilisation
- 💾 Espace Disque (taille, disponible, % utilisé)
- 💿 I/O Disque (read/write rates)
- 🌐 Trafic Réseau Détaillé (bytes + packets)
- 🔗 Connexions Réseau (TCP established, active opens)

**Refresh :** 30 secondes

---

### 5. **Auto-Optimisation IA** (`ai-optimization.json`)
**URL :** https://grafana.4lb.ca/d/ai-optimization

**Panneaux :**
- 🤖 État Agent Optimizer
- 📊 Analyses Effectuées (total, suggestions appliquées)
- 🎯 Score d'Optimisation (gauge 0-100)
- ⏱️ Temps d'Analyse Moyen
- ⚡ Actions d'Optimisation (tableau)
- 📈 Métriques Système Monitorées (CPU, RAM, GPU)
- 🚀 Performance des Services (response times, queues)
- 📝 Logs d'Optimisation

**Refresh :** 5 minutes

---

### 6. **Logs Centralisés - Loki** (`logs-loki.json`)
**URL :** https://grafana.4lb.ca/d/logs-loki

**Panneaux :**
- 🐘 Logs Laravel Application
- 🔧 Logs MCP Server
- 🤖 Logs AI Optimizer
- 🧠 Logs Ollama
- ❌ Erreurs Système (tous les services)
- 🌐 Requêtes API
- 🎮 Activités GPU

**Refresh :** 10 secondes

## 🔧 Configuration

### Accès Grafana
```
URL : https://grafana.4lb.ca
Utilisateur : admin
Mot de passe : ${GRAFANA_PASSWORD} (défini dans .env)
```

### Métriques Utilisées

**Prometheus :**
- `up{job="..."}` - État des services
- `node_*` - Métriques système
- `DCGM_*` - Métriques GPU NVIDIA
- `mcp_*` - Métriques MCP Server
- `ai_optimizer_*` - Métriques agent IA
- `container_*` - Métriques Docker

**Loki :**
- `{job="laravel"}` - Logs Laravel
- `{job="mcp-server"}` - Logs MCP
- `{job="optimizer"}` - Logs AI Optimizer
- `{job="ollama"}` - Logs Ollama

## 🎨 Personnalisation

### Modifier un Dashboard
1. Aller dans Grafana → Dashboard → Settings
2. Modifier les panels existants
3. Ajouter de nouveaux panels avec les métriques disponibles
4. Sauvegarder → "Save dashboard"

### Ajouter un Nouveau Dashboard
1. Créer un fichier JSON dans `configs/grafana/dashboards/`
2. Redémarrer Grafana : `docker-compose restart grafana`
3. Le dashboard apparaît automatiquement dans Grafana

### Variables Template
Vous pouvez ajouter des variables template pour filtrer par :
- Service (`$service`)
- Instance (`$instance`)
- GPU (`$gpu`)
- Modèle LLM (`$model`)

## 📈 Optimisations Recommandées

### Alertes Grafana
Créer des alertes pour :
- Service DOWN
- CPU > 90%
- RAM > 95%
- GPU température > 80°C
- Queue MCP > 100

### Variables d'Environnement
```bash
# Dans .env
GRAFANA_ALERT_EMAIL=admin@4lb.ca
GRAFANA_SMTP_HOST=mail.4lb.ca
```

### Dashboards Supplémentaires Suggérés
- **Performance Laravel** : Requêtes HTTP, temps de réponse, erreurs PHP
- **Base de Données** : Connexions PostgreSQL, requêtes lentes, cache hit ratio
- **Sécurité** : Tentatives de connexion, firewall blocks, SSL certificates
- **Business Metrics** : Utilisation API, modèles populaires, satisfaction utilisateur

---

**🚀 Prêt à monitorer votre infrastructure IA !**