# 🚀 Guide Complet 4lb.ca

## 1️⃣ Démarrage Automatique au Boot

### Créer le service systemd

Créez le fichier de service :

```bash
sudo nano /etc/systemd/system/4lbca-docker.service
```

Copiez ce contenu :

```ini
[Unit]
Description=4lb.ca Docker Compose Stack
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/lalpha/4lb.ca
ExecStartPre=/usr/bin/docker compose down
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=300
User=lalpha
Group=lalpha

[Install]
WantedBy=multi-user.target
```

### Activer le service

```bash
# Recharger systemd
sudo systemctl daemon-reload

# Activer au démarrage
sudo systemctl enable 4lbca-docker.service

# Démarrer maintenant
sudo systemctl start 4lbca-docker.service

# Vérifier le statut
sudo systemctl status 4lbca-docker.service
```

### Commandes utiles

```bash
# Redémarrer tous les services
sudo systemctl restart 4lbca-docker.service

# Arrêter tous les services
sudo systemctl stop 4lbca-docker.service

# Voir les logs
sudo journalctl -u 4lbca-docker.service -f
```

---

## 2️⃣ Utiliser vos LLM (Large Language Models)

### 🔧 Services LLM disponibles

Vous avez **Ollama** qui tourne sur votre serveur !

#### A) Accès local (depuis le serveur)

```bash
# Lister les modèles installés
docker exec ollama ollama list

# Télécharger un nouveau modèle
docker exec ollama ollama pull llama3.2
docker exec ollama ollama pull mistral
docker exec ollama ollama pull codellama

# Utiliser un modèle en ligne de commande
docker exec -it ollama ollama run llama3.2
```

#### B) Accès via API (depuis n'importe où)

**URL de l'API :** `http://10.10.10.46:11434` (local) ou `http://4lb.ca:11434` (externe si port forwarding configuré)

**Exemple avec curl :**

```bash
# Générer du texte
curl http://10.10.10.46:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Pourquoi le ciel est bleu?",
  "stream": false
}'

# Chat interactif
curl http://10.10.10.46:11434/api/chat -d '{
  "model": "llama3.2",
  "messages": [
    {
      "role": "user",
      "content": "Écris-moi un poème sur l'automne"
    }
  ],
  "stream": false
}'
```

**Exemple avec Python :**

```python
import requests
import json

def ask_llm(question):
    url = "http://10.10.10.46:11434/api/generate"
    payload = {
        "model": "llama3.2",
        "prompt": question,
        "stream": False
    }
    
    response = requests.post(url, json=payload)
    return response.json()['response']

# Utilisation
answer = ask_llm("Explique-moi la photosynthèse en 3 phrases")
print(answer)
```

**Exemple avec JavaScript/Node.js :**

```javascript
const axios = require('axios');

async function askLLM(question) {
    const response = await axios.post('http://10.10.10.46:11434/api/generate', {
        model: 'llama3.2',
        prompt: question,
        stream: false
    });
    
    return response.data.response;
}

// Utilisation
askLLM("Qu'est-ce que Docker?").then(console.log);
```

#### C) Interface Web

Votre **MCP Server** (Model Control Plane) est accessible à :
- **Local :** http://10.10.10.46:8081
- **Externe :** https://ai.4lb.ca

C'est une interface graphique pour interagir avec vos LLM !

---

## 3️⃣ Exécuter Plusieurs Tâches en Parallèle

### Option 1 : Docker Compose Scale (Recommandé)

```bash
# Scaler un service à 5 instances
cd /home/lalpha/4lb.ca
docker compose up -d --scale laravel-worker=5

# Voir les workers actifs
docker ps | grep worker
```

### Option 2 : Créer des workers personnalisés

Modifiez votre `docker-compose.yml` :

```yaml
services:
  # Worker 1 - Tâches lourdes
  worker-heavy:
    image: 4lbca-laravel-worker
    container_name: worker-heavy
    environment:
      - QUEUE_CONNECTION=redis
      - REDIS_QUEUE=heavy
    restart: unless-stopped

  # Worker 2 - Tâches rapides
  worker-fast:
    image: 4lbca-laravel-worker
    container_name: worker-fast
    environment:
      - QUEUE_CONNECTION=redis
      - REDIS_QUEUE=fast
    restart: unless-stopped

  # Worker 3 - Emails
  worker-mail:
    image: 4lbca-laravel-worker
    container_name: worker-mail
    environment:
      - QUEUE_CONNECTION=redis
      - REDIS_QUEUE=mail
    restart: unless-stopped
```

### Option 3 : GNU Parallel (pour scripts bash)

```bash
# Installer GNU Parallel
sudo apt install parallel

# Exemple : Traiter 10 fichiers en parallèle (4 à la fois)
parallel -j 4 process_file {} ::: file1.txt file2.txt file3.txt ... file10.txt

# Exemple : Exécuter des commandes en parallèle
parallel -j 8 ::: \
    "curl http://api1.example.com" \
    "curl http://api2.example.com" \
    "python script1.py" \
    "python script2.py"
```

### Option 4 : Python multiprocessing

```python
from multiprocessing import Pool
import time

def process_task(task_id):
    # Votre tâche ici
    time.sleep(2)
    return f"Task {task_id} completed"

if __name__ == '__main__':
    # Créer un pool de 8 workers
    with Pool(8) as pool:
        results = pool.map(process_task, range(100))
    
    print(f"Completed {len(results)} tasks")
```

### Option 5 : Laravel Queue Workers

Dans Laravel, ajoutez des jobs à différentes queues :

```php
// Tâche lourde
ProcessVideoJob::dispatch($video)->onQueue('heavy');

// Tâche rapide
SendNotificationJob::dispatch($user)->onQueue('fast');

// Email
SendEmailJob::dispatch($email)->onQueue('mail');
```

Puis démarrez des workers pour chaque queue :

```bash
# Worker pour queue heavy
php artisan queue:work redis --queue=heavy --tries=3 &

# Worker pour queue fast
php artisan queue:work redis --queue=fast --tries=1 &

# Worker pour queue mail
php artisan queue:work redis --queue=mail --tries=3 &
```

---

## 📊 Monitoring des Tâches Parallèles

### Voir les workers actifs

```bash
# Tous les conteneurs
docker ps

# Workers spécifiques
docker ps | grep worker

# Statistiques en temps réel
docker stats

# Logs d'un worker
docker logs -f worker-heavy
```

### Redis Queue Monitor

```bash
# Se connecter à Redis
docker exec -it redis redis-cli

# Voir les queues
KEYS queue:*

# Voir le nombre de jobs dans une queue
LLEN queue:heavy
LLEN queue:fast

# Voir les jobs en cours
SMEMBERS queue:heavy:reserved
```

### Prometheus/Grafana

Vos dashboards Grafana montrent :
- Nombre de workers actifs
- Temps de traitement moyen
- Nombre de jobs en attente
- Taux d'erreur

Accès : https://grafana.4lb.ca

---

## 🔧 Corriger les Problèmes Actuels

### Problème 1 : Laravel (supervisord logs)

```bash
# Créer le dossier manquant
docker exec laravel mkdir -p /var/log/supervisor

# Redémarrer
docker restart laravel
```

### Problème 2 : Loki (config schema)

```bash
# Éditer la config Loki
nano /home/lalpha/4lb.ca/configs/loki/loki.yaml

# Ajouter dans la section limits_config:
limits_config:
  allow_structured_metadata: false

# Redémarrer Loki
docker restart loki
```

---

## 🎯 Résumé des URLs

| Service | URL Locale | URL Externe |
|---------|------------|-------------|
| **Site principal** | http://10.10.10.46 | https://4lb.ca |
| **Grafana** | http://10.10.10.46:3000 | https://grafana.4lb.ca |
| **Prometheus** | http://10.10.10.46:9090 | https://prometheus.4lb.ca |
| **Traefik** | http://10.10.10.46:8080 | https://traefik.4lb.ca |
| **Ollama API** | http://10.10.10.46:11434 | - |
| **MCP Server** | http://10.10.10.46:8081 | https://ai.4lb.ca |

---

## 📚 Commandes Essentielles

```bash
# Démarrer tous les services
cd /home/lalpha/4lb.ca && docker compose up -d

# Arrêter tous les services
docker compose down

# Voir les logs en temps réel
docker compose logs -f

# Redémarrer un service spécifique
docker compose restart ollama

# Reconstruire et redémarrer
docker compose up -d --build

# Nettoyer (attention : supprime les volumes)
docker compose down -v
```
